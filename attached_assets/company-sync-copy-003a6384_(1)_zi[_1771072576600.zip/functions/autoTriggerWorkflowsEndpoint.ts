import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

// 🔄 WORKFLOW AUTOMATION HTTP ENDPOINT
// Call this endpoint via external cron service every 1-5 minutes to process scheduled workflows
// URL: https://your-project.deno.dev/autoTriggerWorkflowsEndpoint

Deno.serve(async (req) => {
  try {
    // 🔐 Validate CRON_SECRET_TOKEN
    const authToken = Deno.env.get('CRON_SECRET_TOKEN');
    let processedReq = req;
    
    if (authToken) {
      const requestToken = req.headers.get('Authorization')?.replace('Bearer ', '');
      if (requestToken !== authToken) {
        return Response.json({ error: 'Unauthorized - Invalid token' }, { status: 401 });
      }
      // Remove Authorization header so createClientFromRequest doesn't try to parse it as a user token
      const headers = new Headers(req.headers);
      headers.delete('Authorization');
      processedReq = new Request(req.url, { headers, body: req.body, method: req.method });
    }

    console.log('🔄 [HTTP ENDPOINT] Starting workflow automation check...');
    // Create a base44 client with service role (no user auth needed for cron)
    const base44 = createClientFromRequest(processedReq);

    // Get all pending/active workflow executions that are ready to run
    const now = new Date();
    const allExecutions = await base44.asServiceRole.entities.WorkflowExecution.list('-created_date', 1000);
    
    // Filter for active OR pending status (both need to be processed)
    const pendingExecutions = allExecutions.filter(exec => 
      exec.status === 'pending' || exec.status === 'active'
    );

    console.log(`✅ Found ${pendingExecutions.length} pending workflow executions`);

    // 🔥 FIX: Use next_action_time instead of scheduled_at
    const readyToExecute = pendingExecutions.filter(exec => {
      // If no next_action_time, it's ready
      if (!exec.next_action_time) {
        console.log(`  ✅ Execution ${exec.id} ready (no next_action_time)`);
        return true;
      }

      const isReady = new Date(exec.next_action_time) <= now;
      console.log(`  ${isReady ? '✅' : '⏰'} Execution ${exec.id}: next_action_time=${exec.next_action_time}, ready=${isReady}`);
      return isReady;
    });

    console.log(`✅ ${readyToExecute.length} executions ready to run (out of ${pendingExecutions.length} pending/active)`);

    const results = [];

    for (const execution of readyToExecute) {
      try {
        console.log(`🔄 Executing workflow: ${execution.workflow_id}, step: ${execution.current_step}`);

        // Get the workflow
        const workflows = await base44.asServiceRole.entities.Workflow.filter({
          id: execution.workflow_id
        });

        if (workflows.length === 0) {
          console.error(`❌ Workflow not found: ${execution.workflow_id}`);
          await base44.asServiceRole.entities.WorkflowExecution.update(execution.id, {
            status: 'failed',
            error_message: 'Workflow not found'
          });
          results.push({
            execution_id: execution.id,
            success: false,
            error: 'Workflow not found'
          });
          continue;
        }

        const workflow = workflows[0];

        if (!workflow.is_active) {
          console.log(`⏸️ Workflow ${workflow.id} is not active, skipping`);
          await base44.asServiceRole.entities.WorkflowExecution.update(execution.id, {
            status: 'cancelled',
            error_message: 'Workflow is not active'
          });
          results.push({
            execution_id: execution.id,
            success: false,
            error: 'Workflow not active'
          });
          continue;
        }

        // Get the current action to execute
        const actions = workflow.actions || [];
        const currentAction = actions.find(a => a.step === execution.current_step);

        if (!currentAction) {
          console.log(`✅ No more steps, marking as completed`);
          await base44.asServiceRole.entities.WorkflowExecution.update(execution.id, {
            status: 'completed',
            completed_at: new Date().toISOString()
          });
          results.push({
            execution_id: execution.id,
            success: true,
            message: 'Workflow completed'
          });
          continue;
        }

        // Execute the action
        console.log(`🔄 Executing action: ${currentAction.action_type}`);

        if (currentAction.action_type === 'send_email') {
          // Send email
          const recipient = execution.entity_data?.customer_email || execution.entity_data?.email;
          if (recipient) {
            try {
              await base44.asServiceRole.integrations.Core.SendEmail({
                to: recipient,
                subject: currentAction.email_subject || 'Notification',
                body: currentAction.email_body || ''
              });
              console.log(`✅ Email sent to ${recipient}`);
            } catch (emailError) {
              console.error(`❌ Failed to send email:`, emailError);
            }
          }
        } else if (currentAction.action_type === 'send_sms') {
          // Send SMS (if Twilio is configured)
          const phone = execution.entity_data?.customer_phone || execution.entity_data?.phone;
          if (phone) {
            console.log(`📱 Would send SMS to ${phone}: ${currentAction.sms_message}`);
            // Implement SMS sending here if needed
          }
        } else if (currentAction.action_type === 'create_task') {
          // Create task
          try {
            await base44.asServiceRole.entities.Task.create({
              company_id: execution.company_id,
              name: currentAction.task_title || 'Follow-up Task',
              description: currentAction.task_description || '',
              status: 'not_started',
              source: 'workflow',
              related_to: execution.entity_data?.customer_name || execution.entity_data?.name
            });
            console.log(`✅ Task created`);
          } catch (taskError) {
            console.error(`❌ Failed to create task:`, taskError);
          }
        }

        // Calculate next execution time
        const nextStep = execution.current_step + 1;
        const nextAction = actions.find(a => a.step === nextStep);

        if (nextAction) {
          let nextScheduledAt = null;

          if (nextAction.schedule_type === 'delay' && nextAction.delay_minutes) {
            nextScheduledAt = new Date(Date.now() + nextAction.delay_minutes * 60000);
          }

          await base44.asServiceRole.entities.WorkflowExecution.update(execution.id, {
            current_step: nextStep,
            next_action_time: nextScheduledAt ? nextScheduledAt.toISOString() : null,
            status: 'active'
          });

          console.log(`✅ Moved to step ${nextStep}, next run: ${nextScheduledAt?.toISOString() || 'immediate'}`);
        } else {
          await base44.asServiceRole.entities.WorkflowExecution.update(execution.id, {
            status: 'completed',
            completed_at: new Date().toISOString()
          });
          console.log(`✅ Workflow execution completed`);
        }

        results.push({
          execution_id: execution.id,
          success: true,
          step_executed: execution.current_step
        });

      } catch (execError) {
        console.error(`❌ Error executing workflow ${execution.id}:`, execError);
        await base44.asServiceRole.entities.WorkflowExecution.update(execution.id, {
          status: 'failed',
          error_message: execError.message
        });
        results.push({
          execution_id: execution.id,
          success: false,
          error: execError.message
        });
      }
    }

    console.log('✅ Workflow automation check completed');

    return Response.json({
      success: true,
      message: 'Workflow automation check completed',
      timestamp: new Date().toISOString(),
      results,
      summary: {
        total_pending: pendingExecutions.length,
        executed: readyToExecute.length,
        successful: results.filter(r => r.success).length,
        failed: results.filter(r => !r.success).length
      }
    });

  } catch (error) {
    console.error('❌ Workflow automation error:', error);
    return Response.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
});