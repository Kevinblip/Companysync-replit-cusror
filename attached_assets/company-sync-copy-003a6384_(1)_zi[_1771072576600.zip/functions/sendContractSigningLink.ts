import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    let sessionId;
    
    // Handle both JSON body and form data
    const contentType = req.headers.get('content-type') || '';
    
    if (contentType.includes('application/json')) {
      const body = await req.json();
      console.log('📦 JSON body:', body);
      sessionId = body.sessionId;
    } else {
      const text = await req.text();
      console.log('📦 Text body:', text);
      try {
        const body = JSON.parse(text);
        sessionId = body.sessionId;
      } catch {
        return Response.json({ 
          success: false, 
          error: 'Invalid request format' 
        }, { status: 400 });
      }
    }

    if (!sessionId) {
      return Response.json({ 
        success: false, 
        error: 'sessionId required' 
      }, { status: 400 });
    }

    console.log('📧 Starting sendContractSigningLink for session:', sessionId);

    // Create Base44 client from request with service role access
    const base44 = createClientFromRequest(req);
    
    // Verify user is authenticated
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ 
        success: false, 
        error: 'Unauthorized' 
      }, { status: 401 });
    }

    // Get signing session using service role
    const sessions = await base44.asServiceRole.entities.ContractSigningSession.filter({ id: sessionId });
    const session = sessions[0];
    
    if (!session) {
      console.error('❌ Session not found');
      return Response.json({ 
        success: false, 
        error: 'Session not found' 
      }, { status: 404 });
    }

    console.log('✅ Session found:', session.contract_name);

    // Generate unique signing token
    const signingToken = crypto.randomUUID();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    console.log('🔑 Generated signing token:', signingToken);

    // Update session using service role
    await base44.asServiceRole.entities.ContractSigningSession.update(sessionId, {
      signing_token: signingToken,
      expires_at: expiresAt.toISOString(),
      status: 'sent_to_customer',
      sent_to_customer_at: new Date().toISOString()
    });

    console.log('✅ Session updated');

    // Get app URL - use the full Base44 app URL
    const signingLink = `https://ai-crm-pro-10afd77e.base44.app/sign-contract-customer?token=${signingToken}`;

    console.log('🔗 Signing link:', signingLink);

    // Get company info
    let company = null;
    if (session.company_id) {
      try {
        const companies = await base44.asServiceRole.entities.Company.filter({ id: session.company_id });
        company = companies[0];
      } catch (err) {
        console.log('⚠️ Could not load company:', err.message);
      }
    }

    // Send via chosen method
    if (session.delivery_method === 'sms') {
      console.log('📱 Sending SMS via centralized sendSMS function');
      
      if (!session.customer_phone) {
        return Response.json({ 
          success: false, 
          error: 'Customer phone required for SMS' 
        }, { status: 400 });
      }

      const smsMessage = `${session.rep_name || 'Your rep'} sent you a contract to sign: ${session.template_name}\n\nSign here: ${signingLink}\n\nExpires: ${new Date(expiresAt).toLocaleDateString()}`;

      try {
        // Use the centralized sendSMS function which handles formatting correctly
        const smsResponse = await base44.asServiceRole.functions.invoke('sendSMS', {
          to: session.customer_phone,
          message: smsMessage,
          contactName: session.customer_name,
          companyId: session.company_id
        });

        console.log('✅ SMS sent via sendSMS function:', smsResponse);

        if (!smsResponse.data?.success) {
          throw new Error(smsResponse.data?.error || 'SMS failed');
        }

      } catch (smsError) {
        console.error('❌ SMS failed:', smsError);
        return Response.json({ 
          success: false, 
          error: 'SMS failed: ' + (smsError.message || 'Unknown error')
        }, { status: 500 });
      }

    } else {
      // Send Email using Base44's Core.SendEmail integration
      console.log('📧 Sending email using Core.SendEmail');
      
      if (!session.customer_email) {
        return Response.json({ 
          success: false, 
          error: 'Customer email required' 
        }, { status: 400 });
      }

      const emailBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
    ${company?.logo_url ? `<img src="${company.logo_url}" alt="${company.company_name}" style="max-width: 150px; margin-bottom: 20px;">` : ''}
    <h1 style="color: white; margin: 0; font-size: 28px;">📝 Contract Ready for Your Signature</h1>
  </div>
  
  <div style="background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px;">
    <p style="font-size: 16px; margin-bottom: 20px;">Hello <strong>${session.customer_name}</strong>,</p>
    
    <p style="font-size: 16px; margin-bottom: 20px;">
      ${session.rep_name} has sent you a contract for electronic signature.
    </p>
    
    <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea;">
      <p style="margin: 5px 0;"><strong>Contract:</strong> ${session.template_name}</p>
      <p style="margin: 5px 0;"><strong>Job:</strong> ${session.contract_name}</p>
      <p style="margin: 5px 0;"><strong>Expires:</strong> ${new Date(expiresAt).toLocaleDateString()}</p>
    </div>
    
    <p style="text-align: center; margin: 30px 0;">
      <a href="${signingLink}" 
         style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; 
                font-size: 18px; font-weight: bold; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);">
        📝 Review & Sign Contract
      </a>
    </p>
    
    <p style="font-size: 14px; color: #666; margin-top: 30px;">
      This link expires on <strong>${new Date(expiresAt).toLocaleDateString()}</strong>. 
      If you have any questions, please contact ${session.rep_name}.
    </p>
    
    <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 8px; margin-top: 20px;">
      <p style="margin: 0; font-size: 14px; color: #856404;">
        <strong>⚠️ Security Note:</strong> This is a secure signing link. Please do not forward this email to others.
      </p>
    </div>
    
    ${company?.company_name ? `
    <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
      <p style="color: #999; font-size: 12px; margin: 5px 0;">${company.company_name}</p>
      ${company.phone ? `<p style="color: #999; font-size: 12px; margin: 5px 0;">📞 ${company.phone}</p>` : ''}
      ${company.email ? `<p style="color: #999; font-size: 12px; margin: 5px 0;">📧 ${company.email}</p>` : ''}
    </div>
    ` : ''}
  </div>
</body>
</html>
      `;

      try {
        const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
        
        if (!RESEND_API_KEY) {
          console.error('❌ RESEND_API_KEY not configured');
          return Response.json({ 
            success: false, 
            error: 'Email system not configured' 
          }, { status: 500 });
        }

        const fromName = company?.company_name || 'Contract Signing';
        
        const resendResponse = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${RESEND_API_KEY}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            from: `${fromName} <noreply@mycrewcam.com>`,
            to: [session.customer_email],
            subject: `📝 Contract Ready: ${session.template_name} - ${session.contract_name}`,
            html: emailBody
          })
        });

        const resendData = await resendResponse.json();
        
        if (!resendResponse.ok) {
          console.error('❌ Resend API error:', resendData);
          return Response.json({ 
            success: false, 
            error: 'Email failed: ' + (resendData.message || 'Unknown error')
          }, { status: 500 });
        }

        console.log('✅ Email sent successfully via Resend');

      } catch (emailError) {
        console.error('❌ Email error:', emailError);
        return Response.json({ 
          success: false, 
          error: 'Email failed: ' + emailError.message 
        }, { status: 500 });
      }
    }

    console.log('✅✅✅ Completed successfully!');

    return Response.json({
      success: true,
      signing_link: signingLink,
      expires_at: expiresAt.toISOString(),
      delivery_method: session.delivery_method,
      message: session.delivery_method === 'sms' 
        ? `SMS sent to ${session.customer_phone}` 
        : `Email sent to ${session.customer_email}`
    });

  } catch (error) {
    console.error('💥 ERROR:', error);
    return Response.json({
      success: false,
      error: error.message || 'Unknown error'
    }, { status: 500 });
  }
});