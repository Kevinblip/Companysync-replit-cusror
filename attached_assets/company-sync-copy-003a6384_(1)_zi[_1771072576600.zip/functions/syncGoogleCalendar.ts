import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const getAccessToken = async (user, base44) => {
    console.log('🔑 Getting access token...');
    
    // 1. Try App Connector (Primary)
    try {
        const appToken = await base44.asServiceRole.connectors.getAccessToken("googlecalendar");
        if (appToken) {
            console.log('✅ Using App Connector Access Token');
            return appToken;
        }
    } catch (e) {
        console.log('⚠️ App Connector token not available:', e.message);
    }

    // 2. Fallback to User Token (Legacy)
    const GOOGLE_CLIENT_ID = Deno.env.get('GOOGLE_CLIENT_ID') || Deno.env.get('Google_Client_Id');
    const GOOGLE_CLIENT_SECRET = Deno.env.get('GOOGLE_CLIENT_SECRET') || Deno.env.get('Google_Secret_Key');

    // If token is still valid, return it
    if (user.google_token_expiry && new Date(user.google_token_expiry) > new Date()) {
        console.log('✅ User token still valid, reusing');
        return user.google_access_token;
    }

    if (user.google_refresh_token && GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET) {
        console.log('⏰ User token expired, refreshing...');

        const response = await fetch('https://oauth2.googleapis.com/token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                client_id: GOOGLE_CLIENT_ID,
                client_secret: GOOGLE_CLIENT_SECRET,
                refresh_token: user.google_refresh_token,
                grant_type: 'refresh_token',
            }),
        });

        if (!response.ok) {
            const errorData = await response.text();
            console.error('❌ Token refresh failed:', errorData);
            throw new Error('Failed to refresh Google access token: ' + errorData);
        }

        const tokens = await response.json();
        console.log('✅ New user token received');
        
        const expiryDate = new Date(new Date().getTime() + tokens.expires_in * 1000).toISOString();

        await base44.asServiceRole.entities.User.update(user.id, {
            google_access_token: tokens.access_token,
            google_token_expiry: expiryDate,
        });

        return tokens.access_token;
    }

    throw new Error('No valid Google Calendar connection found.');
};

Deno.serve(async (req) => {
    console.log('📅 ========== GOOGLE CALENDAR SYNC STARTED ==========');
    
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            console.error('❌ No user authenticated');
            return Response.json({ success: false, error: 'Unauthorized' }, { status: 401 });
        }

        console.log('👤 User:', user.email);

        console.log('🔑 Getting access token...');
        let accessToken;
        try {
            accessToken = await getAccessToken(user, base44);
        } catch (e) {
            console.error('❌ Auth error:', e.message);
            return Response.json({ 
                success: false, 
                error: 'Authentication failed. Please check your Google Calendar connection.',
                details: e.message
            }, { status: 401 });
        }
        
        console.log('✅ Access token obtained');

        // --- 1. Sync from Google to CRM ---
        console.log('\n📥 SYNCING FROM GOOGLE TO CRM...');
        
        const timeMin = new Date();
        timeMin.setDate(timeMin.getDate() - 30); // Look back 30 days
        const timeMinISO = timeMin.toISOString();
        
        const googleEventsResponse = await fetch(
            `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${timeMinISO}&singleEvents=true&orderBy=startTime`,
            {
                headers: { 'Authorization': `Bearer ${accessToken}` },
            }
        );

        if (!googleEventsResponse.ok) {
            const errorText = await googleEventsResponse.text();
            console.error('❌ Google Calendar API Error:', errorText);
            throw new Error('Failed to fetch Google Calendar events: ' + errorText);
        }

        const googleEventsData = await googleEventsResponse.json();
        console.log('📊 Google events found:', googleEventsData.items?.length || 0);
        
        const crmEvents = await base44.entities.CalendarEvent.list("-start_time", 2000);
        console.log('📊 CRM events found:', crmEvents.length);
        
        let createdInCrm = 0;
        let updatedInCrm = 0;

        for (const gEvent of googleEventsData.items || []) {
            if (!gEvent.start?.dateTime) continue; // Skip all-day events without time for now

            const existingCrmEvent = crmEvents.find(e => e.google_event_id === gEvent.id);

            const eventData = {
                title: gEvent.summary || 'Untitled Event',
                description: gEvent.description || '',
                start_time: gEvent.start.dateTime,
                end_time: gEvent.end?.dateTime || gEvent.start.dateTime,
                location: gEvent.location || '',
                attendees: gEvent.attendees ? gEvent.attendees.map(a => a.email) : [],
                google_event_id: gEvent.id,
                google_calendar_id: 'primary',
                company_id: user.company_id || crmEvents[0]?.company_id // Fallback to existing company ID context if needed
            };

            if (existingCrmEvent) {
                const lastUpdatedCrm = new Date(existingCrmEvent.updated_date).getTime();
                const lastUpdatedGoogle = new Date(gEvent.updated).getTime();

                if (lastUpdatedGoogle > lastUpdatedCrm) {
                    await base44.entities.CalendarEvent.update(existingCrmEvent.id, eventData);
                    updatedInCrm++;
                }
            } else {
                await base44.entities.CalendarEvent.create({
                    ...eventData,
                    created_by: user.email,
                    assigned_to: user.email // Assign to syncing user
                });
                createdInCrm++;
            }
        }
        
        console.log(`✅ Synced from Google: ${createdInCrm} created, ${updatedInCrm} updated`);

        // --- 2. Sync from CRM to Google ---
        console.log('\n📤 SYNCING FROM CRM TO GOOGLE...');
        
        // Only sync events assigned to this user that don't have a google ID yet
        const crmEventsToSync = crmEvents.filter(e => 
            !e.google_event_id && 
            (e.assigned_to === user.email || e.created_by === user.email)
        );
        
        console.log('📊 CRM events to sync to Google:', crmEventsToSync.length);
        
        let createdInGoogle = 0;
        
        for (const crmEvent of crmEventsToSync) {
            try {
                const googleEventPayload = {
                    summary: crmEvent.title || 'Untitled Event',
                    description: crmEvent.description || '',
                    start: { dateTime: crmEvent.start_time },
                    end: { dateTime: crmEvent.end_time || new Date(new Date(crmEvent.start_time).getTime() + 3600000).toISOString() },
                    location: crmEvent.location || '',
                    attendees: crmEvent.attendees ? crmEvent.attendees.map(email => ({ email })) : [],
                };
                
                const createResponse = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events`, {
                    method: 'POST',
                    headers: { 
                        'Authorization': `Bearer ${accessToken}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(googleEventPayload),
                });

                if (createResponse.ok) {
                    const newGEvent = await createResponse.json();
                    await base44.entities.CalendarEvent.update(crmEvent.id, { 
                        google_event_id: newGEvent.id,
                        google_calendar_id: 'primary'
                    });
                    createdInGoogle++;
                }
            } catch (eventError) {
                console.error('❌ Error syncing event:', eventError.message);
            }
        }

        console.log(`✅ Synced to Google: ${createdInGoogle} created`);

        return Response.json({ 
            success: true, 
            message: 'Sync completed successfully!',
            stats: { createdInCrm, updatedInCrm, createdInGoogle }
        });

    } catch (error) {
        console.error('❌ Sync Error:', error.message);
        return Response.json({ success: false, error: error.message }, { status: 500 });
    }
});