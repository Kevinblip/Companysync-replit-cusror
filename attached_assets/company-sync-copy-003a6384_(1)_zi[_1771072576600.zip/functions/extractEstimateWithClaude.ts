import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me();
    if (!user) {
      return Response.json({
        success: false,
        error: 'Unauthorized'
      }, { status: 401 });
    }

    const body = await req.json();
    const fileUrl = body.fileUrl || body.file_url;
    const pricingSource = body.pricingSource || body.pricing_source || 'xactimate';

    if (!fileUrl) {
      return Response.json({
        success: false,
        error: 'fileUrl or file_url is required'
      }, { status: 400 });
    }

    console.log('📄 Processing file:', fileUrl);
    console.log('🎯 Pricing source:', pricingSource);

    // Fetch price list for context
    let priceList = [];
    try {
      if (pricingSource === 'xactimate') {
        priceList = await base44.entities.PriceListItem.filter({ source: 'Xactimate' }, '-created_date', 50);
      } else if (pricingSource === 'symbility') {
        priceList = await base44.entities.PriceListItem.filter({ source: 'Symbility' }, '-created_date', 50);
      } else {
        priceList = await base44.entities.PriceListItem.filter({ source: 'Custom' }, '-created_date', 50);
      }
      console.log(`📋 Loaded ${priceList.length} items from ${pricingSource} price list`);
    } catch (err) {
      console.warn('⚠️ Could not load price list:', err.message);
    }

    // Build context
    let priceListContext = '';
    if (priceList.length > 0) {
      const contextItems = priceList.slice(0, 30).map(item => 
        `${item.code}: ${item.description?.substring(0, 50) || ''} - $${item.price}/${item.unit}`
      );
      priceListContext = contextItems.join('\n');
    }

    const systemPrompt = `You are an expert insurance estimator specializing in ${pricingSource === 'xactimate' ? 'Xactimate' : pricingSource === 'symbility' ? 'Symbility' : 'roofing'} estimates.

Extract ALL line items from the document with actual codes.

${priceListContext ? `Sample codes for reference:\n${priceListContext}\n\n` : ''}

Common roofing codes:
- Shingles: RFG SSSQ, RFG ARLM
- Ridge: RFG RDG
- Hip: RFG HP
- Valley: RFG VLY
- Flashing: RFG FLS
- Drip Edge: RFG DE
- Ice & Water: RFG IWS
- Underlayment: RFG UL
- Tear-off: RFG R&R

Extract all measurements and line items from this roofing measurement report.`;

    console.log('🤖 Calling InvokeLLM with document...');
    
    const llmResponse = await base44.integrations.Core.InvokeLLM({
      prompt: systemPrompt,
      file_urls: [fileUrl],
      response_json_schema: {
        type: "object",
        properties: {
          line_items: {
            type: "array",
            items: {
              type: "object",
              properties: {
                code: { type: "string" },
                description: { type: "string" },
                quantity: { type: "number" },
                unit: { type: "string" }
              }
            }
          },
          customer_info: {
            type: "object",
            properties: {
              customer_name: { type: "string" },
              property_address: { type: "string" },
              claim_number: { type: "string" },
              insurance_company: { type: "string" }
            }
          },
          total_from_report: { type: "number" }
        }
      }
    });

    console.log('🤖 LLM Response received');

    const parsed = llmResponse;
    
    // Match extracted items with price list to get actual prices
    const processedLineItems = (parsed.line_items || []).map((item, index) => {
      const code = item.code?.toUpperCase() || '';
      const matchedPrice = priceList.find(p => p.code?.toUpperCase() === code);
      
      const quantity = Number(item.quantity) || 0;
      const rate = matchedPrice ? Number(matchedPrice.price) : 0;
      const rcv = quantity * rate;
      
      return {
        line: index + 1,
        code: item.code || '',
        description: item.description || '',
        quantity: quantity,
        unit: item.unit || 'EA',
        rate: rate,
        rcv: rcv,
        acv: rcv,
        amount: rcv,
        depreciation: 0
      };
    });
    
    const totalRcv = processedLineItems.reduce((sum, item) => sum + (item.rcv || 0), 0);
    
    return Response.json({
      success: true,
      estimate: {
        title: 'Extracted Estimate',
        line_items: processedLineItems,
        total_rcv: totalRcv,
        customer_info: parsed.customer_info || {}
      }
    });

  } catch (error) {
    console.error('💥 Error:', error);
    return Response.json({
      success: false,
      error: error.message,
      errorType: error.constructor.name,
      details: error.stack
    }, { status: 500 });
  }
});