import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const companies = await base44.asServiceRole.entities.Company.filter({ 
            created_by: user.email 
        });

        if (!companies || companies.length === 0) {
            return Response.json({ error: 'No company found' }, { status: 400 });
        }

        const company = companies[0];

        // Claims Specialist permissions - view/edit OWN data only
        const permissions = {
            dashboard: { view: true },
            leads: { view_own: true, create: true, edit_own: true, delete_own: true },
            customers: { view_own: true, create: true, edit_own: true, delete_own: true },
            estimates: { view_own: true, create: true, edit_own: true, delete_own: true, view_all_templates: true },
            proposals: { view_own: true, create: true, edit_own: true, delete_own: true, view_all_templates: true },
            invoices: { view_own: true, create: true, edit_own: true, delete_own: true },
            payments: { view_own: true, create: true, edit_own: true, delete_own: true },
            items: { view: true, create: true, edit: true },
            tasks: { view_own: true, create: true, edit_own: true, delete_own: true },
            reminders: { view_own: true, create: true, edit: true, delete: true },
            contracts: { view_own: true, create: true, edit_own: true, delete_own: true },
            ai_estimator: { view: true, create: true, generate_images: true, generate_audio: true },
            lexi_ai: { view: true, chat: true },
            permit_assistant: { view: true, generate: true },
            daily_reports: { view: true },
            inspections: { view_own: true, create: true, capture_photos: true, edit_own: true, delete_own: true },
            lead_inspections: { view_own: true, create: true, edit: true },
            drone_analysis: { view: true, upload: true, analyze: true },
            communication_hub: { view_own: true, audio_call: true, video_call: true, send_sms: true, send_email: true },
            mailbox: { view_own: true, send: true, delete_own: true },
            messages: { view_own: true, send: true },
            email_templates: { view: true },
            sms_templates: { view: true },
            zoom_meeting: { view: true, create: true },
            documents: { view_own: true, upload: true, delete_own: true },
            contract_templates: { view: true },
            contract_signing: { view_own: true, create: true, send: true },
            knowledge_base: { view: true },
            reports: { view_own: true },
            analytics_dashboard: { view_own: true },
            sales_reports: { view_own: true },
            sales_dashboard: { view_own: true },
            calendar: { view_own: true, create: true, edit_own: true, delete_own: true },
            activity: { view_own: true },
            review_requests: { view_own: true, create: true, send: true },
            map: { view: true },
            subscription: { view: true }
        };

        const roles = await base44.asServiceRole.entities.StaffRole.filter({
            company_id: company.id,
            name: "Insurance Claims Specialist"
        });

        let result;
        if (roles && roles.length > 0) {
            result = await base44.asServiceRole.entities.StaffRole.update(roles[0].id, {
                permissions: permissions
            });
            return Response.json({
                success: true,
                message: '✅ Updated Insurance Claims Specialist permissions',
                role: result
            });
        } else {
            result = await base44.asServiceRole.entities.StaffRole.create({
                company_id: company.id,
                name: "Insurance Claims Specialist",
                description: "Field specialist - view/edit own data only, full AI tools access",
                permissions: permissions
            });
            return Response.json({
                success: true,
                message: '✅ Created Insurance Claims Specialist role',
                role: result
            });
        }

    } catch (error) {
        console.error('Error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});