import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const getAccessToken = async (user, base44) => {
    console.log('🔑 Getting access token...');
    
    // 1. Try App Connector (Primary) - managed by Base44 platform, auto-refreshes
    try {
        const appToken = await base44.asServiceRole.connectors.getAccessToken("googlecalendar");
        if (appToken) {
            console.log('✅ Using App Connector Access Token (auto-refreshed by platform)');
            return appToken;
        }
    } catch (e) {
        console.log('⚠️ App Connector token not available:', e.message);
    }

    // If app connector failed, throw clear error - we use app connector as primary auth now
    throw new Error('Google Calendar app connector not available. Please contact support.');
};

function convertGoogleDateToISO(googleDateTime) {
    if (!googleDateTime) return null;
    try {
        const date = new Date(googleDateTime);
        if (isNaN(date.getTime())) return null;
        return date.toISOString();
    } catch (error) {
        return null;
    }
}

// Helper to add delay between API calls to avoid rate limits
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

Deno.serve(async (req) => {
    let targetUser = null;
    
    try {
        console.log('🚀 === TWO-WAY GOOGLE CALENDAR SYNC STARTED ===');
        
        const base44 = createClientFromRequest(req);
        const requestingUser = await base44.auth.me();

        if (!requestingUser) {
            console.error('❌ Unauthorized');
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        let bodyData = {};
        try {
            const contentType = req.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                const text = await req.text();
                if (text && text.trim() && text !== '{}') {
                    bodyData = JSON.parse(text);
                }
            }
        } catch (parseError) {
            console.log('ℹ️ No JSON body or empty body - using requesting user');
        }

        const { targetUserEmail } = bodyData;
        
        if (targetUserEmail && targetUserEmail !== requestingUser.email) {
            console.log(`🔄 Admin sync requested for: ${targetUserEmail}`);
            if (requestingUser.role !== 'admin') {
                return Response.json({ error: 'Only admins can sync other users calendars' }, { status: 403 });
            }
            
            const users = await base44.asServiceRole.entities.User.filter({ email: targetUserEmail });
            targetUser = users[0];
            
            if (!targetUser) {
                return Response.json({ error: 'Target user not found' }, { status: 404 });
            }
        } else {
            targetUser = requestingUser;
        }

        console.log('✅ Syncing calendar for:', targetUser.email);

        // Get company ID
        console.log('🔍 Fetching company ID...');
        const staffProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ 
            user_email: targetUser.email 
        });
        
        let companyId = staffProfiles[0]?.company_id || null;
        
        if (!companyId) {
            const companies = await base44.asServiceRole.entities.Company.filter({ 
                created_by: targetUser.email 
            });
            companyId = companies[0]?.id || null;
        }

        console.log(`🏢 Using company ID: ${companyId || 'None (will be null in events)'}`);

        // 🔧 Get company timezone
        let companyTimezone = 'America/New_York';
        if (companyId) {
            try {
                const companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
                const company = companies[0];
                if (company && company.timezone) {
                    companyTimezone = company.timezone;
                }
            } catch (err) {}
        }

        // Get Access Token
        let accessToken;
        try {
            accessToken = await getAccessToken(targetUser, base44);
        } catch (e) {
            console.error('❌ Auth error:', e.message);
            return Response.json({ 
                error: 'Authentication failed. Please check your Google Calendar connection.',
                details: e.message,
                needsReconnect: true
            }, { status: 401 });
        }

        // STEP 1: Sync FROM Google Calendar TO CRM
        console.log('📥 STEP 1: Syncing FROM Google Calendar TO CRM...');
        
        const timeMin = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
        const timeMax = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString();

        let fromGoogleCreated = 0;
        let fromGoogleUpdated = 0;
        let fromGoogleDeleted = 0;
        let fromGoogleErrors = 0;

        try {
            const googleResponse = await fetch(
                `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${timeMin}&timeMax=${timeMax}&singleEvents=true&orderBy=startTime&maxResults=250&showDeleted=true`,
                { headers: { 'Authorization': `Bearer ${accessToken}` } }
            );

            if (!googleResponse.ok) {
                const errorText = await googleResponse.text();
                throw new Error(`Google API error (${googleResponse.status}): ${errorText}`);
            }

            const googleData = await googleResponse.json();
            const googleEvents = googleData.items || [];
            console.log(`📋 Found ${googleEvents.length} events in Google Calendar`);

            // Process in batches to avoid rate limits
            const batchSize = 5;
            for (let i = 0; i < googleEvents.length; i += batchSize) {
                const batch = googleEvents.slice(i, i + batchSize);
                
                for (const gEvent of batch) {
                    try {
                        // Handle deletions
                        if (gEvent.status === 'cancelled') {
                            const existingEvents = await base44.asServiceRole.entities.CalendarEvent.filter({ google_event_id: gEvent.id });
                            if (existingEvents.length > 0) {
                                await base44.asServiceRole.entities.CalendarEvent.delete(existingEvents[0].id);
                                fromGoogleDeleted++;
                            }
                            continue;
                        }

                        if (!gEvent.start?.dateTime && !gEvent.start?.date) continue;

                        const startTimeISO = convertGoogleDateToISO(gEvent.start.dateTime || gEvent.start.date);
                        const endTimeISO = convertGoogleDateToISO(gEvent.end?.dateTime || gEvent.end?.date) || startTimeISO;

                        if (!startTimeISO) continue;

                        const existingEvents = await base44.asServiceRole.entities.CalendarEvent.filter({ google_event_id: gEvent.id });

                        const eventData = {
                            title: gEvent.summary || 'Untitled Event',
                            description: gEvent.description || '',
                            start_time: startTimeISO,
                            end_time: endTimeISO,
                            location: gEvent.location || '',
                            google_event_id: gEvent.id,
                            google_calendar_id: 'primary',
                            assigned_to: targetUser.email,
                            event_type: 'meeting',
                            color: '#3b82f6',
                            company_id: companyId
                        };

                        if (existingEvents.length > 0) {
                            const existingEvent = existingEvents[0];
                            const lastUpdatedCrm = new Date(existingEvent.updated_date).getTime();
                            const lastUpdatedGoogle = new Date(gEvent.updated).getTime();

                            // Only update CRM if Google is newer
                            if (lastUpdatedGoogle > lastUpdatedCrm) {
                                await base44.asServiceRole.entities.CalendarEvent.update(existingEvent.id, eventData);
                                fromGoogleUpdated++;
                            }
                        } else {
                            await base44.asServiceRole.entities.CalendarEvent.create(eventData);
                            fromGoogleCreated++;
                        }
                    } catch (eventError) {
                        fromGoogleErrors++;
                        console.error(`⚠️ Error processing Google event ${gEvent.summary}:`, eventError.message);
                    }
                }
                
                // Add delay between batches to avoid rate limits
                if (i + batchSize < googleEvents.length) {
                    await delay(500);
                }
            }
        } catch (googleSyncError) {
            console.error('❌ Error syncing from Google Calendar:', googleSyncError.message);
            fromGoogleErrors++;
        }

        // STEP 2: Sync FROM CRM TO Google Calendar
        console.log('📤 STEP 2: Syncing FROM CRM TO Google Calendar...');

        let toGoogleCreated = 0;
        let toGoogleUpdated = 0;
        let toGoogleErrors = 0;

        try {
            // Get all events assigned to user
            const allCRMEvents = await base44.asServiceRole.entities.CalendarEvent.filter({
                assigned_to: targetUser.email
            }, '-start_time', 1000);
            
            // Filter by date range
            const now = new Date();
            const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            const oneYearFromNow = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
            
            const userCRMEvents = allCRMEvents.filter(event => {
                try {
                    const eventTime = new Date(event.start_time);
                    return eventTime >= thirtyDaysAgo && eventTime <= oneYearFromNow;
                } catch { return false; }
            });

            console.log(`📋 Found ${userCRMEvents.length} CRM events for ${targetUser.email}`);

            // Process in batches to avoid rate limits
            const crmBatchSize = 10;
            for (let i = 0; i < userCRMEvents.length; i += crmBatchSize) {
                const batch = userCRMEvents.slice(i, i + crmBatchSize);
                
                for (const crmEvent of batch) {
                    try {
                        if (!crmEvent.start_time) continue;

                        const googleEventData = {
                            summary: crmEvent.title || 'Untitled',
                            description: crmEvent.description || '',
                            location: crmEvent.location || '',
                            start: {
                                dateTime: new Date(crmEvent.start_time).toISOString(),
                                timeZone: companyTimezone
                            },
                            end: {
                                dateTime: new Date(crmEvent.end_time || crmEvent.start_time).toISOString(),
                                timeZone: companyTimezone
                            },
                            reminders: { useDefault: false, overrides: [] }
                        };

                        // Add reminders
                        if (crmEvent.send_email_notification && crmEvent.email_reminder_minutes) {
                            const mins = Array.isArray(crmEvent.email_reminder_minutes) ? crmEvent.email_reminder_minutes : [crmEvent.email_reminder_minutes];
                            mins.forEach(m => { if (!isNaN(m)) googleEventData.reminders.overrides.push({ method: 'email', minutes: m }); });
                        }
                        if (crmEvent.send_browser_notification && crmEvent.browser_reminder_minutes) {
                            const mins = Array.isArray(crmEvent.browser_reminder_minutes) ? crmEvent.browser_reminder_minutes : [crmEvent.browser_reminder_minutes];
                            mins.forEach(m => { if (!isNaN(m)) googleEventData.reminders.overrides.push({ method: 'popup', minutes: m }); });
                        }

                        if (crmEvent.google_event_id) {
                            const updateResponse = await fetch(
                                `https://www.googleapis.com/calendar/v3/calendars/primary/events/${crmEvent.google_event_id}`,
                                {
                                    method: 'PUT',
                                    headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
                                    body: JSON.stringify(googleEventData)
                                }
                            );

                            if (updateResponse.ok) {
                                toGoogleUpdated++;
                            } else if (updateResponse.status === 404 || updateResponse.status === 410) {
                                console.log(`⚠️ Event not found in Google, recreating: ${crmEvent.title}`);
                                const createResponse = await fetch(
                                    'https://www.googleapis.com/calendar/v3/calendars/primary/events',
                                    {
                                        method: 'POST',
                                        headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
                                        body: JSON.stringify(googleEventData)
                                    }
                                );

                                if (createResponse.ok) {
                                    const newGoogleEvent = await createResponse.json();
                                    await base44.asServiceRole.entities.CalendarEvent.update(crmEvent.id, { google_event_id: newGoogleEvent.id });
                                    toGoogleCreated++;
                                }
                            }
                        } else {
                            console.log(`➕ Creating new event in Google: "${crmEvent.title}"`);
                            const createResponse = await fetch(
                                'https://www.googleapis.com/calendar/v3/calendars/primary/events',
                                {
                                    method: 'POST',
                                    headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
                                    body: JSON.stringify(googleEventData)
                                }
                            );

                            if (createResponse.ok) {
                                const newGoogleEvent = await createResponse.json();
                                await base44.asServiceRole.entities.CalendarEvent.update(crmEvent.id, { google_event_id: newGoogleEvent.id });
                                toGoogleCreated++;
                            } else {
                                const err = await createResponse.text();
                                console.error(`❌ Failed to create in Google: ${err}`);
                                toGoogleErrors++;
                            }
                        }
                    } catch (error) {
                        toGoogleErrors++;
                        console.error(`⚠️ Error syncing CRM event ${crmEvent.title}:`, error.message);
                    }
                }
                
                // Add delay between batches to avoid rate limits
                if (i + crmBatchSize < userCRMEvents.length) {
                    await delay(500);
                }
            }

            console.log(`✅ To Google: ${toGoogleCreated} created, ${toGoogleUpdated} updated, ${toGoogleErrors} errors`);
        } catch (crmSyncError) {
            console.error('❌ Error syncing to Google Calendar:', crmSyncError.message);
            toGoogleErrors++;
        }

        try {
            await base44.asServiceRole.entities.User.update(targetUser.id, { last_google_sync: new Date().toISOString() });
        } catch (e) {}

        console.log('✅ === TWO-WAY SYNC COMPLETED ===');

        return Response.json({ 
            success: true,
            fromGoogle: { created: fromGoogleCreated, updated: fromGoogleUpdated, deleted: fromGoogleDeleted, errors: fromGoogleErrors },
            toGoogle: { created: toGoogleCreated, updated: toGoogleUpdated, errors: toGoogleErrors },
            total: fromGoogleCreated + fromGoogleUpdated + toGoogleCreated + toGoogleUpdated,
            timezone: companyTimezone
        });

    } catch (error) {
        console.error('❌ === SYNC ERROR ===');
        return Response.json({ error: error.message, details: error.stack }, { status: 500 });
    }
});