import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        console.log('🔄 Connecting Google Calendar for user:', user.email);

        // Get access token from app connector
        const accessToken = await base44.asServiceRole.connectors.getAccessToken('googlecalendar');
        
        if (!accessToken) {
            console.error('❌ No access token from connector');
            return Response.json({ 
                error: 'Google Calendar app connector not authorized. Please authorize it in the Base44 dashboard.' 
            }, { status: 400 });
        }

        console.log('✅ Got access token from connector');

        // Mark user as connected and store minimal info
        await base44.asServiceRole.entities.User.update(user.id, {
            google_calendar_connected: true,
            google_access_token: accessToken,
            google_token_expires_at: new Date(Date.now() + 3600000).toISOString() // 1 hour
        });

        console.log('✅ User marked as connected:', user.email);

        return Response.json({ 
            success: true,
            message: 'Google Calendar connected successfully! You can now sync your calendar.'
        });

    } catch (error) {
        console.error('❌ Error connecting Google Calendar:', error);
        return Response.json({ 
            error: error.message 
        }, { status: 500 });
    }
});