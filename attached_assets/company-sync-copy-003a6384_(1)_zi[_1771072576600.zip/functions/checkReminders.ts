import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import { format } from 'npm:date-fns@3.0.0';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Get current time
        const now = new Date();
        
        console.log('🔔 Checking for reminders at', now.toISOString());
        
        // Only fetch upcoming events (next 48 hours) to avoid timeout
        const twoDaysFromNow = new Date(now.getTime() + (48 * 60 * 60 * 1000));
        
        // OPTIMIZATION: Filter for future events at DB level and sort by SOONEST first
        const allEvents = await base44.asServiceRole.entities.CalendarEvent.filter({
            status: { $ne: 'cancelled' },
            start_time: { $gte: now.toISOString() }
        }, "start_time", 200); // 200 limit is safer for memory, sorted ASCENDING
        
        // Secondary filter just to be safe on the upper bound
        const upcomingEvents = allEvents.filter(e => {
            const eventTime = new Date(e.start_time);
            return eventTime <= twoDaysFromNow;
        });
        
        console.log(`📋 Found ${upcomingEvents.length} upcoming events in next 48 hours`);
        
        // PARALLEL PROCESSING to avoid timeouts
        const results = await Promise.all(upcomingEvents.map(async (event) => {
            const eventResults = [];
            
            if (event.status === 'completed') {
                return null;
            }

            const eventStartTime = new Date(event.start_time);
            const minutesUntilEvent = Math.floor((eventStartTime - now) / 60000);

            // 📧 Check EMAIL reminders
            if (event.send_email_notification && !event.notification_sent) {
                const emailReminderMinutes = Array.isArray(event.email_reminder_minutes) 
                    ? event.email_reminder_minutes 
                    : [event.email_reminder_minutes || 0];

                for (const reminderMinutes of emailReminderMinutes) {
                    const shouldSend = minutesUntilEvent <= reminderMinutes && minutesUntilEvent >= (reminderMinutes - 5);

                    if (shouldSend) {
                        try {
                            const userEmail = event.assigned_to || event.created_by;
                            if (!userEmail) {
                                console.warn('⚠️ Event has no assigned user:', event.id);
                                continue;
                            }

                            // Get company for email sender name
                            const companies = await base44.asServiceRole.entities.Company.filter({ 
                                id: event.company_id 
                            });
                            const company = companies[0];

                            const eventTime = format(eventStartTime, 'EEEE, MMMM d, yyyy \'at\' h:mm a');

                            const emailSubject = `⏰ Reminder: ${event.title}`;
                            const emailBody = `
                                <h2>📅 Upcoming Event Reminder</h2>
                                <p><strong>${event.title}</strong></p>
                                <p><strong>Time:</strong> ${eventTime}</p>
                                ${event.location ? `<p><strong>Location:</strong> ${event.location}</p>` : ''}
                                ${event.description ? `<p><strong>Details:</strong> ${event.description}</p>` : ''}
                                <br/>
                                <p style="color: #666; font-size: 12px;">This reminder was set for ${reminderMinutes === 0 ? 'event time' : reminderMinutes + ' minutes before'}</p>
                            `;
                            
                            await base44.asServiceRole.integrations.Core.SendEmail({
                                to: userEmail,
                                subject: emailSubject,
                                body: emailBody,
                                from_name: `${company?.company_name || 'AI CRM Pro'} - Calendar Reminders`
                            });
                            
                            // Mark as sent (only mark once for the first reminder)
                            if (reminderMinutes === emailReminderMinutes[0]) {
                                await base44.asServiceRole.entities.CalendarEvent.update(event.id, {
                                    notification_sent: true,
                                    notification_sent_at: now.toISOString()
                                });
                            }
                            
                            eventResults.push({ 
                                event_id: event.id, 
                                event_title: event.title,
                                type: 'email', 
                                status: 'sent', 
                                sent_to: userEmail,
                                reminder_minutes: reminderMinutes 
                            });
                            console.log(`✅ Email sent to ${userEmail} for event: ${event.title} (${reminderMinutes} min before)`);
                        } catch (error) {
                            console.error(`❌ Failed to send EMAIL for event ${event.id}:`, error);
                            eventResults.push({ 
                                event_id: event.id, 
                                event_title: event.title,
                                type: 'email', 
                                status: 'failed', 
                                error: error.message 
                            });
                        }
                    }
                }
            }

            // 📱 Check SMS reminders
            if (event.send_sms_notification && !event.sms_notification_sent) {
                const smsReminderMinutes = Array.isArray(event.sms_reminder_minutes) 
                    ? event.sms_reminder_minutes 
                    : [event.sms_reminder_minutes || 10];

                for (const reminderMinutes of smsReminderMinutes) {
                    const shouldSend = minutesUntilEvent <= reminderMinutes && minutesUntilEvent >= (reminderMinutes - 5);

                    if (shouldSend) {
                        try {
                            const userEmail = event.assigned_to || event.created_by;
                            if (!userEmail) {
                                console.warn('⚠️ Event has no assigned user:', event.id);
                                continue;
                            }

                            const profiles = await base44.asServiceRole.entities.StaffProfile.filter({ 
                                user_email: userEmail 
                            });
                            const userProfile = profiles[0];

                            if (userProfile && userProfile.phone) {
                                const eventTime = format(eventStartTime, 'MMM d \'at\' h:mm a');
                                const smsMessage = `⏰ Reminder: "${event.title}" on ${eventTime}${event.location ? ` at ${event.location}` : ''}`;
                                
                                // Get company ID for SMS
                                let companyId = event.company_id;
                                if (!companyId) {
                                    const companies = await base44.asServiceRole.entities.Company.filter({ 
                                        created_by: userEmail 
                                    });
                                    companyId = companies[0]?.id;
                                }

                                if (companyId) {
                                    await base44.asServiceRole.functions.invoke('sendSMS', {
                                        to: userProfile.phone,
                                        message: smsMessage,
                                        companyId: companyId
                                    });

                                    // Mark as sent (only mark once for the first reminder)
                                    if (reminderMinutes === smsReminderMinutes[0]) {
                                        await base44.asServiceRole.entities.CalendarEvent.update(event.id, {
                                            sms_notification_sent: true,
                                            sms_notification_sent_at: now.toISOString()
                                        });
                                    }

                                    eventResults.push({ 
                                        event_id: event.id,
                                        event_title: event.title, 
                                        type: 'sms', 
                                        status: 'sent', 
                                        sent_to: userProfile.phone,
                                        reminder_minutes: reminderMinutes 
                                    });
                                    console.log(`✅ SMS sent to ${userProfile.phone} for event: ${event.title} (${reminderMinutes} min before)`);
                                } else {
                                    console.warn(`⚠️ No company ID for SMS: ${event.title}`);
                                }
                            } else {
                                console.warn(`⚠️ SMS skipped for ${userEmail}. No phone number in StaffProfile.`);
                                eventResults.push({ 
                                    event_id: event.id,
                                    event_title: event.title, 
                                    type: 'sms', 
                                    status: 'skipped', 
                                    reason: 'No phone number' 
                                });
                            }
                        } catch (error) {
                            console.error(`❌ Failed to send SMS for event ${event.id}:`, error);
                            eventResults.push({ 
                                event_id: event.id,
                                event_title: event.title, 
                                type: 'sms', 
                                status: 'failed', 
                                error: error.message 
                            });
                        }
                    }
                }
            }
            
            return eventResults;
        }));
        
        // Flatten results
        const finalResults = results.flat().filter(Boolean);
        
        console.log(`✅ Reminder check complete. Processed ${finalResults.length} notifications.`);
        
        return Response.json({
            success: true,
            checked_at: now.toISOString(),
            events_checked: upcomingEvents.length,
            total_events_in_db: allEvents.length,
            notifications_sent: finalResults.filter(r => r.status === 'sent').length,
            results: finalResults
        });
        
    } catch (error) {
        console.error('❌ Error in checkReminders function:', error);
        return Response.json({ success: false, error: error.message }, { status: 500 });
    }
});