import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  const debugLogs = [];
  
  try {
    debugLogs.push('🛰️ Function started');
    
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    debugLogs.push(`✅ User authenticated: ${user.email}`);

    const { latitude, longitude, address } = await req.json();

    if (!latitude || !longitude) {
      return Response.json({ 
        success: false, 
        error: 'Latitude and longitude are required' 
      }, { status: 400 });
    }

    debugLogs.push(`📍 Analyzing EXACT coordinates: ${address} (${latitude}, ${longitude})`);

    const googleApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!googleApiKey) {
      return Response.json({ 
        success: false, 
        error: 'Google Maps API key not configured. Please add GOOGLE_MAPS_API_KEY in Settings → Secrets.',
        debug_logs: debugLogs
      }, { status: 500 });
    }

    debugLogs.push('✅ Google API key found');
    
    // Generate high-res satellite image URL for AI analysis
    const satelliteImageUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${latitude},${longitude}&zoom=20&size=640x640&maptype=satellite&key=${googleApiKey}`;
    debugLogs.push('📸 Generated satellite image URL for AI analysis');

    // Call Google Solar API with EXACT coordinates
    const solarApiUrl = `https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=${latitude}&location.longitude=${longitude}&requiredQuality=HIGH&key=${googleApiKey}`;
    
    debugLogs.push(`🌐 Calling Google Solar API for EXACT building at (${latitude}, ${longitude})...`);
    
    const response = await fetch(solarApiUrl);
    debugLogs.push(`📡 Solar API Response Status: ${response.status}`);
    
    let effectiveResponse = response;
    if (!response.ok) {
      const errorText = await response.text();
      debugLogs.push(`❌ Solar API Error (HIGH): ${errorText}`);

      // Retry with MEDIUM quality
      const retryMediumUrl = `https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=${latitude}&location.longitude=${longitude}&requiredQuality=MEDIUM&key=${googleApiKey}`;
      debugLogs.push('🔁 Retrying Solar API with MEDIUM quality...');
      const mediumResp = await fetch(retryMediumUrl);
      debugLogs.push(`📡 Solar API Response Status (MEDIUM): ${mediumResp.status}`);

      if (mediumResp.ok) {
        effectiveResponse = mediumResp;
      } else {
        const mediumErr = await mediumResp.text();
        debugLogs.push(`❌ Solar API Error (MEDIUM): ${mediumErr}`);

        // Retry without requiredQuality
        const retryAnyUrl = `https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=${latitude}&location.longitude=${longitude}&key=${googleApiKey}`;
        debugLogs.push('🔁 Retrying Solar API without requiredQuality...');
        const anyResp = await fetch(retryAnyUrl);
        debugLogs.push(`📡 Solar API Response Status (ANY): ${anyResp.status}`);

        if (anyResp.ok) {
          effectiveResponse = anyResp;
        } else {
          const anyErr = await anyResp.text();
          debugLogs.push(`❌ Solar API Error (ANY): ${anyErr}`);

          // Fallback: return estimated measurements
          const estimatedAreaSqFt = 600;
          const roofAreaSquares = 6;

          const sqrtArea = Math.sqrt(estimatedAreaSqFt);
          const ridgeLf = Math.round(sqrtArea * 0.8);
          const valleyLf = Math.round(sqrtArea * 0.2);
          const rakeLf = Math.round(sqrtArea * 1.8);
          const eaveLf = Math.round(sqrtArea * 2.2);
          const stepFlashingLf = Math.round(sqrtArea * 0.4);

          return Response.json({
            success: true,
            roof_area_sq: roofAreaSquares,
            roof_area_sqft: estimatedAreaSqFt,
            ridge_lf: ridgeLf,
            hip_lf: 0,
            valley_lf: valleyLf,
            rake_lf: rakeLf,
            eave_lf: eaveLf,
            step_flashing_lf: stepFlashingLf,
            pitch: "6/12",
            overall_confidence: 40,
            ridge_confidence: 40,
            hip_confidence: 40,
            valley_confidence: 40,
            rake_confidence: 40,
            eave_confidence: 40,
            step_flashing_confidence: 40,
            analysis_notes: `⚠️ Google Solar API couldn't detect building near coordinates (${latitude}, ${longitude}). Using estimated ${roofAreaSquares} SQ for typical small structure. For accuracy, use Manual Drawing mode or upload inspection photos.`,
            debug_logs: debugLogs,
            fallback_used: true
          });
        }
      }
    }

    const solarData = await (effectiveResponse || response).json();
    debugLogs.push('✅ Parsed Solar API response');

    if (solarData.center) {
      debugLogs.push(`📍 Solar API detected building at: ${solarData.center.latitude}, ${solarData.center.longitude}`);
    }

    const roofSegments = solarData.solarPotential?.roofSegmentStats || [];
    debugLogs.push(`📊 Found ${roofSegments.length} roof segments`);
    
    if (roofSegments.length === 0) {
      debugLogs.push('⚠️ No roof segments found in Solar API data');
      
      const estimatedAreaSqFt = 600;
      const roofAreaSquares = 6;
      
      const sqrtArea = Math.sqrt(estimatedAreaSqFt);
      const ridgeLf = Math.round(sqrtArea * 0.8);
      const valleyLf = Math.round(sqrtArea * 0.2);
      const rakeLf = Math.round(sqrtArea * 1.8);
      const eaveLf = Math.round(sqrtArea * 2.2);
      const stepFlashingLf = Math.round(sqrtArea * 0.4);
      
      return Response.json({
        success: true,
        roof_area_sq: roofAreaSquares,
        roof_area_sqft: estimatedAreaSqFt,
        ridge_lf: ridgeLf,
        hip_lf: 0,
        valley_lf: valleyLf,
        rake_lf: rakeLf,
        eave_lf: eaveLf,
        step_flashing_lf: stepFlashingLf,
        pitch: "6/12",
        overall_confidence: 40,
        ridge_confidence: 40,
        hip_confidence: 40,
        valley_confidence: 40,
        rake_confidence: 40,
        eave_confidence: 40,
        step_flashing_confidence: 40,
        analysis_notes: `⚠️ No detailed roof data available. Using estimated measurements. For accurate measurements, use Manual Drawing mode.`,
        debug_logs: debugLogs,
        fallback_used: true
      });
    }
    
    let totalAreaSqFt = 0;
    const wholeAreaM2 = solarData.solarPotential?.wholeRoofStats?.areaMeters2;
    const usedWhole = !!(wholeAreaM2 && wholeAreaM2 > 0);
    if (usedWhole) {
      totalAreaSqFt = wholeAreaM2 * 10.764;
      debugLogs.push(`📗 Total area (wholeRoofStats): ${totalAreaSqFt.toFixed(2)} sq ft`);
    }
    roofSegments.forEach(segment => {
      const areaMeters = segment.stats?.areaMeters2 || 0;
      if (!usedWhole) { totalAreaSqFt += areaMeters * 10.764; }
    });

    debugLogs.push(`📐 Total area: ${totalAreaSqFt.toFixed(2)} sq ft`);

    const roofAreaSquares = Math.round((totalAreaSqFt / 100) * 100) / 100;
    debugLogs.push(`📦 Roof squares: ${roofAreaSquares} SQ`);

    const sqrtArea = Math.sqrt(totalAreaSqFt);
    const ridgeLf = Math.round(sqrtArea * 0.8);
    const hipLf = 0;
    const valleyLf = Math.round(sqrtArea * 0.3);
    const rakeLf = Math.round(sqrtArea * 1.8);
    const eaveLf = Math.round(sqrtArea * 2.2);
    const stepFlashingLf = Math.round(sqrtArea * 0.6);

    const degs = (roofSegments || [])
      .map(s => (typeof s.pitchDegrees === 'number' ? s.pitchDegrees : (typeof s.tiltDegrees === 'number' ? s.tiltDegrees : null)))
      .filter(v => typeof v === 'number' && !isNaN(v) && v > 0);
    const avgDeg = degs.length ? (degs.reduce((a,b)=>a+b,0) / degs.length) : null;
    const degToX12 = (deg) => {
      const rise = Math.tan((deg * Math.PI) / 180) * 12;
      const clamped = Math.min(20, Math.max(1, Math.round(rise)));
      return `${clamped}/12`;
    };
    const pitchStr = avgDeg ? degToX12(avgDeg) : '6/12';

    const isFlatRoof = pitchStr === '0/12' || pitchStr === '1/12' || pitchStr === '2/12' || (avgDeg !== null && avgDeg <= 9.5);
    
    debugLogs.push(`✅ Measurements calculated | Pitch: ${pitchStr} | Flat Roof: ${isFlatRoof}`);

    // Static confidence values based on data source
    const overall_confidence = usedWhole ? 95 : 85;
    
    const analysisNotes = usedWhole 
      ? "Used Google Solar wholeRoofStats (full-roof area). LF estimated from area." 
      : "Used sum of roofSegmentStats (solar-eligible area). LF estimated from area.";
    
    debugLogs.push(`📈 Final confidence: ${overall_confidence}%`);

    return Response.json({
      success: true,
      roof_area_sq: roofAreaSquares,
      roof_area_sqft: totalAreaSqFt,
      ridge_lf: ridgeLf,
      hip_lf: hipLf,
      valley_lf: valleyLf,
      rake_lf: rakeLf,
      eave_lf: eaveLf,
      step_flashing_lf: stepFlashingLf,
      pitch: pitchStr,
      is_flat_roof: isFlatRoof,
      overall_confidence: overall_confidence,
      ridge_confidence: usedWhole ? 90 : 80,
      hip_confidence: usedWhole ? 99 : 90,
      valley_confidence: usedWhole ? 85 : 75,
      rake_confidence: usedWhole ? 90 : 80,
      eave_confidence: usedWhole ? 90 : 80,
      step_flashing_confidence: usedWhole ? 85 : 75,
      analysis_notes: analysisNotes,
      debug_logs: debugLogs
    });

  } catch (error) {
    console.error('💥 Error:', error);
    debugLogs.push(`💥 ERROR: ${error.message}`);
    
    return Response.json({ 
      success: false, 
      error: error.message,
      stack: error.stack,
      debug_logs: debugLogs
    }, { status: 500 });
  }
});