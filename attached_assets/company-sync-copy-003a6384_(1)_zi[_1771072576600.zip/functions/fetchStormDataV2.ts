import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// Helper for batched processing
async function processInBatches(items, batchSize, fn) {
  const results = [];
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const batchResults = await Promise.all(batch.map(fn));
    results.push(...batchResults);
  }
  return results;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const daysBack = body.daysBack || 60;
    const nationwide = body.nationwide || false;

    const now = new Date();
    const startDate = new Date(now);
    startDate.setDate(startDate.getDate() - daysBack);

    console.log(`🌪️ Fetching storm data V2 (${daysBack} days back)...`);
    
    // Default to OH, TX, FL if nationwide is false and no settings (simplified for V2)
    let targetStates = new Set(['OH', 'TX', 'FL']); 
    
    if (nationwide) {
        const allStates = [
            'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
            'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
            'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
            'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
            'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'
        ];
        allStates.forEach(s => targetStates.add(s));
    }

    const eventsToCreate = [];
    const eventIdsSet = new Set();

    // Load existing IDs
    const existing = await base44.asServiceRole.entities.StormEvent.list('-created_date', 5000);
    existing.forEach(e => eventIdsSet.add(e.event_id));

    // FETCH IEM DATA
    const stateList = Array.from(targetStates);
    console.log(`🔎 Processing ${stateList.length} states using lsr.php...`);

    await processInBatches(stateList, 5, async (stateCode) => {
        console.log(`📡 Fetching state: ${stateCode}`);
        
        try {
            // Format timestamps for lsr.php (YYYY-MM-DDTHH:MM)
            const sts = startDate.toISOString().substring(0, 16);
            const ets = now.toISOString().substring(0, 16);
            
            // Use local time for IEM usually, but UTC is safer if specifying Z. 
            // lsr.php usually takes YYYYMMDDHHMM in UTC.
            // Let's use the format that works: ISO8601 usually works if encoded.
            // But standard lsr.php usage is sts=202401010000.
            
            // Let's try ISO first as standard.
            const iemUrl = `https://mesonet.agron.iastate.edu/geojson/lsr.php?sts=${sts}&ets=${ets}&states=${stateCode}`;
            
            console.log(`🌐 Fetching: ${iemUrl}`);

            const iemResponse = await fetch(iemUrl, {
              headers: { 'User-Agent': 'Base44-CRM/1.0' }
            });

            if (iemResponse.ok) {
                const data = await iemResponse.json();
                const features = data.features || [];
                console.log(`   ✅ ${stateCode}: Received ${features.length} reports`);
                
                for (const feature of features) {
                    const props = feature.properties;
                    const coords = feature.geometry?.coordinates;
                    if (!coords || coords.length < 2) continue;

                    const longitude = coords[0];
                    const latitude = coords[1];
                    
                    const state = props.state || stateCode;
                    const typeCode = props.type || '';
                    const remark = (props.remark || '').toUpperCase();

                    let eventType = null;
                    let severity = 'moderate';
                    let hailSize = null;
                    let windSpeed = null;

                    // Simplified parsing
                    if (typeCode === 'H') {
                        eventType = 'hail';
                        hailSize = props.magnitude ? parseFloat(props.magnitude) : 0.5;
                        if (hailSize >= 2.0) severity = 'severe';
                    } else if (typeCode === 'G' || typeCode === 'D') {
                        eventType = 'high_wind';
                        windSpeed = props.magnitude ? parseFloat(props.magnitude) : 50;
                        if (windSpeed >= 75) severity = 'severe';
                    } else if (typeCode === 'T') {
                        eventType = 'tornado';
                        severity = 'extreme';
                    }

                    if (!eventType) continue;

                    const eventTime = props.valid; // ISO string
                    const eventId = `IEM_${state}_${eventType}_${latitude}_${longitude}_${eventTime}`;

                    if (!eventIdsSet.has(eventId)) {
                        eventIdsSet.add(eventId);
                        eventsToCreate.push({
                            event_id: eventId,
                            event_type: eventType,
                            severity: severity,
                            title: `${eventType.toUpperCase()} - ${props.city}, ${state}`,
                            description: remark,
                            affected_areas: [`${props.city}, ${state}`],
                            start_time: eventTime,
                            latitude: latitude,
                            longitude: longitude,
                            radius_miles: 10,
                            hail_size_inches: hailSize,
                            wind_speed_mph: windSpeed,
                            status: 'ended',
                            source: 'IEM V2'
                        });
                    }
                }
            } else {
                 console.error(`❌ IEM fetch failed for ${stateCode}: ${iemResponse.status}`);
            }
        } catch (error) {
            console.error(`❌ Error fetching ${stateCode}:`, error.message);
        }
    });

    if (eventsToCreate.length > 0) {
        console.log(`💾 Saving ${eventsToCreate.length} new events...`);
        // Save in batches properly (smaller chunks with delay to avoid 429s)
        const chunkSize = 25;
        for (let i = 0; i < eventsToCreate.length; i += chunkSize) {
            const batch = eventsToCreate.slice(i, i + chunkSize);
            try {
                await base44.asServiceRole.entities.StormEvent.bulkCreate(batch);
                // Small delay to prevent rate limiting
                await new Promise(resolve => setTimeout(resolve, 200));
            } catch (err) {
                console.error(`⚠️ Bulk save failed for batch ${Math.floor(i/chunkSize) + 1}, trying individually:`, err.message);
                // Fallback: Try individually with delay
                for (const evt of batch) {
                    try {
                        await base44.asServiceRole.entities.StormEvent.create(evt);
                        await new Promise(resolve => setTimeout(resolve, 50));
                    } catch (e) {
                         // Ignore duplicates
                    }
                }
            }
        }
    }

    // Count distinct events for Ohio
    const ohioEvents = eventsToCreate.filter(e => e.affected_areas.some(a => a.includes(', OH'))).length;
    
    // Also count existing Ohio events in DB (simple check)
    // We can't easily filter existing array for Ohio string without fetching all, but we have new ones.

    return Response.json({
      success: true,
      newEvents: eventsToCreate.length,
      ohioNewEvents: ohioEvents,
      message: `Processed ${eventsToCreate.length} new events.`
    });

  } catch (error) {
    console.error('❌ Error:', error);
    return Response.json({ error: String(error), stack: error.stack }, { status: 500 });
  }
});