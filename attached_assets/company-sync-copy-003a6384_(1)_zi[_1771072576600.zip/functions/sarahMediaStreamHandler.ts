import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Sarah Media Stream Handler - Real-time voice via Twilio Media Streams + Gemini Live API
 * 
 * This is a TEST handler that does NOT affect the existing sarahVoiceCallHandler.
 * Configure a separate Twilio number to point here for testing.
 * 
 * Flow:
 * 1. Twilio calls this endpoint when a call comes in
 * 2. We return TwiML with <Connect><Stream> to start a WebSocket media stream
 * 3. Twilio opens a WebSocket back to us with raw caller audio
 * 4. We forward that audio to Gemini Live API (after format conversion)
 * 5. Gemini streams back response audio
 * 6. We convert and send it back to Twilio's WebSocket
 * 7. Caller hears Sarah respond in near real-time
 */

// ─── In-memory settings cache ───
const settingsCache = {};
const CACHE_TTL_MS = 5 * 60 * 1000;

async function loadSettings(companyId, base44Client) {
    const now = Date.now();
    const cached = settingsCache[companyId];
    if (cached && (now - cached.ts) < CACHE_TTL_MS) {
        return cached.data;
    }

    const [settingsResult, trainingResult] = await Promise.allSettled([
        base44Client.asServiceRole.entities.AssistantSettings.filter({ company_id: companyId }),
        base44Client.asServiceRole.entities.AITrainingData.filter({ company_id: companyId, is_active: true })
    ]);

    const sarahSettings = settingsResult.status === 'fulfilled' ? settingsResult.value[0] : null;
    if (!sarahSettings) {
        const fallback = { sarahSettings: null, systemPrompt: '', knowledgeBase: '', voiceId: 'Kore' };
        settingsCache[companyId] = { ts: now, data: fallback };
        return fallback;
    }

    const systemPrompt = sarahSettings.system_prompt || '';
    const voiceId = sarahSettings.voice_id || 'Kore';

    const kbParts = [];
    if (sarahSettings.knowledge_base) kbParts.push(sarahSettings.knowledge_base);
    if (sarahSettings.custom_responses) kbParts.push(JSON.stringify(sarahSettings.custom_responses));

    let trainingData = trainingResult.status === 'fulfilled' ? trainingResult.value : [];
    if (trainingData.length > 0) {
        for (const td of trainingData.sort((a, b) => (b.priority || 0) - (a.priority || 0)).slice(0, 5)) {
            if (td.content) kbParts.push(`[${td.title || td.data_type}]: ${td.content.substring(0, 1500)}`);
        }
    }

    const result = { sarahSettings, systemPrompt, knowledgeBase: kbParts.join('\n\n'), voiceId };
    settingsCache[companyId] = { ts: now, data: result };
    return result;
}

// ─── Audio conversion utilities ───

// Convert mulaw 8kHz (Twilio) to PCM 16-bit 16kHz (Gemini input)
function mulawToPcm16k(mulawBase64) {
    const mulawBytes = Uint8Array.from(atob(mulawBase64), c => c.charCodeAt(0));
    
    // mu-law decode table
    const MULAW_BIAS = 33;
    const pcm8k = new Int16Array(mulawBytes.length);
    
    for (let i = 0; i < mulawBytes.length; i++) {
        let mulaw = ~mulawBytes[i] & 0xFF;
        const sign = (mulaw & 0x80) ? -1 : 1;
        mulaw = mulaw & 0x7F;
        const exponent = (mulaw >> 4) & 0x07;
        const mantissa = mulaw & 0x0F;
        let sample = ((mantissa << (exponent + 3)) + MULAW_BIAS * ((1 << (exponent + 3)) - 1)) >> (exponent + 3 - 1);
        if (exponent === 0) {
            sample = (mantissa * 2 + 1) * MULAW_BIAS / 2;
        } else {
            sample = ((1 << exponent) * (mantissa * 2 + 33)) - MULAW_BIAS;
        }
        pcm8k[i] = sign * Math.min(sample, 32767);
    }
    
    // Upsample 8kHz → 16kHz (simple linear interpolation)
    const pcm16k = new Int16Array(pcm8k.length * 2);
    for (let i = 0; i < pcm8k.length - 1; i++) {
        pcm16k[i * 2] = pcm8k[i];
        pcm16k[i * 2 + 1] = Math.round((pcm8k[i] + pcm8k[i + 1]) / 2);
    }
    pcm16k[(pcm8k.length - 1) * 2] = pcm8k[pcm8k.length - 1];
    pcm16k[(pcm8k.length - 1) * 2 + 1] = pcm8k[pcm8k.length - 1];
    
    // Convert to base64
    const bytes = new Uint8Array(pcm16k.buffer);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

// Convert PCM 16-bit 24kHz (Gemini output) to mulaw 8kHz (Twilio)
function pcm24kToMulaw8k(pcmBase64) {
    const binaryString = atob(pcmBase64);
    const len = binaryString.length;
    const pcm24k = new Int16Array(len / 2);
    const view = new DataView(new ArrayBuffer(len));
    for (let i = 0; i < len; i++) {
        view.setUint8(i, binaryString.charCodeAt(i));
    }
    for (let i = 0; i < len / 2; i++) {
        pcm24k[i] = view.getInt16(i * 2, true);
    }
    
    // Downsample 24kHz → 8kHz (take every 3rd sample)
    const pcm8k = new Int16Array(Math.floor(pcm24k.length / 3));
    for (let i = 0; i < pcm8k.length; i++) {
        pcm8k[i] = pcm24k[i * 3];
    }
    
    // PCM to mu-law encode
    const MULAW_MAX = 0x1FFF;
    const MULAW_BIAS = 33;
    const mulawBytes = new Uint8Array(pcm8k.length);
    
    for (let i = 0; i < pcm8k.length; i++) {
        let sample = pcm8k[i];
        const sign = sample < 0 ? 0x80 : 0;
        if (sample < 0) sample = -sample;
        sample = Math.min(sample, MULAW_MAX);
        sample += MULAW_BIAS;
        
        let exponent = 7;
        const expMask = 0x4000;
        for (; exponent > 0; exponent--) {
            if (sample & (expMask >> (7 - exponent))) break;
        }
        
        const mantissa = (sample >> (exponent + 3)) & 0x0F;
        const mulaw = ~(sign | (exponent << 4) | mantissa) & 0xFF;
        mulawBytes[i] = mulaw;
    }
    
    // Convert to base64
    let binary = '';
    for (let i = 0; i < mulawBytes.length; i++) {
        binary += String.fromCharCode(mulawBytes[i]);
    }
    return btoa(binary);
}

// ─── Main handler ───
Deno.serve(async (req) => {
    try {
        const url = new URL(req.url);
        const companyId = url.searchParams.get('companyId') || '695944e3c1fb00b7ab716c6f';
        const companyName = decodeURIComponent(url.searchParams.get('companyName') || 'CompanySync');
        
        const RAILWAY_HOST = Deno.env.get('SARAH_VOICE_BRIDGE_URL') || 'sarah-media-stream-bridge-production.up.railway.app';
        const BRIDGE_SECRET = Deno.env.get('SARAH_BRIDGE_SECRET') || '';
        
        console.log(`📞 Incoming call for ${companyName} (${companyId})`);
        console.log(`📞 Request method: ${req.method}`);
        console.log(`📞 Railway host: ${RAILWAY_HOST}`);
        
        // NOTE: Twilio webhooks have NO auth token - we must use service role directly
        // createClientFromRequest won't work here since Twilio sends form-encoded POST, not JSON with auth
        let base44 = null;
        try {
            base44 = createClientFromRequest(req);
        } catch (e) {
            console.log('⚠️ Could not create client from request (expected for Twilio webhooks):', e.message);
        }
        
        // Load Sarah settings - skip if no client available
        let settings = { systemPrompt: '', knowledgeBase: '', voiceId: 'Kore' };
        if (base44) {
            try {
                settings = await loadSettings(companyId, base44);
            } catch (e) {
                console.error('⚠️ Failed to load settings:', e.message);
            }
        }
        
        // Build full system instruction
        const systemInstruction = buildSystemInstruction(settings, companyName);
        
        // Truncate system prompt to avoid exceeding URL length limits
        const maxPromptLen = 2000;
        const truncatedPrompt = systemInstruction.length > maxPromptLen 
            ? systemInstruction.substring(0, maxPromptLen) + '...' 
            : systemInstruction;
        
        // Build Railway WebSocket URL
        const wsUrl = `wss://${RAILWAY_HOST}/`;
        
        console.log(`📞 Returning TwiML with Stream → ${wsUrl}`);
        
        const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">Hi there! One moment while I connect you.</Say>
    <Pause length="1"/>
    <Connect>
        <Stream url="${escapeXml(wsUrl)}">
            <Parameter name="secret" value="${escapeXml(BRIDGE_SECRET)}" />
            <Parameter name="companyId" value="${escapeXml(companyId)}" />
            <Parameter name="companyName" value="${escapeXml(companyName)}" />
            <Parameter name="systemPrompt" value="${escapeXml(truncatedPrompt)}" />
            <Parameter name="voice" value="${escapeXml(settings.voiceId || 'Kore')}" />
        </Stream>
    </Connect>
</Response>`;
        
        return new Response(twiml, {
            headers: { 'Content-Type': 'text/xml' }
        });
    } catch (error) {
        console.error('❌ FATAL ERROR in sarahMediaStreamHandler:', error);
        // Even on error, return valid TwiML so the call doesn't just die silently
        const fallbackTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">I'm sorry, we're experiencing technical difficulties. Please try again later.</Say>
    <Hangup/>
</Response>`;
        return new Response(fallbackTwiml, {
            headers: { 'Content-Type': 'text/xml' }
        });
    }
});

function escapeXml(unsafe) {
    if (!unsafe) return '';
    return String(unsafe).replace(/[<>&"']/g, (c) => {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '"': return '&quot;';
            case "'": return '&apos;';
        }
    });
}

function buildSystemInstruction(settings, companyName) {
    let prompt = settings.systemPrompt 
        ? settings.systemPrompt 
        : `You are Sarah, a friendly and professional receptionist for ${companyName}.`;
    
    // Personality
    const assertiveness = settings.sarahSettings?.personality_assertiveness ?? 50;
    const humor = settings.sarahSettings?.personality_humor ?? 20;
    if (assertiveness <= 25) prompt += '\nSTYLE: Gentle, suggestive tone.';
    else if (assertiveness >= 75) prompt += '\nSTYLE: Direct, confident tone.';
    if (humor >= 60) prompt += ' Warm and witty.';
    else if (humor <= 15) prompt += ' Strictly professional.';
    
    // Knowledge base (trimmed for speed)
    if (settings.knowledgeBase) {
        const trimmed = settings.knowledgeBase.length > 3000 
            ? settings.knowledgeBase.substring(0, 3000) + '...' 
            : settings.knowledgeBase;
        prompt += `\n\nKNOWLEDGE BASE:\n${trimmed}`;
    }
    
    prompt += `\n\nRULES (VOICE CALL):
- Answer directly in 2-3 sentences max. Be natural and warm.
- Use your knowledge base to answer questions.
- Never say you're an AI. You are Sarah, a real person.
- After answering, suggest one logical next step.
- Keep responses SHORT - this is a phone call, not an essay.
- If asked about emergencies, escalate immediately.`;
    
    return prompt;
}