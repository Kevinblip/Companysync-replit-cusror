import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        console.log('🔄 === AUTO-SYNC ALL CALENDARS STARTED ===');
        
        const base44 = createClientFromRequest(req);
        
        // Get app connector access token (shared by all users)
        let accessToken;
        try {
            accessToken = await base44.asServiceRole.connectors.getAccessToken("googlecalendar");
            if (!accessToken) {
                throw new Error('No access token available');
            }
            console.log('✅ Got App Connector Access Token');
        } catch (e) {
            console.error('❌ App Connector not available:', e.message);
            return Response.json({ error: 'Google Calendar app connector not configured', details: e.message }, { status: 500 });
        }

        // Get all users with staff profiles (active subscribers)
        const allStaffProfiles = await base44.asServiceRole.entities.StaffProfile.list('-created_date', 1000);
        const uniqueEmails = [...new Set(allStaffProfiles.map(s => s.user_email).filter(Boolean))];
        
        console.log(`📋 Found ${uniqueEmails.length} users to sync`);

        let totalCreated = 0;
        let totalUpdated = 0;
        let totalDeleted = 0;
        let usersProcessed = 0;
        let usersFailed = 0;

        // Time range for sync
        const timeMin = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
        const timeMax = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString();

        // Fetch all Google Calendar events once
        let googleEvents = [];
        try {
            const googleResponse = await fetch(
                `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${timeMin}&timeMax=${timeMax}&singleEvents=true&orderBy=startTime&maxResults=500&showDeleted=true`,
                { headers: { 'Authorization': `Bearer ${accessToken}` } }
            );

            if (!googleResponse.ok) {
                const errorText = await googleResponse.text();
                throw new Error(`Google API error (${googleResponse.status}): ${errorText}`);
            }

            const googleData = await googleResponse.json();
            googleEvents = googleData.items || [];
            console.log(`📥 Fetched ${googleEvents.length} events from Google Calendar`);
        } catch (e) {
            console.error('❌ Failed to fetch Google Calendar:', e.message);
            return Response.json({ error: 'Failed to fetch from Google Calendar', details: e.message }, { status: 500 });
        }

        // Process each user
        for (const userEmail of uniqueEmails) {
            try {
                console.log(`👤 Processing: ${userEmail}`);

                // Get user's company ID
                const staffProfile = allStaffProfiles.find(s => s.user_email === userEmail);
                let companyId = staffProfile?.company_id;

                if (!companyId) {
                    const companies = await base44.asServiceRole.entities.Company.filter({ created_by: userEmail });
                    companyId = companies[0]?.id;
                }

                if (!companyId) {
                    console.log(`⚠️ No company found for ${userEmail}, skipping`);
                    continue;
                }

                // Get company timezone
                let companyTimezone = 'America/New_York';
                try {
                    const companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
                    if (companies[0]?.timezone) {
                        companyTimezone = companies[0].timezone;
                    }
                } catch (err) {}

                // Sync FROM Google TO CRM
                for (const gEvent of googleEvents) {
                    try {
                        // Handle deletions
                        if (gEvent.status === 'cancelled') {
                            const existing = await base44.asServiceRole.entities.CalendarEvent.filter({ 
                                google_event_id: gEvent.id,
                                company_id: companyId 
                            });
                            if (existing.length > 0) {
                                await base44.asServiceRole.entities.CalendarEvent.delete(existing[0].id);
                                totalDeleted++;
                            }
                            continue;
                        }

                        if (!gEvent.start?.dateTime && !gEvent.start?.date) continue;

                        const startTime = gEvent.start.dateTime || gEvent.start.date;
                        const endTime = gEvent.end?.dateTime || gEvent.end?.date || startTime;

                        // Check if event exists in CRM for this company
                        const existing = await base44.asServiceRole.entities.CalendarEvent.filter({ 
                            google_event_id: gEvent.id,
                            company_id: companyId
                        });

                        const eventData = {
                            title: gEvent.summary || 'Untitled Event',
                            description: gEvent.description || '',
                            start_time: new Date(startTime).toISOString(),
                            end_time: new Date(endTime).toISOString(),
                            location: gEvent.location || '',
                            google_event_id: gEvent.id,
                            google_calendar_id: 'primary',
                            assigned_to: userEmail,
                            event_type: 'meeting',
                            color: '#3b82f6',
                            company_id: companyId
                        };

                        if (existing.length > 0) {
                            const crmUpdated = new Date(existing[0].updated_date).getTime();
                            const googleUpdated = new Date(gEvent.updated).getTime();

                            if (googleUpdated > crmUpdated) {
                                await base44.asServiceRole.entities.CalendarEvent.update(existing[0].id, eventData);
                                totalUpdated++;
                            }
                        } else {
                            await base44.asServiceRole.entities.CalendarEvent.create(eventData);
                            totalCreated++;
                        }
                    } catch (eventError) {
                        console.error(`⚠️ Error processing event for ${userEmail}:`, eventError.message);
                    }
                }

                // Sync FROM CRM TO Google (push new CRM events)
                const crmEvents = await base44.asServiceRole.entities.CalendarEvent.filter({
                    company_id: companyId,
                    assigned_to: userEmail
                }, '-start_time', 500);

                for (const crmEvent of crmEvents) {
                    try {
                        if (!crmEvent.start_time) continue;
                        if (crmEvent.google_event_id) continue; // Already synced

                        const eventTime = new Date(crmEvent.start_time);
                        const now = new Date();
                        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                        const oneYearFromNow = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);

                        if (eventTime < thirtyDaysAgo || eventTime > oneYearFromNow) continue;

                        const googleEventData = {
                            summary: crmEvent.title || 'Untitled',
                            description: crmEvent.description || '',
                            location: crmEvent.location || '',
                            start: {
                                dateTime: new Date(crmEvent.start_time).toISOString(),
                                timeZone: companyTimezone
                            },
                            end: {
                                dateTime: new Date(crmEvent.end_time || crmEvent.start_time).toISOString(),
                                timeZone: companyTimezone
                            }
                        };

                        const createResponse = await fetch(
                            'https://www.googleapis.com/calendar/v3/calendars/primary/events',
                            {
                                method: 'POST',
                                headers: { 
                                    'Authorization': `Bearer ${accessToken}`, 
                                    'Content-Type': 'application/json' 
                                },
                                body: JSON.stringify(googleEventData)
                            }
                        );

                        if (createResponse.ok) {
                            const newGoogleEvent = await createResponse.json();
                            await base44.asServiceRole.entities.CalendarEvent.update(crmEvent.id, { 
                                google_event_id: newGoogleEvent.id 
                            });
                            totalCreated++;
                        }
                    } catch (pushError) {
                        console.error(`⚠️ Error pushing CRM event to Google:`, pushError.message);
                    }
                }

                // Update user's last sync time
                try {
                    const users = await base44.asServiceRole.entities.User.filter({ email: userEmail });
                    if (users[0]) {
                        await base44.asServiceRole.entities.User.update(users[0].id, { 
                            last_google_sync: new Date().toISOString() 
                        });
                    }
                } catch (e) {}

                usersProcessed++;
            } catch (userError) {
                console.error(`❌ Failed to process ${userEmail}:`, userError.message);
                usersFailed++;
            }
        }

        console.log('✅ === AUTO-SYNC ALL CALENDARS COMPLETED ===');
        console.log(`📊 Users: ${usersProcessed} processed, ${usersFailed} failed`);
        console.log(`📊 Events: ${totalCreated} created, ${totalUpdated} updated, ${totalDeleted} deleted`);

        return Response.json({
            success: true,
            usersProcessed,
            usersFailed,
            events: {
                created: totalCreated,
                updated: totalUpdated,
                deleted: totalDeleted
            }
        });

    } catch (error) {
        console.error('❌ Auto-sync error:', error.message);
        return Response.json({ error: error.message }, { status: 500 });
    }
});