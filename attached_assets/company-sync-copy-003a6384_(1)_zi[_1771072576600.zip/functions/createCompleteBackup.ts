import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { companyId, backupName } = await req.json();

    if (!companyId) {
      return Response.json({ error: 'Company ID required' }, { status: 400 });
    }

    console.log(`Creating complete backup for company ${companyId}...`);

    // List of all entities to backup
    const entityTypes = [
      'Customer', 'Lead', 'Invoice', 'Payment', 'Estimate', 'Task', 
      'Project', 'Communication', 'CalendarEvent', 'Item', 'PriceListItem',
      'Proposal', 'DroneInspection', 'IntegrationSetting', 'EstimateFormat',
      'CalendarSettings', 'TaskBoard', 'Contract', 'StormEvent', 
      'StormAlertSettings', 'MenuSettings', 'CustomField', 'ImportLog',
      'EmailTemplate', 'SMSTemplate', 'Workflow', 'LeadScore',
      'WorkflowExecution', 'KnowledgeBaseArticle', 'Document', 'Signature',
      'Message', 'SavedReport', 'DashboardWidget', 'RevenueGoal',
      'AITrainingData', 'Property', 'ContractTemplate', 'GeneratedContract',
      'ContractSigningSession', 'AIMemory', 'ConversationHistory',
      'StaffProfile', 'Transaction', 'ChartOfAccount', 'StaffRole',
      'JobMedia', 'InspectionJob', 'CommissionDeduction', 'TaxRate',
      'CustomerGroup', 'EstimateTemplate', 'InspectorProfile',
      'QuickBooksSettings', 'Notification', 'SubscriptionUsage',
      'CommissionRule', 'DailyReport', 'GoogleChatSettings', 'EstimateVersion',
      'InspectionReportTemplate', 'EmailTracking', 'IntegrationCredential',
      'CommissionPayment', 'NotificationPreference', 'SlackSettings',
      'DashboardSettings', 'FieldActivity', 'Territory', 'RepLocation',
      'RoundRobinSettings', 'Campaign', 'TrainingVideo', 'FamilyMember',
      'FamilyCommissionRecord', 'LeadSource', 'Payout', 'ChartOfAccounts',
      'Expense', 'BankAccount', 'Subcontractor', 'Vendor', 'BuildingCode',
      'ReviewRequest', 'AssistantSettings', 'ImpersonationLog', 'CompanySetting'
    ];

    const backupData = {};
    const entityCounts = {};

    // Backup each entity type
    for (const entityType of entityTypes) {
      try {
        const records = await base44.asServiceRole.entities[entityType].filter({ 
          company_id: companyId 
        });
        backupData[entityType] = records;
        entityCounts[entityType] = records.length;
        console.log(`Backed up ${records.length} ${entityType} records`);
      } catch (err) {
        console.log(`Entity ${entityType} not found or error: ${err.message}`);
        backupData[entityType] = [];
        entityCounts[entityType] = 0;
      }
    }

    // Also backup the Company record itself
    try {
      const company = await base44.asServiceRole.entities.Company.filter({ id: companyId });
      backupData['Company'] = company;
      entityCounts['Company'] = company.length;
    } catch (err) {
      console.log(`Error backing up Company: ${err.message}`);
    }

    // Create the backup record
    const backup = await base44.asServiceRole.entities.CompleteBackup.create({
      backup_name: backupName || `Backup ${new Date().toLocaleString()}`,
      company_id: companyId,
      company_name: backupData.Company?.[0]?.company_name || 'Unknown',
      backup_data: backupData,
      entity_counts: entityCounts,
      created_by_email: user.email
    });

    const totalRecords = Object.values(entityCounts).reduce((sum, count) => sum + count, 0);

    return Response.json({
      success: true,
      backup_id: backup.id,
      total_records: totalRecords,
      entity_counts: entityCounts,
      message: `Backup created successfully with ${totalRecords} total records`
    });

  } catch (error) {
    console.error('Backup error:', error);
    return Response.json({ 
      success: false, 
      error: error.message 
    }, { status: 500 });
  }
});