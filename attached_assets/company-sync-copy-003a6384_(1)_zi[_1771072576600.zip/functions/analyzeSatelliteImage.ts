import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// FORCE UPDATE V3 - Fixed static map handling
Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { address } = await req.json();
        if (!address) {
            return Response.json({ error: 'Address is required' }, { status: 400 });
        }

        const apiKey = Deno.env.get("GOOGLE_MAPS_API_KEY");
        if (!apiKey) {
            return Response.json({ error: 'Google Maps API key not configured' }, { status: 500 });
        }

        // 1. Geocode
        let lat = null;
        let lng = null;
        
        console.log(`Starting analysis V3 for: ${address}`);

        // Try Google Geocoding first
        try {
            console.log('Attempting Google Geocoding...');
            const geoResponse = await fetch(
                `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${apiKey}`
            );
            const geoData = await geoResponse.json();
            
            if (geoData.status === 'OK' && geoData.results[0]) {
                lat = geoData.results[0].geometry.location.lat;
                lng = geoData.results[0].geometry.location.lng;
                console.log(`Google Geocoding success: ${lat}, ${lng}`);
            } else {
                console.warn(`Google Geocoding failed: ${geoData.status}`);
            }
        } catch (e) {
            console.warn(`Google Geocoding exception: ${e.message}`);
        }

        // Fallback to Nominatim if Google failed
        if (!lat || !lng) {
            console.log('Falling back to Nominatim for geocoding...');
            try {
                const nominatimUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`;
                const nominatimResp = await fetch(nominatimUrl, {
                    headers: { 'User-Agent': 'Base44App/1.0 (base44.ai)' }
                });
                
                if (nominatimResp.ok) {
                    const nominatimData = await nominatimResp.json();
                    if (nominatimData && nominatimData.length > 0) {
                        lat = parseFloat(nominatimData[0].lat);
                        lng = parseFloat(nominatimData[0].lon);
                        console.log(`Nominatim success: ${lat}, ${lng}`);
                    } else {
                        console.warn('Nominatim returned no results');
                    }
                } else {
                    console.warn(`Nominatim failed: ${nominatimResp.status}`);
                }
            } catch (e) {
                console.error(`Nominatim Geocoding error: ${e.message}`);
            }
        }

        if (!lat || !lng) {
            return Response.json({ error: 'Geocoding failed. Could not determine location.' }, { status: 400 });
        }

        // 2. Generate Satellite URL & Upload to Storage
        const staticMapUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${lat},${lng}&zoom=20&size=600x600&maptype=satellite&key=${apiKey}`;
        console.log(`Fetching static map: ${staticMapUrl}`);
        
        let satellite_image_url = staticMapUrl;
        
        try {
            const mapResp = await fetch(staticMapUrl);
            if (mapResp.ok) {
                const mapBlob = await mapResp.blob();
                console.log(`Downloaded map blob type: ${mapBlob.type}, size: ${mapBlob.size}`);
                
                // Convert to File object for upload
                const mapFile = new File([mapBlob], "satellite_view.png", { type: "image/png" });
                
                console.log('Uploading satellite image to storage...');
                const uploadRes = await base44.integrations.Core.UploadFile({ file: mapFile });
                if (uploadRes && uploadRes.file_url) {
                    satellite_image_url = uploadRes.file_url;
                    console.log(`Uploaded satellite URL: ${satellite_image_url}`);
                } else {
                    console.warn('UploadFile returned no file_url');
                }
            } else {
                console.warn(`Static Map API fetch failed: ${mapResp.status} ${mapResp.statusText}`);
                // Fallback to URL (might fail in LLM, but worth a try)
            }
        } catch (e) {
            console.error('Error fetching/uploading static map:', e);
        }

        // 3. Analyze with AI
        console.log('Invoking LLM for analysis...');
        const analysis = await base44.integrations.Core.InvokeLLM({
            prompt: `Analyze this satellite image of a property at ${address}.
            Focus on the ROOF layout.
            1. Describe the complexity (simple gable, hip, complex, etc).
            2. Identify the main roof sections/facets.
            3. Estimate the orientation of each section (Front, Back, Left, Right relative to the street).
            
            Provide a concise 'ai_description' and a list of 'sections_identified'.`,
            file_urls: [satellite_image_url],
            response_json_schema: {
                type: "object",
                properties: {
                    ai_description: { type: "string" },
                    sections_identified: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                section_name: { type: "string", description: "e.g. Front Slope, Back Slope" },
                                orientation: { type: "string", description: "e.g. North, South, Front, Back" },
                                description: { type: "string", description: "Brief description" }
                            },
                            required: ["section_name", "orientation", "description"]
                        }
                    }
                },
                required: ["ai_description", "sections_identified"]
            }
        });

        console.log('LLM Analysis complete');

        return Response.json({
            success: true,
            satellite_image_url,
            roof_layout_analysis: analysis,
            location: { lat, lng }
        });

    } catch (error) {
        console.error('analyzeSatelliteImage critical error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});