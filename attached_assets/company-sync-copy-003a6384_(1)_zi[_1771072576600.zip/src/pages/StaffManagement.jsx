import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useSubscriptionLimits } from "@/components/hooks/useSubscriptionLimits";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserPlus, Edit, Search, Download, AlertCircle, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Switch } from "@/components/ui/switch";
import { formatDistanceToNow } from "date-fns";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function StaffManagement() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [pageSize, setPageSize] = useState("25");
  const { canCreateStaff } = useSubscriptionLimits();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles', user?.email],
    queryFn: () => user ? base44.entities.StaffProfile.filter({ user_email: user.email }) : [],
    enabled: !!user,
    initialData: [],
  });

  const myCompany = React.useMemo(() => {
    if (!user) return null;

    // Priority 1: Impersonation
    const impersonatedId = typeof window !== 'undefined' ? sessionStorage.getItem('impersonating_company_id') : null;
    if (impersonatedId) {
      const target = companies.find(c => c.id === impersonatedId);
      if (target) return target;
    }

    // Priority 2: Staff profile company
    const staffProfile = staffProfiles[0];
    if (staffProfile?.company_id) {
      const profileCompany = companies.find(c => c.id === staffProfile.company_id);
      if (profileCompany) return profileCompany;
    }

    // Priority 3: Owned company
    const ownedCompany = companies.find(c => c.created_by === user.email);
    if (ownedCompany) return ownedCompany;
    return null;
  }, [user, companies, staffProfiles]);

  const handleNewStaffClick = async () => {
    if (!myCompany?.id) return;
    const canAdd = await canCreateStaff(myCompany.id);
    if (canAdd) {
      handleEditClick('new');
    }
  };

  const { data: companyStaffProfiles = [] } = useQuery({
    queryKey: ['company-staff-profiles', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.StaffProfile.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const updateProfileMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.StaffProfile.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-staff-profiles'] });
    }
  });

  const deleteProfileMutation = useMutation({
    mutationFn: (id) => base44.entities.StaffProfile.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-staff-profiles'] });
    }
  });

  // Show ALL staff profiles, with a flag if they don't have a User account yet
  const staff = companyStaffProfiles
    .map(profile => ({
      ...profile,
      profile_id: profile.id,
      full_name: profile.full_name,
      email: profile.user_email,
      position: profile.position,
      phone: profile.phone,
      twilio_number: profile.twilio_number, // Kept for consistency with original profile, even if not displayed
      whatsapp_enabled: profile.whatsapp_enabled, // Kept for consistency with original profile, even if not displayed
      is_active: profile.is_active,
      avatar_url: profile.avatar_url,
      commission_rate: profile.commission_rate,
      is_administrator: profile.is_administrator,
      is_super_admin: profile.is_super_admin,
      role_name: profile.role_name,
      last_login: profile.last_login,
    }))
    .filter(s => 
      s.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.position?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.role_name?.toLowerCase().includes(searchTerm.toLowerCase()) // Added role_name to search
    );

  const handleToggleActive = (member) => {
    if (member.profile_id) {
      updateProfileMutation.mutate({
        id: member.profile_id,
        data: { is_active: !member.is_active }
      });
    }
  };

  const handleToggleWhatsApp = (member) => {
    // This function is no longer triggered by a displayed switch, but kept if needed elsewhere.
    if (member.profile_id) {
      updateProfileMutation.mutate({
        id: member.profile_id,
        data: { whatsapp_enabled: !member.whatsapp_enabled }
      });
    }
  };
  
  const handleEditClick = (email) => {
    navigate(createPageUrl(`StaffProfilePage`) + `?email=${encodeURIComponent(email)}`);
  };

  const handleDelete = (member) => {
    if (window.confirm(`⚠️ Delete ${member.full_name}?\n\nThis will remove their staff profile but NOT delete their user account.\n\nAre you sure?`)) {
      deleteProfileMutation.mutate(member.profile_id);
    }
  };

  const [deleteEmail, setDeleteEmail] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteOrphanedAccount = async () => {
    if (!deleteEmail) {
      alert('Please enter an email address');
      return;
    }
    
    if (!confirm(`🗑️ Delete authentication account for ${deleteEmail}?\n\nThis will allow the email to be reused.\n\nAre you sure?`)) {
      return;
    }
    
    setIsDeleting(true);
    try {
      await base44.functions.invoke('deleteUserAccount', { email: deleteEmail });
      alert(`✅ User account ${deleteEmail} deleted successfully!`);
      setDeleteEmail("");
    } catch (error) {
      alert(`❌ Failed: ${error.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-white min-h-screen">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Staff</h1>
        <Button onClick={handleNewStaffClick}>
          <UserPlus className="w-4 h-4 mr-2" />
          New Staff Member
        </Button>
      </div>



      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
            <Select value={pageSize} onValueChange={setPageSize}>
                <SelectTrigger className="w-20">
                    <SelectValue placeholder="25" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                </SelectContent>
            </Select>
            <Button variant="outline">
                <Download className="w-4 h-4 mr-2"/>
                Export
            </Button>
        </div>
        <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input 
                placeholder="Search..." 
                className="pl-10"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
            />
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="p-4 text-left font-semibold text-gray-600">Full name</th>
                  <th className="p-4 text-left font-semibold text-gray-600">Email</th>
                  <th className="p-4 text-left font-semibold text-gray-600">Role</th>
                  <th className="p-4 text-left font-semibold text-gray-600">Position</th>
                  <th className="p-4 text-left font-semibold text-gray-600">Last Login</th>
                  <th className="p-4 text-left font-semibold text-gray-600">Commission %</th>
                  <th className="p-4 text-left font-semibold text-gray-600">Active</th>
                  <th className="p-4 text-left font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {staff.map((member) => (
                  <tr key={member.profile_id} className="hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={member.avatar_url} />
                          <AvatarFallback>{member.full_name?.charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <span className="font-medium">{member.full_name}</span>
                          {member.is_super_admin && (
                            <Badge className="ml-2 bg-purple-100 text-purple-700 text-xs">Super Admin</Badge>
                          )}
                          {member.is_administrator && !member.is_super_admin && (
                            <Badge className="ml-2 bg-red-100 text-red-700 text-xs">Admin</Badge>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-gray-600">{member.email}</td>
                    <td className="p-4">
                      {member.role_name ? (
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">
                          {member.role_name}
                        </Badge>
                      ) : (
                        <span className="text-gray-400 text-sm">No role</span>
                      )}
                    </td>
                    <td className="p-4 text-gray-600">
                        {member.position || <span className="text-gray-400">—</span>}
                    </td>
                    <td className="p-4 text-gray-600">
                        {member.last_login ? (
                            <span>{formatDistanceToNow(new Date(member.last_login), { addSuffix: true })}</span>
                        ) : (
                            <span className="text-gray-400">Never</span>
                        )}
                    </td>
                    <td className="p-4">
                      {member.commission_rate ? (
                        <Badge className="bg-green-100 text-green-800 font-semibold">
                          {member.commission_rate}%
                        </Badge>
                      ) : (
                        <span className="text-gray-400 text-sm">Not set</span>
                      )}
                    </td>
                    <td className="p-4">
                      <Switch
                        checked={member.is_active ?? true}
                        onCheckedChange={() => handleToggleActive(member)}
                      />
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" onClick={() => handleEditClick(member.email)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDelete(member)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>

                      </div>
                    </td>
                  </tr>
                ))}
                {staff.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-gray-500">
                      <UserPlus className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <h3 className="text-lg font-semibold mb-2">No Staff Members Yet</h3>
                      <p>Click "New Staff Member" to add your team</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}