import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Plus,
  Play,
  Save,
  Download,
  Mail,
  Star,
  Trash2,
  Calendar,
  Filter
} from "lucide-react";
import { format } from "date-fns";

export default function ReportBuilder() {
  const [user, setUser] = React.useState(null);
  const [reportConfig, setReportConfig] = useState({
    report_name: "",
    report_type: "invoices",
    columns: [],
    filters: {
      date_range: "30days",
      start_date: "",
      end_date: "",
      status: [],
      custom_fields: {}
    },
    sort_by: "created_date",
    sort_order: "desc",
    schedule: {
      enabled: false,
      frequency: "weekly",
      recipients: []
    }
  });

  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [previewData, setPreviewData] = useState([]);
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles'],
    queryFn: () => base44.entities.StaffProfile.list("-created_date", 1000),
    initialData: [],
    enabled: !!user,
  });

  const myStaffProfile = React.useMemo(() => {
    if (!user) return null;
    return staffProfiles.find(s => s.user_email === user.email);
  }, [user, staffProfiles]);

  const isAdmin = myStaffProfile?.is_administrator || false;

  const { data: staffRoles = [] } = useQuery({
    queryKey: ['staff-roles', myStaffProfile?.role_id],
    queryFn: () => myStaffProfile?.role_id ? base44.entities.StaffRole.filter({ id: myStaffProfile.role_id }) : [],
    enabled: !!myStaffProfile?.role_id && !isAdmin,
    initialData: [],
  });

  const myRole = staffRoles[0];

  const hasPermission = (feature, capability) => {
    if (isAdmin) return true;
    if (!myRole) return false;
    const rolePermissions = myRole.permissions || {};
    
    if (capability === 'view') {
      return rolePermissions[feature]?.view === true || 
             rolePermissions[feature]?.view_own === true || 
             rolePermissions[feature]?.view_global === true;
    }
    
    return rolePermissions[feature]?.[capability] === true;
  };

  const canViewGlobal = (feature) => {
    if (isAdmin) return true;
    if (!myRole) return false;
    const rolePermissions = myRole.permissions || {};
    return rolePermissions[feature]?.view_global === true || rolePermissions[feature]?.view === true;
  };

  const { data: savedReports = [] } = useQuery({
    queryKey: ['saved-reports'],
    queryFn: () => base44.entities.SavedReport.list("-created_date"),
    initialData: [],
  });

  const { data: allInvoices = [] } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list("-created_date", 10000),
    initialData: [],
    enabled: reportConfig.report_type === 'invoices'
  });

  const invoices = React.useMemo(() => {
    if (!user?.email || !reportConfig.report_type === 'invoices') return allInvoices;
    if (canViewGlobal('invoices')) return allInvoices;
    // Only see their own sales
    return allInvoices.filter(inv => inv.sale_agent === user.email);
  }, [allInvoices, user?.email, isAdmin, myRole, reportConfig.report_type]);

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list("-created_date", 10000),
    initialData: [],
    enabled: !!user
  });

  const { data: allEstimates = [] } = useQuery({
    queryKey: ['estimates'],
    queryFn: () => base44.entities.Estimate.list("-created_date", 10000),
    initialData: [],
    enabled: reportConfig.report_type === 'estimates'
  });

  const estimates = React.useMemo(() => {
    if (!user?.email || !reportConfig.report_type === 'estimates') return allEstimates;
    if (canViewGlobal('estimates')) return allEstimates;
    // Only see estimates for their assigned customers
    return allEstimates.filter(est => {
      const customer = customers.find(c => c.name === est.customer_name);
      if (!customer) return false;
      return customer.assigned_to === user.email || customer.assigned_to_users?.includes(user.email);
    });
  }, [allEstimates, user?.email, isAdmin, myRole, customers, reportConfig.report_type]);

  const { data: allPayments = [] } = useQuery({
    queryKey: ['payments'],
    queryFn: () => base44.entities.Payment.list("-payment_date", 10000),
    initialData: [],
    enabled: reportConfig.report_type === 'payments'
  });

  const payments = React.useMemo(() => {
    if (!user?.email || !reportConfig.report_type === 'payments') return allPayments;
    if (canViewGlobal('payments')) return allPayments;
    // Only see payments from their customers
    return allPayments.filter(payment => {
      const customer = customers.find(c => c.name === payment.customer_name);
      if (!customer) return false;
      return customer.assigned_to === user.email || customer.assigned_to_users?.includes(user.email);
    });
  }, [allPayments, user?.email, isAdmin, myRole, customers, reportConfig.report_type]);

  const { data: allCustomers = [] } = useQuery({
    queryKey: ['all-customers'],
    queryFn: () => base44.entities.Customer.list("-created_date", 10000),
    initialData: [],
    enabled: reportConfig.report_type === 'customers'
  });

  const filteredCustomers = React.useMemo(() => {
    if (!user?.email || !reportConfig.report_type === 'customers') return allCustomers;
    if (canViewGlobal('customers')) return allCustomers;
    // Only see their assigned customers
    return allCustomers.filter(c => 
      c.assigned_to === user.email || c.assigned_to_users?.includes(user.email)
    );
  }, [allCustomers, user?.email, isAdmin, myRole, reportConfig.report_type]);

  const { data: allLeads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date", 10000),
    initialData: [],
    enabled: reportConfig.report_type === 'leads'
  });

  const leads = React.useMemo(() => {
    if (!user?.email || !reportConfig.report_type === 'leads') return allLeads;
    if (canViewGlobal('leads')) return allLeads;
    // Only see their assigned leads
    return allLeads.filter(l => 
      l.assigned_to === user.email || l.assigned_to_users?.includes(user.email)
    );
  }, [allLeads, user?.email, isAdmin, myRole, reportConfig.report_type]);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = React.useMemo(() => {
    if (!user) return null;
    return companies.find(c => c.created_by === user.email);
  }, [companies, user]);

  const { data: allExpenses = [] } = useQuery({
    queryKey: ['expenses'],
    queryFn: () => myCompany ? base44.entities.Expense.filter({ company_id: myCompany.id }) : [],
    initialData: [],
    enabled: reportConfig.report_type === 'expenses' && !!myCompany
  });

  const expenses = React.useMemo(() => {
    if (!user?.email || reportConfig.report_type !== 'expenses') return allExpenses;
    if (canViewGlobal('expenses')) return allExpenses;
    // Only see expenses from their customers
    return allExpenses.filter(exp => {
      if (!exp.customer_id) return false;
      const customer = customers.find(c => c.id === exp.customer_id);
      if (!customer) return false;
      return customer.assigned_to === user.email || customer.assigned_to_users?.includes(user.email);
    });
  }, [allExpenses, user?.email, isAdmin, myRole, customers, reportConfig.report_type]);

  const saveMutation = useMutation({
    mutationFn: (data) => base44.entities.SavedReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['saved-reports'] });
      setShowSaveDialog(false);
      alert('✅ Report saved successfully!');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SavedReport.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['saved-reports'] });
    },
  });

  const availableColumns = {
    invoices: [
      { id: 'invoice_number', label: 'Invoice #' },
      { id: 'customer_name', label: 'Customer' },
      { id: 'amount', label: 'Amount' },
      { id: 'status', label: 'Status' },
      { id: 'issue_date', label: 'Issue Date' },
      { id: 'due_date', label: 'Due Date' },
      { id: 'created_date', label: 'Created Date' }
    ],
    estimates: [
      { id: 'estimate_number', label: 'Estimate #' },
      { id: 'customer_name', label: 'Customer' },
      { id: 'amount', label: 'Amount' },
      { id: 'status', label: 'Status' },
      { id: 'valid_until', label: 'Valid Until' },
      { id: 'created_date', label: 'Created Date' }
    ],
    payments: [
      { id: 'payment_number', label: 'Payment #' },
      { id: 'customer_name', label: 'Customer' },
      { id: 'amount', label: 'Amount' },
      { id: 'payment_method', label: 'Method' },
      { id: 'payment_date', label: 'Date' },
      { id: 'reference_number', label: 'Reference' }
    ],
    customers: [
      { id: 'name', label: 'Name' },
      { id: 'email', label: 'Email' },
      { id: 'phone', label: 'Phone' },
      { id: 'company', label: 'Company' },
      { id: 'total_revenue', label: 'Total Revenue' },
      { id: 'created_date', label: 'Created Date' }
    ],
    leads: [
      { id: 'name', label: 'Name' },
      { id: 'email', label: 'Email' },
      { id: 'phone', label: 'Phone' },
      { id: 'status', label: 'Status' },
      { id: 'source', label: 'Source' },
      { id: 'value', label: 'Value' },
      { id: 'created_date', label: 'Created Date' }
    ],
    expenses: [
      { id: 'expense_date', label: 'Date' },
      { id: 'vendor_name', label: 'Vendor' },
      { id: 'category', label: 'Category' },
      { id: 'amount', label: 'Amount' },
      { id: 'description', label: 'Description' },
      { id: 'payment_method', label: 'Payment Method' },
      { id: 'customer_name', label: 'Customer' },
      { id: 'created_date', label: 'Created Date' }
    ]
  };

  const handleColumnToggle = (columnId) => {
    setReportConfig(prev => ({
      ...prev,
      columns: prev.columns.includes(columnId)
        ? prev.columns.filter(c => c !== columnId)
        : [...prev.columns, columnId]
    }));
  };

  const getDataSource = () => {
    switch(reportConfig.report_type) {
      case 'invoices': return invoices;
      case 'estimates': return estimates;
      case 'payments': return payments;
      case 'customers': return filteredCustomers;
      case 'leads': return leads;
      case 'expenses': return expenses;
      default: return [];
    }
  };

  const runReport = () => {
    const data = getDataSource();
    
    if (!data || data.length === 0) {
      const isLoading = reportConfig.report_type === 'invoices' ? invoices.length === 0 :
                       reportConfig.report_type === 'estimates' ? estimates.length === 0 :
                       reportConfig.report_type === 'payments' ? payments.length === 0 :
                       reportConfig.report_type === 'customers' ? filteredCustomers.length === 0 :
                       reportConfig.report_type === 'leads' ? leads.length === 0 :
                       reportConfig.report_type === 'expenses' ? expenses.length === 0 : false;
      
      if (isLoading) {
        return;
      }
    }
    
    let filtered = data.filter(item => {
      if (reportConfig.filters.status.length > 0) {
        if (!reportConfig.filters.status.includes(item.status)) return false;
      }
      
      return true;
    });

    filtered.sort((a, b) => {
      const aVal = a[reportConfig.sort_by];
      const bVal = b[reportConfig.sort_by];
      
      if (reportConfig.sort_order === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });

    setPreviewData(filtered || []);
  };

  const handleSave = () => {
    if (!reportConfig.report_name) {
      alert('Please enter a report name');
      return;
    }
    
    saveMutation.mutate(reportConfig);
  };

  const loadReport = (report) => {
    setReportConfig(report);
    runReport();
  };

  const exportToPDF = async () => {
    alert('PDF export coming soon!');
  };

  const exportToExcel = () => {
    // Convert to CSV
    const columns = availableColumns[reportConfig.report_type].filter(col => 
      reportConfig.columns.includes(col.id)
    );
    
    let csv = columns.map(col => col.label).join(',') + '\n';
    
    previewData.forEach(row => {
      csv += reportConfig.columns.map(colId => {
        let value = row[colId];
        if (colId.includes('date') && value) {
          value = format(new Date(value), 'yyyy-MM-dd');
        }
        return `"${value || ''}"`;
      }).join(',') + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${reportConfig.report_name || 'report'}.csv`;
    a.click();
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Custom Report Builder</h1>
          <p className="text-gray-500 mt-1">Build, save, and schedule custom reports</p>
        </div>

        <div className="flex gap-2">
          <Button 
            variant="outline"
            onClick={() => setShowSaveDialog(true)}
            disabled={reportConfig.columns.length === 0}
          >
            <Save className="w-4 h-4 mr-2" />
            Save Report
          </Button>

          <Button 
            onClick={runReport}
            disabled={reportConfig.columns.length === 0}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Play className="w-4 h-4 mr-2" />
            Run Report
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Configuration Panel */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Report Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Report Type</Label>
                <Select 
                  value={reportConfig.report_type} 
                  onValueChange={(value) => setReportConfig({...reportConfig, report_type: value, columns: []})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="invoices">Invoices</SelectItem>
                    <SelectItem value="estimates">Estimates</SelectItem>
                    <SelectItem value="payments">Payments</SelectItem>
                    <SelectItem value="expenses">Expenses</SelectItem>
                    <SelectItem value="customers">Customers</SelectItem>
                    <SelectItem value="leads">Leads</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="mb-2 block">Select Columns</Label>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {availableColumns[reportConfig.report_type]?.map(col => (
                    <div key={col.id} className="flex items-center gap-2">
                      <Checkbox
                        checked={reportConfig.columns.includes(col.id)}
                        onCheckedChange={() => handleColumnToggle(col.id)}
                        id={col.id}
                      />
                      <label htmlFor={col.id} className="text-sm cursor-pointer">
                        {col.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>Sort By</Label>
                <Select 
                  value={reportConfig.sort_by}
                  onValueChange={(value) => setReportConfig({...reportConfig, sort_by: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {availableColumns[reportConfig.report_type]?.map(col => (
                      <SelectItem key={col.id} value={col.id}>{col.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Sort Order</Label>
                <Select 
                  value={reportConfig.sort_order}
                  onValueChange={(value) => setReportConfig({...reportConfig, sort_order: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="asc">Ascending</SelectItem>
                    <SelectItem value="desc">Descending</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Date Range</Label>
                <Select 
                  value={reportConfig.filters.date_range}
                  onValueChange={(value) => setReportConfig({
                    ...reportConfig, 
                    filters: {...reportConfig.filters, date_range: value}
                  })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="7days">Last 7 Days</SelectItem>
                    <SelectItem value="30days">Last 30 Days</SelectItem>
                    <SelectItem value="90days">Last 90 Days</SelectItem>
                    <SelectItem value="year">This Year</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setShowScheduleDialog(true)}
              >
                <Calendar className="w-4 h-4 mr-2" />
                Schedule Report
              </Button>
            </CardContent>
          </Card>

          {/* Saved Reports */}
          <Card>
            <CardHeader>
              <CardTitle>Saved Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {savedReports.map(report => (
                  <div 
                    key={report.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer"
                    onClick={() => loadReport(report)}
                  >
                    <div className="flex items-center gap-2">
                      {report.is_favorite && <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />}
                      <div>
                        <p className="font-medium text-sm">{report.report_name}</p>
                        <p className="text-xs text-gray-500">{report.report_type}</p>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm('Delete this report?')) {
                          deleteMutation.mutate(report.id);
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>
                ))}
                {savedReports.length === 0 && (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No saved reports yet
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Preview Panel */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Report Preview</CardTitle>
              {previewData.length > 0 && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToExcel}>
                    <Download className="w-4 h-4 mr-2" />
                    Export CSV
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    <Download className="w-4 h-4 mr-2" />
                    Export PDF
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              {previewData.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        {reportConfig.columns.map(colId => {
                          const col = availableColumns[reportConfig.report_type].find(c => c.id === colId);
                          return (
                            <th key={colId} className="px-4 py-3 text-left text-sm font-semibold">
                              {col?.label}
                            </th>
                          );
                        })}
                      </tr>
                    </thead>
                    <tbody>
                      {previewData.slice(0, 100).map((row, idx) => (
                        <tr key={idx} className="border-b hover:bg-gray-50">
                          {reportConfig.columns.map(colId => (
                            <td key={colId} className="px-4 py-3 text-sm">
                              {colId.includes('date') && row[colId] 
                                ? format(new Date(row[colId]), 'MMM d, yyyy')
                                : colId === 'amount' || colId === 'value' || colId === 'total_revenue'
                                ? `$${(row[colId] || 0).toLocaleString()}`
                                : row[colId] || '-'
                              }
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <p className="text-sm text-gray-500 mt-4">
                    Showing {Math.min(100, previewData.length)} of {previewData.length} results
                  </p>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Filter className="w-12 h-12 mx-auto text-gray-400 mb-3" />
                  <p className="text-gray-500">Configure your report and click "Run Report" to see results</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Save Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Report Name</Label>
              <Input
                value={reportConfig.report_name}
                onChange={(e) => setReportConfig({...reportConfig, report_name: e.target.value})}
                placeholder="e.g., Monthly Revenue Report"
              />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                checked={reportConfig.is_favorite}
                onCheckedChange={(checked) => setReportConfig({...reportConfig, is_favorite: checked})}
                id="favorite"
              />
              <Label htmlFor="favorite" className="cursor-pointer">
                Add to favorites
              </Label>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
                Save Report
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Schedule Dialog */}
      <Dialog open={showScheduleDialog} onOpenChange={setShowScheduleDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Schedule Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Checkbox
                checked={reportConfig.schedule.enabled}
                onCheckedChange={(checked) => setReportConfig({
                  ...reportConfig,
                  schedule: {...reportConfig.schedule, enabled: checked}
                })}
                id="schedule-enabled"
              />
              <Label htmlFor="schedule-enabled" className="cursor-pointer">
                Enable scheduled reports
              </Label>
            </div>

            {reportConfig.schedule.enabled && (
              <>
                <div>
                  <Label>Frequency</Label>
                  <Select 
                    value={reportConfig.schedule.frequency}
                    onValueChange={(value) => setReportConfig({
                      ...reportConfig,
                      schedule: {...reportConfig.schedule, frequency: value}
                    })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly (Monday)</SelectItem>
                      <SelectItem value="monthly">Monthly (1st)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Email Recipients</Label>
                  <Input
                    placeholder="email@example.com, email2@example.com"
                    value={reportConfig.schedule.recipients?.join(', ')}
                    onChange={(e) => setReportConfig({
                      ...reportConfig,
                      schedule: {...reportConfig.schedule, recipients: e.target.value.split(',').map(s => s.trim())}
                    })}
                  />
                  <p className="text-xs text-gray-500 mt-1">Separate multiple emails with commas</p>
                </div>
              </>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowScheduleDialog(false)}>
                Cancel
              </Button>
              <Button onClick={() => {
                setShowScheduleDialog(false);
                alert('Schedule saved! Report will be sent automatically.');
              }} className="bg-blue-600 hover:bg-blue-700">
                Save Schedule
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}