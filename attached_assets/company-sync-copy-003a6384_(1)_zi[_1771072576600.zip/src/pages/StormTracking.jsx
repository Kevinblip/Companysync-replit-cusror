import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MapContainer, TileLayer, Circle, Popup, Marker, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';
import {
  Cloud,
  CloudRain,
  Wind,
  AlertTriangle,
  RefreshCw,
  MapPin,
  Users,
  Search,
  Settings,
  Info,
  CheckCircle,
  XCircle,
  Loader2,
  Bell,
  Filter,
  CheckCircle2,
  ChevronRight
} from "lucide-react";
import { format } from "date-fns";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import 'leaflet/dist/leaflet.css';

function getDistanceInMiles(lat1, lon1, lat2, lon2) {
  if (lat1 === null || lon1 === null || lat2 === null || lon2 === null || isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2)) return Infinity;
  const R = 3959;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Fix for default marker icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Helper to track map events
function MapEventsHandler({ onZoomEnd, onMoveEnd }) {
  const map = useMapEvents({
    zoomend: () => {
      onZoomEnd(map.getZoom());
    },
    moveend: () => {
      onMoveEnd(map.getCenter());
    }
  });
  return null;
}

// Controller to handle programmatic map updates without full re-renders
function MapController({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  return null;
}

const geocodeAddress = async (address, state = null) => {
  if (!address) return null;
  try {
    // Try multiple variations to get better results for counties
    const queries = state 
      ? [`${address}, ${state}`]
      : [
          `${address} County, USA`,
          address,
          `${address}, USA`
        ];
    
    for (const query of queries) {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&countrycodes=us`
      );
      const data = await response.json();
      if (data && data[0]) {
        return {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon)
        };
      }
      // Add small delay between requests to respect API rate limits
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  } catch (error) {
    console.error('Geocoding error:', error);
  }
  return null;
};

export default function StormTracking() {
  const navigate = useNavigate();
  const [selectedStorm, setSelectedStorm] = useState(null);
  const [filterType, setFilterType] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [mapCenter, setMapCenter] = useState([39.8283, -98.5795]);
  const [mapZoom, setMapZoom] = useState(4);
  const [serviceCenterCoords, setServiceCenterCoords] = useState(null);
  const [isGeocoding, setIsGeocoding] = useState(true);
  const [showAllStorms, setShowAllStorms] = useState(() => {
    const saved = localStorage.getItem('showAllStorms');
    return saved === 'true';
  });

  // Persist showAllStorms to localStorage
  useEffect(() => {
    localStorage.setItem('showAllStorms', showAllStorms.toString());
  }, [showAllStorms]);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [daysBack, setDaysBack] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('stormDaysBack');
      return saved ? parseInt(saved) : 30;
    }
    return 30;
  });
  const [geocodedAreas, setGeocodedAreas] = useState({});
  const [clusters, setClusters] = useState([]);
  const [selectedClusterStorms, setSelectedClusterStorms] = useState(null);

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: storms = [], isLoading: isLoadingStorms, error: stormsError, refetch: refetchStorms } = useQuery({
    queryKey: ['storm-events'],
    queryFn: () => base44.entities.StormEvent.list('-start_time', 20000),
    initialData: [],
    refetchInterval: autoRefresh ? 300000 : false,
  });

  const { data: alertSettingsData = [] } = useQuery({
    queryKey: ['storm-alert-settings', user?.id],
    queryFn: () => base44.entities.StormAlertSettings.list(),
    enabled: !!user,
  });

  const companySettings = alertSettingsData[0];

  useEffect(() => {
    if (companySettings?.service_center_location) {
      setIsGeocoding(true);
      
      // Parse city and state for better geocoding accuracy
      const parts = companySettings.service_center_location.split(',').map(p => p.trim());
      const city = parts[0];
      const state = parts[1] || null;
      
      geocodeAddress(city, state).then(coords => {
        if (coords) {
          setServiceCenterCoords(coords);
          setMapCenter([coords.lat, coords.lng]);
          setMapZoom(8);
        } else {
          setServiceCenterCoords(null);
        }
        setIsGeocoding(false);
      });
    } else {
      setServiceCenterCoords(null);
      setIsGeocoding(false);
    }
  }, [companySettings]);

  // Helper to extract location from NWS area strings
  const extractLocationFromArea = (area) => {
    // Extract city and state from strings like "Coastal Waters from Eastport, ME to Schoodic Point, ME"
    // or "Knox, Lincoln, Sagadahoc, Waldo, Washington, ME"
    
    // Try to extract state abbreviation
    const stateMatch = area.match(/\b([A-Z]{2})\b/);
    if (!stateMatch) return area;
    
    const state = stateMatch[1];
    
    // Extract first city/county name before comma and state
    const locationMatch = area.match(/([A-Za-z\s]+),\s*[A-Z]{2}/);
    if (locationMatch) {
      const location = locationMatch[1].trim();
      // Remove common prefixes like "Coastal Waters from"
      const cleanLocation = location.replace(/^(Coastal Waters from|Waters from|from)\s+/i, '');
      return `${cleanLocation}, ${state}`;
    }
    
    // If multiple counties listed, just use the first one with state
    const countyMatch = area.match(/^([A-Za-z\s]+),/);
    if (countyMatch) {
      return `${countyMatch[1].trim()}, ${state}`;
    }
    
    return area;
  };



  const fetchStormsMutation = useMutation({
    mutationFn: (variables) => {
      const days = variables?.daysBack || daysBack;
      const isNationwide = variables?.nationwide ?? showAllStorms;
      console.log('🔄 Fetching storms (V2) with daysBack:', days, 'Nationwide:', isNationwide);
      return base44.functions.invoke('fetchStormDataV2', { 
        daysBack: days,
        nationwide: isNationwide
      });
    },
    onSuccess: async (response) => {
      console.log('✅ Fetch complete:', response.data);
      await refetchStorms();
      const newCount = response.data?.newEvents || 0;
      const summary = response.data?.summary || {};
      
      if (newCount > 0) {
        alert(`✅ Found ${newCount} new storm event${newCount === 1 ? '' : 's'}!\n\nNew Imports:\n- Historical: ${summary.historical_events || 0}\n- Active Alerts: ${summary.active_alerts || 0}\n\nBy Type:\n- Hail: ${summary.by_type?.hail || 0}\n- Wind: ${summary.by_type?.high_wind || 0}\n- Tornado: ${summary.by_type?.tornado || 0}\n\nTotal in Database: ${summary.total_in_database || 0}\n\nPage will reload in 2 seconds.`);
        setTimeout(() => window.location.reload(), 2000);
      } else {
        alert(`✅ Storm data updated. No new storms found.\n\nSearched last ${daysBack} days.\nTotal storms in database: ${summary.total_in_database || 0}\n\n${summary.total_in_database > 0 ? 'All storms from this period were already imported.' : 'No storms found in date range - try a longer period or check IEM API.'}\n\nCheck Storm Alert Settings to ensure storm types are enabled.`);
      }
    },
    onError: (error) => {
      console.error('❌ Fetch error:', error);
      alert('❌ Failed to fetch storm data: ' + error.message);
    }
  });

  const generateLeadsMutation = useMutation({
    mutationFn: (stormId) => base44.functions.invoke('generateStormLeads', { stormId }),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ['storm-events'] });
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      const count = response.data?.leadsGenerated || 0;
      alert(`✅ Generated ${count} lead${count === 1 ? '' : 's'} from ${response.data?.stormTitle}!`);
    },
    onError: (error) => {
      alert('❌ Failed to generate leads: ' + error.message);
    }
  });

  const handleGenerateLeads = (storm) => {
    if (confirm(`Generate leads for properties affected by "${storm.title}"?\n\nThis will create potential customer leads in the affected areas.`)) {
      generateLeadsMutation.mutate(storm.id);
    }
  };

  const getStormIcon = (type) => {
    const icons = {
      hail: Cloud,
      tornado: Wind,
      thunderstorm: CloudRain,
      high_wind: Wind,
      flood: CloudRain,
      winter_storm: Cloud
    };
    return icons[type] || AlertTriangle;
  };

  const getSeverityColorClasses = (severity) => {
    const configs = {
      minor: { bg: 'bg-blue-100', text: 'text-blue-700', border: 'border-blue-200' },
      moderate: { bg: 'bg-yellow-100', text: 'text-yellow-700', border: 'border-yellow-200' },
      severe: { bg: 'bg-orange-100', text: 'text-orange-700', border: 'border-orange-200' },
      extreme: { bg: 'bg-red-100', text: 'text-red-700', border: 'border-red-200' }
    };
    return configs[severity] || configs.moderate;
  };

  const getCircleColor = (severity) => {
    const colors = {
      minor: '#3b82f6',
      moderate: '#f59e0b',
      severe: '#f97316',
      extreme: '#ef4444'
    };
    return colors[severity] || colors.moderate;
  };

  const getSeverityBgColor = (severity) => {
    const colors = {
      minor: 'rgba(59, 130, 246, 0.4)',      // blue
      moderate: 'rgba(245, 158, 11, 0.4)',   // yellow/amber
      severe: 'rgba(249, 115, 22, 0.4)',    // orange
      extreme: 'rgba(239, 68, 68, 0.5)'      // red
    };
    return colors[severity] || colors.moderate;
  };

  const stormsInServiceArea = useMemo(() => {
    if (!storms.length) {
      return [];
    }

    // Filter by date range first
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);
    cutoffDate.setHours(0, 0, 0, 0); // Reset to beginning of the day to include full history

    // Debug date filtering
    console.log(`🔍 Filtering storms since ${cutoffDate.toISOString()} (Days back: ${daysBack})`);

    const dateFilteredStorms = storms.filter(storm => {
      if (!storm.start_time) return true;
      const stormDate = new Date(storm.start_time);
      return stormDate >= cutoffDate;
    });
    
    console.log(`✅ ${dateFilteredStorms.length} storms match date filter`);

    if (showAllStorms) {
      return dateFilteredStorms;
    }

    if (!companySettings || !companySettings.service_center_location) {
       return [];
     }

     const { service_radius_miles = 50, service_areas = [] } = companySettings;

     const filtered = dateFilteredStorms.filter(storm => {
       // 1. Check by distance if coordinates exist (both storm AND service center)
       if (serviceCenterCoords && storm.latitude && storm.longitude && !isNaN(storm.latitude) && !isNaN(storm.longitude)) {
         const distance = getDistanceInMiles(
           serviceCenterCoords.lat,
           serviceCenterCoords.lng,
           storm.latitude,
           storm.longitude
         );
         if (distance <= service_radius_miles) return true;
       }

       // 2. For storms without coordinates OR when service center coords not ready, check text matches
       if (storm.affected_areas && storm.affected_areas.length > 0) {
         const serviceCenterName = companySettings.service_center_location.toLowerCase();
         const serviceCenterParts = serviceCenterName.split(',').map(p => p.trim());

         // Check if any affected area mentions the service center city or nearby
         const affectsServiceArea = storm.affected_areas.some(area => {
           const areaLower = area.toLowerCase();
           // Check if service center city is mentioned
           if (serviceCenterParts.some(part => areaLower.includes(part))) return true;

           // Check monitored areas
           return service_areas.some(serviceArea =>
             areaLower.includes(serviceArea.toLowerCase()) ||
             serviceArea.toLowerCase().includes(areaLower)
           );
         });

         if (affectsServiceArea) return true;

         // Check geocoded affected areas (only if service center coords are ready)
         if (serviceCenterCoords) {
           for (const area of storm.affected_areas) {
             const key = `${storm.id}-${area}`;
             const coords = geocodedAreas[key];

             if (coords) {
               const distance = getDistanceInMiles(
                 serviceCenterCoords.lat,
                 serviceCenterCoords.lng,
                 coords.lat,
                 coords.lng
               );
               if (distance <= service_radius_miles) return true;
             }
           }
         }
       }

       return false;
       });

       return filtered;
       }, [storms, companySettings, serviceCenterCoords, isGeocoding, showAllStorms, daysBack, geocodedAreas]);

  const filteredStorms = useMemo(() => {
    return stormsInServiceArea.filter(storm => {
      // Filter by dropdown selection (always respect this - if user selects hail, show hail)
      const matchesType = filterType === 'all' || storm.event_type === filterType;

      // Filter by search term - support state names, abbreviations, counties, and titles
      const searchLower = searchTerm.toLowerCase();
      
      // Only build map if searching to save perf
      let matchesSearch = true;
      if (searchLower) {
        const stateAbbreviations = {
          'alabama': 'al', 'alaska': 'ak', 'arizona': 'az', 'arkansas': 'ar', 'california': 'ca',
          'colorado': 'co', 'connecticut': 'ct', 'delaware': 'de', 'florida': 'fl', 'georgia': 'ga',
          'hawaii': 'hi', 'idaho': 'id', 'illinois': 'il', 'indiana': 'in', 'iowa': 'ia',
          'kansas': 'ks', 'kentucky': 'ky', 'louisiana': 'la', 'maine': 'me', 'maryland': 'md',
          'massachusetts': 'ma', 'michigan': 'mi', 'minnesota': 'mn', 'mississippi': 'ms', 'missouri': 'mo',
          'montana': 'mt', 'nebraska': 'ne', 'nevada': 'nv', 'new hampshire': 'nh', 'new jersey': 'nj',
          'new mexico': 'nm', 'new york': 'ny', 'north carolina': 'nc', 'north dakota': 'nd', 'ohio': 'oh',
          'oklahoma': 'ok', 'oregon': 'or', 'pennsylvania': 'pa', 'rhode island': 'ri', 'south carolina': 'sc',
          'south dakota': 'sd', 'tennessee': 'tn', 'texas': 'tx', 'utah': 'ut', 'vermont': 'vt',
          'virginia': 'va', 'washington': 'wa', 'west virginia': 'wv', 'wisconsin': 'wi', 'wyoming': 'wy'
        };
        
        const stateAbbr = stateAbbreviations[searchLower];
        
        matchesSearch = storm.title?.toLowerCase().includes(searchLower) ||
                            storm.affected_areas?.some(area => {
                              const areaLower = area.toLowerCase();
                              // Direct match
                              if (areaLower.includes(searchLower)) return true;
                              // State abbreviation match (e.g., "Custer, SD" matches "south dakota")
                              if (stateAbbr && areaLower.includes(`, ${stateAbbr}`)) return true;
                              return false;
                            });
      }

      // Filter by user's enabled storm types in settings
      const userEnabledTypes = companySettings?.storm_types_to_monitor || [];
      // Always apply user settings unless a specific filter is selected in the dropdown
      const matchesUserSettings = filterType !== 'all' ? true : (userEnabledTypes.length === 0 || userEnabledTypes.includes(storm.event_type));

      return matchesType && matchesSearch && matchesUserSettings;
    });
  }, [stormsInServiceArea, filterType, searchTerm, showAllStorms, companySettings]);

  // Geocode filtered storms that are missing coordinates
  useEffect(() => {
    const geocodeMissing = async () => {
      // Only process filtered storms to save resources
      const missingCoords = filteredStorms.filter(s => 
        !s.latitude && !s.longitude && 
        s.affected_areas && 
        s.affected_areas.some(area => !geocodedAreas[`${s.id}-${area}`])
      );

      if (missingCoords.length === 0) return;

      console.log(`🌍 Geocoding ${missingCoords.length} filtered storms...`);
      const newGeocodedAreas = { ...geocodedAreas };
      let updated = false;

      for (const storm of missingCoords) {
        // Only geocode the first affected area for mapping purposes to save time
        // The clustering logic looks for *any* geocoded area.
        
        for (const area of storm.affected_areas) {
           const key = `${storm.id}-${area}`;
           if (newGeocodedAreas[key]) continue; // Already have it (in local accumulation)

           const cleanArea = extractLocationFromArea(area); 
           const coords = await geocodeAddress(cleanArea);
           if (coords) {
             newGeocodedAreas[key] = coords;
             updated = true;
             // One valid coordinate is enough to show the storm on the map
             break; 
           }
           // Small delay to prevent rate limiting
           await new Promise(r => setTimeout(r, 200)); 
        }
      }

      if (updated) {
        setGeocodedAreas(prev => ({ ...prev, ...newGeocodedAreas }));
      }
    };

    // Use a small timeout to debounce typing in search box
    const timer = setTimeout(() => {
      if (filteredStorms.length > 0 && filteredStorms.length < 100) { // Limit to avoid massive geocoding batches
        geocodeMissing();
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [filteredStorms, geocodedAreas]);

  // Optimized Clustering Logic
  useEffect(() => {
    // Debounce to prevent freezing UI during rapid zoom/pan
    const timer = setTimeout(() => {
      const calculateClusters = () => {
        // 1. Prepare data with coordinates (O(N))
        const points = [];
        for (const storm of filteredStorms) {
          let lat = storm.latitude;
          let lng = storm.longitude;
          
          // If no direct coords, try geocoded areas (use first valid one)
          if ((!lat || !lng) && storm.affected_areas) {
            for (const area of storm.affected_areas) {
              const key = `${storm.id}-${area}`;
              const coords = geocodedAreas[key];
              if (coords) {
                lat = coords.lat;
                lng = coords.lng;
                break; 
              }
            }
          }
          
          if (lat && lng) {
            points.push({ ...storm, lat, lng });
          }
        }

        // 2. Grid-based Clustering (O(N)) - Much faster than distance-based O(N^2)
        // Divide map into grid cells. All points in same cell = one cluster.
        // Cell size depends on zoom level.
        // At zoom 4, 360 deg longitude / 20 = 18 deg per cell roughly. 
        // We want simpler: approx 50px visual size.
        // 360 degrees / 2^zoom = degrees per tile. 
        // 40px threshold ~ 40/256 * (360/2^zoom)
        const gridSize = 60 / Math.pow(2, mapZoom); // Degrees width of a grid cell
        const grid = {};

        points.forEach(point => {
          // Calculate grid cell indices
          const row = Math.floor(point.lat / gridSize);
          const col = Math.floor(point.lng / gridSize);
          const key = `${row}-${col}`;

          if (!grid[key]) {
            grid[key] = {
              id: `g-${key}`,
              points: [],
              latSum: 0,
              lngSum: 0,
              maxSeverity: 'minor'
            };
          }

          const cluster = grid[key];
          cluster.points.push(point);
          cluster.latSum += point.lat;
          cluster.lngSum += point.lng;
          
          // Update max severity
          const sevOrder = { extreme: 4, severe: 3, moderate: 2, minor: 1 };
          if (sevOrder[point.severity] > sevOrder[cluster.maxSeverity]) {
            cluster.maxSeverity = point.severity;
          }
        });

        // 3. Convert grid back to array and calculate centroids
        const newClusters = Object.values(grid).map(cluster => ({
          id: cluster.id,
          points: cluster.points,
          lat: cluster.latSum / cluster.points.length,
          lng: cluster.lngSum / cluster.points.length,
          maxSeverity: cluster.maxSeverity
        }));

        setClusters(newClusters);
      };

      calculateClusters();
    }, 50); // 50ms debounce

    return () => clearTimeout(timer);
  }, [filteredStorms, mapZoom, geocodedAreas]);

  // Auto-zoom map when searching for a specific location
  useEffect(() => {
    if (searchTerm && filteredStorms.length > 0) {
      // Get all storms with coords (both direct + geocoded affected areas)
      const stormsWithCoords = filteredStorms.filter(s => {
        if (s.latitude && s.longitude) return true;
        if (!s.latitude && !s.longitude && s.affected_areas) {
          return s.affected_areas.some(area => {
            const key = `${s.id}-${area}`;
            return geocodedAreas[key];
          });
        }
        return false;
      });
      
      if (stormsWithCoords.length > 0) {
        let totalLat = 0, totalLng = 0, count = 0;
        
        // Add direct coords
        stormsWithCoords.forEach(s => {
          if (s.latitude && s.longitude) {
            totalLat += s.latitude;
            totalLng += s.longitude;
            count++;
          }
        });
        
        // Add geocoded area coords
        stormsWithCoords.forEach(s => {
          if (!s.latitude && !s.longitude && s.affected_areas) {
            s.affected_areas.forEach(area => {
              const key = `${s.id}-${area}`;
              const coords = geocodedAreas[key];
              if (coords) {
                totalLat += coords.lat;
                totalLng += coords.lng;
                count++;
              }
            });
          }
        });
        
        if (count > 0) {
          setMapCenter([totalLat / count, totalLng / count]);
          setMapZoom(6);
        }
      }
    } else if (!searchTerm && serviceCenterCoords) {
      // Reset to service center when search is cleared
      setMapCenter([serviceCenterCoords.lat, serviceCenterCoords.lng]);
      setMapZoom(8);
    }
  }, [searchTerm, filteredStorms.length, serviceCenterCoords, geocodedAreas]);

  const activeStorms = filteredStorms.filter(s => s.status === 'active').length;
  const severeStorms = filteredStorms.filter(s => s.severity === 'severe' || s.severity === 'extreme').length;
  const totalAffectedAreas = new Set(filteredStorms.flatMap(s => s.affected_areas || [])).size;
  const totalLeadsGenerated = filteredStorms.reduce((sum, s) => sum + (s.leads_generated || 0), 0);

  const hasSettings = !!companySettings?.service_center_location;
  const showSetupPrompt = !hasSettings && !isLoadingStorms;

  return (
    <div className="p-2 sm:p-4 md:p-6 space-y-3 sm:space-y-4 md:space-y-6 bg-gray-50 min-h-screen">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900">Storm Tracking</h1>
          <p className="text-xs sm:text-sm md:text-base text-gray-500 mt-1">Real-time severe weather monitoring powered by NOAA</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => navigate(createPageUrl('StormAlertSettings'))}
            className="flex-1 md:flex-none"
          >
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
          <Button
            onClick={() => {
              console.log('🔄 Manual refresh triggered with daysBack:', daysBack, 'Nationwide:', showAllStorms);
              fetchStormsMutation.mutate({ daysBack, nationwide: showAllStorms });
            }}
            disabled={fetchStormsMutation.isPending}
            className="bg-blue-600 hover:bg-blue-700 flex-1 md:flex-none"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${fetchStormsMutation.isPending ? 'animate-spin' : ''}`} />
            {fetchStormsMutation.isPending ? 'Updating...' : `Refresh ${showAllStorms ? 'Nationwide' : 'Local'} (${daysBack}d)`}
          </Button>
          {!showAllStorms && (
            <Button
              onClick={() => {
                if (confirm("Fetch nationwide data? This may take a moment.")) {
                  setShowAllStorms(true);
                  fetchStormsMutation.mutate({ daysBack, nationwide: true });
                }
              }}
              disabled={fetchStormsMutation.isPending}
              className="bg-purple-600 hover:bg-purple-700 flex-1 md:flex-none"
            >
              <Search className="w-4 h-4 mr-2" />
              Find All (Nationwide)
            </Button>
          )}
        </div>
      </div>

      {showSetupPrompt && (
        <Alert className="bg-yellow-50 border-yellow-200">
          <Info className="h-4 w-4 text-yellow-600" />
          <AlertDescription>
            <div className="flex items-start justify-between">
              <div>
                <strong className="text-yellow-900">Setup Required</strong>
                <p className="text-sm text-yellow-800 mt-1">
                  Configure your service area to receive storm alerts and filter relevant storms.
                </p>
              </div>
              <Button 
                size="sm" 
                onClick={() => navigate(createPageUrl('StormAlertSettings'))}
                className="bg-yellow-600 hover:bg-yellow-700 ml-4"
              >
                Setup Now
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {storms.length > 0 && (
        <Alert className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-300 shadow-sm">
          <Info className="h-4 w-4 text-green-700" />
          <AlertDescription>
            <div className="text-sm text-green-900 max-h-[200px] overflow-y-auto pr-2">
              <strong className="text-lg">💰 How to Get REAL Property Owner Leads (100% FREE):</strong>
              <ol className="list-decimal list-inside mt-3 space-y-2 ml-2">
                <li><strong>When a storm hits</strong> → Note the affected zip codes (e.g., 44903, 44906)</li>
                <li><strong>Visit county auditor website</strong> → Go to Property Search</li>
                <li><strong>Filter by zip code</strong> → Select storm-affected areas</li>
                <li><strong>Download CSV</strong> → Export 100-500 REAL property owner records</li>
                <li><strong>Import here</strong> → Click "Get REAL Leads" button on any storm below</li>
                <li><strong>Optional: Get phone numbers</strong> → Use skip tracing to enrich leads with contact info</li>
              </ol>
              <div className="mt-4 p-3 bg-white border border-green-200 rounded-lg">
                <p className="font-semibold text-green-900 mb-2">📊 Current Summary:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li><strong>{storms.length} total storms</strong> in database</li>
                  {companySettings?.service_center_location && (
                    <>
                      <li>Service center: <strong>{companySettings.service_center_location}</strong></li>
                      <li>Service radius: <strong>{companySettings.service_radius_miles || 50} miles</strong></li>
                    </>
                  )}
                  <li className="font-bold text-green-900">
                    {showAllStorms ? (
                      `Showing all ${storms.length} storms nationwide`
                    ) : (
                      `${stormsInServiceArea.length} storms in your service area`
                    )}
                  </li>
                  <li className="text-orange-700 italic">⚠️ Note: NWS alerts (High Wind Warnings) appear in the list but not as circles on the map because they cover entire counties without specific coordinates.</li>
                </ul>
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  {autoRefresh ? <CheckCircle className="w-5 h-5 text-blue-600" /> : <Bell className="w-5 h-5 text-blue-600" />}
                </div>
                <div>
                  <p className="font-medium text-blue-900">Auto-Refresh Storm Data</p>
                  <p className="text-sm text-blue-700">
                    {autoRefresh ? 'Checking for new storms every 5 minutes' : 'Manual refresh only'}
                  </p>
                </div>
              </div>
              <Switch
                checked={autoRefresh}
                onCheckedChange={setAutoRefresh}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1">
                <Label className="font-medium text-purple-900">Search History</Label>
                <p className="text-sm text-purple-700 mt-1">
                  Currently searching back {daysBack} days
                </p>
              </div>
              <select
                value={daysBack.toString()}
                onChange={(e) => {
                  const newDays = parseInt(e.target.value);
                  console.log('📅 Days changed to:', newDays);
                  setDaysBack(newDays);
                  localStorage.setItem('stormDaysBack', newDays.toString());
                }}
                className="px-3 py-2 border border-purple-200 rounded-lg text-sm bg-white font-medium text-purple-900 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              >
                <option value={1}>Today</option>
                <option value={7}>7 days</option>
                <option value={30}>30 days</option>
                <option value={60}>60 days</option>
                <option value={90}>90 days (3 months)</option>
                <option value={180}>180 days (6 months)</option>
                <option value={365}>365 days (1 year)</option>
              </select>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-purple-50 border-purple-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="font-medium text-purple-900">Show All Storms (Nationwide)</p>
              <p className="text-sm text-purple-700 mt-1">
                {showAllStorms 
                  ? `Currently showing all ${storms.length} storms across the United States.` 
                  : companySettings?.service_center_location && serviceCenterCoords
                    ? `Showing storms within ${companySettings.service_radius_miles || 50} miles of ${companySettings.service_center_location} and monitored areas.`
                    : 'Configure your service area in settings to filter storms by location.'}
              </p>
            </div>
            <Switch
              checked={showAllStorms}
              onCheckedChange={setShowAllStorms}
              className="ml-4"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-3 md:gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-blue-700">
                  {showAllStorms ? 'Active (All)' : 'In Service Area'}
                </p>
                <p className="text-2xl md:text-3xl font-bold text-blue-900">{activeStorms}</p>
              </div>
              <CloudRain className="w-6 h-6 md:w-8 md:h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-red-50 hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-orange-700">Severe Events</p>
                <p className="text-2xl md:text-3xl font-bold text-orange-900">{severeStorms}</p>
              </div>
              <AlertTriangle className="w-6 h-6 md:w-8 md:h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-purple-700">Affected Areas</p>
                <p className="text-2xl md:text-3xl font-bold text-purple-900">{totalAffectedAreas}</p>
              </div>
              <MapPin className="w-6 h-6 md:w-8 md:h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate(createPageUrl('Leads'))}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-green-700">Leads Generated</p>
                <p className="text-2xl md:text-3xl font-bold text-green-900">{totalLeadsGenerated}</p>
              </div>
              <Users className="w-6 h-6 md:w-8 md:h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {selectedClusterStorms && (
        <Card className="bg-white border-blue-500">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-blue-600" />
                Affected Areas ({selectedClusterStorms.length})
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedClusterStorms(null)}
              >
                ✕
              </Button>
            </div>
          </CardHeader>
          <CardContent className="max-h-[400px] overflow-y-auto">
            <div className="space-y-2">
              {selectedClusterStorms
                .sort((a, b) => new Date(b.start_time) - new Date(a.start_time))
                .map((storm, idx) => (
                  <div key={`${storm.id}-${idx}`} className="p-3 border rounded-lg hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-sm text-gray-900 line-clamp-2">{storm.title}</h4>
                      <Badge className={`${getSeverityColorClasses(storm.severity).bg} ${getSeverityColorClasses(storm.severity).text} border-0 flex-shrink-0`}>
                        {storm.severity}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 mb-2">
                      {storm.affected_areas?.join(', ')}
                    </p>
                    <p className="text-xs text-gray-500 mb-3">
                      📅 {format(new Date(storm.start_time), 'MMM d, yyyy h:mm a')}
                    </p>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => {
                          navigate(createPageUrl('PropertyDataImporter') + `?storm=${encodeURIComponent(storm.title)}&areas=${encodeURIComponent(storm.affected_areas?.join(', ') || '')}`);
                        }}
                        className="flex-1 bg-green-600 hover:bg-green-700 text-xs h-8"
                      >
                        Get Leads
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          navigate(createPageUrl('StormReport') + `?id=${storm.id}`);
                        }}
                        className="text-xs h-8 px-3"
                      >
                        Report
                      </Button>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4 lg:gap-6">
         <Card className="bg-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cloud className="w-5 h-5" />
              Storm Events ({filteredStorms.length})
            </CardTitle>
            <div className="flex flex-col md:flex-row gap-2 mt-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search storms..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="px-3 py-2 border rounded-md text-sm bg-white"
              >
                <option value="all">All Types</option>
                <option value="hail">Hail</option>
                <option value="tornado">Tornado</option>
                <option value="thunderstorm">Thunderstorm</option>
                <option value="high_wind">High Wind</option>
                <option value="flood">Flood</option>
                <option value="winter_storm">Winter Storm</option>
              </select>
            </div>
          </CardHeader>
          <CardContent className="max-h-[600px] overflow-y-auto space-y-3">
            {isLoadingStorms || isGeocoding ? (
              <div className="text-center py-12 text-gray-500">
                <Loader2 className="w-8 h-8 mx-auto mb-3 animate-spin text-gray-400" />
                <p className="font-medium">{isGeocoding ? 'Locating your service area...' : 'Loading storms...'}</p>
                <p className="text-xs mt-1">Please wait</p>
              </div>
            ) : stormsError ? (
              <Alert className="bg-red-50 border-red-200">
                <XCircle className="h-4 w-4 text-red-600" />
                <AlertDescription>
                  <strong className="text-red-900">Error loading storms</strong>
                  <p className="text-sm text-red-800 mt-1">{stormsError.message}</p>
                  <Button 
                    size="sm" 
                    onClick={() => fetchStormsMutation.mutate()}
                    className="mt-3"
                  >
                    Retry
                  </Button>
                </AlertDescription>
              </Alert>
            ) : filteredStorms.length > 0 ? (
              filteredStorms
                .sort((a, b) => {
                  const severityOrder = { extreme: 4, severe: 3, moderate: 2, minor: 1 };
                  const severityDiff = (severityOrder[b.severity] || 0) - (severityOrder[a.severity] || 0);
                  if (severityDiff !== 0) return severityDiff;
                  return new Date(b.start_time) - new Date(a.start_time);
                })
                .map((storm) => {
                  const StormIcon = getStormIcon(storm.event_type);
                  const severityConfig = getSeverityColorClasses(storm.severity);
                  return (
                    <Card
                      key={storm.id}
                      className={`cursor-pointer transition-all hover:shadow-md ${severityConfig.bg} border-l-4 ${severityConfig.border} ${
                        selectedStorm?.id === storm.id ? 'ring-2 ring-blue-500 shadow-lg' : ''
                      }`}
                      onClick={() => {
                        setSelectedStorm(storm);

                        // Try direct coordinates first
                        if (storm.latitude && storm.longitude) {
                          setMapCenter([storm.latitude, storm.longitude]);
                          setMapZoom(9);
                        } else if (storm.affected_areas && storm.affected_areas.length > 0) {
                          // Try to find geocoded coordinates for first affected area
                          const firstArea = storm.affected_areas[0];
                          const key = `${storm.id}-${firstArea}`;
                          const coords = geocodedAreas[key];

                          if (coords) {
                            setMapCenter([coords.lat, coords.lng]);
                            setMapZoom(9);
                          }
                        }
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg flex-shrink-0 ${severityConfig.bg} ${severityConfig.text}`}>
                            <StormIcon className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <h3 className="font-semibold text-sm line-clamp-2">{storm.title}</h3>
                              <Badge variant="outline" className={`${severityConfig.bg} ${severityConfig.text} ${severityConfig.border} flex-shrink-0 text-xs`}>
                                {storm.severity}
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-600 mt-1 line-clamp-2">
                              {storm.affected_areas?.join(', ')}
                            </p>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {storm.hail_size_inches && (
                                <span className="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded">
                                  🧊 {storm.hail_size_inches}" hail
                                </span>
                              )}
                              {storm.wind_speed_mph && (
                                <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded">
                                  💨 {storm.wind_speed_mph} mph
                                </span>
                              )}
                              <span className={`text-xs font-medium px-2 py-1 rounded ${
                                storm.status === 'active' ? 'text-green-600 bg-green-50' : 'text-gray-600 bg-gray-50'
                              }`}>
                                {storm.status === 'active' ? '🔴 Active' : '✅ Ended'}
                              </span>
                            </div>
                            {storm.leads_generated > 0 && (
                              <p className="text-xs font-medium text-green-600 mt-2 flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" />
                                {storm.leads_generated} leads generated
                              </p>
                            )}
                            {storm.start_time && (
                              <p className="text-xs text-gray-500 mt-2">
                                📅 {format(new Date(storm.start_time), 'MMM d, yyyy h:mm a')}
                              </p>
                            )}
                            <div className="flex gap-2 mt-4">
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigate(createPageUrl('PropertyDataImporter') + `?storm=${encodeURIComponent(storm.title)}&areas=${encodeURIComponent(storm.affected_areas?.join(', ') || '')}`);
                                }}
                                className="bg-green-600 hover:bg-green-700 flex-1"
                              >
                                <Users className="w-3 h-3 mr-1" />
                                Get REAL Leads
                              </Button>
                              
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigate(createPageUrl('StormReport') + `?id=${storm.id}`);
                                }}
                                className="border-blue-300 text-blue-700 hover:bg-blue-50"
                              >
                                <ChevronRight className="w-4 h-4 mr-1" />
                                Report
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
            ) : (
              <div className="text-center py-12 text-gray-500">
                <CloudRain className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p className="font-medium">No storms found</p>
                <p className="text-sm mt-1">
                  {searchTerm 
                    ? 'No storms match your search' 
                    : showAllStorms 
                      ? 'No storms available' 
                      : 'No storms in your service area'}
                </p>
                {!showAllStorms && hasSettings && !searchTerm && (
                  <Button 
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAllStorms(true)}
                    className="mt-3"
                  >
                    Show All Storms Nationwide
                  </Button>
                )}
                {!hasSettings && (
                  <Button 
                    size="sm"
                    onClick={() => navigate(createPageUrl('StormAlertSettings'))}
                    className="mt-3 bg-blue-600 hover:bg-blue-700"
                  >
                    Configure Service Area
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-0">
              <div className="h-[400px] md:h-[600px] rounded-lg overflow-hidden">
                <MapContainer
                center={mapCenter}
                zoom={mapZoom}
                style={{ height: '100%', width: '100%' }}
                className="z-0"
                >
                <MapController center={mapCenter} zoom={mapZoom} />
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; OpenStreetMap contributors'
                />

                {/* Map Events Handler to track zoom for clustering */}
                <MapEventsHandler onZoomEnd={(z) => setMapZoom(z)} onMoveEnd={() => {}} />

                {clusters.map((cluster) => {
                  // --- RENDER CLUSTER (Multi-storm group) ---
                  if (cluster.points.length > 1) {
                    const size = Math.min(60, 30 + (cluster.points.length * 2));
                    const color = getSeverityBgColor(cluster.maxSeverity);

                    const icon = L.divIcon({
                      html: `<div style="background-color: ${color}; width: ${size}px; height: ${size}px; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: white; font-weight: bold; border: 2px solid white; box-shadow: 0 4px 6px rgba(0,0,0,0.1); font-size: ${size > 40 ? '16px' : '12px'};">${cluster.points.length}</div>`,
                      className: 'custom-cluster-icon',
                      iconSize: [size, size],
                      iconAnchor: [size / 2, size / 2]
                    });

                    return (
                      <Marker 
                        key={cluster.id}
                        position={[cluster.lat, cluster.lng]}
                        icon={icon}
                        eventHandlers={{
                          click: (e) => {
                            setSelectedClusterStorms(cluster.points);
                          }
                        }}
                      />
                    );
                  }

                  // --- RENDER SINGLE STORM ---
                   const storm = cluster.points[0];
                   return (
                     <Circle
                       key={`${storm.id}-single`}
                       center={[storm.lat, storm.lng]}
                       radius={storm.radius_miles * 1609.34}
                       pathOptions={{
                         color: getCircleColor(storm.severity),
                         opacity: 0.5,
                         fillColor: getCircleColor(storm.severity),
                         fillOpacity: selectedStorm?.id === storm.id ? 0.3 : 0.15,
                         weight: selectedStorm?.id === storm.id ? 2 : 1
                       }}
                       eventHandlers={{
                         click: (e) => {
                           setSelectedClusterStorms([storm]);
                         }
                       }}
                     />
                   );
                })}

                {serviceCenterCoords && (
                  <>
                    <Marker position={[serviceCenterCoords.lat, serviceCenterCoords.lng]}>
                      <Popup>
                        <strong>Your Service Center</strong><br/>
                        {companySettings?.service_center_location}<br/>
                        Radius: {companySettings?.service_radius_miles || 50} miles
                      </Popup>
                    </Marker>
                    <Circle
                      center={[serviceCenterCoords.lat, serviceCenterCoords.lng]}
                      radius={(companySettings?.service_radius_miles || 50) * 1609.34}
                      pathOptions={{ color: 'blue', fillColor: 'blue', fillOpacity: 0.1, weight: 1, dashArray: '5, 5' }}
                    />
                  </>
                )}
                </MapContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}