import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Upload,
  Loader2,
  Sparkles,
  Send,
  Paperclip,
  FileText,
  Settings,
  Save,
  X,
  UserCircle,
  ClipboardList,
  MapPin,
  Satellite,
  Download,
  Mail,
  Pencil,
  Plus,
  ArrowLeft,
  Edit, // Added Edit icon
  Wind
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import LineItemEditor from "../components/estimates/LineItemEditor";
import { GoogleAddressAutocomplete } from "../components/GoogleAddressAutocomplete";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "../utils";
import { analyzeEstimateCompleteness } from "@/functions/analyzeEstimateCompleteness";
import InteractiveRoofMap from "../components/satellite/InteractiveRoofMap";
import { generateMaterialList } from "@/functions/generateMaterialList";
import StructureSelector from "../components/satellite/StructureSelector";
import VentilationCalculator from "../components/estimator/VentilationCalculator";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Printer, Hammer, Share2, MoreHorizontal, Package, TrendingUp, ArrowUp, DollarSign } from "lucide-react";

export default function AIEstimator() {
  const navigate = useNavigate();
  const [selectedMode, setSelectedMode] = useState("document");
  const [showConfig, setShowConfig] = useState(false);
  const [googleMapsLoaded, setGoogleMapsLoaded] = useState(false);
  const [googleMapsError, setGoogleMapsError] = useState(null);
  const [config, setConfig] = useState(() => {
    const savedConfig = localStorage.getItem('aiEstimatorConfig');
    if (savedConfig) {
      return JSON.parse(savedConfig);
    }
    return {
      specialty: "roofing",
      primaryMaterials: "laminated shingles, vinyl siding, 5\" gutters",
      defaultPricingSource: "xactimate",
      defaultTemplate: null,
      useFavorites: true
    };
  });

  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);

  const [satelliteAddress, setSatelliteAddress] = useState(null);
  const [satelliteAnalysis, setSatelliteAnalysis] = useState(null);
  const [isSatelliteAnalyzing, setIsSatelliteAnalyzing] = useState(false);
  const [useManualDrawing, setUseManualDrawing] = useState(false); // Renamed from useManualDrawing to showManualDrawing for consistency with outline but then reverted to original name to avoid breaking existing code.

  // NEW: Multi-structure support for AI mode
  const [analyzedStructures, setAnalyzedStructures] = useState([]);
  const [isAddingStructure, setIsAddingStructure] = useState(false);
  const [showStructureSelector, setShowStructureSelector] = useState(false);
  const [manualAddOnMode, setManualAddOnMode] = useState(false); // NEW: for hybrid AI + manual
  const [manualMeasurements, setManualMeasurements] = useState([]); // NEW: store manual measurements

  // NEW: Gutters for AI mode
  const [includeGuttersAI, setIncludeGuttersAI] = useState(false);
  const [aiGutterLF, setAiGutterLF] = useState(0);
  const [aiDownspoutCount, setAiDownspoutCount] = useState(0);
  
  // NEW: Roof type selector
  const [roofTypeSelection, setRoofTypeSelection] = useState("shingles");
  
  // NEW: Measurement API selector (Google Solar vs Gemini Vision)
  const [measurementAPI, setMeasurementAPI] = useState(() => {
    const saved = localStorage.getItem('aiEstimatorMeasurementAPI');
    return saved || 'google_solar';
  });

  const [currentEstimate, setCurrentEstimate] = useState(null);
  const [lineItems, setLineItems] = useState([]);
  
  // NEW: Estimate history for undo
  const [estimateHistory, setEstimateHistory] = useState([]);
  
  const [pricingSource, setPricingSource] = useState("xactimate");
  const [jobType, setJobType] = useState("roofing");
  const [selectedContactId, setSelectedContactId] = useState(() => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('customer_id') || "";
  });
  const [selectedFormatId, setSelectedFormatId] = useState(null);
  const [isExporting, setIsExporting] = useState(false);
  const [showMaterialList, setShowMaterialList] = useState(false);
  const [materialListData, setMaterialListData] = useState(null);
  const [isGeneratingMaterials, setIsGeneratingMaterials] = useState(false);
  const [showMergeDialog, setShowMergeDialog] = useState(false);
  const [mergeFiles, setMergeFiles] = useState([]);
  const [isMerging, setIsMerging] = useState(false);

  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showVentilationCalc, setShowVentilationCalc] = useState(false);

  // NEW: Linked inspection job state
  const [linkedInspectionJobId, setLinkedInspectionJobId] = useState(null);
  
  // Duplicate customer handling
  const [showDuplicateDialog, setShowDuplicateDialog] = useState(false);
  const [duplicateCustomer, setDuplicateCustomer] = useState(null);
  const [pendingSaveData, setPendingSaveData] = useState(null);

  const [customerInfo, setCustomerInfo] = useState(() => {
    // Pre-fill from URL params if coming from customer/lead page
    const urlParams = new URLSearchParams(window.location.search);
    return {
      customer_name: urlParams.get('customer_name') || "",
      customer_email: urlParams.get('customer_email') || "",
      customer_phone: urlParams.get('customer_phone') || "",
      property_address: urlParams.get('property_address') || "",
      claim_number: urlParams.get('claim_number') || "",
      insurance_company: urlParams.get('insurance_company') || "",
      adjuster_name: urlParams.get('adjuster_name') || "",
      adjuster_phone: urlParams.get('adjuster_phone') || "",
      notes: "",
      disclaimer: "",
      report_type: "unknown"
    };
  });

  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();

  // Get inspectionJobId from URL if present
  const urlParams = new URLSearchParams(location.search);
  const inspectionJobIdFromUrl = urlParams.get('inspection_job_id');

  useEffect(() => {
    const loadGoogleMaps = async () => {
      if (window.google && window.google.maps && window.google.maps.places) {
        setGoogleMapsLoaded(true);
        return;
      }

      try {
        // Cache the API key in sessionStorage to avoid repeated backend calls
        let apiKey = sessionStorage.getItem('_gmaps_key');
        if (!apiKey) {
          const response = await base44.functions.invoke('getGoogleMapsApiKey');
          apiKey = response.data?.apiKey;
          if (apiKey) {
            sessionStorage.setItem('_gmaps_key', apiKey);
          }
        }

        if (!apiKey) {
          throw new Error('Google Maps API key not configured');
        }

        const script = document.createElement('script');
        script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,geometry,drawing`;
        script.async = true;
        script.defer = true;

        script.onload = () => {
          console.log('✅ Google Maps loaded successfully');
          setGoogleMapsLoaded(true);
        };

        script.onerror = () => {
          console.error('❌ Failed to load Google Maps');
          setGoogleMapsError('Failed to load Google Maps. Please refresh the page.');
        };

        document.head.appendChild(script);
      } catch (error) {
        console.error('Error loading Google Maps:', error);
        sessionStorage.removeItem('_gmaps_key');
        setGoogleMapsError(error.message || 'Failed to load Google Maps API');
      }
    };

    loadGoogleMaps();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (lineItems.length > 0) {
      const total = Math.round(lineItems.reduce((acc, item) => acc + (Number(item.rcv) || 0), 0) * 100) / 100;
      
      setCurrentEstimate(prev => {
        if (!prev) return null;
        
        return {
          ...prev,
          line_items: lineItems,
          total_rcv: total
        };
      });
    } else {
      setCurrentEstimate(null);
    }
  }, [lineItems]);

  // NEW: Helper to save current state to history before making changes
  const saveToHistory = () => {
    if (lineItems.length > 0) {
      setEstimateHistory(prev => [...prev, {
        lineItems: JSON.parse(JSON.stringify(lineItems)),
        currentEstimate: currentEstimate ? JSON.parse(JSON.stringify(currentEstimate)) : null,
        timestamp: new Date().toISOString()
      }]);
    }
  };

  // NEW: Undo function
  const handleUndo = () => {
    if (estimateHistory.length === 0) {
      alert('Nothing to undo');
      return;
    }

    const previousState = estimateHistory[estimateHistory.length - 1];
    setLineItems(previousState.lineItems);
    setCurrentEstimate(previousState.currentEstimate);
    setEstimateHistory(prev => prev.slice(0, -1));

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `↩️ Undone! Restored previous estimate.`,
      timestamp: new Date().toISOString()
    }]);
  };

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date", 1),
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list("-created_date", 100),
    initialData: [],
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date", 100),
    initialData: [],
  });

  const { data: estimates = [] } = useQuery({
    queryKey: ['estimates'],
    queryFn: () => base44.entities.Estimate.list("-created_date", 100),
    initialData: [],
  });

  // Query for linked job media specific to the linkedInspectionJobId
  const { data: linkedJobMedia = [] } = useQuery({
    queryKey: ['linked-job-media', linkedInspectionJobId],
    queryFn: () => linkedInspectionJobId ? base44.entities.JobMedia.filter({ 
      related_entity_id: linkedInspectionJobId, 
      related_entity_type: 'InspectionJob',
      file_type: 'photo'
    }) : [],
    enabled: !!linkedInspectionJobId,
    initialData: [],
  });

  // Query for all inspection jobs
  const { data: allInspectionJobs = [] } = useQuery({
    queryKey: ['inspection-jobs'],
    queryFn: () => base44.entities.InspectionJob.list("-created_date", 100),
    initialData: [],
  });

  const allContacts = [
    ...customers.map(c => ({
      ...c,
      type: 'customer',
      displayName: c.name || c.full_name || c.company || 'Unnamed Customer',
      searchText: `${c.name || ''} ${c.full_name || ''} ${c.email || ''} ${c.company || ''}`.toLowerCase()
    })),
    ...leads.map(l => ({
      ...l,
      type: 'lead',
      displayName: l.name || l.full_name || l.company || 'Unnamed Lead',
      searchText: `${l.name || ''} ${l.full_name || ''} ${l.email || ''} ${l.company || ''}`.toLowerCase()
    }))
  ].sort((a, b) => (a.displayName || "").localeCompare(b.displayName || ""));

  const myCompany = companies.find(c => c.created_by === user?.email) || companies[0];

  const { data: estimatorMemories = [] } = useQuery({
    queryKey: ['estimator-memories', user?.email],
    queryFn: () => user ? base44.entities.AIMemory.filter({
      user_email: user.email,
      category: 'estimator',
      is_active: true
    }, '-importance', 20) : [],
    enabled: !!user,
    initialData: [],
  });

  const { data: knowledgeArticles = [] } = useQuery({
    queryKey: ['knowledge-base-ai', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.KnowledgeBaseArticle.filter({
      company_id: myCompany.id,
      is_ai_training: true,
      is_published: true
    }, '-priority', 50) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const estimatorKnowledge = knowledgeArticles.filter(article =>
    article.ai_assistant_targets?.includes("estimator")
  );

  const { data: allPriceListItems = [] } = useQuery({
    queryKey: ['all-price-list-items'],
    queryFn: () => base44.entities.PriceListItem.list("-created_date", 10000),
    initialData: [],
  });

  const xactimatePriceList = allPriceListItems.filter(item => item.source === "Xactimate" && item.is_active !== false);
  const xactimateNewPriceList = allPriceListItems.filter(item => item.source === "Xactimate_New" && item.is_active !== false);
  const customPriceList = allPriceListItems.filter(item => item.source === "Custom" && item.is_active !== false);
  const symbilityPriceList = allPriceListItems.filter(item => item.source === "Symbility" && item.is_active !== false);

  const { data: formats = [] } = useQuery({
    queryKey: ['estimate-formats'],
    queryFn: () => base44.entities.EstimateFormat.filter({ is_active: true }),
    initialData: [],
  });

  const selectedFormat = selectedFormatId ? formats.find(f => f.id === selectedFormatId) : null;

  const getFormatForSource = (source) => {
    const lowerSource = source.toLowerCase();
    const insuranceFormat = formats.find(f =>
      f.insurance_company?.toLowerCase().includes(lowerSource) ||
      f.insurance_company?.toLowerCase().includes(source === 'xactimate' || source === 'xactimate_new' ? 'xactimate' : source === 'symbility' ? 'symbility' : '')
    );

    if (insuranceFormat) return insuranceFormat;

    const categoryFormat = formats.find(f =>
      f.category === (source === 'custom' ? 'custom' : 'insurance')
    );

    if (categoryFormat) return categoryFormat;

    if (source === 'xactimate' || source === 'xactimate_new' || source === 'symbility') {
      return {
        format_name: source.includes('xactimate') ? 'Xactimate Standard' : 'Symbility Standard',
        show_rcv_acv: true,
        show_depreciation: false,
        rcv_label: 'RCV',
        acv_label: 'ACV'
      };
    }

    return {
      format_name: 'Custom',
      show_rcv_acv: false,
      show_depreciation: false,
      rcv_label: 'RCV',
      acv_label: 'ACV'
    };
  };

  const currentFormat = selectedFormat || getFormatForSource(pricingSource);

  // Get header color class based on format color_scheme
  const getHeaderColorClass = (format) => {
    const colorScheme = format?.color_scheme || 'blue';
    const colorMap = {
      red: 'bg-gradient-to-r from-red-500 to-red-600',
      green: 'bg-gradient-to-r from-green-500 to-green-600',
      blue: 'bg-gradient-to-r from-blue-500 to-blue-600',
      gray: 'bg-gradient-to-r from-gray-500 to-gray-600'
    };
    return colorMap[colorScheme] || colorMap.blue;
  };

  useEffect(() => {
    const savedConfig = localStorage.getItem('aiEstimatorConfig');
    if (savedConfig) {
      const parsed = JSON.parse(savedConfig);
      setConfig(parsed);
      setPricingSource(parsed.defaultPricingSource);
      if (parsed.defaultTemplate) {
        setSelectedFormatId(parsed.defaultTemplate);
      }
      setShowConfig(false);

      setMessages([{
        role: 'assistant',
        content: `🏗️ **Welcome back!**

Your AI Estimator is configured for **${parsed.specialty}** with:
• Primary materials: ${parsed.primaryMaterials}
• Pricing source: ${parsed.defaultPricingSource.replace('xactimate_new', 'Xactimate New')}
${parsed.defaultTemplate ? `• Template: ${formats.find(f => f.id === parsed.defaultTemplate)?.format_name || 'Custom'}` : ''}
• Using favorites: ${parsed.useFavorites ? 'Yes' : 'No'}

Choose your mode: Upload documents OR use satellite measurements!`,
        timestamp: new Date().toISOString()
      }]);
    }
  }, [estimatorMemories, user]);

  const handleFormatChange = (formatId) => {
    setSelectedFormatId(formatId);
    const format = formats.find(f => f.id === formatId);
    if (format) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ **Switched to "${format.format_name}" template**\n\n📋 This template uses ${format.show_rcv_acv ? 'RCV/ACV' : 'standard'} pricing${format.show_depreciation ? ' with depreciation' : ''}.`,
        timestamp: new Date().toISOString()
      }]);
    }
  };

  const smartDescriptionMatch = (description, priceList) => {
    if (!description || !priceList || priceList.length === 0) return null;

    const descLower = description.toLowerCase().trim();

    // SPECIAL CASE: Tear off / Remove roof covering
    if (descLower.includes('tear off') || descLower.includes('remove roof') || descLower.includes('r&r')) {
      // STEP 1: Try exact code match for 3-tab first
      const codeMatch = priceList.find(item => {
        const itemCode = item.code?.toUpperCase() || '';
        return itemCode === 'ARMV' || itemCode === 'ARMVN';
      });
      if (codeMatch) return codeMatch;
      
      // STEP 2: Look for 3-tab in description
      const tabMatch = priceList.find(item => {
        const itemDesc = item.description?.toLowerCase() || '';
        return (
          (itemDesc.includes('tear off') || itemDesc.includes('remove')) &&
          (itemDesc.includes('3 tab') || itemDesc.includes('3-tab') || itemDesc.includes('comp')) &&
          !itemDesc.includes('membrane') &&
          !itemDesc.includes('slate') &&
          !itemDesc.includes('tile') &&
          !itemDesc.includes('metal')
        );
      });
      if (tabMatch) return tabMatch;
      
      // STEP 3: Fallback to general composition (excluding specialty types)
      const tearOffMatch = priceList.find(item => {
        const itemDesc = item.description?.toLowerCase() || '';
        return (
          (itemDesc.includes('remove roof') || itemDesc.includes('tear off') || itemDesc.includes('r&r')) &&
          (itemDesc.includes('composition') || itemDesc.includes('shingle')) &&
          !itemDesc.includes('slate') &&
          !itemDesc.includes('tile') &&
          !itemDesc.includes('metal') &&
          !itemDesc.includes('cedar') &&
          !itemDesc.includes('shake') &&
          !itemDesc.includes('wood') &&
          !itemDesc.includes('membrane') &&
          !itemDesc.includes('modified') &&
          !itemDesc.includes('built-up') &&
          !itemDesc.includes('tar') &&
          !itemDesc.includes('gravel')
        );
      });
      if (tearOffMatch) return tearOffMatch;
    }

    if (descLower.includes('sheath') || descLower.includes('deck')) {
      const deckingMatch = priceList.find(item => {
        const itemDesc = item.description?.toLowerCase() || '';
        return (
          (itemDesc.includes('osb') || itemDesc.includes('plywood') || itemDesc.includes('sheathing')) &&
          (itemDesc.includes('roof') || itemDesc.includes('deck')) &&
          !itemDesc.includes('water') &&
          !itemDesc.includes('barrier') &&
          !itemDesc.includes('membrane')
        );
      });
      if (deckingMatch) return deckingMatch;
    }

    const exactMatch = priceList.find(item =>
      item.description?.toLowerCase().trim() === descLower ||
      item.code?.toLowerCase().trim() === descLower
    );
    if (exactMatch) return exactMatch;

    const codeMatch = priceList.find(item =>
      descLower.includes(item.code?.toLowerCase()) ||
      item.code?.toLowerCase().includes(descLower)
    );
    if (codeMatch) return codeMatch;

    const words = descLower.split(/\s+/);
    const significantWords = words.filter(w => w.length > 3);

    if (significantWords.length >= 2) {
      const multiWordMatch = priceList.find(item => {
        const itemDesc = item.description?.toLowerCase() || '';
        return significantWords.every(word => itemDesc.includes(word));
      });
      if (multiWordMatch) return multiWordMatch;
    }

    const singleWordMatch = priceList.find(item => {
      const itemDesc = item.description?.toLowerCase() || '';
      return significantWords.some(word => {
        if (word.length < 5) return false;
        return itemDesc.includes(word);
      });
    });
    if (singleWordMatch) return singleWordMatch;

    const roofingTerms = {
      'ice': ['ice', 'water', 'shield', 'iws'],
      'shingle': ['shingle', 'architectural', 'laminated', 'asphalt'],
      'ridge': ['ridge', 'cap'],
      'valley': ['valley'],
      'starter': ['starter', 'strip'],
      'drip': ['drip', 'edge'],
      'flashing': ['flashing', 'step'],
      'underlayment': ['underlayment', 'felt'],
      'debris': ['debris', 'removal', 'dumpster']
    };

    for (const [category, terms] of Object.entries(roofingTerms)) {
      if (terms.some(term => descLower.includes(term))) {
        const categoryMatch = priceList.find(item => {
          const itemDesc = item.description?.toLowerCase() || '';
          return terms.some(term => itemDesc.includes(term));
        });
        if (categoryMatch) return categoryMatch;
      }
    }

    return null;
  };

  const handlePricingSourceChange = (newSource) => {
    setPricingSource(newSource);
    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `📊 **Pricing source changed to: ${newSource.replace('xactimate_new', 'Xactimate New').toUpperCase()}**\n\nRecalculating all items...`,
      timestamp: new Date().toISOString()
    }]);

    // Save to history before modifying line items
    saveToHistory();

    if (lineItems.length > 0) {
      const priceList = newSource === 'xactimate' ? xactimatePriceList :
                        newSource === 'xactimate_new' ? xactimateNewPriceList :
                        newSource === 'symbility' ? symbilityPriceList :
                        customPriceList;

      const updatedItems = lineItems.map(item => {
        let matchedItem = null;

        // STEP 1: Try exact CODE match (most reliable)
        if (item.code) {
          matchedItem = priceList.find(p => 
            p.code?.toUpperCase() === item.code?.toUpperCase()
          );
          if (matchedItem) {
            console.log(`✅ Code match: ${item.code} → ${matchedItem.code} @ $${matchedItem.price}`);
          }
        }

        // STEP 2: If no code match, try matching by description + unit (strict)
        if (!matchedItem) {
          // Extract key words from description (ignore filler words)
          const itemDesc = item.description?.toLowerCase() || '';
          const keywords = itemDesc.split(/\s+/).filter(word => 
            word.length > 3 && !['the', 'and', 'for', 'with', 'from'].includes(word)
          );

          matchedItem = priceList.find(p => {
            // Must have same unit
            if (p.unit?.toUpperCase() !== item.unit?.toUpperCase()) return false;
            
            const priceDesc = p.description?.toLowerCase() || '';
            
            // At least 2 keywords must match
            const matchingKeywords = keywords.filter(kw => priceDesc.includes(kw));
            return matchingKeywords.length >= Math.min(2, keywords.length);
          });

          if (matchedItem) {
            console.log(`✅ Desc+Unit match: "${item.description}" → "${matchedItem.description}" @ $${matchedItem.price}`);
          }
        }

        // STEP 3: Final fallback using smart matching
        if (!matchedItem) {
          matchedItem = smartDescriptionMatch(item.description, priceList);
          if (matchedItem) {
            console.log(`⚠️ Fallback match: "${item.description}" → "${matchedItem.description}" @ $${matchedItem.price}`);
          }
        }
        
        if (matchedItem) {
          const newPrice = Number(matchedItem.price) || 0;
          const qty = Number(item.quantity) || 0;
          const newRcv = Math.round(newPrice * qty * 100) / 100;
          const depPercent = Number(item.depreciation_percent) || 0;
          const newAcv = Math.round(newRcv * (1 - depPercent / 100) * 100) / 100;
          
          return {
            ...item,
            code: matchedItem.code,
            unit: matchedItem.unit || item.unit,
            rate: Math.round(newPrice * 100) / 100,
            rcv: newRcv,
            acv: newAcv,
            amount: newRcv
          };
        }
        
        // No match found - keep original data but zero out pricing
        console.warn(`❌ No match for: ${item.description} (${item.unit})`);
        return {
          ...item,
          rate: 0,
          rcv: 0,
          acv: 0,
          amount: 0
        };
      });

      setLineItems(updatedItems);

      const totalRcv = updatedItems.reduce((acc, item) => acc + (Number(item.rcv) || 0), 0);
      const unmatchedCount = updatedItems.filter(i => (Number(i.rate) || 0) === 0).length;

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Updated all ${updatedItems.length} items.\n\nNew total: $${totalRcv.toLocaleString()}${unmatchedCount > 0 ? `\n\n⚠️ ${unmatchedCount} items not found in ${newSource} - set to $0` : ''}`,
        timestamp: new Date().toISOString()
      }]);
    }
  };

  const handleSatelliteAddressSelect = async (address, details) => {
    if (!details?.geometry?.location) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Could not get location details for the address. Please try again.`,
        timestamp: new Date().toISOString()
      }]);
      return;
    }

    const lat = details.geometry.location.lat();
    const lng = details.geometry.location.lng();

    console.log('📍 Selected address:', address);
    console.log('🗺️ Coordinates:', { lat, lng });

    setSatelliteAddress({
      address: address,
      coordinates: { lat, lng }
    });
    setSatelliteAnalysis(null);
    setUseManualDrawing(false);
    setManualAddOnMode(false); // Reset manual add-on mode
    setManualMeasurements([]); // Clear manual add-on measurements

    setCustomerInfo(prev => ({
      ...prev,
      property_address: address
    }));

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `📍 **Property selected:** ${address}\n\n✨ **Choose your measurement method:**\n\n1️⃣ **AI Auto-Detect** (30-60 seconds) - Let AI analyze the roof automatically\n2️⃣ **Manual Drawing** (Most Accurate) - Draw lines yourself on the satellite map\n\nClick the button below to choose!`,
      timestamp: new Date().toISOString()
    }]);
  };

  // handleManualMeasurementsComplete is removed, its logic is now inline in InteractiveRoofMap's onMeasurementComplete
  // within the `else` branch (when manualAddOnMode is false)

  const handleAIAutoDetect = async () => {
    if (!satelliteAddress) {
      console.error('❌ No satellite address available');
      return;
    }

    const { lat, lng } = satelliteAddress.coordinates;

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `🤖 **AI is analyzing the roof from satellite imagery...**\n\n⏱️ This takes 30-60 seconds...`,
      timestamp: new Date().toISOString()
    }]);

    setIsSatelliteAnalyzing(true);
    setUseManualDrawing(false);
    setManualAddOnMode(false);

    try {
      const functionName = measurementAPI === 'gemini_vision' ? 'geminiRoofMeasurement' : 'aiRoofMeasurement';
      console.log(`🚀 Calling ${functionName} function...`);
      console.log('Payload:', { latitude: lat, longitude: lng, address: satelliteAddress.address });
      
      const response = await base44.functions.invoke(functionName, {
        latitude: lat,
        longitude: lng,
        address: satelliteAddress.address
      });

      console.log('📊 Function response:', response);
      console.log('Response status:', response?.status);
      console.log('Response data:', response?.data);

      if (response?.data?.debug_logs) {
        console.log('🔍 Backend logs:', response.data.debug_logs);
      }

      // Check for error responses
      if (!response || !response.data) {
        console.error('❌ Empty response from backend');
        throw new Error('No response from AI measurement service');
      }

      if (!response.data.success) {
        console.error('❌ Backend returned error:', response.data.error);
        throw new Error(response.data.error || 'Failed to analyze roof');
      }

      console.log('✅ Backend returned success:', response.data.success);

      const analysis = {
        roof_area_sq: response.data.roof_area_sq,
        roof_area_sqft: response.data.roof_area_sqft,
        // Capture new fields
        final_order_quantity_sq: response.data.final_order_quantity_sq,
        waste_percentage: response.data.waste_percentage,
        waste_reason: response.data.waste_reason,
        warning_message: response.data.warning_message,
        
        ridge_lf: response.data.ridge_lf,
        hip_lf: response.data.hip_lf,
        valley_lf: response.data.valley_lf,
        rake_lf: response.data.rake_lf,
        eave_lf: response.data.eave_lf,
        step_flashing_lf: response.data.step_flashing_lf,
        pitch: response.data.pitch,
        is_flat_roof: response.data.is_flat_roof || false,
        satellite_image_url: response.data.satellite_image_url,
        satellite_image_base64: response.data.satellite_image_base64,
        detected_lines: response.data.detected_lines,
        overall_confidence: response.data.overall_confidence || 100,
        ridge_confidence: response.data.ridge_confidence || 100,
        hip_confidence: response.data.hip_confidence || 100,
        valley_confidence: response.data.valley_confidence || 100,
        rake_confidence: response.data.rake_confidence || 100,
        eave_confidence: response.data.eave_confidence || 100,
        step_flashing_confidence: response.data.step_flashing_confidence || 100,
        analysis_notes: response.data.analysis_notes || null,
        gutter_lf: 0, // Controlled by UI state
        downspout_count: 0, // Controlled by UI state
        structures: []
      };

      console.log('✅ Analysis object created:', analysis);

      // NEW: Store as a structure
      const structureData = {
        id: Date.now(), // Unique ID for keying
        name: isAddingStructure ? `Structure ${analyzedStructures.length + 1}` : "Main Property", // Changed "Main House" to "Main Property"
        address: satelliteAddress.address,
        analysis: analysis // Store the individual analysis
      };

      if (isAddingStructure) {
        setAnalyzedStructures(prev => [...prev, structureData]);
        setSatelliteAnalysis(null); // Clear analysis to allow new measurement
        setIsAddingStructure(false); // Reset adding structure mode

        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `✅ **Added ${structureData.name}!**\n\n📊 ${analysis.roof_area_sq.toFixed(2)} SQ • Pitch: ${analysis.pitch}\n\n💡 Click "Generate Combined Estimate" to create estimate with all structures!`, // Updated message
          timestamp: new Date().toISOString()
        }]);
      } else {
        // First structure being analyzed
        setAnalyzedStructures([structureData]); // Initialize with the first structure
        setSatelliteAnalysis(analysis); // Set satelliteAnalysis for display of first structure
        // Gutters auto-filled by useEffect based on analyzedStructures
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `✅ **Analyzed ${structureData.name} (${analysis.roof_area_sq.toFixed(2)} SQ)!**\n\nReview the measurements, add gutters, or add more structures. When ready, click "Generate Estimate".`,
          timestamp: new Date().toISOString()
        }]);

        if (analysis.overall_confidence < 80) {
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `⚠️ **AI Confidence Below 80% Threshold**\n\n📊 Current confidence: ${analysis.overall_confidence}%\n\n💡 **Recommendation:** For more accurate linear measurements, consider:\n• Uploading an aerial measurement report (HOVER, EagleView)\n• Using Manual Drawing mode for precise control\n• Verifying measurements with on-site inspection\n\nEstimate created but should be reviewed before sending to customer.`,
            timestamp: new Date().toISOString()
          }]);
        }
      }

    } catch (error) {
      console.error('💥 Satellite analysis error:', error);
      console.error('Error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ **Error analyzing property:**\n\n${error.message}\n\n**Troubleshooting:**\n• Make sure GOOGLE_MAPS_API_KEY is set in Settings → Secrets\n• Make sure Google Solar API is enabled for this key\n• Try a different address\n• Use Manual Drawing mode instead (most accurate!)`,
        timestamp: new Date().toISOString()
      }]);
    }

    setIsSatelliteAnalyzing(false);
  };

  // NEW: Generate combined estimate from all structures and manual add-ons
  const handleGenerateCombinedEstimate = async () => {
    if (analyzedStructures.length === 0 && manualMeasurements.length === 0) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `⚠️ No measurements available to generate an estimate. Please analyze a property or draw manually.`,
        timestamp: new Date().toISOString()
      }]);
      return;
    }

    let combinedAnalysis = {
      roof_area_sq: 0,
      roof_area_sqft: 0,
      ridge_lf: 0,
      hip_lf: 0,
      valley_lf: 0,
      rake_lf: 0,
      eave_lf: 0,
      step_flashing_lf: 0,
      pitch: '7/12', // Default pitch
      satellite_image_url: null,
      overall_confidence: 100,
      structures: [],
      manual_measurements_details: [],
      analysis_notes: 'Combined measurements'
    };

    // 1. Add measurements from analyzedStructures if they exist
    if (analyzedStructures.length > 0) {
      combinedAnalysis.roof_area_sq = analyzedStructures.reduce((sum, s) => sum + (s.analysis.roof_area_sq || 0), 0);
      combinedAnalysis.roof_area_sqft = analyzedStructures.reduce((sum, s) => sum + (s.analysis.roof_area_sqft || 0), 0);
      combinedAnalysis.ridge_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.ridge_lf || 0), 0);
      combinedAnalysis.hip_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.hip_lf || 0), 0);
      combinedAnalysis.valley_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.valley_lf || 0), 0);
      combinedAnalysis.rake_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.rake_lf || 0), 0);
      combinedAnalysis.eave_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.eave_lf || 0), 0);
      combinedAnalysis.step_flashing_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.step_flashing_lf || 0), 0);
      combinedAnalysis.pitch = analyzedStructures[0].analysis.pitch; // Take first structure's pitch as primary
      combinedAnalysis.satellite_image_url = analyzedStructures[0].analysis.satellite_image_url;
      combinedAnalysis.overall_confidence = Math.min(...analyzedStructures.map(s => s.analysis.overall_confidence || 100));
      combinedAnalysis.structures = analyzedStructures;
      combinedAnalysis.analysis_notes = analyzedStructures[0].analysis.analysis_notes;
    }

    // 2. Add all manual add-on measurements
    if (manualMeasurements.length > 0) {
      combinedAnalysis.roof_area_sq += manualMeasurements.reduce((sum, m) => sum + (m.roof_area_sq || 0), 0);
      combinedAnalysis.roof_area_sqft += manualMeasurements.reduce((sum, m) => sum + (m.roof_area_sqft || 0), 0);
      combinedAnalysis.ridge_lf += manualMeasurements.reduce((sum, m) => sum + (m.ridge_lf || 0), 0);
      combinedAnalysis.hip_lf += manualMeasurements.reduce((sum, m) => sum + (m.hip_lf || 0), 0);
      combinedAnalysis.valley_lf += manualMeasurements.reduce((sum, m) => sum + (m.valley_lf || 0), 0);
      combinedAnalysis.rake_lf += manualMeasurements.reduce((sum, m) => sum + (m.rake_lf || 0), 0);
      combinedAnalysis.eave_lf += manualMeasurements.reduce((sum, m) => sum + (m.eave_lf || 0), 0);
      combinedAnalysis.step_flashing_lf += manualMeasurements.reduce((sum, m) => sum + (m.step_flashing_lf || 0), 0);
      combinedAnalysis.overall_confidence = Math.min(combinedAnalysis.overall_confidence, 100); // Manual adds 100% confidence
      combinedAnalysis.analysis_notes = (combinedAnalysis.analysis_notes ? combinedAnalysis.analysis_notes + '\n' : '') + `Manual Add-ons: ${manualMeasurements.reduce((sum, m) => sum + m.roof_area_sq, 0).toFixed(2)} SQ`;
      combinedAnalysis.manual_measurements_details = manualMeasurements;
    }
    
    // 3. Add gutters from UI state (these are already synced with combined eaves by useEffect)
    combinedAnalysis.gutter_lf = includeGuttersAI ? aiGutterLF : 0;
    combinedAnalysis.downspout_count = includeGuttersAI ? aiDownspoutCount : 0;

    console.log('📏 Combined measurements about to convert:', combinedAnalysis);
    
    // Generate based on user's roof type selection
    if (roofTypeSelection === "flat") {
      await convertFlatRoofToLineItems(combinedAnalysis);
    } else if (roofTypeSelection === "metal") {
      await convertMetalRoofToLineItems(combinedAnalysis);
    } else {
      await convertMeasurementsToLineItems(combinedAnalysis);
    }

    // After generating the estimate, reset state for new property or further additions
    setIsAddingStructure(false);
    setManualAddOnMode(false);
    setManualMeasurements([]);
  };

  // NEW: Regenerate estimate when gutters are toggled or values changed
  const handleRegenerateWithGutters = async () => {
    if (analyzedStructures.length === 0 && manualMeasurements.length === 0) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `⚠️ No measurements available to regenerate.`,
        timestamp: new Date().toISOString()
      }]);
      return;
    }

    // Re-run the combination logic
    let combinedAnalysis = {
      roof_area_sq: 0, roof_area_sqft: 0, ridge_lf: 0, hip_lf: 0,
      valley_lf: 0, rake_lf: 0, eave_lf: 0, step_flashing_lf: 0,
      pitch: '7/12', satellite_image_url: null, overall_confidence: 100,
      structures: [], manual_measurements_details: [], analysis_notes: 'Combined measurements'
    };

    if (analyzedStructures.length > 0) {
      combinedAnalysis.roof_area_sq = analyzedStructures.reduce((sum, s) => sum + (s.analysis.roof_area_sq || 0), 0);
      combinedAnalysis.roof_area_sqft = analyzedStructures.reduce((sum, s) => sum + (s.analysis.roof_area_sqft || 0), 0);
      combinedAnalysis.ridge_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.ridge_lf || 0), 0);
      combinedAnalysis.hip_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.hip_lf || 0), 0);
      combinedAnalysis.valley_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.valley_lf || 0), 0);
      combinedAnalysis.rake_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.rake_lf || 0), 0);
      combinedAnalysis.eave_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.eave_lf || 0), 0);
      combinedAnalysis.step_flashing_lf = analyzedStructures.reduce((sum, s) => sum + (s.analysis.step_flashing_lf || 0), 0);
      combinedAnalysis.pitch = analyzedStructures[0].analysis.pitch;
      combinedAnalysis.satellite_image_url = analyzedStructures[0].analysis.satellite_image_url;
      combinedAnalysis.overall_confidence = Math.min(...analyzedStructures.map(s => s.analysis.overall_confidence || 100));
      combinedAnalysis.structures = analyzedStructures;
      combinedAnalysis.analysis_notes = analyzedStructures[0].analysis.analysis_notes;
    }

    if (manualMeasurements.length > 0) {
      combinedAnalysis.roof_area_sq += manualMeasurements.reduce((sum, m) => sum + (m.roof_area_sq || 0), 0);
      combinedAnalysis.roof_area_sqft += manualMeasurements.reduce((sum, m) => sum + (m.roof_area_sqft || 0), 0);
      combinedAnalysis.ridge_lf += manualMeasurements.reduce((sum, m) => sum + (m.ridge_lf || 0), 0);
      combinedAnalysis.hip_lf += manualMeasurements.reduce((sum, m) => sum + (m.hip_lf || 0), 0);
      combinedAnalysis.valley_lf += manualMeasurements.reduce((sum, m) => sum + (m.valley_lf || 0), 0);
      combinedAnalysis.rake_lf += manualMeasurements.reduce((sum, m) => sum + (m.rake_lf || 0), 0);
      combinedAnalysis.eave_lf += manualMeasurements.reduce((sum, m) => sum + (m.eave_lf || 0), 0);
      combinedAnalysis.step_flashing_lf += manualMeasurements.reduce((sum, m) => sum + (m.step_flashing_lf || 0), 0);
      combinedAnalysis.overall_confidence = Math.min(combinedAnalysis.overall_confidence, 100);
      combinedAnalysis.analysis_notes = (combinedAnalysis.analysis_notes ? combinedAnalysis.analysis_notes + '\n' : '') + `Manual Add-ons: ${manualMeasurements.reduce((sum, m) => sum + m.roof_area_sq, 0).toFixed(2)} SQ`;
      combinedAnalysis.manual_measurements_details = manualMeasurements;
    }

    combinedAnalysis.gutter_lf = includeGuttersAI ? aiGutterLF : 0;
    combinedAnalysis.downspout_count = includeGuttersAI ? aiDownspoutCount : 0;

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `🔄 **Regenerating estimate${includeGuttersAI ? ' with gutters & downspouts' : ' without gutters'}...**`,
      timestamp: new Date().toISOString()
    }]);

    // Generate based on user's roof type selection
    if (roofTypeSelection === "flat") {
      await convertFlatRoofToLineItems(combinedAnalysis);
    } else if (roofTypeSelection === "metal") {
      await convertMetalRoofToLineItems(combinedAnalysis);
    } else {
      await convertMeasurementsToLineItems(combinedAnalysis);
    }
  };

  // NEW: Convert metal roof measurements to line items
  const convertMetalRoofToLineItems = async (measurements) => {
    console.log('🔩 Converting METAL ROOF measurements to line items:', measurements);
    
    saveToHistory();

    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;

    const items = [];
    let lineNumber = 1;
    const squares = Number(measurements.roof_area_sq) || 0;

    const findMetalItem = (codes, keywords, fallback, unit = null) => {
      for (const code of codes) {
        const match = priceList.find(item => item.code?.toUpperCase() === code.toUpperCase());
        if (match) return match;
      }
      for (const kw of keywords) {
        const match = priceList.find(item => {
          const desc = item.description?.toLowerCase() || '';
          const isMatch = desc.includes(kw.toLowerCase()) && 
                 !desc.includes('asphalt') && 
                 !desc.includes('shingle') && 
                 !desc.includes('composition');
          
          if (unit) {
            return isMatch && item.unit?.toUpperCase() === unit.toUpperCase();
          }
          return isMatch;
        });
        if (match) return match;
      }
      return fallback;
    };

    // 1. METAL PANELS
    if (squares > 0) {
      const panelItem = findMetalItem(
        ['RFG METAL', 'METAL', 'STANDING SEAM'],
        ['metal panel', 'standing seam', 'corrugated metal'],
        { price: 650, unit: "SQ", code: "METAL", description: "Metal Roof Panels - Standing Seam" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: panelItem.code,
        description: panelItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(panelItem.price),
        rcv: Number(panelItem.price) * squares,
        acv: Number(panelItem.price) * squares,
        amount: Number(panelItem.price) * squares,
        depreciation: 0
      });
    }

    // 2. UNDERLAYMENT (High-temp for metal)
    if (squares > 0) {
      const underlaymentItem = findMetalItem(
        ['RFG UL SYN', 'SYNTH HT'],
        ['synthetic underlayment high temp', 'high-temp underlayment'],
        { price: 45, unit: "SQ", code: "UL-HT", description: "Underlayment, synthetic, high-temp for metal" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: underlaymentItem.code,
        description: underlaymentItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(underlaymentItem.price),
        rcv: Number(underlaymentItem.price) * squares,
        acv: Number(underlaymentItem.price) * squares,
        amount: Number(underlaymentItem.price) * squares,
        depreciation: 0
      });
    }

    // 3. ICE & WATER SHIELD
    const eavesLF = Number(measurements.eave_lf) || 0;
    const valleysLF = Number(measurements.valley_lf) || 0;
    const totalIceWater = Math.ceil((eavesLF * 2 + valleysLF) * 1.10);
    if (totalIceWater > 0) {
      const iceWaterItem = findMetalItem(['IWS', 'RFG IWS'], ['ice & water barrier'], { price: 2.25, unit: "LF", code: "IWS", description: "Ice & water barrier" });
      items.push({ line: lineNumber++, code: iceWaterItem.code, description: iceWaterItem.description, quantity: totalIceWater, unit: "LF", rate: Number(iceWaterItem.price), rcv: Number(iceWaterItem.price) * totalIceWater, acv: Number(iceWaterItem.price) * totalIceWater, amount: Number(iceWaterItem.price) * totalIceWater, depreciation: 0 });
    }
    
    // 4. RIDGE CAP (Metal)
    const ridgeLF = Number(measurements.ridge_lf) || 0;
    if (ridgeLF > 0) {
      const ridgeItem = findMetalItem(
        ['RIDGE M', 'METAL RIDGE'],
        ['ridge cap metal', 'metal ridge'],
        { price: 15, unit: "LF", code: "RIDGE M", description: "Ridge Cap - Metal" }
      );
      items.push({ line: lineNumber++, code: ridgeItem.code, description: ridgeItem.description, quantity: ridgeLF, unit: "LF", rate: Number(ridgeItem.price), rcv: Number(ridgeItem.price) * ridgeLF, acv: Number(ridgeItem.price) * ridgeLF, amount: Number(ridgeItem.price) * ridgeLF, depreciation: 0 });
    }

    // 5. HIP CAP (Metal)
    const hipLF = Number(measurements.hip_lf) || 0;
    if (hipLF > 0) {
      const hipItem = findMetalItem(['HIP M'], ['hip cap metal'], { price: 15, unit: "LF", code: "HIP M", description: "Hip Cap - Metal" });
      items.push({ line: lineNumber++, code: hipItem.code, description: hipItem.description, quantity: hipLF, unit: "LF", rate: Number(hipItem.price), rcv: Number(hipItem.price) * hipLF, acv: Number(hipItem.price) * hipLF, amount: Number(hipItem.price) * hipLF, depreciation: 0 });
    }
    
    // 6. VALLEY FLASHING (Metal)
    if (valleysLF > 0) {
      const valleyItem = findMetalItem(['VMTLWP'], ['valley metal', 'w valley'], { price: 12, unit: "LF", code: "VMTLWP", description: "Valley metal - (W) profile - painted" });
      items.push({ line: lineNumber++, code: valleyItem.code, description: valleyItem.description, quantity: valleysLF, unit: "LF", rate: Number(valleyItem.price), rcv: Number(valleyItem.price) * valleysLF, acv: Number(valleyItem.price) * valleysLF, amount: Number(valleyItem.price) * valleysLF, depreciation: 0 });
    }
    
    // 7. DRIP EDGE / EAVE TRIM
    const rakeLF = Number(measurements.rake_lf) || 0;
    const totalEdge = rakeLF + eavesLF;
    if (totalEdge > 0) {
      const dripItem = findMetalItem(
        ['RFG DE', 'DRIP'],
        ['drip edge', 'eave trim'],
        { price: 3.5, unit: "LF", code: "DRIP", description: "Drip edge, metal" }
      );
      items.push({ line: lineNumber++, code: dripItem.code, description: dripItem.description, quantity: totalEdge, unit: "LF", rate: Number(dripItem.price), rcv: Number(dripItem.price) * totalEdge, acv: Number(dripItem.price) * totalEdge, amount: Number(dripItem.price) * totalEdge, depreciation: 0 });
    }

    // 8. STEP FLASHING
    const stepFlashLF = Number(measurements.step_flashing_lf) || 0;
    if (stepFlashLF > 0) {
      const flashItem = findMetalItem(['RFG FLS'], ['step flashing'], { price: 4.5, unit: "LF", code: "RFG FLS", description: "Step flashing, metal" });
      items.push({ line: lineNumber++, code: flashItem.code, description: flashItem.description, quantity: stepFlashLF, unit: "LF", rate: Number(flashItem.price), rcv: Number(flashItem.price) * stepFlashLF, acv: Number(flashItem.price) * stepFlashLF, amount: Number(flashItem.price) * stepFlashLF, depreciation: 0 });
    }

    // 9. FASTENERS/SCREWS
    if (squares > 0) {
      const fastenerItem = findMetalItem(
        ['FASTENERS', 'SCREWS'],
        ['metal roof fasteners', 'roofing screws'],
        { price: 25, unit: "SQ", code: "FASTENERS", description: "Fasteners and screws for metal panels" }
      );
      items.push({ line: lineNumber++, code: fastenerItem.code, description: fastenerItem.description, quantity: squares, unit: "SQ", rate: Number(fastenerItem.price), rcv: Number(fastenerItem.price) * squares, acv: Number(fastenerItem.price) * squares, amount: Number(fastenerItem.price) * squares, depreciation: 0 });
    }

    // 10. TEAR OFF
    if (squares > 0) {
      const tearOffItem = findMetalItem(
        ['ARMV', 'TEAR', 'REMOVE'],
        ['remove roof', 'tear off shingle', 'tear off composition'],
        { price: 85, unit: "SQ", code: "ARMV", description: "Remove existing roof covering - composition" }
      );
      items.push({ line: lineNumber++, code: tearOffItem.code, description: tearOffItem.description, quantity: squares, unit: "SQ", rate: Number(tearOffItem.price), rcv: Number(tearOffItem.price) * squares, acv: Number(tearOffItem.price) * squares, amount: Number(tearOffItem.price) * squares, depreciation: 0 });
    }

    console.log('✅ Metal roof line items created:', items);
    setLineItems(items);

    const total = items.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
    const titleText = `${squares.toFixed(2)} SQ Metal Roof - ${satelliteAddress?.address || measurements.customer_info?.property_address || 'Property'}`;

    setCurrentEstimate({ title: titleText });

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `✅ **Created Complete METAL ROOF Estimate!**\n\n📊 **${items.length} items** • **Total: $${total.toLocaleString()}**\n\n🔩 All necessary metal components, flashing, and fasteners included.`,
      timestamp: new Date().toISOString()
    }]);
  };

  // NEW: Convert flat roof measurements to line items
  const convertFlatRoofToLineItems = async (measurements) => {
    console.log('🏢 Converting FLAT ROOF measurements to line items:', measurements);
    
    saveToHistory();

    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;

    const items = [];
    let lineNumber = 1;
    const squares = Number(measurements.roof_area_sq) || 0;
    const perimeter = Number(measurements.eave_lf) + Number(measurements.rake_lf) || 0;

    // Helper to find flat roof items
    const findFlatRoofItem = (codes, keywords, fallback, unit = null) => {
      for (const code of codes) {
        const match = priceList.find(item => item.code?.toUpperCase() === code.toUpperCase());
        if (match) return match;
      }
      for (const kw of keywords) {
        const match = priceList.find(item => {
          const desc = item.description?.toLowerCase() || '';
          const isMatch = desc.includes(kw.toLowerCase()) && 
                 !desc.includes('asphalt') && 
                 !desc.includes('shingle') && 
                 !desc.includes('composition');
          
          if (unit) {
            return isMatch && item.unit?.toUpperCase() === unit.toUpperCase();
          }
          return isMatch;
        });
        if (match) return match;
      }
      return fallback;
    };

    // 1. EPDM MEMBRANE (Default flat roof system)
    if (squares > 0) {
      const membraneItem = findFlatRoofItem(
        ['EPDM', 'TPO', 'RFG EPDM'],
        ['epdm membrane', 'rubber membrane', 'tpo membrane'],
        { price: 450, unit: "SQ", code: "EPDM", description: "EPDM Membrane - 60 mil" },
        "SQ"
      );
      const wasteMultiplier = 1.15;
      const qty = squares * wasteMultiplier;
      items.push({
        line: lineNumber++,
        code: membraneItem.code,
        description: membraneItem.description,
        quantity: qty,
        unit: "SQ",
        rate: Number(membraneItem.price),
        rcv: Number(membraneItem.price) * qty,
        acv: Number(membraneItem.price) * qty,
        amount: Number(membraneItem.price) * qty,
        depreciation: 0,
        notes: `Includes ${((wasteMultiplier - 1) * 100).toFixed(0)}% waste factor`
      });
    }

    // 2. INSULATION (2" Polyiso standard)
    if (squares > 0) {
      const insulationItem = findFlatRoofItem(
        ['INSUL', 'POLYISO'],
        ['polyiso insulation', 'roof insulation', 'insulation board'],
        { price: 120, unit: "SQ", code: "INSUL", description: "Polyiso Insulation - 2 inch" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: insulationItem.code,
        description: insulationItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(insulationItem.price),
        rcv: Number(insulationItem.price) * squares,
        acv: Number(insulationItem.price) * squares,
        amount: Number(insulationItem.price) * squares,
        depreciation: 0
      });
    }

    // 3. COVER BOARD
    if (squares > 0) {
      const coverBoardItem = findFlatRoofItem(
        ['COVER', 'GYPSUM'],
        ['cover board', 'gypsum board'],
        { price: 85, unit: "SQ", code: "COVER", description: "Cover Board - 1/2 inch Gypsum" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: coverBoardItem.code,
        description: coverBoardItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(coverBoardItem.price),
        rcv: Number(coverBoardItem.price) * squares,
        acv: Number(coverBoardItem.price) * squares,
        amount: Number(coverBoardItem.price) * squares,
        depreciation: 0
      });
    }

    // 4. TERMINATION BARS
    if (perimeter > 0) {
      const termBarItem = findFlatRoofItem(
        ['TERM', 'TERMBAR'],
        ['termination bar', 'edge bar'],
        { price: 8.50, unit: "LF", code: "TERMBAR", description: "Termination Bar - Aluminum" },
        "LF"
      );
      items.push({
        line: lineNumber++,
        code: termBarItem.code,
        description: termBarItem.description,
        quantity: perimeter,
        unit: "LF",
        rate: Number(termBarItem.price),
        rcv: Number(termBarItem.price) * perimeter,
        acv: Number(termBarItem.price) * perimeter,
        amount: Number(termBarItem.price) * perimeter,
        depreciation: 0
      });
    }

    // 5. EDGE METAL / GRAVEL STOP
    if (perimeter > 0) {
      const edgeMetalItem = findFlatRoofItem(
        ['EDGE', 'GRAVEL'],
        ['edge metal', 'gravel stop', 'drip edge'],
        { price: 12.00, unit: "LF", code: "EDGE", description: "Edge Metal / Gravel Stop" },
        "LF"
      );
      items.push({
        line: lineNumber++,
        code: edgeMetalItem.code,
        description: edgeMetalItem.description,
        quantity: perimeter,
        unit: "LF",
        rate: Number(edgeMetalItem.price),
        rcv: Number(edgeMetalItem.price) * perimeter,
        acv: Number(edgeMetalItem.price) * perimeter,
        amount: Number(edgeMetalItem.price) * perimeter,
        depreciation: 0
      });
    }

    // 6. ROOF DRAINS (Estimate 1 per 600 SF)
    const drainCount = Math.max(1, Math.ceil((squares * 100) / 600));
    if (drainCount > 0) {
      const drainItem = findFlatRoofItem(
        ['DRAIN', 'RFG DRAIN'],
        ['roof drain', 'drain cast iron'],
        { price: 250, unit: "EA", code: "DRAIN", description: "Roof Drain - 4 inch Cast Iron" },
        "EA"
      );
      items.push({
        line: lineNumber++,
        code: drainItem.code,
        description: drainItem.description,
        quantity: drainCount,
        unit: "EA",
        rate: Number(drainItem.price),
        rcv: Number(drainItem.price) * drainCount,
        acv: Number(drainItem.price) * drainCount,
        amount: Number(drainItem.price) * drainCount,
        depreciation: 0
      });
    }

    // 7. FASTENERS & PLATES (Estimate per SQ based on system)
    if (squares > 0) {
      const fastenerItem = findFlatRoofItem(
        ['FASTENER', 'PLATE'],
        ['insulation fastener', 'fastener plate'],
        { price: 45, unit: "SQ", code: "FASTENERS", description: "Insulation Fasteners & Plates" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: fastenerItem.code,
        description: fastenerItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(fastenerItem.price),
        rcv: Number(fastenerItem.price) * squares,
        acv: Number(fastenerItem.price) * squares,
        amount: Number(fastenerItem.price) * squares,
        depreciation: 0
      });
    }

    // 8. TEAR OFF EXISTING ROOF
    if (squares > 0) {
      const tearOffItem = findFlatRoofItem(
        ['TEAR', 'REMOVE'],
        ['remove roof', 'tear off membrane'],
        { price: 125, unit: "SQ", code: "TEAR", description: "Remove existing flat roof membrane & insulation" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: tearOffItem.code,
        description: tearOffItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(tearOffItem.price),
        rcv: Number(tearOffItem.price) * squares,
        acv: Number(tearOffItem.price) * squares,
        amount: Number(tearOffItem.price) * squares,
        depreciation: 0
      });
    }

    // 9. LABOR
    if (squares > 0) {
      const laborItem = findFlatRoofItem(
        ['LABOR', 'INSTALL'],
        ['flat roof labor', 'epdm installation'],
        { price: 200, unit: "SQ", code: "LABOR-FLAT", description: "Flat Roof Installation Labor" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: laborItem.code,
        description: laborItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(laborItem.price),
        rcv: Number(laborItem.price) * squares,
        acv: Number(laborItem.price) * squares,
        amount: Number(laborItem.price) * squares,
        depreciation: 0
      });
    }
    
    // 10. WARRANTY
    if (squares > 0) {
      const warrantyItem = findFlatRoofItem(
        ['WARRANTY'],
        ['manufacturer warranty', 'NDL warranty'],
        { price: 25, unit: "SQ", code: "WARRANTY", description: "Manufacturer NDL Warranty - 20 Year" },
        "SQ"
      );
      items.push({
        line: lineNumber++,
        code: warrantyItem.code,
        description: warrantyItem.description,
        quantity: squares,
        unit: "SQ",
        rate: Number(warrantyItem.price),
        rcv: Number(warrantyItem.price) * squares,
        acv: Number(warrantyItem.price) * squares,
        amount: Number(warrantyItem.price) * squares,
        depreciation: 0
      });
    }

    console.log('✅ Flat roof line items created:', items);
    setLineItems(items);

    const total = items.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
    const titleText = `${squares.toFixed(2)} SQ Flat Roof (EPDM) - ${measurements.customer_info?.property_address || 'Commercial Property'}`;

    setCurrentEstimate({ title: titleText });

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `✅ **Created COMPLETE Flat Roof Estimate (EPDM System)!**\n\n📊 **${items.length} items** • **Total: $${total.toLocaleString()}**\n\n🏢 Roof: ${squares.toFixed(2)} SQ\n📏 Perimeter: ${perimeter.toFixed(0)} LF\n🚰 Drains: ${drainCount}\n\n💡 *Tip: Ask AI to "switch to TPO" or "add torch down cap sheet" if needed*`,
      timestamp: new Date().toISOString()
    }]);

    // Set customer info if available
    if (measurements.customer_info) {
      setCustomerInfo(prev => ({
        ...prev,
        customer_name: measurements.customer_info.customer_name || prev.customer_name,
        property_address: measurements.customer_info.property_address || prev.property_address,
        claim_number: measurements.customer_info.claim_number || prev.claim_number
      }));
    }
  };

  const convertSidingMeasurementsToLineItems = async (measurements) => {
    console.log('🔄 convertSidingMeasurementsToLineItems called with:', measurements);
    
    // Save to history before making changes
    saveToHistory();

    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;

    console.log(`📋 Using ${pricingSource} price list with ${priceList.length} items for siding`);

    const items = [];
    let lineNumber = 1;

    const findSidingItem = (searchTerms, fallback) => {
      for (const code of searchTerms.codes || []) {
        const match = priceList.find(item => {
          if (item.code?.toUpperCase() !== code.toUpperCase()) return false;
          
          const desc = item.description?.toLowerCase() || '';
          if (searchTerms.exclude) {
            for (const excludeWord of searchTerms.exclude) {
              if (desc.includes(excludeWord.toLowerCase())) {
                return false;
              }
            }
          }
          
          return true;
        });
        
        if (match) {
          console.log(`✅ Code match: ${match.code} - ${match.description} @ $${match.price}`);
          return match;
        }
      }
      
      for (const term of searchTerms.keywords || []) {
        const match = priceList.find(item => {
          const itemDesc = item.description?.toLowerCase() || '';
          
          if (!itemDesc.includes(term.toLowerCase())) return false;
          
          if (searchTerms.exclude) {
            for (const excludeWord of searchTerms.exclude) {
              if (itemDesc.includes(excludeWord.toLowerCase())) return false;
            }
          }
          
          return true;
        });
        if (match) {
          console.log(`✅ Keyword match: ${match.code} - ${match.description} @ $${match.price}`);
          return match;
        }
      }
      
      console.log(`⚠️ No match found, using fallback: ${fallback.description} @ $${fallback.price}`);
      return fallback;
    };

    const wallAreaSQ = Number(measurements.wall_area_sq) || (Number(measurements.wall_area_sqft) / 100) || 0;
    const wallAreaSF = Number(measurements.wall_area_sqft) || (wallAreaSQ * 100) || 0;

    // 1. REMOVE OLD SIDING (Do FIRST before installing new)
    if (wallAreaSQ > 0) {
      const removalItem = findSidingItem({
        codes: ['SID REM', 'REMOVE SIDING'],
        keywords: ['remove siding', 'removal siding', 'tear off siding'],
        exclude: []
      }, {
        price: 45,
        unit: "SQ",
        code: "SID REM",
        description: "Remove siding, vinyl or aluminum"
      });
      
      const price = Number(removalItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: removalItem.code,
        description: removalItem.description,
        quantity: wallAreaSQ,
        unit: "SQ",
        rate: price,
        rcv: price * wallAreaSQ,
        acv: price * wallAreaSQ,
        amount: price * wallAreaSQ,
        depreciation: 0
      });
    }

    // 2. VINYL SIDING
    if (wallAreaSQ > 0) {
      const sidingItem = findSidingItem({
        codes: ['SID VS', 'VINYL SIDING'],
        keywords: ['vinyl siding', 'siding vinyl'],
        exclude: ['removal', 'remove', 'soffit', 'fascia', 'trim', 'corner']
      }, {
        price: 425,
        unit: "SQ",
        code: "SID VS",
        description: "Vinyl siding, standard grade"
      });
      
      const price = Number(sidingItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: sidingItem.code,
        description: sidingItem.description,
        quantity: wallAreaSQ,
        unit: "SQ",
        rate: price,
        rcv: price * wallAreaSQ,
        acv: price * wallAreaSQ,
        amount: price * wallAreaSQ,
        depreciation: 0
      });
    }

    // 3. J-CHANNEL (Wall Top)
    const wallTopLF = Number(measurements.wall_top_lf) || 0;
    if (wallTopLF > 0) {
      const jChannelItem = findSidingItem({
        codes: ['SID J', 'J-CHANNEL'],
        keywords: ['j-channel', 'j channel'],
        exclude: []
      }, {
        price: 3.50,
        unit: "LF",
        code: "SID J",
        description: "J-channel, vinyl"
      });
      
      const price = Number(jChannelItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: jChannelItem.code,
        description: jChannelItem.description + " (Top)",
        quantity: wallTopLF,
        unit: "LF",
        rate: price,
        rcv: price * wallTopLF,
        acv: price * wallTopLF,
        amount: price * wallTopLF,
        depreciation: 0
      });
    }

    // 4. J-CHANNEL (Wall Bottom)
    const wallBottomLF = Number(measurements.wall_bottom_lf) || 0;
    if (wallBottomLF > 0) {
      const jChannelItem = findSidingItem({
        codes: ['SID J', 'J-CHANNEL'],
        keywords: ['j-channel', 'j channel'],
        exclude: []
      }, {
        price: 3.50,
        unit: "LF",
        code: "SID J",
        description: "J-channel, vinyl"
      });
      
      const price = Number(jChannelItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: jChannelItem.code,
        description: jChannelItem.description + " (Bottom)",
        quantity: wallBottomLF,
        unit: "LF",
        rate: price,
        rcv: price * wallBottomLF,
        acv: price * wallBottomLF,
        amount: price * wallBottomLF,
        depreciation: 0
      });
    }

    // 5. INSIDE CORNERS
    const insideCornersLF = Number(measurements.inside_corners_lf) || 0;
    if (insideCornersLF > 0) {
      const insideCornerItem = findSidingItem({
        codes: ['SID IC', 'INSIDE CORNER'],
        keywords: ['inside corner', 'corner inside'],
        exclude: []
      }, {
        price: 4.25,
        unit: "LF",
        code: "SID IC",
        description: "Inside corner, vinyl"
      });
      
      const price = Number(insideCornerItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: insideCornerItem.code,
        description: insideCornerItem.description,
        quantity: insideCornersLF,
        unit: "LF",
        rate: price,
        rcv: price * insideCornersLF,
        acv: price * insideCornersLF,
        amount: price * insideCornersLF,
        depreciation: 0,
        notes: `${measurements.inside_corners_count || 0} corners`
      });
    }

    // 6. OUTSIDE CORNERS
    const outsideCornersLF = Number(measurements.outside_corners_lf) || 0;
    if (outsideCornersLF > 0) {
      const outsideCornerItem = findSidingItem({
        codes: ['SID OC', 'OUTSIDE CORNER'],
        keywords: ['outside corner', 'corner outside'],
        exclude: []
      }, {
        price: 4.25,
        unit: "LF",
        code: "SID OC",
        description: "Outside corner, vinyl"
      });
      
      const price = Number(outsideCornerItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: outsideCornerItem.code,
        description: outsideCornerItem.description,
        quantity: outsideCornersLF,
        unit: "LF",
        rate: price,
        rcv: price * outsideCornersLF,
        acv: price * outsideCornersLF,
        amount: price * outsideCornersLF,
        depreciation: 0,
        notes: `${measurements.outside_corners_count || 0} corners`
      });
    }

    console.log('✅ Siding line items created:', items);
    console.log('📊 Total items:', items.length);
    
    setLineItems(items);

    const total = items.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);

    const titleText = `${wallAreaSQ.toFixed(2)} SQ Siding - ${satelliteAddress?.address || measurements.customer_info?.property_address || 'Property'}`;

    setCurrentEstimate({
      title: titleText
    });

    const itemDescriptions = [];
    itemDescriptions.push(`🏠 Wall Area: ${wallAreaSQ.toFixed(2)} SQ (${wallAreaSF.toFixed(0)} SF)`);
    itemDescriptions.push(`Wall Top: ${wallTopLF.toFixed(0)} LF`);
    itemDescriptions.push(`Wall Bottom: ${wallBottomLF.toFixed(0)} LF`);
    itemDescriptions.push(`Inside Corners: ${measurements.inside_corners_count || 0} (${insideCornersLF.toFixed(0)} LF)`);
    itemDescriptions.push(`Outside Corners: ${measurements.outside_corners_count || 0} (${outsideCornersLF.toFixed(0)} LF)`);

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `✅ **Created Complete Siding Estimate!**\n\n📊 **${items.length} items** • **Total: $${total.toLocaleString()}**\n\n${itemDescriptions.join('\n')}\n\n💡 *Ask AI to "add 10% waste" or "add 15% waste" when ready. Use "AI Review" to check for missing items like soffit, fascia, or trim*`,
      timestamp: new Date().toISOString()
    }]);
  };

  // Helper: Convert measurements to line items array (without setting state)
  const convertMeasurementsToLineItemsArray = async (measurements) => {
    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;

    // EagleView fallback: derive squares if only sqft provided
    if ((!measurements.roof_area_sq || Number(measurements.roof_area_sq) === 0) && Number(measurements.roof_area_sqft) > 0) {
      measurements.roof_area_sq = Number(measurements.roof_area_sqft) / 100;
    }

    const items = [];
    let lineNumber = 1;

    const findExactRoofItem = (searchTerms, fallback) => {
      for (const term of searchTerms.codes || []) {
        const match = priceList.find(item => {
          if (item.code?.toUpperCase() !== term.toUpperCase()) return false;
          const desc = item.description?.toLowerCase() || '';
          if (searchTerms.exclude) {
            for (const excludeWord of searchTerms.exclude) {
              if (desc.includes(excludeWord.toLowerCase())) return false;
            }
          }
          return true;
        });
        if (match) return match;
      }
      
      for (const term of searchTerms.keywords || []) {
        const match = priceList.find(item => {
          const itemDesc = item.description?.toLowerCase() || '';
          if (!itemDesc.includes(term.toLowerCase())) return false;
          if (searchTerms.exclude) {
            for (const excludeWord of searchTerms.exclude) {
              if (itemDesc.includes(excludeWord.toLowerCase())) return false;
            }
          }
          return true;
        });
        if (match) return match;
      }
      
      return fallback;
    };

    // Shingles
    if (measurements.roof_area_sq > 0) {
      const item = findExactRoofItem({ codes: ['RFG SSSQ'], keywords: ['architectural asphalt'], exclude: ['wood', 'tile', 'metal'] }, 
        { price: 350, unit: "SQ", code: "RFG SSSQ", description: "Shingles, architectural asphalt" });
      const price = Number(item.price) || 0;
      items.push({ line: lineNumber++, code: item.code, description: item.description, quantity: measurements.roof_area_sq, unit: "SQ", rate: price, rcv: price * measurements.roof_area_sq, acv: price * measurements.roof_area_sq, amount: price * measurements.roof_area_sq, depreciation: 0 });
    }

    // Underlayment
    if (measurements.roof_area_sq > 0) {
      const item = findExactRoofItem({ codes: ['RFG UL'], keywords: ['underlayment'], exclude: [] }, 
        { price: 25, unit: "SQ", code: "RFG UL", description: "Underlayment, #30 felt" });
      const price = Number(item.price) || 0;
      items.push({ line: lineNumber++, code: item.code, description: item.description, quantity: measurements.roof_area_sq, unit: "SQ", rate: price, rcv: price * measurements.roof_area_sq, acv: price * measurements.roof_area_sq, amount: price * measurements.roof_area_sq, depreciation: 0 });
    }

    // Ice & Water, Starter, Drip, Ridge, Hip, Valley, Step Flashing, Tear Off, Gutters, Downspouts (simplified)
    const eavesLF = Number(measurements.eave_lf) || 0;
    const valleysLF = Number(measurements.valley_lf) || 0;
    const totalIceWater = Math.ceil((eavesLF * 2 + valleysLF) * 1.10);
    if (totalIceWater > 0) {
      const item = findExactRoofItem({ codes: ['IWS'], keywords: ['ice & water'], exclude: [] }, { price: 2.02, unit: "LF", code: "IWS", description: "Ice & water barrier" });
      items.push({ line: lineNumber++, code: item.code, description: item.description, quantity: totalIceWater, unit: "LF", rate: Number(item.price), rcv: Number(item.price) * totalIceWater, acv: Number(item.price) * totalIceWater, amount: Number(item.price) * totalIceWater, depreciation: 0 });
    }

    const rakeLF = Number(measurements.rake_lf) || 0;
    const totalEdge = rakeLF + eavesLF;
    if (totalEdge > 0) {
      const starter = findExactRoofItem({ codes: ['RFG STR'], keywords: ['starter'], exclude: [] }, { price: 2.5, unit: "LF", code: "RFG STR", description: "Starter strip, 3-tab asphalt" });
      items.push({ line: lineNumber++, code: starter.code, description: starter.description, quantity: totalEdge, unit: "LF", rate: Number(starter.price), rcv: Number(starter.price) * totalEdge, acv: Number(starter.price) * totalEdge, amount: Number(starter.price) * totalEdge, depreciation: 0 });
      
      const drip = findExactRoofItem({ codes: ['RFG DE'], keywords: ['drip edge'], exclude: [] }, { price: 3, unit: "LF", code: "RFG DE", description: "Drip edge, metal" });
      items.push({ line: lineNumber++, code: drip.code, description: drip.description, quantity: totalEdge, unit: "LF", rate: Number(drip.price), rcv: Number(drip.price) * totalEdge, acv: Number(drip.price) * totalEdge, amount: Number(drip.price) * totalEdge, depreciation: 0 });
    }

    if (measurements.ridge_lf > 0) {
      const ridge = findExactRoofItem({ codes: ['RFG RDC'], keywords: ['ridge cap'], exclude: [] }, { price: 8.5, unit: "LF", code: "RFG RDC", description: "Ridge cap, architectural asphalt" });
      items.push({ line: lineNumber++, code: ridge.code, description: ridge.description, quantity: measurements.ridge_lf, unit: "LF", rate: Number(ridge.price), rcv: Number(ridge.price) * measurements.ridge_lf, acv: Number(ridge.price) * measurements.ridge_lf, amount: Number(ridge.price) * measurements.ridge_lf, depreciation: 0 });
    }

    if (measurements.hip_lf > 0) {
      const hip = findExactRoofItem({ codes: ['RFG HP'], keywords: ['hip cap'], exclude: [] }, { price: 8.5, unit: "LF", code: "RFG HP", description: "Hip cap, architectural asphalt" });
      items.push({ line: lineNumber++, code: hip.code, description: hip.description, quantity: measurements.hip_lf, unit: "LF", rate: Number(hip.price), rcv: Number(hip.price) * measurements.hip_lf, acv: Number(hip.price) * measurements.hip_lf, amount: Number(hip.price) * measurements.hip_lf, depreciation: 0 });
    }

    if (measurements.valley_lf > 0) {
      const valley = findExactRoofItem({ codes: ['VMTLWP'], keywords: ['valley metal'], exclude: [] }, { price: 12, unit: "LF", code: "VMTLWP", description: "Valley metal - (W) profile - painted" });
      items.push({ line: lineNumber++, code: valley.code, description: valley.description, quantity: measurements.valley_lf, unit: "LF", rate: Number(valley.price), rcv: Number(valley.price) * measurements.valley_lf, acv: Number(valley.price) * measurements.valley_lf, amount: Number(valley.price) * measurements.valley_lf, depreciation: 0 });
    }

    if (measurements.step_flashing_lf > 0) {
      const flash = findExactRoofItem({ codes: ['RFG FLS'], keywords: ['step flashing'], exclude: [] }, { price: 4.5, unit: "LF", code: "RFG FLS", description: "Step flashing, metal" });
      items.push({ line: lineNumber++, code: flash.code, description: flash.description, quantity: measurements.step_flashing_lf, unit: "LF", rate: Number(flash.price), rcv: Number(flash.price) * measurements.step_flashing_lf, acv: Number(flash.price) * measurements.step_flashing_lf, amount: Number(flash.price) * measurements.step_flashing_lf, depreciation: 0 });
    }

    if (measurements.roof_area_sq > 0) {
      const tearOff = findExactRoofItem({ codes: ['RFG R&R'], keywords: ['remove roof covering'], exclude: [] }, { price: 75, unit: "SQ", code: "RFG R&R", description: "Remove roof covering, 3-tab composition shingle" });
      items.push({ line: lineNumber++, code: tearOff.code, description: tearOff.description, quantity: measurements.roof_area_sq, unit: "SQ", rate: Number(tearOff.price), rcv: Number(tearOff.price) * measurements.roof_area_sq, acv: Number(tearOff.price) * measurements.roof_area_sq, amount: Number(tearOff.price) * measurements.roof_area_sq, depreciation: 0 });
    }

    if (measurements.gutter_lf > 0) {
      const gutter = findExactRoofItem({ codes: ['RFG GTR'], keywords: ['gutter aluminum'], exclude: [] }, { price: 10.33, unit: "LF", code: "RFG GTR", description: "Gutter / downspout - aluminum - up to 5\"" });
      items.push({ line: lineNumber++, code: gutter.code, description: gutter.description, quantity: measurements.gutter_lf, unit: "LF", rate: Number(gutter.price), rcv: Number(gutter.price) * measurements.gutter_lf, acv: Number(gutter.price) * measurements.gutter_lf, amount: Number(gutter.price) * measurements.gutter_lf, depreciation: 0 });
    }

    if (measurements.downspout_count > 0) {
      const downspout = findExactRoofItem({ codes: ['DNSPOUT'], keywords: ['downspout'], exclude: [] }, { price: 45, unit: "EA", code: "DNSPOUT", description: "Downspout - aluminum - 2\" x 3\"" });
      items.push({ line: lineNumber++, code: downspout.code, description: downspout.description, quantity: measurements.downspout_count, unit: "EA", rate: Number(downspout.price), rcv: Number(downspout.price) * measurements.downspout_count, acv: Number(downspout.price) * measurements.downspout_count, amount: Number(downspout.price) * measurements.downspout_count, depreciation: 0 });
    }

    return items;
  };

  // Helper: Convert siding measurements to line items array (without setting state)
  const convertSidingMeasurementsToLineItemsArray = async (measurements) => {
    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;

    const items = [];
    let lineNumber = 1;

    const findSidingItem = (searchTerms, fallback) => {
      for (const code of searchTerms.codes || []) {
        const match = priceList.find(item => item.code?.toUpperCase() === code.toUpperCase());
        if (match) return match;
      }
      for (const term of searchTerms.keywords || []) {
        const match = priceList.find(item => item.description?.toLowerCase().includes(term.toLowerCase()));
        if (match) return match;
      }
      return fallback;
    };

    const wallAreaSQ = Number(measurements.wall_area_sq) || (Number(measurements.wall_area_sqft) / 100) || 0;

    if (wallAreaSQ > 0) {
      const removal = findSidingItem({ codes: ['SID REM'], keywords: ['remove siding'], exclude: [] }, { price: 45, unit: "SQ", code: "SID REM", description: "Remove siding, vinyl or aluminum" });
      items.push({ line: lineNumber++, code: removal.code, description: removal.description, quantity: wallAreaSQ, unit: "SQ", rate: Number(removal.price), rcv: Number(removal.price) * wallAreaSQ, acv: Number(removal.price) * wallAreaSQ, amount: Number(removal.price) * wallAreaSQ, depreciation: 0 });

      const siding = findSidingItem({ codes: ['SID VS'], keywords: ['vinyl siding'], exclude: [] }, { price: 425, unit: "SQ", code: "SID VS", description: "Vinyl siding, standard grade" });
      items.push({ line: lineNumber++, code: siding.code, description: siding.description, quantity: wallAreaSQ, unit: "SQ", rate: Number(siding.price), rcv: Number(siding.price) * wallAreaSQ, acv: Number(siding.price) * wallAreaSQ, amount: Number(siding.price) * wallAreaSQ, depreciation: 0 });
    }

    if (measurements.wall_top_lf > 0) {
      const jChannel = findSidingItem({ codes: ['SID J'], keywords: ['j-channel'], exclude: [] }, { price: 3.50, unit: "LF", code: "SID J", description: "J-channel, vinyl" });
      items.push({ line: lineNumber++, code: jChannel.code, description: jChannel.description + " (Top)", quantity: measurements.wall_top_lf, unit: "LF", rate: Number(jChannel.price), rcv: Number(jChannel.price) * measurements.wall_top_lf, acv: Number(jChannel.price) * measurements.wall_top_lf, amount: Number(jChannel.price) * measurements.wall_top_lf, depreciation: 0 });
    }

    if (measurements.wall_bottom_lf > 0) {
      const jChannel = findSidingItem({ codes: ['SID J'], keywords: ['j-channel'], exclude: [] }, { price: 3.50, unit: "LF", code: "SID J", description: "J-channel, vinyl" });
      items.push({ line: lineNumber++, code: jChannel.code, description: jChannel.description + " (Bottom)", quantity: measurements.wall_bottom_lf, unit: "LF", rate: Number(jChannel.price), rcv: Number(jChannel.price) * measurements.wall_bottom_lf, acv: Number(jChannel.price) * measurements.wall_bottom_lf, amount: Number(jChannel.price) * measurements.wall_bottom_lf, depreciation: 0 });
    }

    if (measurements.inside_corners_lf > 0) {
      const corner = findSidingItem({ codes: ['SID IC'], keywords: ['inside corner'], exclude: [] }, { price: 4.25, unit: "LF", code: "SID IC", description: "Inside corner, vinyl" });
      items.push({ line: lineNumber++, code: corner.code, description: corner.description, quantity: measurements.inside_corners_lf, unit: "LF", rate: Number(corner.price), rcv: Number(corner.price) * measurements.inside_corners_lf, acv: Number(corner.price) * measurements.inside_corners_lf, amount: Number(corner.price) * measurements.inside_corners_lf, depreciation: 0 });
    }

    if (measurements.outside_corners_lf > 0) {
      const corner = findSidingItem({ codes: ['SID OC'], keywords: ['outside corner'], exclude: [] }, { price: 4.25, unit: "LF", code: "SID OC", description: "Outside corner, vinyl" });
      items.push({ line: lineNumber++, code: corner.code, description: corner.description, quantity: measurements.outside_corners_lf, unit: "LF", rate: Number(corner.price), rcv: Number(corner.price) * measurements.outside_corners_lf, acv: Number(corner.price) * measurements.outside_corners_lf, amount: Number(corner.price) * measurements.outside_corners_lf, depreciation: 0 });
    }

    return items;
  };

  const convertMeasurementsToLineItems = async (measurements) => {
    console.log('🔄 convertMeasurementsToLineItems called with:', measurements);
    
    // Save to history before making changes
    saveToHistory();

    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;

    console.log(`📋 Using ${pricingSource} price list with ${priceList.length} items`);

    // EagleView fallback: if only sqft is provided, derive squares
    if ((!measurements.roof_area_sq || Number(measurements.roof_area_sq) === 0) && Number(measurements.roof_area_sqft) > 0) {
      measurements.roof_area_sq = Number(measurements.roof_area_sqft) / 100;
    }

    // EagleView fallback: derive squares if only sqft provided
    if ((!measurements.roof_area_sq || Number(measurements.roof_area_sq) === 0) && Number(measurements.roof_area_sqft) > 0) {
      measurements.roof_area_sq = Number(measurements.roof_area_sqft) / 100;
    }

    const items = [];
    let lineNumber = 1;

    // Normalization helpers for EagleView/HOVER key variants
    const toNum = (v) => { if (v === undefined || v === null) return 0; const n = Number(String(v).replace(/,/g, '')); return isNaN(n) ? 0 : n; };
    const normalizeRoof = (obj = {}) => {
      const o = { ...(obj || {}) };
      const sqft = toNum(o.roof_area_sqft || o.area_sqft || o.total_area_sqft || o['Total Area (All Pitches)']);
      const sq = toNum(o.roof_area_sq || o.area_sq || o.squares || o['Squares']) || (sqft / 100);
      o.roof_area_sq = sq;
      o.roof_area_sqft = sqft || (sq * 100);
      o.ridge_lf = toNum(o.ridge_lf || o.ridges || o['Ridges'] || o.ridges_ft || o['Ridges (ft)']);
      o.hip_lf = toNum(o.hip_lf || o.hips || o['Hips'] || o.hips_ft || o['Hips (ft)']);
      o.valley_lf = toNum(o.valley_lf || o.valleys || o['Valleys'] || o.valleys_ft || o['Valleys (ft)']);
      o.rake_lf = toNum(o.rake_lf || o.rakes || o['Rakes'] || o.rakes_ft || o['Rakes (ft)']);
      o.eave_lf = toNum(o.eave_lf || o.eaves || o['Eaves'] || o.eaves_ft || o['Eaves (ft)']);
      o.step_flashing_lf = toNum(o.step_flashing_lf || o.step_flashing || o['Step flashing'] || o['Step flashing (ft)']);
      if (!o.pitch) o.pitch = o.predominant_pitch || o['Predominant Pitch'] || 'Unknown';
      return o;
    };

    // Check if this is a multi-structure estimate
    const hasMultipleStructures = measurements.structures && measurements.structures.length > 1;

    const findExactRoofItem = (searchTerms, fallback) => {
      for (const term of searchTerms.codes || []) {
        const match = priceList.find(item => {
          if (item.code?.toUpperCase() !== term.toUpperCase()) return false;
          
          const desc = item.description?.toLowerCase() || '';
          if (searchTerms.exclude) {
            for (const excludeWord of searchTerms.exclude) {
              if (desc.includes(excludeWord.toLowerCase())) {
                console.log(`❌ Code match excluded: ${item.code} - ${item.description} (contains "${excludeWord}")`);
                return false;
              }
            }
          }
          
          return true;
        });
        
        if (match) {
          console.log(`✅ Code match: ${match.code} - ${match.description} @ $${match.price}`);
          return match;
        }
      }
      
      for (const term of searchTerms.keywords || []) {
        const match = priceList.find(item => {
          const itemDesc = item.description?.toLowerCase() || '';
          
          if (!itemDesc.includes(term.toLowerCase())) return false;
          if (itemDesc.includes('vent') || itemDesc.includes('window') || itemDesc.includes('kit')) return false;
          
          if (searchTerms.exclude) {
            for (const excludeWord of searchTerms.exclude) {
              if (itemDesc.includes(excludeWord.toLowerCase())) return false;
            }
          }
          
          console.log(`⭐ Favorite match: ${item.code} - ${item.description} @ $${item.price}`);
          return true;
        });
        if (match) return match;
      }
      
      for (const term of searchTerms.keywords || []) {
        const match = priceList.find(item => {
          const itemDesc = item.description?.toLowerCase() || '';
          
          if (!itemDesc.includes(term.toLowerCase())) return false;
          if (itemDesc.includes('vent') || itemDesc.includes('window') || itemDesc.includes('kit') || itemDesc.includes('labor minimum')) return false;
          
          if (searchTerms.exclude) {
            for (const excludeWord of searchTerms.exclude) {
              if (itemDesc.includes(excludeWord.toLowerCase())) return false;
            }
          }
          
          console.log(`📝 Description match: ${item.code} - ${item.description} @ $${item.price}`);
          return true;
        });
        if (match) return match;
      }
      
      console.log(`⚠️ No match found, using fallback: ${fallback.description} @ $${fallback.price}`);
      return fallback;
    };

    // If multiple structures, generate line items for EACH structure separately
    if (hasMultipleStructures) {
      for (const structure of measurements.structures) {
        // Support both {analysis:{...}} and flat structure {...}
        const s = normalizeRoof((structure && structure.analysis) ? structure.analysis : (structure || {}));
        const name = (structure?.name || s?.name || 'Structure').toString();
        const areaSq = Number(s.roof_area_sq) || 0;
        const pitch = s.pitch || 'Unknown';
        const confidence = s.overall_confidence != null ? s.overall_confidence : 100;

        // Add structure header/separator
        items.push({
          line: lineNumber++,
          code: '',
          description: `━━━ ${name.toUpperCase()} (${areaSq.toFixed(2)} SQ) ━━━`,
          quantity: 0,
          unit: '',
          rate: 0,
          rcv: 0,
          acv: 0,
          amount: 0,
          depreciation: 0,
          long_description: `${pitch} pitch • ${confidence}% confidence`
        });

        // Generate line items for this specific structure
        const structMeasurements = normalizeRoof(s);

        // Shingles for this structure
        if ((Number(structMeasurements.roof_area_sq) || (Number(structMeasurements.roof_area_sqft)/100)) > 0) {
          const shingleItem = findExactRoofItem({
            codes: ['RFG SSSQ', 'SHINGLE', 'LAMINATED - COMP SH'],
            keywords: ['architectural asphalt', 'laminated comp', 'asphalt shingle'],
            exclude: ['wood', 'shake', 'cedar', 'tile', 'metal', 'slate', 'steep', 'surcharge', 'tear', 'ridge', 'hip', 'starter', 'valley', 'eave', 'rake']
          }, { price: 350, unit: "SQ", code: "RFG SSSQ", description: "Shingles, architectural asphalt" });
          const price = Number(shingleItem.price) || 0;
          const sqQty = Number(structMeasurements.roof_area_sq) || (Number(structMeasurements.roof_area_sqft)/100) || 0;
          items.push({ line: lineNumber++, code: shingleItem.code, description: shingleItem.description, quantity: sqQty, unit: "SQ", rate: price, rcv: price * sqQty, acv: price * sqQty, amount: price * sqQty, depreciation: 0 });
        }

        // Underlayment
        if ((Number(structMeasurements.roof_area_sq) || (Number(structMeasurements.roof_area_sqft)/100)) > 0) {
          const underlaymentItem = findExactRoofItem({ codes: ['RFG UL', 'UL'], keywords: ['underlayment', 'felt', 'synthetic'], exclude: ['vertical', 'units', 'ice', 'water', 'barrier'] }, { price: 25, unit: "SQ", code: "RFG UL", description: "Underlayment, #30 felt" });
          const price = Number(underlaymentItem.price) || 0;
          items.push({ line: lineNumber++, code: underlaymentItem.code, description: underlaymentItem.description, quantity: structMeasurements.roof_area_sq, unit: "SQ", rate: price, rcv: price * structMeasurements.roof_area_sq, acv: price * structMeasurements.roof_area_sq, amount: price * structMeasurements.roof_area_sq, depreciation: 0 });
        }

        // Ice & Water Shield
        const eavesLF = Number(structMeasurements.eave_lf) || 0;
        const valleysLF = Number(structMeasurements.valley_lf) || 0;
        const totalIceWater = Math.ceil((eavesLF * 2 + valleysLF) * 1.10);
        if (totalIceWater > 0) {
          const iceWaterItem = findExactRoofItem({ codes: ['IWS', 'RFG IWS'], keywords: ['ice & water barrier', 'ice and water'] }, { price: 2.02, unit: "LF", code: "IWS", description: "Ice & water barrier" });
          const price = Number(iceWaterItem.price) || 0;
          items.push({ line: lineNumber++, code: iceWaterItem.code, description: iceWaterItem.description, quantity: totalIceWater, unit: "LF", rate: price, rcv: price * totalIceWater, acv: price * totalIceWater, amount: price * totalIceWater, depreciation: 0 });
        }

        // Starter, Drip, Ridge, Hip, Valley, Step Flashing, Tear Off for this structure
        const rakeLF = Number(structMeasurements.rake_lf) || 0;
        const totalEdge = rakeLF + eavesLF;
        if (totalEdge > 0) {
          const starterItem = findExactRoofItem({ codes: ['RFG STR', 'STARTER'], keywords: ['starter strip', 'starter shingle'] }, { price: 2.5, unit: "LF", code: "RFG STR", description: "Starter strip, 3-tab asphalt" });
          items.push({ line: lineNumber++, code: starterItem.code, description: starterItem.description, quantity: totalEdge, unit: "LF", rate: Number(starterItem.price), rcv: Number(starterItem.price) * totalEdge, acv: Number(starterItem.price) * totalEdge, amount: Number(starterItem.price) * totalEdge, depreciation: 0 });
          
          const dripItem = findExactRoofItem({ codes: ['RFG DE', 'DRIP'], keywords: ['drip edge', 'drip metal'] }, { price: 3, unit: "LF", code: "RFG DE", description: "Drip edge, metal" });
          items.push({ line: lineNumber++, code: dripItem.code, description: dripItem.description, quantity: totalEdge, unit: "LF", rate: Number(dripItem.price), rcv: Number(dripItem.price) * totalEdge, acv: Number(dripItem.price) * totalEdge, amount: Number(dripItem.price) * totalEdge, depreciation: 0 });
        }

        if (structMeasurements.ridge_lf > 0) {
          const ridgeItem = findExactRoofItem({ codes: ['RFG RDC', 'RFG HP'], keywords: ['ridge cap', 'hip cap', 'architectural asphalt'] }, { price: 8.5, unit: "LF", code: "RFG RDC", description: "Ridge cap, architectural asphalt" });
          items.push({ line: lineNumber++, code: ridgeItem.code, description: ridgeItem.description, quantity: structMeasurements.ridge_lf, unit: "LF", rate: Number(ridgeItem.price), rcv: Number(ridgeItem.price) * structMeasurements.ridge_lf, acv: Number(ridgeItem.price) * structMeasurements.ridge_lf, amount: Number(ridgeItem.price) * structMeasurements.ridge_lf, depreciation: 0 });
        }

        if (structMeasurements.hip_lf > 0) {
          const hipItem = findExactRoofItem({ codes: ['RFG HP'], keywords: ['hip cap', 'architectural asphalt'] }, { price: 8.5, unit: "LF", code: "RFG HP", description: "Hip cap, architectural asphalt" });
          items.push({ line: lineNumber++, code: hipItem.code, description: hipItem.description, quantity: structMeasurements.hip_lf, unit: "LF", rate: Number(hipItem.price), rcv: Number(hipItem.price) * structMeasurements.hip_lf, acv: Number(hipItem.price) * structMeasurements.hip_lf, amount: Number(hipItem.price) * structMeasurements.hip_lf, depreciation: 0 });
        }

        if (valleysLF > 0) {
          const valleyItem = findExactRoofItem({ codes: ['VMTLWP', 'RFG VLY'], keywords: ['valley metal', 'valley flashing'] }, { price: 12, unit: "LF", code: "VMTLWP", description: "Valley metal - (W) profile - painted" });
          items.push({ line: lineNumber++, code: valleyItem.code, description: valleyItem.description, quantity: valleysLF, unit: "LF", rate: Number(valleyItem.price), rcv: Number(valleyItem.price) * valleysLF, acv: Number(valleyItem.price) * valleysLF, amount: Number(valleyItem.price) * valleysLF, depreciation: 0 });
        }

        if (structMeasurements.step_flashing_lf > 0) {
          const flashingItem = findExactRoofItem({ codes: ['RFG FLS', 'STEP FLSH'], keywords: ['step flashing metal', 'flashing step'] }, { price: 4.5, unit: "LF", code: "RFG FLS", description: "Step flashing, metal" });
          items.push({ line: lineNumber++, code: flashingItem.code, description: flashingItem.description, quantity: structMeasurements.step_flashing_lf, unit: "LF", rate: Number(flashingItem.price), rcv: Number(flashingItem.price) * structMeasurements.step_flashing_lf, acv: Number(flashingItem.price) * structMeasurements.step_flashing_lf, amount: Number(flashingItem.price) * structMeasurements.step_flashing_lf, depreciation: 0 });
        }

        if ((Number(structMeasurements.roof_area_sq) || (Number(structMeasurements.roof_area_sqft)/100)) > 0) {
          const sqQty = Number(structMeasurements.roof_area_sq) || (Number(structMeasurements.roof_area_sqft)/100);
          const tearOffItem = findExactRoofItem({ codes: ['RFG R&R', 'TEAR', 'ARMV'], keywords: ['remove roof covering', 'tear off', 'remove shingle', '3 tab', '3-tab', 'tier 3 tab'], exclude: ['slate', 'tile', 'metal', 'cedar', 'shake', 'wood', 'membrane', 'modified', 'built-up', 'tar', 'gravel'] }, { price: 75, unit: "SQ", code: "RFG R&R", description: "Remove roof covering, 3-tab composition shingle" });
          items.push({ line: lineNumber++, code: tearOffItem.code, description: tearOffItem.description, quantity: sqQty, unit: "SQ", rate: Number(tearOffItem.price), rcv: Number(tearOffItem.price) * sqQty, acv: Number(tearOffItem.price) * sqQty, amount: Number(tearOffItem.price) * sqQty, depreciation: 0 });
        }
      }

      // After all structures, add gutters if any
      if (measurements.gutter_lf && measurements.gutter_lf > 0) {
        const gutterItem = findExactRoofItem({ codes: ['RFG GTR', 'GUTTER'], keywords: ['gutter aluminum', 'gutter k-style', 'gutter / downspout'] }, { price: 10.33, unit: "LF", code: "RFG GTR", description: "Gutter / downspout - aluminum - up to 5\"" });
        items.push({ line: lineNumber++, code: gutterItem.code, description: gutterItem.description, quantity: measurements.gutter_lf, unit: "LF", rate: Number(gutterItem.price), rcv: Number(gutterItem.price) * measurements.gutter_lf, acv: Number(gutterItem.price) * measurements.gutter_lf, amount: Number(gutterItem.price) * measurements.gutter_lf, depreciation: 0 });
      }

      if (measurements.downspout_count && measurements.downspout_count > 0) {
        const downspoutItem = findExactRoofItem({ codes: ['DNSPOUT', 'RFG DS'], keywords: ['downspout', 'down spout'] }, { price: 45.00, unit: "EA", code: "DNSPOUT", description: "Downspout - aluminum - 2\" x 3\"" });
        items.push({ line: lineNumber++, code: downspoutItem.code, description: downspoutItem.description, quantity: measurements.downspout_count, unit: "EA", rate: Number(downspoutItem.price), rcv: Number(downspoutItem.price) * measurements.downspout_count, acv: Number(downspoutItem.price) * measurements.downspout_count, amount: Number(downspoutItem.price) * measurements.downspout_count, depreciation: 0 });
      }

      console.log('✅ Line items created with structure breakdown:', items);
      console.log('📊 Total items:', items.length);
      
      setLineItems(items);

      const total = items.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);

      const combinedSq = Number(measurements.roof_area_sq) || 0;
      let titleText = `${combinedSq ? combinedSq.toFixed(2) : 'Multi-Structure'} SQ Roof`;
      if (measurements.structures && measurements.structures.length > 1) {
        titleText += ` (${measurements.structures.length} structures)`;
      }
      if (satelliteAddress?.address) {
        titleText += ` - ${satelliteAddress.address}`;
      }

      setCurrentEstimate({ title: titleText });

      const itemDescriptions = [`📊 ${measurements.structures.length} structures measured separately`];
      if (measurements.gutter_lf > 0) itemDescriptions.push(`Gutters: ${measurements.gutter_lf.toFixed(0)} LF`);
      if (measurements.downspout_count > 0) itemDescriptions.push(`Downspouts: ${measurements.downspout_count}`);

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ **Created Multi-Structure Estimate!**\n\n📊 **${items.length} items** • **Total: $${total.toLocaleString()}**\n\n${itemDescriptions.join(' • ')}\n\n💡 Each structure listed separately with its own measurements.`,
        timestamp: new Date().toISOString()
      }]);

      return;
    }

    // Original single-structure logic below
    // Normalize single-structure input first
    measurements = normalizeRoof(measurements);
    // 1. SHINGLES
    if (Number(measurements.roof_area_sq) > 0) {
      const shingleItem = findExactRoofItem({
        codes: ['RFG SSSQ', 'SHINGLE', 'LAMINATED - COMP SH'],
        keywords: ['architectural asphalt', 'laminated comp', 'asphalt shingle'],
        exclude: ['wood', 'shake', 'cedar', 'tile', 'metal', 'slate', 'steep', 'surcharge', 'tear', 'ridge', 'hip', 'starter', 'valley', 'eave', 'rake']
      }, {
        price: 350,
        unit: "SQ",
        code: "RFG SSSQ",
        description: "Shingles, architectural asphalt"
      });
      
      const price = Number(shingleItem.price) || 0;
      const qty = Number(measurements.roof_area_sq) || 0;
      
      items.push({
        line: lineNumber++,
        code: shingleItem.code,
        description: shingleItem.description,
        quantity: qty,
        unit: "SQ",
        rate: price,
        rcv: price * qty,
        acv: price * qty,
        amount: price * qty,
        depreciation: 0
      });
    }

    // 2. UNDERLAYMENT
    if ((Number(measurements.roof_area_sq) || (Number(measurements.roof_area_sqft)/100)) > 0) {
      const underlaymentItem = findExactRoofItem({
        codes: ['RFG UL', 'UL'],
        keywords: ['underlayment', 'felt', 'synthetic'],
        exclude: ['vertical', 'units', 'ice', 'water', 'barrier']
      }, {
        price: 25,
        unit: "SQ",
        code: "RFG UL",
        description: "Underlayment, #30 felt"
      });
      
      const price = Number(underlaymentItem.price) || 0;
      const qty = Number(measurements.roof_area_sq) || 0;
      
      items.push({
        line: lineNumber++,
        code: underlaymentItem.code,
        description: underlaymentItem.description,
        quantity: qty,
        unit: "SQ",
        rate: price,
        rcv: price * qty,
        acv: price * qty,
        amount: price * qty,
        depreciation: 0
      });
    }

    // 3. ICE & WATER SHIELD
    const eavesLF = Number(measurements.eave_lf) || 0;
    const valleysLF = Number(measurements.valley_lf) || 0;
    
    const iceWaterEaves = eavesLF * 2;
    const iceWaterValleys = valleysLF * 1;
    const iceWaterBaseTotal = iceWaterEaves + iceWaterValleys;
    const totalIceWater = Math.ceil(iceWaterBaseTotal * 1.10);
    
    if (totalIceWater > 0) {
      const iceWaterItem = findExactRoofItem({
        codes: ['IWS', 'RFG IWS'],
        keywords: ['ice & water barrier', 'ice and water']
      }, {
        price: 2.02,
        unit: "LF",
        code: "IWS",
        description: "Ice & water barrier"
      });
      
      const price = Number(iceWaterItem.price) || 0;
      const rollsNeeded = Math.ceil(totalIceWater / 50);
      const iceWaterSquares = (totalIceWater * 3) / 100;
      
      items.push({
        line: lineNumber++,
        code: iceWaterItem.code,
        description: iceWaterItem.description,
        quantity: totalIceWater,
        unit: "LF",
        rate: price,
        rcv: price * totalIceWater,
        acv: price * totalIceWater,
        amount: price * totalIceWater,
        depreciation: 0,
        notes: `≈${iceWaterSquares.toFixed(1)} SQ (≈${rollsNeeded} rolls @ 50 LF/roll). Code requires 24" inside warm wall per IRC R905.2.7.1`
      });
    }

    // 4. STARTER STRIP
    const rakeLF = Number(measurements.rake_lf) || 0;
    const totalEdge = rakeLF + eavesLF;
    
    if (totalEdge > 0) {
      const starterItem = findExactRoofItem({
        codes: ['RFG STR', 'STARTER'],
        keywords: ['starter strip', 'starter shingle']
      }, {
        price: 2.5,
        unit: "LF",
        code: "RFG STR",
        description: "Starter strip, 3-tab asphalt"
      });
      
      const price = Number(starterItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: starterItem.code,
        description: starterItem.description,
        quantity: totalEdge,
        unit: "LF",
        rate: price,
        rcv: price * totalEdge,
        acv: price * totalEdge,
        amount: price * totalEdge,
        depreciation: 0
      });
    }

    // 5. DRIP EDGE
    if (totalEdge > 0) {
      const dripItem = findExactRoofItem({
        codes: ['RFG DE', 'DRIP'],
        keywords: ['drip edge', 'drip metal']
      }, {
        price: 3,
        unit: "LF",
        code: "RFG DE",
        description: "Drip edge, metal"
      });
      
      const price = Number(dripItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: dripItem.code,
        description: dripItem.description,
        quantity: totalEdge,
        unit: "LF",
        rate: price,
        rcv: price * totalEdge,
        acv: price * totalEdge,
        amount: price * totalEdge,
        depreciation: 0
      });
    }

    // 6. RIDGE CAP
    const ridgeLF = Number(measurements.ridge_lf) || 0;
    
    if (ridgeLF > 0) {
      const ridgeItem = findExactRoofItem({
        codes: ['RFG RDC', 'RFG HP'],
        keywords: ['ridge cap', 'hip cap', 'architectural asphalt']
      }, {
        price: 8.5,
        unit: "LF",
        code: "RFG RDC",
        description: "Ridge cap, architectural asphalt"
      });
      
      const price = Number(ridgeItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: ridgeItem.code,
        description: ridgeItem.description,
        quantity: ridgeLF,
        unit: "LF",
        rate: price,
        rcv: price * ridgeLF,
        acv: price * ridgeLF,
        amount: price * ridgeLF,
        depreciation: 0
      });
    }

    // 7. HIP CAP
    const hipLF = Number(measurements.hip_lf) || 0;
    
    if (hipLF > 0) {
      const hipItem = findExactRoofItem({
        codes: ['RFG HP'],
        keywords: ['hip cap', 'architectural asphalt']
      }, {
        price: 8.5,
        unit: "LF",
        code: "RFG HP",
        description: "Hip cap, architectural asphalt"
      });
      
      const price = Number(hipItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: hipItem.code,
        description: hipItem.description,
        quantity: hipLF,
        unit: "LF",
        rate: price,
        rcv: price * hipLF,
        acv: price * hipLF,
        amount: price * hipLF,
        depreciation: 0
      });
    }

    // 8. VALLEY FLASHING
    if (valleysLF > 0) {
      const valleyItem = findExactRoofItem({
        codes: ['VMTLWP', 'RFG VLY'],
        keywords: ['valley metal', 'valley flashing']
      }, {
        price: 12,
        unit: "LF",
        code: "VMTLWP",
        description: "Valley metal - (W) profile - painted"
      });
      
      const price = Number(valleyItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: valleyItem.code,
        description: valleyItem.description,
        quantity: valleysLF,
        unit: "LF",
        rate: price,
        rcv: price * valleysLF,
        acv: price * valleysLF,
        amount: price * valleysLF,
        depreciation: 0
      });
    }

    // 9. STEP FLASHING
    const stepFlashLF = Number(measurements.step_flashing_lf) || 0;
    
    if (stepFlashLF > 0) {
      const flashingItem = findExactRoofItem({
        codes: ['RFG FLS', 'STEP FLSH'],
        keywords: ['step flashing metal', 'flashing step']
      }, {
        price: 4.5,
        unit: "LF",
        code: "RFG FLS",
        description: "Step flashing, metal"
      });
      
      const price = Number(flashingItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: flashingItem.code,
        description: flashingItem.description,
        quantity: stepFlashLF,
        unit: "LF",
        rate: price,
        rcv: price * stepFlashLF,
        acv: price * stepFlashLF,
        amount: price * stepFlashLF,
        depreciation: 0
      });
    }

    // 10. TEAR OFF
    const roofSQ = Number(measurements.roof_area_sq) || 0;
    
    if (roofSQ > 0) {
      const tearOffItem = findExactRoofItem({
        codes: ['RFG R&R', 'TEAR', 'ARMV'],
        keywords: ['remove roof covering', 'tear off', 'remove shingle', '3 tab', '3-tab', 'tier 3 tab'],
        exclude: ['slate', 'tile', 'metal', 'cedar', 'shake', 'wood', 'membrane', 'modified', 'built-up', 'tar', 'gravel']
      }, {
        price: 75,
        unit: "SQ",
        code: "RFG R&R",
        description: "Remove roof covering, 3-tab composition shingle"
      });
      
      const price = Number(tearOffItem.price) || 0;
      
      items.push({
        line: lineNumber++,
        code: tearOffItem.code,
        description: tearOffItem.description,
        quantity: roofSQ,
        unit: "SQ",
        rate: price,
        rcv: price * roofSQ,
        acv: price * roofSQ,
        amount: price * roofSQ,
        depreciation: 0
      });
    }

    // NEW: Add gutters and downspouts
    if (measurements.gutter_lf && measurements.gutter_lf > 0) {
      const gutterItem = findExactRoofItem({
        codes: ['RFG GTR', 'GUTTER'],
        keywords: ['gutter aluminum', 'gutter k-style', 'gutter / downspout']
      }, {
        price: 10.33,
        unit: "LF",
        code: "RFG GTR",
        description: "Gutter / downspout - aluminum - up to 5\""
      });
      
      const price = Number(gutterItem.price) || 0;
      const qty = Number(measurements.gutter_lf) || 0;
      
      items.push({
        line: lineNumber++,
        code: gutterItem.code,
        description: gutterItem.description,
        quantity: qty,
        unit: "LF",
        rate: price,
        rcv: price * qty,
        acv: price * qty,
        amount: price * qty,
        depreciation: 0
      });
      
      console.log(`✅ Added ${qty} LF of gutters @ $${price}/LF`);
    }

    if (measurements.downspout_count && measurements.downspout_count > 0) {
      const downspoutItem = findExactRoofItem({
        codes: ['DNSPOUT', 'RFG DS'],
        keywords: ['downspout', 'down spout']
      }, {
        price: 45.00,
        unit: "EA",
        code: "DNSPOUT",
        description: "Downspout - aluminum - 2\" x 3\""
      });
      
      const price = Number(downspoutItem.price) || 0;
      const qty = Number(measurements.downspout_count) || 0;
      
      items.push({
        line: lineNumber++,
        code: downspoutItem.code,
        description: downspoutItem.description,
        quantity: qty,
        unit: "EA",
        rate: price,
        rcv: price * qty,
        acv: price * qty,
        amount: price * qty,
        depreciation: 0
      });
      
      console.log(`✅ Added ${qty} downspouts @ $${price} each`);
    }

    console.log('✅ Line items created:', items);
    console.log('📊 Total items:', items.length);
    
    setLineItems(items);

    const total = items.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);

    // NEW: Include structure info in title if multiple structures
    let titleText = `${measurements.roof_area_sq?.toFixed(2) || 'Manual'} SQ Roof (${measurements.pitch || "Unknown"} Pitch)`;
    
    if (measurements.structures && Array.isArray(measurements.structures) && measurements.structures.length > 1) {
      const structureNames = measurements.structures.map(s => s.name).join(' + ');
      titleText += ` - ${structureNames}`;
    }
    
    if (satelliteAddress?.address) {
      titleText += ` - ${satelliteAddress.address}`;
    } else if (measurements.structures && measurements.structures[0]?.address) { // Fallback for combined analysis
        titleText += ` - ${measurements.structures[0].address}`;
    }


    setCurrentEstimate({
      title: titleText
    });

    const itemDescriptions = [];
    itemDescriptions.push(`🏠 Roof: ${measurements.roof_area_sq?.toFixed(2) || 'Manually Measured'} SQ`);
    itemDescriptions.push(`Pitch: ${measurements.pitch || 'Unknown'}`);
    
    if (measurements.structures && Array.isArray(measurements.structures) && measurements.structures.length > 1) {
      itemDescriptions.push(`Structures: ${measurements.structures.map(s => s.name).join(', ')}`);
    }
    
    if (measurements.gutter_lf > 0) {
      itemDescriptions.push(`Gutters: ${measurements.gutter_lf.toFixed(0)} LF`);
    }
    
    if (measurements.downspout_count > 0) {
      itemDescriptions.push(`Downspouts: ${measurements.downspout_count}`);
    }

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `✅ **Created Complete Roof Estimate!**\n\n📊 **${items.length} items** • **Total: $${total.toLocaleString()}**\n\n${itemDescriptions.join(' • ')}\n\n💡 *Tip: Click "10% Waste" button to add material overage*`,
      timestamp: new Date().toISOString()
    }]);
  };

  const handleReviewEstimate = async () => {
    if (!lineItems || lineItems.length === 0) {
      alert('No estimate to review');
      return;
    }

    setIsAnalyzing(true);
    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `🔍 **Analyzing estimate for completeness...**\n\nChecking against industry standards and your knowledge base...`,
      timestamp: new Date().toISOString()
    }]);

    try {
      const response = await analyzeEstimateCompleteness({
        lineItems: lineItems,
        jobType: config.specialty,
        roofPitch: satelliteAnalysis?.pitch || currentEstimate?.pitch,
        customerInfo: customerInfo
      });

      if (response.data.success) {
        setSuggestions(response.data);
        setShowSuggestions(true);

        const criticalCount = response.data.suggestions?.filter(s => s.priority === 'critical').length || 0;
        const recommendedCount = response.data.suggestions?.filter(s => s.priority === 'recommended').length || 0;

        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `✅ **Analysis Complete!**\n\n📊 Quality Score: ${response.data.estimate_quality_score}/100\n\n${criticalCount === 0 && recommendedCount === 0 ? '✨ Estimate looks complete!' : `Review dialog opened with ${criticalCount} critical and ${recommendedCount} recommended items.`}`,
          timestamp: new Date().toISOString()
        }]);
      } else {
        throw new Error(response.data.error || "Failed to analyze estimate.");
      }
    } catch (error) {
      console.error('Review error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Error analyzing estimate: ${error.message}`,
        timestamp: new Date().toISOString()
      }]);
    }

    setIsAnalyzing(false);
  };

  const handleAddVentilationItems = (newItems) => {
    saveToHistory();
    
    const processedItems = newItems.map((item, idx) => {
      // Try to find price in price list
      const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                        pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                        pricingSource === 'symbility' ? symbilityPriceList :
                        customPriceList;
                        
      let rate = item.rate || 0;
      let code = item.code;
      let description = item.description;
      
      // Try to match code first
      const matched = priceList.find(p => p.code === item.code) || 
                      priceList.find(p => p.description.includes('Ridge Vent') && item.description.includes('Ridge')) ||
                      priceList.find(p => p.description.includes('Turtle') && item.description.includes('Box'));
                      
      if (matched) {
        rate = Number(matched.price) || 0;
        code = matched.code;
        description = matched.description; // Use official description
      }
      
      return {
        line: lineItems.length + 1 + idx,
        code: code,
        description: description + (item.description !== description ? ` (${item.description})` : ''),
        quantity: item.quantity,
        unit: item.unit,
        rate: rate,
        rcv: rate * item.quantity,
        acv: rate * item.quantity,
        amount: rate * item.quantity,
        depreciation: 0
      };
    });
    
    setLineItems(prev => [...prev, ...processedItems]);
    
    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `✅ Added ${processedItems.length} ventilation items based on calculator.`,
      timestamp: new Date().toISOString()
    }]);
  };

  const handleAddSuggestedItem = async (suggestion) => {
    console.log('📋 Adding suggested item:', suggestion);
    
    // Save current state before modifying line items
    saveToHistory();

    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;
    
    const description = suggestion.item_description.toLowerCase();
    
    // SMART MATCHING - Find the RIGHT item based on description
    let matchedItem = null;
    
    // 1. UNDERLAYMENT
    if (description.includes('underlayment') || description.includes('felt')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return (
          (desc.includes('underlayment') || desc.includes('felt') || desc.includes('synthetic')) &&
          desc.includes('roof') &&
          !desc.includes('ice') &&
          !desc.includes('water') &&
          !desc.includes('barrier') &&
          !desc.includes('vent')
        );
      });
    }
    
    // 2. ICE & WATER SHIELD
    else if (description.includes('ice') || description.includes('water shield')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        const code = item.code?.toLowerCase() || '';
        return (
          (desc.includes('ice') && desc.includes('water')) ||
          code.includes('iws') ||
          desc.includes('ice & water')
        );
      });
    }
    
    // 3. DRIP EDGE
    else if (description.includes('drip edge')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return desc.includes('drip') && desc.includes('edge');
      });
    }
    
    // 4. RIDGE CAP
    else if (description.includes('ridge cap')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return (
          desc.includes('ridge') && 
          desc.includes('cap') &&
          !desc.includes('vent')
        );
      });
    }
    
    // 5. PIPE FLASHINGS
    else if (description.includes('pipe') && description.includes('flash')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return (
          desc.includes('pipe') && 
          (desc.includes('flash') || desc.includes('boot') || desc.includes('jack'))
        );
      });
    }
    
    // 6. RIDGE VENTS / BOX VENTS
    else if (description.includes('vent')) {
      if (description.includes('ridge')) {
        matchedItem = priceList.find(item => {
          const desc = item.description?.toLowerCase() || '';
          return desc.includes('ridge') && desc.includes('vent');
        });
      } else if (description.includes('box')) {
        matchedItem = priceList.find(item => {
          const desc = item.description?.toLowerCase() || '';
          return desc.includes('box') && desc.includes('vent');
        });
      } else {
        // Generic vent
        matchedItem = priceList.find(item => {
          const desc = item.description?.toLowerCase() || '';
          return desc.includes('vent') && desc.includes('roof');
        });
      }
    }
    
    // 7. STARTER STRIP
    else if (description.includes('starter')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return desc.includes('starter') && (desc.includes('strip') || desc.includes('shingle'));
      });
    }
    
    // 8. VALLEY METAL
    else if (description.includes('valley')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return desc.includes('valley') && (desc.includes('metal') || desc.includes('flash'));
      });
    }
    
    // 9. STEP FLASHING
    else if (description.includes('step') && description.includes('flash')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return desc.includes('step') && desc.includes('flash');
      });
    }
    
    // 10. OVERHEAD & PROFIT
    else if (description.includes('overhead') || description.includes('profit') || description.includes('o&p')) {
      // Calculate O&P as 21% of current total
      const currentTotal = lineItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
      const opAmount = currentTotal * 0.21;
      
      const newItem = {
        line: lineItems.length + 1,
        code: 'O&P',
        description: 'Overhead & Profit (10% + 10%)',
        quantity: 1,
        unit: 'LS',
        rate: opAmount,
        rcv: opAmount,
        acv: opAmount,
        amount: opAmount,
        depreciation: 0
      };
      
      setLineItems(prev => [...prev, newItem]);
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Added O&P (21% = $${opAmount.toFixed(2)})`,
        timestamp: new Date().toISOString()
      }]);
      
      // Remove from suggestions
      setSuggestions(prev => {
        if (!prev || !prev.suggestions) return prev;
        return {
          ...prev,
          suggestions: prev.suggestions.filter(s => s !== suggestion)
        };
      });
      
      return;
    }
    
    // 11. DUMPSTER / DEBRIS REMOVAL
    else if (description.includes('debris') || description.includes('dumpster')) {
      matchedItem = priceList.find(item => {
        const desc = item.description?.toLowerCase() || '';
        return (desc.includes('debris') || desc.includes('dumpster')) && 
               (desc.includes('removal') || desc.includes('haul'));
      });
    }
    
    // 12. WASTE / OVERAGE
    else if (description.includes('waste') || description.includes('overage')) {
      // Apply 10% waste to materials
      const wastePercent = 10;
      const updatedItems = lineItems.map(item => {
        if (item.description?.toLowerCase().includes('shingle') ||
            item.description?.toLowerCase().includes('underlayment') ||
            item.description?.toLowerCase().includes('felt')) {
          const multiplier = 1 + (wastePercent / 100);
          const newQuantity = (Number(item.quantity) || 0) * multiplier;
          const newRcv = newQuantity * (Number(item.rate) || 0);
          return {
            ...item,
            quantity: newQuantity,
            rcv: newRcv,
            acv: newRcv,
            amount: newRcv
          };
        }
        return item;
      });
      
      setLineItems(updatedItems);
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Applied 10% waste to materials`,
        timestamp: new Date().toISOString()
      }]);
      
      // Remove from suggestions
      setSuggestions(prev => {
        if (!prev || !prev.suggestions) return prev;
        return {
          ...prev,
          suggestions: prev.suggestions.filter(s => s !== suggestion)
        };
      });
      
      return;
    }
    
    // Fallback: Use smart description match
    if (!matchedItem) {
      matchedItem = smartDescriptionMatch(suggestion.item_description, priceList);
    }
    
    if (matchedItem) {
      const quantity = Number(suggestion.typical_quantity) || 1;
      const unit = suggestion.typical_unit || matchedItem.unit || 'EA';
      const price = Number(matchedItem.price) || 0;
      
      const newItem = {
        line: lineItems.length + 1,
        code: matchedItem.code,
        description: matchedItem.description,
        quantity: quantity,
        unit: unit,
        rate: price,
        rcv: price * quantity,
        acv: price * quantity,
        amount: price * quantity,
        depreciation: 0
      };
      
      setLineItems(prev => [...prev, newItem]);
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Added ${quantity} ${unit} of ${matchedItem.description}`,
        timestamp: new Date().toISOString()
      }]);
    } else {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Could not find "${suggestion.item_description}" in ${pricingSource} price list`,
        timestamp: new Date().toISOString()
      }]);
    }
    
    // Remove this suggestion from the list
    setSuggestions(prev => {
      if (!prev || !prev.suggestions) return prev;
      return {
        ...prev,
        suggestions: prev.suggestions.filter(s => s !== suggestion)
      };
    });
  };

  const processWithAI = async (userMessage, fileUrls = []) => {
    setIsProcessing(true);
    
    try {
      const messageLower = userMessage.toLowerCase().trim();
      
      const commands = [];
      
      // IMPROVED: Better command detection for dumpster/debris
      if (messageLower.includes('dumpster') || messageLower.includes('debris removal')) {
        commands.push({ type: 'add_item', quantity: 1, description: 'dumpster debris removal haul' });
      }
      
      // DEPRECIATION COMMAND (apply % depreciation to all items)
      if (messageLower.includes('depreciat') || messageLower.includes('depr')) {
        const percentMatch = userMessage.match(/(\d+)%?\s*(depreciat|depr)/i);
        const percent = percentMatch ? parseInt(percentMatch[1]) : 20;
        commands.push({ type: 'depreciate', percent });
      }
      
      // WASTE COMMAND (increase material quantities)
      else if (messageLower.includes('waste')) {
        const percentMatch = userMessage.match(/(\d+)%?\s*waste/);
        commands.push({ type: 'waste', percent: percentMatch ? parseInt(percentMatch[1]) : 10 });
      }
      
      if (messageLower.includes('steep') && !commands.some(c => c.type === 'steep')) {
        commands.push({ type: 'steep' });
      }
      
      if (messageLower.includes('high') && !commands.some(c => c.type === 'high')) {
        commands.push({ type: 'high' });
      }
      
      if ((messageLower.includes('o&p') || messageLower.includes('overhead') || messageLower.includes('profit')) && !commands.some(c => c.type === 'op')) {
        commands.push({ type: 'op' });
      }

      // Add pipe flashing detection
      if (messageLower.includes('pipe') && (messageLower.includes('flash') || messageLower.includes('boot') || messageLower.match(/\d+\s+pipe/))) {
        const pipeMatch = userMessage.match(/(\d+)\s+pipe/i);
        const pipeQty = pipeMatch ? parseInt(pipeMatch[1]) : 1;
        commands.push({ type: 'add_item', quantity: pipeQty, description: 'pipe flashing boot' });
      }

      const patterns = [
        /(\d+)\s+([\w\s-]+?(?=\s*(?:and|,\s*add|$)))/gi,
        /add\s+(\d+)?\s*([\w\s-]+?(?=\s*(?:and|,\s*add|$)))/gi,
      ];
      
      patterns.forEach(pattern => {
        const matches = [...userMessage.matchAll(pattern)];
        matches.forEach(match => {
          const quantity = match[1] ? parseInt(match[1]) : 1;
          const description = match[2] ? match[2].trim() : '';
          
          if (description && !['steep', 'high', 'waste', 'o&p', 'overhead', 'profit', 'dumpster', 'debris', 'pipe'].some(keyword => description.toLowerCase().includes(keyword))) {
            commands.push({ type: 'add_item', quantity, description });
          }
        });
      });

      if (commands.length > 0 && lineItems.length > 0) {
        console.log('🎯 Executing commands:', commands);
        
        // SAVE TO HISTORY BEFORE MAKING CHANGES
        saveToHistory();
        
        let updatedItems = [...lineItems];
        let assistantResponseMessages = [];
        
        for (const cmd of commands) {
          if (cmd.type === 'depreciate') {
            const depreciationPercent = cmd.percent;
            updatedItems = updatedItems.map(item => {
              const currentQty = Number(item.quantity) || 0;
              const currentRate = Number(item.rate) || 0;
              const currentRcv = Number(item.rcv) || (currentQty * currentRate);
              
              // Calculate ACV based on depreciation %
              const newAcv = currentRcv * (1 - depreciationPercent / 100);
              
              return {
                ...item,
                depreciation_percent: depreciationPercent,
                acv: newAcv,
                rcv: currentRcv,
                amount: currentRcv
              };
            });
            assistantResponseMessages.push(`✅ Applied ${depreciationPercent}% depreciation to all materials (ACV reduced by ${depreciationPercent}%).`);
          }
          
          else if (cmd.type === 'waste') {
            const wastePercent = cmd.percent;
            updatedItems = updatedItems.map(item => {
              const desc = item.description?.toLowerCase() || '';
              // ROOFING materials
              const isRoofingMaterial = desc.includes('shingle') ||
                  desc.includes('underlayment') ||
                  desc.includes('felt') ||
                  desc.includes('ice & water') ||
                  desc.includes('starter') ||
                  desc.includes('drip') ||
                  desc.includes('cap') ||
                  desc.includes('valley') ||
                  desc.includes('flashing');
              
              // SIDING materials (add waste to siding, corners, j-channel)
              const isSidingMaterial = desc.includes('siding') ||
                  desc.includes('j-channel') ||
                  desc.includes('j channel') ||
                  desc.includes('corner') ||
                  desc.includes('soffit') ||
                  desc.includes('fascia');
              
              if (isRoofingMaterial || isSidingMaterial) {
                const multiplier = 1 + (wastePercent / 100);
                const qty = Number(item.quantity) || 0;
                const rate = Number(item.rate) || 0;
                const newQuantity = qty * multiplier;
                const newRcv = newQuantity * rate;
                const depPercent = Number(item.depreciation_percent) || 0;
                const newAcv = newRcv * (1 - depPercent / 100);
                return {
                  ...item,
                  quantity: newQuantity,
                  rcv: newRcv,
                  acv: newAcv,
                  amount: newRcv
                };
              }
              return item;
            });
            assistantResponseMessages.push(`✅ Applied ${wastePercent}% waste to roofing & siding materials.`);
          }
          
          else if (cmd.type === 'steep') {
            if (!updatedItems.some(item => 
              (item.code?.toLowerCase().includes('steep') || item.code?.toLowerCase().includes('shstp')) || 
              (item.description?.toLowerCase().includes('steep') && (item.description?.toLowerCase().includes('roof') || item.description?.toLowerCase().includes('slope')))
            )) {
              const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                                pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                                pricingSource === 'symbility' ? symbilityPriceList :
                                customPriceList;
              
              const steepItem = priceList.find(item => {
                const desc = item.description?.toLowerCase() || '';
                const code = item.code?.toLowerCase() || '';
                return (
                  code.includes('steep') || code.includes('shstp') ||
                  (desc.includes('steep') && (desc.includes('roof') || desc.includes('slope'))) ||
                  desc.includes('additional charge for steep') ||
                  desc.includes('steep roofing')
                );
              });
              
              if (steepItem) {
                const roofAreaSq = Number(satelliteAnalysis?.roof_area_sq) || 
                                  Number(updatedItems.find(item => item.unit?.toUpperCase() === 'SQ')?.quantity) || 
                                  1;
                
                const price = Number(steepItem.price) || 0;
                
                updatedItems.push({
                  line: updatedItems.length + 1,
                  code: steepItem.code,
                  description: steepItem.description,
                  quantity: roofAreaSq,
                  unit: steepItem.unit || 'SQ',
                  rate: price,
                  rcv: price * roofAreaSq,
                  acv: price * roofAreaSq,
                  amount: price * roofAreaSq,
                  depreciation: 0
                });
                assistantResponseMessages.push(`✅ Added steep roof surcharge.`);
              } else {
                assistantResponseMessages.push(`❌ Could not find steep roof surcharge in ${pricingSource.replace('_new', ' New')} price list.`);
              }
            } else {
              assistantResponseMessages.push(`⚠️ Steep roof surcharge already applied.`);
            }
          }
          
          else if (cmd.type === 'high') {
            if (!updatedItems.some(item => item.code === 'HIGHSRG' || 
                (item.description?.toLowerCase().includes('high') && item.description?.toLowerCase().includes('roof')))) {
              const currentTotal = updatedItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
              const highAmount = currentTotal * 0.15;
              updatedItems.push({
                line: updatedItems.length + 1,
                code: 'HIGHSRG',
                description: 'High Roof Surcharge (15%)',
                quantity: 1,
                unit: 'LS',
                rate: highAmount,
                rcv: highAmount,
                acv: highAmount,
                amount: highAmount,
                depreciation: 0
              });
              assistantResponseMessages.push(`✅ Applied 15% high roof surcharge.`);
            } else {
              assistantResponseMessages.push(`⚠️ High roof surcharge already applied.`);
            }
          }
          
          else if (cmd.type === 'op') {
            if (!updatedItems.some(item => item.code === 'O&P' || 
                (item.description?.toLowerCase().includes('overhead') && item.description?.toLowerCase().includes('profit')))) {
              const currentTotal = updatedItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
              const opAmount = currentTotal * 0.21;
              updatedItems.push({
                line: updatedItems.length + 1,
                code: 'O&P',
                description: 'Overhead & Profit (10% + 10%)',
                quantity: 1,
                unit: 'LS',
                rate: opAmount,
                rcv: opAmount,
                acv: opAmount,
                amount: opAmount,
                depreciation: 0
              });
              assistantResponseMessages.push(`✅ Applied O&P (21%).`);
            } else {
              assistantResponseMessages.push(`⚠️ O&P already applied.`);
            }
          }
          
          else if (cmd.type === 'add_item') {
            const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                              pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                              pricingSource === 'symbility' ? symbilityPriceList :
                              customPriceList;
            
            const matchedItem = smartDescriptionMatch(cmd.description, priceList);
            
            if (matchedItem) {
              const price = Number(matchedItem.price) || 0;
              const qty = Number(cmd.quantity) || 1;
              
              updatedItems.push({
                line: updatedItems.length + 1,
                code: matchedItem.code,
                description: matchedItem.description,
                quantity: qty,
                unit: matchedItem.unit || 'EA',
                rate: price,
                rcv: price * qty,
                acv: price * qty,
                amount: price * qty,
                depreciation: 0
              });
              assistantResponseMessages.push(`✅ Added ${qty} ${matchedItem.unit || 'EA'} of ${matchedItem.description}.`);
            } else {
              assistantResponseMessages.push(`⚠️ Could not find "${cmd.description}" in price list. Item not added.`);
            }
          }
        }
        
        if (assistantResponseMessages.length > 0) {
            setLineItems(updatedItems);
            const newTotal = updatedItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
            
            setMessages(prev => [...prev, {
              role: 'assistant',
              content: `${assistantResponseMessages.join('\n')}\n\n💰 New total: $${newTotal.toLocaleString()}`,
              timestamp: new Date().toISOString()
            }]);
            
            setIsProcessing(false);
            return;
        }
      }
      
      // 6. Remove/delete line item
      if ((messageLower.includes('remove') || messageLower.includes('delete')) && (messageLower.includes('item') || messageLower.includes('line'))) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `To remove a line item, click the red trash icon (🗑️) next to the item in the table above.`,
          timestamp: new Date().toISOString()
        }]);
        setIsProcessing(false);
        return;
      }
      
      // 7. Change quantity
      if (messageLower.includes('change') && messageLower.includes('quantity')) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `To change quantities, click directly on the Qty field in the table and type the new value.`,
          timestamp: new Date().toISOString()
        }]);
        setIsProcessing(false);
        return;
      }
      
      // 8. If we have line items and user is asking about pricing/totals
      if (lineItems.length > 0 && (messageLower.includes('total') || messageLower.includes('price') || messageLower.includes('cost'))) {
        const total = lineItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `📊 **Current Estimate:**\n• ${lineItems.length} line items\n• Total: $${total.toLocaleString()}\n\nWhat else would you like to adjust?`,
          timestamp: new Date().toISOString()
        }]);
        setIsProcessing(false);
        return;
      }
      
      // 9. If no line items exist yet, or no files and message is general, show help.
      // Otherwise, use LLM to create estimate or handle complex queries.
      if (lineItems.length === 0 && fileUrls.length === 0 && userMessage.trim().length > 0) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `I can help you with:\n• **"steep"** - Add steep roof surcharge\n• **"high"** - Add high roof surcharge\n• **"10% waste"** - Add waste to materials\n• **"3 vents"** - Add specific items\n• **"o&p"** - Add overhead & profit\n• **"dumpster"** - Add debris removal\n• **"5 pipe"** - Add pipe flashings\n\nOr upload a document to create an estimate!`,
          timestamp: new Date().toISOString()
        }]);
        setIsProcessing(false);
        return;
      }
      
      // If we reach here, it means either:
      // a) lineItems.length is 0 but fileUrls exist (process files for initial estimate)
      // b) lineItems.length > 0 but no simple commands/questions were matched (complex query for LLM)
      // c) lineItems.length is 0, no fileUrls, but the message is empty or only whitespace (should be caught by initial trim/return, but for safety)
      if (lineItems.length === 0 || fileUrls.length > 0 || userMessage.trim().length > 0) {
        const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                          pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                          pricingSource === 'symbility' ? symbilityPriceList :
                          customPriceList;

        const topPrices = priceList.slice(0, 100);
        const priceListContext = topPrices.map(p =>
          `${p.code}: ${p.description} - $${p.price} per ${p.unit}`
        ).join('\n');

        const systemPrompt = `You are an expert construction estimator. Use this pricing database:

${priceListContext}

Create an estimate with line items matching the database.`;

        const llmResponse = await base44.integrations.Core.InvokeLLM({
          prompt: `${systemPrompt}\n\n${userMessage}`,
          file_urls: fileUrls,
          response_json_schema: {
            type: "object",
            properties: {
              line_items: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    code: { type: "string" },
                    description: { type: "string" },
                    quantity: { type: "number" },
                    unit: { type: "string" }
                  },
                  required: ["description", "quantity", "unit"]
                }
              },
              project_name: { type: "string" },
              customer_info: {
                type: "object",
                properties: {
                  customer_name: { type: "string" },
                  property_address: { type: "string" },
                  claim_number: { type: "string" },
                  insurance_company: { type: "string" }
                }
              }
            }
          }
        });

        if (llmResponse && typeof llmResponse === 'object' && Array.isArray(llmResponse.line_items) && llmResponse.line_items.length > 0) {
          _generateAndSetEstimate(llmResponse, uploadedFiles.length > 0 ? uploadedFiles[0].name : "AI generated estimate");
        } else {
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `⚠️ I couldn't generate an estimate from your request. Please be more specific or upload a document.`,
            timestamp: new Date().toISOString()
          }]);
        }
      }
    } catch (error) {
      console.error('AI Error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Error: ${error.message}`,
        timestamp: new Date().toISOString()
      }]);
    }
    
    setIsProcessing(false);
  };

  const _generateAndSetEstimate = (extractedData, fileName) => {
    // Save current state before modifying line items
    saveToHistory();

    const items = extractedData.line_items || [];

    const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                      pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                      pricingSource === 'symbility' ? symbilityPriceList :
                      customPriceList;

    const enrichedItems = items.map((item, index) => {
      const extractedRate = Number(item.rate) || 0;
      const matchedItem = !extractedRate && item.description ? smartDescriptionMatch(item.description, priceList) : null;

      const price = extractedRate || (matchedItem ? (Number(matchedItem.price) || 0) : 0);
      const qty = Number(item.quantity) || 0;

      return {
        line: index + 1,
        code: item.code || matchedItem?.code || '',
        description: item.description,
        quantity: qty,
        unit: item.unit || matchedItem?.unit || 'EA',
        rate: price,
        amount: price * qty,
        rcv: price * qty,
        depreciation: 0,
        acv: price * qty
      };
    });

    setLineItems(enrichedItems);

    const totalRcv = enrichedItems.reduce((acc, item) => {
      return acc + (Number(item.rcv) || 0);
    }, 0);

    const unmatched = enrichedItems.filter(i => (Number(i.rate) || 0) === 0).length;

    setCurrentEstimate({
      title: extractedData.project_name || `Estimate from ${fileName}`,
      line_items: enrichedItems,
      total_rcv: totalRcv
    });

    if (extractedData.customer_info) {
      setCustomerInfo(prev => {
        // If we have a selected contact (locked context), ONLY update fields that are empty
        if (selectedContactId) {
          return {
            ...prev,
            // Don't overwrite name/email/phone if we have a linked contact
            property_address: prev.property_address || extractedData.customer_info.property_address || "",
            claim_number: prev.claim_number || extractedData.customer_info.claim_number || "",
            insurance_company: prev.insurance_company || extractedData.customer_info.insurance_company || "",
            // Keep existing contact details strictly
            customer_name: prev.customer_name,
            customer_email: prev.customer_email,
            customer_phone: prev.customer_phone
          };
        }
        
        // Otherwise, use AI data freely
        return {
          ...prev,
          customer_name: extractedData.customer_info.customer_name || prev.customer_name,
          customer_email: extractedData.customer_info.customer_email || prev.customer_email,
          customer_phone: extractedData.customer_info.customer_phone || prev.customer_phone,
          property_address: extractedData.customer_info.property_address || prev.property_address,
          claim_number: extractedData.customer_info.claim_number || prev.claim_number,
          insurance_company: extractedData.customer_info.insurance_company || prev.insurance_company
        };
      });
    }

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `✅ Extracted ${enrichedItems.length} items. Total: $${totalRcv.toLocaleString()}${unmatched > 0 ? `\n⚠️ ${unmatched} items need pricing` : ''}`,
      timestamp: new Date().toISOString()
    }]);
  };

  const _processEstimateRequest = async (fileUrls, userMessage, fileName) => {
    setIsProcessing(true);

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `🤖 **AI is analyzing ${fileUrls.length > 1 ? `${fileUrls.length} documents` : 'your document'}...**\n\n⏱️ This may take 30-60 seconds...`,
      timestamp: new Date().toISOString()
    }]);

    try {
      // MULTI-DOCUMENT HANDLING: Process each file separately then merge
      if (fileUrls.length > 1) {
        const allExtractedItems = [];
        let mergedCustomerInfo = {};

        for (let i = 0; i < fileUrls.length; i++) {
          const singleFileUrl = [fileUrls[i]];
          const docName = uploadedFiles[i]?.name || `Document ${i+1}`;

          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `📄 **Processing ${docName}** (${i + 1}/${fileUrls.length})...`,
            timestamp: new Date().toISOString()
          }]);

          // Detect type for this specific file
          const typeCheck = await base44.integrations.Core.InvokeLLM({
            prompt: `Analyze this document and respond with ONLY ONE of these types:
- "hover_measurement" if it's a roof measurement report (HOVER, EagleView) with NO PRICES
- "siding_measurement" if it's a wall/siding measurement report (Aerial Reports) with NO PRICES
- "insurance_estimate" if it contains line items WITH PRICES
- "contractor_estimate" if it's a contractor estimate WITH PRICES

Respond with just the type, nothing else.`,
            file_urls: singleFileUrl
          });

          const detectedType = typeCheck.toLowerCase().trim();
          const docType = detectedType.includes('siding') ? 'siding_measurement' :
                        detectedType.includes('hover') ? 'hover_measurement' :
                        detectedType.includes('insurance') ? 'insurance_estimate' :
                        detectedType.includes('contractor') ? 'contractor_estimate' : 'unknown';

          console.log(`📄 Document ${i+1} type:`, docType);

          // Extract based on type
          if (docType === 'hover_measurement') {
            const measurementsResponse = await base44.integrations.Core.InvokeLLM({
              prompt: `Extract ALL roof measurements from this roof measurement report (HOVER, EagleView, or similar). 

            CRITICAL: Search the ENTIRE document thoroughly - measurements may be in tables, diagrams, or text. Look for:
            - Total roof area (square feet AND squares)
            - Ridge, Hip, Valley, Rake, Eave lengths (LF)
            - Pitch/slope
            - Roof type: Is this a FLAT ROOF (0/12 to 2/12 pitch) or PITCHED ROOF (3/12+)?
            - Any other roof measurements

            Return JSON with roof_area_sq, ridge_lf, hip_lf, valley_lf, rake_lf, eave_lf, step_flashing_lf, pitch, is_flat_roof (boolean), gutter_lf, downspout_count, and customer_info.`,
              file_urls: singleFileUrl,
              response_json_schema: {
                type: "object",
                properties: {
                  roof_area_sqft: { type: "number" },
                  roof_area_sq: { type: "number" },
                  ridge_lf: { type: "number" },
                  hip_lf: { type: "number" },
                  valley_lf: { type: "number" },
                  rake_lf: { type: "number" },
                  eave_lf: { type: "number" },
                  step_flashing_lf: { type: "number" },
                  pitch: { type: "string" },
                  is_flat_roof: { type: "boolean" },
                  gutter_lf: { type: "number" },
                  downspout_count: { type: "number" },
                  customer_info: { type: "object", properties: { customer_name: { type: "string" }, property_address: { type: "string" }, claim_number: { type: "string" } } }
                }
              }
            });

            // Normalize EagleView fields
            if ((!measurementsResponse.roof_area_sq || Number(measurementsResponse.roof_area_sq) === 0) && Number(measurementsResponse.roof_area_sqft) > 0) {
              measurementsResponse.roof_area_sq = Number(measurementsResponse.roof_area_sqft) / 100;
            }
            // Convert roof measurements to line items WITHOUT setting state
            const roofItems = await convertMeasurementsToLineItemsArray(measurementsResponse);
            allExtractedItems.push(...roofItems);
            mergedCustomerInfo = { ...mergedCustomerInfo, ...measurementsResponse.customer_info };

          } else if (docType === 'siding_measurement') {
            const sidingResponse = await base44.integrations.Core.InvokeLLM({
              prompt: `Extract ALL siding/wall measurements from this Aerial Reports measurement report. Return JSON with wall_area_sq, wall_top_lf, wall_bottom_lf, inside_corners_count, inside_corners_lf, outside_corners_count, outside_corners_lf, and customer_info.`,
              file_urls: singleFileUrl,
              response_json_schema: {
                type: "object",
                properties: {
                  wall_area_sqft: { type: "number" },
                  wall_area_sq: { type: "number" },
                  wall_top_lf: { type: "number" },
                  wall_bottom_lf: { type: "number" },
                  inside_corners_count: { type: "number" },
                  inside_corners_lf: { type: "number" },
                  outside_corners_count: { type: "number" },
                  outside_corners_lf: { type: "number" },
                  customer_info: { type: "object", properties: { customer_name: { type: "string" }, property_address: { type: "string" } } }
                }
              }
            });

            // Convert siding measurements to line items WITHOUT setting state
            const sidingItems = await convertSidingMeasurementsToLineItemsArray(sidingResponse);
            allExtractedItems.push(...sidingItems);
            mergedCustomerInfo = { ...mergedCustomerInfo, ...sidingResponse.customer_info };

          } else {
            // Priced estimate extraction
            const response = await base44.integrations.Core.InvokeLLM({
              prompt: `Extract ALL line items from this estimate. For EACH item, extract: description, quantity, unit, AND rate (price). Return JSON.`,
              file_urls: singleFileUrl,
              response_json_schema: {
                type: "object",
                properties: {
                  line_items: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        code: { type: "string" },
                        description: { type: "string" },
                        quantity: { type: "number" },
                        unit: { type: "string" },
                        rate: { type: "number" }
                      }
                    }
                  },
                  customer_info: { type: "object" }
                }
              }
            });

            if (response?.line_items) {
              const enrichedItems = response.line_items.map((item, index) => {
                const price = Number(item.rate) || 0;
                const qty = Number(item.quantity) || 0;
                return {
                  line: allExtractedItems.length + index + 1,
                  code: item.code || '',
                  description: item.description,
                  quantity: qty,
                  unit: item.unit || 'EA',
                  rate: price,
                  rcv: price * qty,
                  acv: price * qty,
                  amount: price * qty,
                  depreciation: 0
                };
              });
              allExtractedItems.push(...enrichedItems);
              mergedCustomerInfo = { ...mergedCustomerInfo, ...response.customer_info };
            }
          }
        }

        // NOW set all merged items at once
        setLineItems(allExtractedItems);
        const totalRcv = allExtractedItems.reduce((acc, item) => acc + (Number(item.rcv) || 0), 0);
        
        setCurrentEstimate({
          title: `Combined Estimate - ${mergedCustomerInfo.customer_name || customerInfo.customer_name || 'Multiple Documents'}`,
          line_items: allExtractedItems,
          total_rcv: totalRcv
        });

        if (mergedCustomerInfo) {
          setCustomerInfo(prev => ({
            ...prev,
            customer_name: mergedCustomerInfo.customer_name || prev.customer_name,
            property_address: mergedCustomerInfo.property_address || prev.property_address,
            claim_number: mergedCustomerInfo.claim_number || prev.claim_number,
            insurance_company: mergedCustomerInfo.insurance_company || prev.insurance_company
          }));
        }

        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `✅ **Merged ${fileUrls.length} documents!**\n\n📊 ${allExtractedItems.length} total items • $${totalRcv.toLocaleString()}\n\n💡 Review the combined estimate below and adjust as needed.`,
          timestamp: new Date().toISOString()
        }]);

        setIsProcessing(false);
        return;
      }

      // SINGLE DOCUMENT PROCESSING (original logic)
      let docTypeResponse;
      try {
        const simpleTypeCheck = await base44.integrations.Core.InvokeLLM({
          prompt: `Analyze this document and respond with ONLY ONE of these types:
- "hover_measurement" if it's a roof measurement report (HOVER, EagleView) with NO PRICES
- "siding_measurement" if it's a wall/siding measurement report (Aerial Reports) with NO PRICES
- "insurance_estimate" if it contains line items WITH PRICES
- "contractor_estimate" if it's a contractor estimate WITH PRICES

Respond with just the type, nothing else.`,
          file_urls: fileUrls
        });

        const detectedType = simpleTypeCheck.toLowerCase().trim();
        
        docTypeResponse = {
          document_type: detectedType.includes('siding') ? 'siding_measurement' :
                        detectedType.includes('hover') ? 'hover_measurement' :
                        detectedType.includes('insurance') ? 'insurance_estimate' :
                        detectedType.includes('contractor') ? 'contractor_estimate' : 'unknown',
          confidence: 85,
          reason: `Detected as ${detectedType}`
        };
        
        console.log('📄 Document type detected:', docTypeResponse);
      } catch (docTypeError) {
        console.error('❌ Document type detection failed:', docTypeError);
        // Fallback: Try to detect by attempting extraction
        docTypeResponse = {
          document_type: 'unknown',
          confidence: 0,
          reason: 'Failed to detect type - will try multiple extraction methods'
        };
      }

      // STEP 2: Extract based on document type
      if (docTypeResponse.document_type === "unknown") {
        // Try all extraction methods
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `🔍 **Detecting document type...**`,
          timestamp: new Date().toISOString()
        }]);

        // Try siding first, then roof, then priced estimate
        try {
          const sidingTest = await base44.integrations.Core.InvokeLLM({
            prompt: `Does this document contain wall/siding measurements? Answer with just "yes" or "no".`,
            file_urls: fileUrls
          });
          
          if (sidingTest.toLowerCase().includes('yes')) {
            docTypeResponse.document_type = 'siding_measurement';
          } else {
            const roofTest = await base44.integrations.Core.InvokeLLM({
              prompt: `Does this document contain roof measurements (ridges, valleys, eaves)? Answer with just "yes" or "no".`,
              file_urls: fileUrls
            });
            
            if (roofTest.toLowerCase().includes('yes')) {
              docTypeResponse.document_type = 'hover_measurement';
            } else {
              docTypeResponse.document_type = 'insurance_estimate';
            }
          }
        } catch (testError) {
          console.error('Type testing failed:', testError);
          docTypeResponse.document_type = 'insurance_estimate'; // Default fallback
        }
      }

      console.log('📄 Final document type:', docTypeResponse.document_type);

      if (docTypeResponse.document_type === "hover_measurement") {
        // Extract MEASUREMENTS (no prices in document)
        const measurementsResponse = await base44.integrations.Core.InvokeLLM({
          prompt: `Extract ALL roof measurements from this roof measurement report (HOVER, EagleView, or similar).

**CRITICAL: Look for these measurements anywhere in the document:**
- Roof area in square feet AND squares (1 SQ = 100 sq ft)
- Ridge length (LF)
- Hip length (LF)
- Valley length (LF)
- Rake length (LF)
- Eave length (LF)
- Step flashing length (LF)
- Drip edge/perimeter length (LF)
- Primary pitch (e.g., 5/12 or 6:12)
- **FLAT ROOF DETECTION:** Is this a flat/low-slope roof (0/12 to 2/12 pitch)?
- Total gutter length (LF)
- Number of downspouts (EA)
- List all structures (e.g., House, Garage, Shed)
- Customer info if available

**Important:** Search the ENTIRE document for measurements. EagleView and HOVER reports may use different layouts. Extract all numeric measurements you can find.

Return JSON with these exact measurements.`,
          file_urls: fileUrls,
          response_json_schema: {
            type: "object",
            properties: {
              roof_area_sqft: { type: "number", description: "Total roof area in square feet" },
              roof_area_sq: { type: "number", description: "Total roof area in squares (SQ)" },
              ridge_lf: { type: "number" },
              hip_lf: { type: "number" },
              valley_lf: { type: "number" },
              rake_lf: { type: "number" },
              eave_lf: { type: "number" },
              step_flashing_lf: { type: "number" },
              drip_edge_lf: { type: "number" },
              gutter_lf: { type: "number", description: "Total linear feet of gutters" },
              downspout_count: { type: "number", description: "Total number of downspouts" },
              pitch: { type: "string", description: "Primary pitch (e.g., 5/12)" },
              is_flat_roof: { type: "boolean", description: "True if flat/low-slope roof (0/12 to 2/12 pitch)" },
              structures: { type: "array", items: { type: "object", properties: { name: { type: "string" }, area_sq: { type: "number" } } } },
              customer_info: {
                type: "object",
                properties: {
                  customer_name: { type: "string" },
                  property_address: { type: "string" },
                  claim_number: { type: "string" }
                }
              }
            }
          }
        });

        console.log('📏 Extracted measurements:', measurementsResponse);

        if (!measurementsResponse || typeof measurementsResponse !== 'object') {
          throw new Error('Invalid measurements response - please try a different file');
        }

        const hasRoof = Number(measurementsResponse?.roof_area_sq) > 0 || Number(measurementsResponse?.roof_area_sqft) > 0;
        const hasGutter = Number(measurementsResponse?.gutter_lf) > 0 || Number(measurementsResponse?.downspout_count) > 0;
        if (hasRoof || hasGutter) {
          // 🏢 FLAT ROOF DETECTION
          const isFlatRoof = measurementsResponse.is_flat_roof || 
                            measurementsResponse.pitch?.toLowerCase().includes('flat') ||
                            (measurementsResponse.pitch && parseInt(measurementsResponse.pitch) <= 2);

          if (isFlatRoof) {
            await convertFlatRoofToLineItems(measurementsResponse);
          } else {
            await convertMeasurementsToLineItems(measurementsResponse);
          }

          // Set customer info
          if (measurementsResponse.customer_info) {
            setCustomerInfo(prev => ({
              ...prev,
              customer_name: measurementsResponse.customer_info.customer_name || prev.customer_name,
              property_address: measurementsResponse.customer_info.property_address || prev.property_address,
              claim_number: measurementsResponse.customer_info.claim_number || prev.claim_number
            }));
          }
        } else {
          throw new Error('Could not extract roof or gutter measurements from HOVER report');
        }

      } else if (docTypeResponse.document_type === "siding_measurement") {
        // Extract SIDING MEASUREMENTS (no prices in document)
        const sidingResponse = await base44.integrations.Core.InvokeLLM({
          prompt: `Extract ALL siding/wall measurements from this Aerial Reports measurement report.

**Key measurements to extract:**
- Total wall area in square feet (ft²)
- Total wall area in squares (SQ) - 1 SQ = 100 sq ft
- Wall top trim length (LF)
- Wall bottom trim length (LF)
- Number of inside corners
- Total length of inside corners (LF)
- Number of outside corners
- Total length of outside corners (LF)
- Total wall length/perimeter (LF)
- Customer/property info if available

Return JSON with these exact measurements.`,
          file_urls: fileUrls,
          response_json_schema: {
            type: "object",
            properties: {
              wall_area_sqft: { type: "number", description: "Total wall area in square feet" },
              wall_area_sq: { type: "number", description: "Total wall area in squares (SQ)" },
              wall_top_lf: { type: "number", description: "Wall top trim length" },
              wall_bottom_lf: { type: "number", description: "Wall bottom trim length" },
              inside_corners_count: { type: "number" },
              inside_corners_lf: { type: "number" },
              outside_corners_count: { type: "number" },
              outside_corners_lf: { type: "number" },
              total_wall_length: { type: "number" },
              customer_info: {
                type: "object",
                properties: {
                  customer_name: { type: "string" },
                  property_address: { type: "string" }
                }
              }
            }
          }
        });

        console.log('📏 Extracted siding measurements:', sidingResponse);

        if (!sidingResponse || typeof sidingResponse !== 'object') {
          throw new Error('Invalid siding measurements response - please try a different file');
        }

        if (Number(sidingResponse.wall_area_sq) > 0 || Number(sidingResponse.wall_area_sqft) > 0) {
          // Convert siding measurements to line items
          await convertSidingMeasurementsToLineItems(sidingResponse);

          // Set customer info
          if (sidingResponse.customer_info) {
            setCustomerInfo(prev => ({
              ...prev,
              customer_name: sidingResponse.customer_info.customer_name || prev.customer_name,
              property_address: sidingResponse.customer_info.property_address || prev.property_address
            }));
          }
        } else {
          throw new Error('Could not extract wall measurements from siding report');
        }

      } else {
        // Extract PRICED LINE ITEMS (insurance/contractor estimates)
        const priceList = pricingSource === 'xactimate' ? xactimatePriceList :
                          pricingSource === 'xactimate_new' ? xactimateNewPriceList :
                          pricingSource === 'symbility' ? symbilityPriceList :
                          customPriceList;

        const topPrices = priceList.slice(0, 50);
        const priceListJson = topPrices.map(p => ({
          code: p.code,
          desc: p.description?.substring(0, 60) || '',
          unit: p.unit
        }));

        const response = await base44.integrations.Core.InvokeLLM({
          prompt: `Extract ALL line items from this insurance/contractor estimate PDF.

**CRITICAL EXTRACTION RULES:**
1. ONLY extract from main estimate sections (with columns: Description, Qty, Unit, Rate/Price, RCV, ACV)
2. SKIP these pages entirely:
   - "Trade Summary" pages
   - "Time & Material Breakdown" pages
   - "Recap by Room" or "Recap by Category" pages
   - Labor/Material detail breakdowns
   - Summary pages that aggregate other sections
3. Look for line items that show: Description, Quantity, Unit, Rate/Price
4. Extract EXACT prices from the "Unit Price" or "Rate" column
5. Units: SQ (squares), LF (linear feet), SF (square feet), EA (each)

**Example:**
"Drip Edge, Aluminum | 190.23 | $2.90 | LF | $551.66"
Extract as: {description: "Drip Edge, Aluminum", quantity: 190.23, unit: "LF", rate: 2.90}

**IMPORTANT:** If you see duplicate items (same description appearing twice), only extract it ONCE from the main estimate section.

**Xactimate code hints (for reference only, DO NOT use these prices):**
${JSON.stringify(priceListJson, null, 2)}

Return JSON with ONLY unique line items from main estimate sections.`,
          file_urls: fileUrls,
          response_json_schema: {
            type: "object",
            properties: {
              line_items: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    code: { type: "string" },
                    description: { type: "string" },
                    quantity: { type: "number" },
                    unit: { type: "string" },
                    rate: { type: "number", description: "EXACT price per unit from PDF" }
                  },
                  required: ["description", "quantity", "unit"]
                }
              },
              total_items_extracted: { type: "number" },
              customer_info: {
                type: "object",
                properties: {
                  customer_name: { type: "string" },
                  property_address: { type: "string" },
                  claim_number: { type: "string" }
                }
              }
            }
          }
        });

        console.log('📊 LLM Response:', JSON.stringify(response, null, 2));

        if (response?.line_items && response.line_items.length > 0) {
          console.log(`✅ Extracted ${response.line_items.length} priced items from estimate`);
          
          if (response.total_items_extracted && response.line_items.length < response.total_items_extracted * 0.8) {
            setMessages(prev => [...prev, {
              role: 'assistant',
              content: `⚠️ **Possible incomplete extraction:** Found ${response.line_items.length} items, but document may contain ${response.total_items_extracted}.`,
              timestamp: new Date().toISOString()
            }]);
          }
          
          _generateAndSetEstimate(response, fileName);
        } else {
          console.error('❌ No line items in response:', response);
          
          // Try simpler extraction as fallback
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `⚠️ **Initial extraction failed. Trying alternate method...**`,
            timestamp: new Date().toISOString()
          }]);
          
          try {
            const fallbackResponse = await base44.integrations.Core.InvokeLLM({
              prompt: `Extract line items from this estimate PDF. Return ALL items with:
- description (item name)
- quantity (number)
- unit (SQ, LF, EA, etc.)
- rate (price per unit, if visible)

Be very thorough and extract EVERY line item you see.`,
              file_urls: fileUrls,
              response_json_schema: {
                type: "object",
                properties: {
                  line_items: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        description: { type: "string" },
                        quantity: { type: "number" },
                        unit: { type: "string" },
                        rate: { type: "number" }
                      },
                      required: ["description", "quantity"]
                    }
                  }
                }
              }
            });
            
            if (fallbackResponse?.line_items && fallbackResponse.line_items.length > 0) {
              console.log(`✅ Fallback extraction succeeded: ${fallbackResponse.line_items.length} items`);
              _generateAndSetEstimate(fallbackResponse, fileName);
            } else {
              throw new Error('Could not extract line items from estimate - PDF may be scanned image or unreadable');
            }
          } catch (fallbackError) {
            throw new Error('Could not extract line items - try uploading a different file or enter items manually');
          }
        }
      }

    } catch (error) {
      console.error('PDF Extraction Error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Error: ${error.message}\n\n**Troubleshooting:**\n• Make sure the PDF is text-based (not scanned image)\n• Try re-uploading\n• Use "Add Row" to enter manually`,
        timestamp: new Date().toISOString()
      }]);
      // Visible alert so users see the issue even before an estimate exists
      alert(`Failed to analyze document: ${error.message}`);
    }

    setIsProcessing(false);
  };

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    // Validate file types (case-insensitive)
    const supportedTypes = ['pdf', 'png', 'jpg', 'jpeg'];
    const unsupportedFiles = files.filter(file => {
      const fileExtension = file.name.split('.').pop()?.toLowerCase() || '';
      return !supportedTypes.includes(fileExtension);
    });

    if (unsupportedFiles.length > 0) {
      const fileNames = unsupportedFiles.map(f => f.name).join(', ');
      alert(`❌ Unsupported file type(s): ${fileNames}\n\n✅ Supported formats:\n• PDF documents\n• Images (PNG, JPG, JPEG)\n\n💡 Tip: Convert DOCX files to PDF before uploading.`);
      
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      
      return;
    }

    setMessages(prev => [...prev, {
      role: 'user',
      content: `📎 Uploaded: ${files.map(f => f.name).join(', ')}`,
      timestamp: new Date().toISOString()
    }]);

    try {
      const uploadedUrls = [];
      for (const file of files) {
        // Normalize file extension to lowercase to prevent issues with integrations
        const originalName = file.name;
        const nameParts = originalName.split('.');
        const extension = nameParts.pop();
        const baseName = nameParts.join('.');
        const normalizedName = `${baseName}.${extension.toLowerCase()}`;
        
        // Create a new File object with normalized name
        const normalizedFile = new File([file], normalizedName, { type: file.type });
        
        const { file_url } = await base44.integrations.Core.UploadFile({ file: normalizedFile });
        uploadedUrls.push({ name: normalizedName, url: file_url });
      }

      setUploadedFiles(uploadedUrls);

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Files uploaded! Click "Analyze" to process.`,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Upload failed: ${error.message}`,
        timestamp: new Date().toISOString()
      }]);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!userInput.trim() && uploadedFiles.length === 0 && !currentEstimate) { // Added !currentEstimate to handle initial non-file messages
      // If there's no estimate and no file, and no message, do nothing
      if (!userInput.trim()) return;
    }

    const message = userInput.trim();

    setMessages(prev => [...prev, {
      role: 'user',
      content: message || (uploadedFiles.length > 0 ? "Analyzing files..." : "No message provided."),
      timestamp: new Date().toISOString()
    }]);

    setUserInput("");

    if (selectedMode === "document" && uploadedFiles.length > 0) {
      const urls = uploadedFiles.map(f => f.url);
      await _processEstimateRequest(urls, message, uploadedFiles[0].name);
      setUploadedFiles([]);
    } else {
      await processWithAI(message);
    }
  };

  const handleSelectContact = (contactId) => {
    setSelectedContactId(contactId);
    const contact = allContacts.find(c => c.id === contactId);
    if (contact) {
      setCustomerInfo(prev => ({
        ...prev,
        customer_name: contact.displayName,
        customer_email: contact.email || '',
        customer_phone: contact.phone || '',
        property_address: contact.address || ''
      }));

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Selected: ${contact.displayName}`,
        timestamp: new Date().toISOString()
      }]);
    }
  };

  const handleExportToXactimate = async () => {
    if (!currentEstimate || lineItems.length === 0) {
      alert('No estimate to export');
      return;
    }

    setIsExporting(true);

    try {
      const response = await base44.functions.invoke('exportToXactimate', {
        estimate: {
          ...currentEstimate,
          line_items: lineItems,
          customer_info: customerInfo
        }
      });

      const blob = new Blob([response.data.xml_content], { type: 'text/xml' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${customerInfo.customer_name || 'estimate'}_xactimate.xml`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Exported to Xactimate`,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
      alert('Export failed: ' + error.message);
    }

    setIsExporting(false);
  };

  // Helper to generate the next estimate number with (AI) suffix
  const generateNextEstimateNumber = async () => {
    const existingEstimates = estimates;
    if (existingEstimates.length === 0) {
      return "EST-1 (AI)";
    }
    
    const numbers = existingEstimates
      .map(est => est.estimate_number)
      .filter(num => num && num.startsWith('EST-'))
      .map(num => parseInt(num.replace(/EST-|[^\d]/g, '')))
      .filter(num => !isNaN(num));
    
    if (numbers.length === 0) {
      return "EST-1 (AI)";
    }
    
    const maxNumber = Math.max(...numbers);
    const nextNumber = maxNumber + 1;
    return `EST-${nextNumber} (AI)`;
  };


  const completeSaveEstimate = async (customerId, saveData) => {
    try {
      const { companyId } = saveData;

      // Use current lineItems state directly
      const items = lineItems;

      if (!items || items.length === 0) {
        alert('No line items to save');
        return;
      }

      const totalRcv = Math.round(items.reduce((acc, item) => {
        return acc + (Number(item.rcv) || 0);
      }, 0) * 100) / 100;

      const totalAcv = Math.round(items.reduce((acc, item) => {
        return acc + (Number(item.acv) || 0);
      }, 0) * 100) / 100;

      const newEstimateNumber = await generateNextEstimateNumber();

      const estimateData = {
        customer_id: customerId,
        estimate_number: newEstimateNumber,
        estimate_title: currentEstimate.title || `Estimate - ${customerInfo.customer_name}`,
        customer_name: customerInfo.customer_name,
        customer_email: customerInfo.customer_email || '',
        customer_phone: customerInfo.customer_phone || '',
        amount: totalRcv,
        property_address: customerInfo.property_address,
        items: items,
        total_rcv: totalRcv,
        total_acv: totalAcv,
        status: 'draft',
        pricing_source: pricingSource,
        claim_number: customerInfo.claim_number,
        insurance_company: customerInfo.insurance_company,
        adjuster_name: customerInfo.adjuster_name || '',
        adjuster_phone: customerInfo.adjuster_phone || '',
        notes: customerInfo.notes || '',
        format_id: selectedFormatId,
        company_id: companyId,
        related_inspection_job_id: inspectionJobIdFromUrl || null,
      };

      console.log('💾 Saving estimate with', items.length, 'items, total:', totalRcv);
      console.log('📎 Linking to customer ID:', customerId);

      const savedEstimate = await base44.entities.Estimate.create(estimateData);
      
      console.log('✅ Estimate created:', savedEstimate.id);
      console.log('🔗 Customer ID in estimate:', savedEstimate.customer_id);
      
      if (inspectionJobIdFromUrl) {
        await base44.entities.InspectionJob.update(inspectionJobIdFromUrl, {
          related_estimate_id: savedEstimate.id
        });
      }

      // 🔔 Create notifications and trigger workflows
      try {
        await base44.functions.invoke('universalNotificationDispatcher', {
          action: 'create',
          entityType: 'Estimate',
          entityId: savedEstimate.id,
          entityData: savedEstimate,
          companyId
        });
        console.log('✅ Notifications sent for new estimate');
      } catch (notifError) {
        console.warn('⚠️ Notifications failed (non-critical):', notifError);
      }

      try {
        await base44.functions.invoke('triggerWorkflow', {
          triggerType: 'estimate_created',
          companyId: companyId,
          entityType: 'estimate',
          entityId: savedEstimate.id,
          entityData: {
            ...savedEstimate,
            customer_name: customerInfo.customer_name,
            customer_email: customerInfo.customer_email,
            customer_phone: customerInfo.customer_phone,
            estimate_number: newEstimateNumber,
            amount: totalRcv
          }
        });
        console.log('✅ Workflow triggered for new estimate');
      } catch (workflowError) {
        console.warn('⚠️ Workflow trigger failed (non-critical):', workflowError);
      }

      queryClient.invalidateQueries(['estimates']);

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Estimate ${newEstimateNumber} saved to CRM!${inspectionJobIdFromUrl ? '\n🔗 Linked to inspection job.' : ''}`,
        timestamp: new Date().toISOString()
      }]);

      setTimeout(() => navigate(createPageUrl('EstimateEditor') + `?estimate_id=${savedEstimate.id}`), 2000);
    } catch (error) {
      console.error('Error saving estimate:', error);
      alert('Error saving: ' + error.message);
    }
  };

  const handleSaveEstimate = async () => {
    if (!currentEstimate || lineItems.length === 0) {
      alert('No estimate to save');
      return;
    }

    try {
      const currentUser = user;
      if (!currentUser) {
        alert('❌ User not logged in. Cannot save estimate.');
        return;
      }

      let companyId = myCompany?.id;

      if (!companyId) {
        const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: currentUser.email });
        if (staffProfiles && staffProfiles.length > 0) {
          companyId = staffProfiles[0].company_id;
        } else {
          const fetchedCompanies = await base44.entities.Company.filter({ created_by: currentUser.email });
          if (fetchedCompanies && fetchedCompanies.length > 0) {
            companyId = fetchedCompanies[0].id;
          }
        }
      }

      if (!companyId) {
        alert('❌ No company found. Please complete company setup first.');
        return;
      }

      let customerId = selectedContactId;
      
      if (!customerId && customerInfo.customer_name) {
        console.log("🔍 No contact selected, checking for existing customer...");
        console.log("📋 Customer info to match:", JSON.stringify({
          name: customerInfo.customer_name,
          email: customerInfo.customer_email,
          phone: customerInfo.customer_phone,
          address: customerInfo.property_address
        }, null, 2));
        
        // CRITICAL: Refetch customers to ensure we have the latest data
        console.log("♻️ Refetching customers to prevent duplicates...");
        let allCustomers = await base44.entities.Customer.filter({ company_id: companyId });
        console.log(`📊 Found ${allCustomers.length} existing customers in CRM for company ${companyId}`);
        
        // If no customers in current company, search ALL customers (cross-company fallback)
        if (allCustomers.length === 0) {
          console.log("⚠️ No customers in current company, searching ALL customers...");
          allCustomers = await base44.entities.Customer.list('-created_date', 10000);
          console.log(`📊 Found ${allCustomers.length} total customers across all companies`);
        }
        
        // Log customers with emails to see what we're comparing against
        const customersWithEmail = allCustomers.filter(c => c.email);
        console.log(`📋 ${customersWithEmail.length} customers have emails`);
        
        let existingCustomer = null;
        let matchType = null;
        
        // Normalize name by removing parenthetical suffixes like "(Scott Bickel)"
        const normalizeName = (name) => {
          if (!name) return '';
          return name
            .toLowerCase()
            .trim()
            .replace(/\s+/g, ' ')
            .replace(/[^\w\s]/g, '')
            .replace(/\s*\([^)]*\)/g, '')
            .trim();
        };
        
        // Check by email FIRST (most reliable)
        if (customerInfo.customer_email) {
          const emailLower = String(customerInfo.customer_email || '')
            .toLowerCase()
            .trim()
            .replace(/\s+/g, '')
            .replace(/[^\x00-\x7F]/g, '');
          
          console.log(`🔍 Searching for email: "${emailLower}"`);
          
          existingCustomer = allCustomers.find(c => {
            if (!c.email) {
              return false;
            }
            
            const customerEmail = String(c.email || '')
              .toLowerCase()
              .trim()
              .replace(/\s+/g, '')
              .replace(/[^\x00-\x7F]/g, '');
            
            const isMatch = customerEmail === emailLower;
            
            if (isMatch) {
              console.log(`✅ EMAIL MATCH FOUND: ${c.name} (ID: ${c.id})`);
              console.log(`   Matched email: "${customerEmail}" === "${emailLower}"`);
            }
            
            return isMatch;
          });
          
          if (!existingCustomer) {
            console.log(`❌ No email match found for: "${emailLower}"`);
            console.log(`   Checked ${allCustomers.length} customers`);
          }
        }
        
        // Check by phone if no email match
        if (!existingCustomer && customerInfo.customer_phone) {
          const cleanPhone = customerInfo.customer_phone.replace(/\D/g, '');
          console.log(`🔍 Searching for phone: "${cleanPhone}"`);
          
          if (cleanPhone.length >= 10) {
            const last10Digits = cleanPhone.slice(-10);
            console.log(`   Using last 10 digits: ${last10Digits}`);
            
            existingCustomer = allCustomers.find(c => {
              if (!c.phone) {
                return false;
              }
              
              const customerPhoneStr = String(c.phone || '');
              const customerCleanPhone = customerPhoneStr.replace(/\D/g, '');
              
              if (!customerCleanPhone || customerCleanPhone.length < 10) {
                return false;
              }
              
              const customerLast10 = customerCleanPhone.slice(-10);
              const isMatch = customerLast10 === last10Digits;
              
              if (isMatch) {
                console.log(`✅ PHONE MATCH FOUND: ${c.name} (ID: ${c.id})`);
                console.log(`   Matched phone: ${customerLast10} === ${last10Digits}`);
              }
              
              return isMatch;
            });
            
            if (!existingCustomer) {
              console.log(`❌ No phone match found for: "${last10Digits}"`);
            }
          }
        }
        
        // Name normalization fallback
        if (!existingCustomer && customerInfo.customer_name) {
          const inputNameNormalized = normalizeName(customerInfo.customer_name);
          console.log(`🔍 Searching by normalized name: "${inputNameNormalized}"`);
          
          existingCustomer = allCustomers.find(c => {
            if (!c.name) return false;
            const customerNameNormalized = normalizeName(c.name);
            const isMatch = customerNameNormalized === inputNameNormalized;
            if (isMatch) {
              console.log(`✅ NAME MATCH FOUND: ${c.name} -> ${customerNameNormalized} (ID: ${c.id})`);
            }
            return isMatch;
          });
        }
        
        // FINAL FALLBACK: Search ALL customers across all companies if still no match
        if (!existingCustomer && allCustomers.length < 100) {
          console.log("🌍 No match in company customers, searching ALL customers globally...");
          const globalCustomers = await base44.entities.Customer.list('-created_date', 10000);
          console.log(`📊 Searching ${globalCustomers.length} customers globally`);
          
          // Try email match globally
          if (customerInfo.customer_email) {
            const emailLower = String(customerInfo.customer_email || '')
              .toLowerCase()
              .trim()
              .replace(/\s+/g, '')
              .replace(/[^\x00-\x7F]/g, '');
            
            existingCustomer = globalCustomers.find(c => {
              if (!c.email) return false;
              const customerEmail = String(c.email || '')
                .toLowerCase()
                .trim()
                .replace(/\s+/g, '')
                .replace(/[^\x00-\x7F]/g, '');
              return customerEmail === emailLower;
            });
            
            if (existingCustomer) {
              console.log(`🌍 GLOBAL EMAIL MATCH FOUND: ${existingCustomer.name} (ID: ${existingCustomer.id}, Company: ${existingCustomer.company_id})`);
              if (existingCustomer.company_id !== companyId) {
                console.warn(`⚠️ Customer belongs to different company! Expected: ${companyId}, Found: ${existingCustomer.company_id}`);
              }
            }
          }
          
          // Try phone match globally if still no match
          if (!existingCustomer && customerInfo.customer_phone) {
            const cleanPhone = customerInfo.customer_phone.replace(/\D/g, '');
            if (cleanPhone.length >= 10) {
              const last10Digits = cleanPhone.slice(-10);
              
              existingCustomer = globalCustomers.find(c => {
                if (!c.phone) return false;
                const customerPhoneStr = String(c.phone || '');
                const customerCleanPhone = customerPhoneStr.replace(/\D/g, '');
                if (!customerCleanPhone || customerCleanPhone.length < 10) return false;
                const customerLast10 = customerCleanPhone.slice(-10);
                return customerLast10 === last10Digits;
              });
              
              if (existingCustomer) {
                console.log(`🌍 GLOBAL PHONE MATCH FOUND: ${existingCustomer.name} (ID: ${existingCustomer.id}, Company: ${existingCustomer.company_id})`);
                if (existingCustomer.company_id !== companyId) {
                  console.warn(`⚠️ Customer belongs to different company! Expected: ${companyId}, Found: ${existingCustomer.company_id}`);
                }
              }
            }
          }
        }
        
        // DEBUG: Check for known duplicate customer #741
        const knownDuplicate = allCustomers.find(c => c.customer_number === 741 || c.id === '69106adc6acb59d7adbe2487');
        if (knownDuplicate && customerInfo.customer_email) {
          console.log("🎯 FOUND CUSTOMER #741 IN FETCHED DATA:");
          console.log("   ID:", knownDuplicate.id);
          console.log("   Name:", JSON.stringify(knownDuplicate.name));
          console.log("   Email:", JSON.stringify(knownDuplicate.email));
          console.log("   Phone:", JSON.stringify(knownDuplicate.phone));
          
          const testEmail = String(customerInfo.customer_email || '').toLowerCase().trim().replace(/\s+/g, '').replace(/[^\x00-\x7F]/g, '');
          const customerEmail = String(knownDuplicate.email || '').toLowerCase().trim().replace(/\s+/g, '').replace(/[^\x00-\x7F]/g, '');
          console.log("   Email comparison:", `"${testEmail}" === "${customerEmail}"`, testEmail === customerEmail);
          
          if (customerInfo.customer_phone) {
            const testPhone = customerInfo.customer_phone.replace(/\D/g, '').slice(-10);
            const customerPhone = (knownDuplicate.phone || '').replace(/\D/g, '').slice(-10);
            console.log("   Phone comparison:", `"${testPhone}" === "${customerPhone}"`, testPhone === customerPhone);
          }
        }
        
        // Check by name (normalized to handle variations)
        if (!existingCustomer && customerInfo.customer_name) {
          const normalizedInputName = normalizeName(customerInfo.customer_name);
          existingCustomer = allCustomers.find(c => {
            const normalizedCustomerName = normalizeName(c.name);
            return normalizedCustomerName === normalizedInputName;
          });
          if (existingCustomer) {
            matchType = 'name';
            console.log(`✅ Found match by NAME: ${existingCustomer.name}`);
          }
        }
        
        // Check by address as final fallback
        if (!existingCustomer && customerInfo.property_address) {
          const extractZipCode = (addressStr) => {
            const zipMatch = addressStr.match(/\b(\d{5})(?:-\d{4})?\b/);
            return zipMatch ? zipMatch[1] : null;
          };
          
          const extractStreetNumber = (addressStr) => {
            const match = addressStr.match(/^\s*(\d+)\s+/);
            return match ? match[1] : null;
          };
          
          const inputZip = extractZipCode(customerInfo.property_address);
          const inputStreetNum = extractStreetNumber(customerInfo.property_address);
          const inputStreet = customerInfo.property_address.toLowerCase().split(',')[0]?.trim() || '';
          
          if (inputZip && inputStreetNum) {
            existingCustomer = allCustomers.find(c => {
              const customerFullAddr = [c.street, c.city, c.state, c.zip].filter(Boolean).join(', ');
              const customerZip = extractZipCode(c.zip || customerFullAddr || c.address || '');
              const customerStreetNum = extractStreetNumber(c.street || c.address || '');
              const customerStreet = (c.street || c.address || '').toLowerCase().trim();
              
              // Match if ZIP matches AND street number matches
              return customerZip === inputZip && 
                     customerStreetNum === inputStreetNum &&
                     (customerStreet.includes(inputStreet) || inputStreet.includes(customerStreet));
            });
            if (existingCustomer) {
              matchType = 'address';
              console.log(`✅ Found match by ADDRESS: ${existingCustomer.name}`);
            }
          }
        }

        if (existingCustomer) {
          // ALWAYS auto-use existing customer and update with new info
          customerId = existingCustomer.id;
          console.log(`✅ Auto-linked to existing customer (${matchType} match):`, existingCustomer.name);
          
          // Update customer with any new info from estimate
          await base44.entities.Customer.update(existingCustomer.id, {
            email: customerInfo.customer_email || existingCustomer.email,
            phone: customerInfo.customer_phone || existingCustomer.phone,
            claim_number: customerInfo.claim_number || existingCustomer.claim_number,
            insurance_company: customerInfo.insurance_company || existingCustomer.insurance_company,
            adjuster_name: customerInfo.adjuster_name || existingCustomer.adjuster_name,
            adjuster_phone: customerInfo.adjuster_phone || existingCustomer.adjuster_phone,
          });
          
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `✅ Linked to existing customer: ${existingCustomer.name} (#${existingCustomer.customer_number})`,
            timestamp: new Date().toISOString()
          }]);
        } else {
          console.log('❌ No existing customer found, creating new one...');
          const newCustomer = await base44.entities.Customer.create({
            company_id: companyId,
            name: customerInfo.customer_name,
            email: customerInfo.customer_email || '',
            phone: customerInfo.customer_phone || '',
            street: customerInfo.property_address || '',
            insurance_company: customerInfo.insurance_company || '',
            claim_number: customerInfo.claim_number || '',
            adjuster_name: customerInfo.adjuster_name || '',
            adjuster_phone: customerInfo.adjuster_phone || '',
          });
          customerId = newCustomer.id;
          
          console.log('✅ Created new customer:', newCustomer.name, newCustomer.id);
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `✅ Created new customer: ${newCustomer.name} (#${newCustomer.customer_number})`,
            timestamp: new Date().toISOString()
          }]);
        }
      }

      await completeSaveEstimate(customerId, { companyId, currentUser, lineItems });
    } catch (error) {
      console.error('Error saving estimate:', error);
      alert('Error saving: ' + error.message);
    }
  };

  const handleGenerateMaterialList = async () => {
    if (!currentEstimate || lineItems.length === 0) {
      alert('No estimate to generate materials from');
      return;
    }

    setIsGeneratingMaterials(true);

    try {
      console.log('📋 Generating material list with', lineItems.length, 'items');
      
      const tempEstimate = {
        items: lineItems,
        estimate_number: 'DRAFT',
        customer_name: customerInfo.customer_name,
        property_address: customerInfo.property_address
      };

      console.log('📤 Calling generateMaterialList function...');
      
      const response = await generateMaterialList({
        estimateId: null,
        estimate: tempEstimate
      });

      console.log('✅ Response received:', response.data);

      setMaterialListData(response.data);
      setShowMaterialList(true);

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ Material list generated! ${response.data.materials.length} materials, ${response.data.labor.length} labor items.`,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
        console.error('❌ Material list error:', error);
        const serverErr = error?.response?.data?.error || error.message || 'Unknown error';
        const serverDetails = error?.response?.data?.details ? `\nDetails: ${error.response.data.details}` : '';
        alert(`Failed to generate material list: ${serverErr}${serverDetails}`);
      }

    setIsGeneratingMaterials(false);
  };

  const downloadMaterialList = () => {
    if (!materialListData) return;

    // SIMPLIFIED CSV - Only essential purchase info
    let csv = 'MATERIALS TO PURCHASE\n\n';
    csv += `Customer: ${materialListData.estimate.customer_name}\n`;
    csv += `Address: ${materialListData.estimate.property_address}\n\n`;

    csv += 'Material,Qty to Buy,Unit,Notes\n';
    materialListData.material_calculations.forEach(item => {
      csv += `"${item.material}",${item.quantity},"${item.purchaseUnit || item.unit}","${item.notes}"\n`;
    });

    csv += `\n\nGrand Total:,$${materialListData.totals.grand_total.toFixed(2)}\n`;

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `material-list-${customerInfo.customer_name || 'estimate'}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  // NEW: Auto-calculate AI gutters when checkbox is toggled
  useEffect(() => {
    if (includeGuttersAI && analyzedStructures.length > 0) {
      const totalEaves = analyzedStructures.reduce((sum, s) => sum + (s.analysis.eave_lf || 0), 0);
      setAiGutterLF(totalEaves);
      setAiDownspoutCount(Math.ceil(totalEaves / 35));
    } else if (!includeGuttersAI) {
      setAiGutterLF(0);
      setAiDownspoutCount(0);
    }
  }, [includeGuttersAI, analyzedStructures]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 md:p-6 pb-24 md:pb-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Sparkles className="w-8 h-8 text-purple-600" />
                AI Construction Estimator
              </h1>
              <p className="text-gray-500 mt-1">Upload any report or use satellite measurements to generate estimates</p>
            </div>
            <div className="flex gap-2">
              {estimateHistory.length > 0 && (
                <Button 
                  variant="outline" 
                  onClick={handleUndo}
                  className="border-orange-500 text-orange-700 hover:bg-orange-50"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Undo ({estimateHistory.length})
                </Button>
              )}
              <Button variant="outline" onClick={() => setShowConfig(true)}>
                <Settings className="w-4 h-4 mr-2" />
                Configure
              </Button>
            </div>
          </div>

          <Card className="mt-4 bg-gradient-to-r from-blue-50 to-purple-50">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-sm font-semibold text-gray-700">Template:</span>
                  <Select value={selectedFormatId || ''} onValueChange={handleFormatChange}>
                    <SelectTrigger className="w-full sm:w-64">
                      <SelectValue placeholder="Auto (based on pricing)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>None (Default)</SelectItem>
                      {formats.map(format => (
                        <SelectItem key={format.id} value={format.id}>
                          {format.format_name} {format.insurance_company ? `(${format.insurance_company})` : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-700">Pricing:</span>
                  <Select value={pricingSource} onValueChange={handlePricingSourceChange}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="xactimate">Xactimate (Old)</SelectItem>
                      <SelectItem value="xactimate_new">Xactimate New 🆕</SelectItem>
                      <SelectItem value="symbility">Symbility</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardContent className="p-4">
            <Tabs value={selectedMode} onValueChange={setSelectedMode}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="document" className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Document Upload
                </TabsTrigger>
                <TabsTrigger value="satellite" className="flex items-center gap-2">
                  <Satellite className="w-4 h-4" />
                  Satellite Measurement
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardContent>
        </Card>

        <Dialog open={showConfig} onOpenChange={setShowConfig}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Configure AI Estimator</DialogTitle>
              <DialogDescription>Set up your estimator preferences</DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label>Your Specialty</Label>
                <Select value={config.specialty} onValueChange={(v) => setConfig({...config, specialty: v})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="roofing">Roofing</SelectItem>
                    <SelectItem value="siding">Siding</SelectItem>
                    <SelectItem value="gutters">Gutters</SelectItem>
                    <SelectItem value="windows">Windows & Doors</SelectItem>
                    <SelectItem value="general">General Contractor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Primary Materials You Use</Label>
                <Input
                  value={config.primaryMaterials}
                  onChange={(e) => setConfig({...config, primaryMaterials: e.target.value})}
                  placeholder="e.g., laminated shingles, vinyl siding"
                />
              </div>

              <div>
                <Label>Default Pricing Source</Label>
                <Select value={config.defaultPricingSource} onValueChange={(v) => setConfig({...config, defaultPricingSource: v})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="xactimate">Xactimate (Old)</SelectItem>
                    <SelectItem value="xactimate_new">Xactimate New</SelectItem>
                    <SelectItem value="symbility">Symbility</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Default Template</Label>
                <Select value={config.defaultTemplate || ''} onValueChange={(v) => setConfig({...config, defaultTemplate: v || null})}>
                  <SelectTrigger>
                    <SelectValue placeholder="None (Auto-detect)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>None (Default)</SelectItem>
                    {formats.map(format => (
                      <SelectItem key={format.id} value={format.id}>
                        {format.format_name} {format.insurance_company ? `(${format.insurance_company})` : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={() => {
                  localStorage.setItem('aiEstimatorConfig', JSON.stringify(config));
                  setPricingSource(config.defaultPricingSource);
                  setShowConfig(false);
                  setMessages([{
                    role: 'assistant',
                    content: `✅ Configuration saved!`,
                    timestamp: new Date().toISOString()
                  }]);
                }}
                className="w-full"
              >
                Save Configuration
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Ventilation Calculator */}
        <VentilationCalculator
          open={showVentilationCalc}
          onOpenChange={setShowVentilationCalc}
          roofAreaSqFt={
            (satelliteAnalysis?.roof_area_sq * 100) || 
            (analyzedStructures.reduce((sum, s) => sum + s.analysis.roof_area_sq, 0) * 100) || 
            (currentEstimate?.line_items?.find(i => i.unit === 'SQ')?.quantity * 100) || 
            2000 // Default fallback
          }
          onAddItems={handleAddVentilationItems}
        />

        {/* Suggestions Dialog */}
        <Dialog open={showSuggestions} onOpenChange={setShowSuggestions}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-purple-600" />
                AI Estimate Review
              </DialogTitle>
              <DialogDescription className="text-gray-600">
                {suggestions?.analysis_summary}
              </DialogDescription>
            </DialogHeader>

            {suggestions && (
              <div className="space-y-4">
                {/* Quality Score */}
                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-gray-900">Estimate Quality Score</span>
                    <Badge className={`text-lg px-4 py-1.5 ${
                      suggestions.estimate_quality_score >= 85 ? 'bg-green-600' :
                      suggestions.estimate_quality_score >= 70 ? 'bg-orange-500' :
                      'bg-red-600'
                    }`}>
                      {suggestions.estimate_quality_score}/100
                    </Badge>
                  </div>
                </div>

                {/* Critical Items */}
                {suggestions.suggestions?.filter(s => s.priority === 'critical').length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      🔴 Critical Items (Usually Required)
                    </h3>
                    <div className="space-y-3">
                      {suggestions.suggestions.filter(s => s.priority === 'critical').map((item, idx) => (
                        <div key={idx} className="bg-red-50 border border-red-200 rounded-lg p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900 mb-2">{item.item_description}</h4>
                              <p className="text-sm text-gray-700 mb-2">{item.reason}</p>
                              {item.calculation_note && (
                                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-2 mb-2">
                                  <p className="text-xs text-gray-700 italic">💡 {item.calculation_note}</p>
                                </div>
                              )}
                              {item.typical_quantity && item.typical_unit && (
                                <div className="bg-gray-100 rounded px-3 py-1.5 inline-block mt-2">
                                  <p className="text-sm font-medium text-gray-900">
                                    Suggested: {item.typical_quantity} {item.typical_unit}
                                  </p>
                                </div>
                              )}
                            </div>
                            <Button
                              size="sm"
                              onClick={() => handleAddSuggestedItem(item)}
                              className="bg-red-600 hover:bg-red-700 text-white px-6"
                            >
                              Add
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Recommended Items */}
                {suggestions.suggestions?.filter(s => s.priority === 'recommended').length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      🟡 Recommended Items (Common for This Job Type)
                    </h3>
                    <div className="space-y-3">
                      {suggestions.suggestions.filter(s => s.priority === 'recommended').map((item, idx) => (
                        <div key={idx} className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900 mb-2">{item.item_description}</h4>
                              <p className="text-sm text-gray-700 mb-2">{item.reason}</p>
                              {item.calculation_note && (
                                <div className="bg-yellow-100 border-l-4 border-yellow-400 p-2 mb-2">
                                  <p className="text-xs text-gray-700 italic">💡 {item.calculation_note}</p>
                                </div>
                              )}
                              {item.typical_quantity && item.typical_unit && (
                                <div className="bg-gray-100 rounded px-3 py-1.5 inline-block mt-2">
                                  <p className="text-sm font-medium text-gray-900">
                                    Suggested: {item.typical_quantity} {item.typical_unit}
                                  </p>
                                </div>
                              )}
                            </div>
                            <Button
                              size="sm"
                              onClick={() => handleAddSuggestedItem(item)}
                              className="bg-red-600 hover:bg-red-700 text-white px-6"
                            >
                              Add
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Optional Items */}
                {suggestions.suggestions?.filter(s => s.priority === 'optional').length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      🔵 Optional Items (Upgrades/Add-ons)
                    </h3>
                    <div className="space-y-3">
                      {suggestions.suggestions.filter(s => s.priority === 'optional').map((item, idx) => (
                        <div key={idx} className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900 mb-2">{item.item_description}</h4>
                              <p className="text-sm text-gray-700 mb-2">{item.reason}</p>
                              {item.calculation_note && (
                                <div className="bg-blue-100 border-l-4 border-blue-400 p-2 mb-2">
                                  <p className="text-xs text-gray-700 italic">💡 {item.calculation_note}</p>
                                </div>
                              )}
                              {item.typical_quantity && item.typical_unit && (
                                <div className="bg-gray-100 rounded px-3 py-1.5 inline-block mt-2">
                                  <p className="text-sm font-medium text-gray-900">
                                    Suggested: {item.typical_quantity} {item.typical_unit}
                                  </p>
                                </div>
                              )}
                            </div>
                            <Button
                              size="sm"
                              onClick={() => handleAddSuggestedItem(item)}
                              className="bg-red-600 hover:bg-red-700 text-white px-6"
                            >
                              Add
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* No Suggestions */}
                {suggestions.suggestions?.length === 0 && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                    <p className="text-lg font-semibold text-green-900 mb-1">✅ Estimate Looks Complete!</p>
                    <p className="text-sm text-green-700">No missing items detected based on industry standards.</p>
                  </div>
                )}

                <div className="flex justify-end pt-4 border-t">
                  <Button variant="outline" onClick={() => setShowSuggestions(false)}>
                    Close
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={showMergeDialog} onOpenChange={setShowMergeDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-blue-600" />
                Merge Additional Documents
              </DialogTitle>
              <DialogDescription>
                Upload roof, siding, or other estimates to merge with your current estimate
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900 mb-2">
                  <strong>Current Estimate:</strong> {lineItems.length} items • ${lineItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0).toLocaleString()}
                </p>
                <p className="text-xs text-blue-700">
                  Upload additional documents to add more line items to this estimate
                </p>
              </div>

              <div>
                <Label>Upload Documents (PDF, PNG, JPG)</Label>
                <input
                  type="file"
                  onChange={(e) => setMergeFiles(Array.from(e.target.files || []))}
                  className="mt-2 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                  accept=".pdf,.PDF,.png,.PNG,.jpg,.JPG,.jpeg,.JPEG"
                  multiple
                />
              </div>

              {mergeFiles.length > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-sm font-semibold text-green-900 mb-2">Files to merge:</p>
                  {mergeFiles.map((file, idx) => (
                    <p key={idx} className="text-xs text-green-700">• {file.name}</p>
                  ))}
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => {
                  setShowMergeDialog(false);
                  setMergeFiles([]);
                }}>
                  Cancel
                </Button>
                <Button
                  onClick={async () => {
                    if (mergeFiles.length === 0) {
                      alert('Select files to merge');
                      return;
                    }

                    setIsMerging(true);
                    saveToHistory(); // Save current state before merging

                    try {
                      const uploadedUrls = [];
                      for (const file of mergeFiles) {
                        const { file_url } = await base44.integrations.Core.UploadFile({ file });
                        uploadedUrls.push(file_url);
                      }

                      setMessages(prev => [...prev, {
                        role: 'assistant',
                        content: `🔄 **Merging ${mergeFiles.length} documents into current estimate...**`,
                        timestamp: new Date().toISOString()
                      }]);

                      // Process each file and collect items
                      const newItems = [];
                      for (let i = 0; i < uploadedUrls.length; i++) {
                        const fileUrl = [uploadedUrls[i]];
                        const docName = mergeFiles[i].name;

                        const typeCheck = await base44.integrations.Core.InvokeLLM({
                          prompt: `What type of document is this? Respond with ONLY: "hover_measurement", "siding_measurement", or "insurance_estimate"`,
                          file_urls: fileUrl
                        });

                        const docType = typeCheck.toLowerCase().includes('siding') ? 'siding_measurement' :
                                      typeCheck.toLowerCase().includes('hover') ? 'hover_measurement' : 'insurance_estimate';

                        if (docType === 'hover_measurement') {
                          const measurements = await base44.integrations.Core.InvokeLLM({
                            prompt: `Extract roof measurements: roof_area_sq, ridge_lf, hip_lf, valley_lf, rake_lf, eave_lf, step_flashing_lf, pitch, gutter_lf, downspout_count`,
                            file_urls: fileUrl,
                            response_json_schema: {
                              type: "object",
                              properties: {
                                roof_area_sq: { type: "number" }, ridge_lf: { type: "number" }, hip_lf: { type: "number" },
                                valley_lf: { type: "number" }, rake_lf: { type: "number" }, eave_lf: { type: "number" },
                                step_flashing_lf: { type: "number" }, pitch: { type: "string" }, gutter_lf: { type: "number" },
                                downspout_count: { type: "number" }
                              }
                            }
                          });
                          const items = await convertMeasurementsToLineItemsArray(measurements);
                          newItems.push(...items);

                        } else if (docType === 'siding_measurement') {
                          const measurements = await base44.integrations.Core.InvokeLLM({
                            prompt: `Extract siding measurements: wall_area_sq, wall_top_lf, wall_bottom_lf, inside_corners_lf, outside_corners_lf`,
                            file_urls: fileUrl,
                            response_json_schema: {
                              type: "object",
                              properties: {
                                wall_area_sq: { type: "number" }, wall_top_lf: { type: "number" }, wall_bottom_lf: { type: "number" },
                                inside_corners_lf: { type: "number" }, outside_corners_lf: { type: "number" }
                              }
                            }
                          });
                          const items = await convertSidingMeasurementsToLineItemsArray(measurements);
                          newItems.push(...items);

                        } else {
                          const response = await base44.integrations.Core.InvokeLLM({
                            prompt: `Extract ALL line items with description, quantity, unit, rate`,
                            file_urls: fileUrl,
                            response_json_schema: {
                              type: "object",
                              properties: {
                                line_items: {
                                  type: "array",
                                  items: {
                                    type: "object",
                                    properties: {
                                      code: { type: "string" }, description: { type: "string" },
                                      quantity: { type: "number" }, unit: { type: "string" }, rate: { type: "number" }
                                    }
                                  }
                                }
                              }
                            }
                          });

                          if (response?.line_items) {
                            const items = response.line_items.map((item, idx) => ({
                              line: lineItems.length + newItems.length + idx + 1,
                              code: item.code || '',
                              description: item.description,
                              quantity: Number(item.quantity) || 0,
                              unit: item.unit || 'EA',
                              rate: Number(item.rate) || 0,
                              rcv: (Number(item.rate) || 0) * (Number(item.quantity) || 0),
                              acv: (Number(item.rate) || 0) * (Number(item.quantity) || 0),
                              amount: (Number(item.rate) || 0) * (Number(item.quantity) || 0),
                              depreciation: 0
                            }));
                            newItems.push(...items);
                          }
                        }
                      }

                      // Merge with existing items
                      const mergedItems = [...lineItems, ...newItems].map((item, idx) => ({ ...item, line: idx + 1 }));
                      setLineItems(mergedItems);

                      const newTotal = mergedItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);

                      setMessages(prev => [...prev, {
                        role: 'assistant',
                        content: `✅ **Merged ${mergeFiles.length} documents!**\n\n📊 Added ${newItems.length} new items\n💰 New total: $${newTotal.toLocaleString()}`,
                        timestamp: new Date().toISOString()
                      }]);

                      setShowMergeDialog(false);
                      setMergeFiles([]);
                    } catch (error) {
                      alert('Merge failed: ' + error.message);
                    }

                    setIsMerging(false);
                  }}
                  disabled={mergeFiles.length === 0 || isMerging}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isMerging ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Merging...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Merge {mergeFiles.length > 0 ? `${mergeFiles.length} Files` : 'Documents'}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={showMaterialList} onOpenChange={setShowMaterialList}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-2">
                <ClipboardList className="w-6 h-6 text-green-600" />
                Material Purchase List
              </DialogTitle>
              <DialogDescription>
                {materialListData?.estimate.customer_name && `For: ${materialListData.estimate.customer_name}`}
              </DialogDescription>
            </DialogHeader>

            {materialListData && (
              <div className="space-y-6">
                {/* NEW: Material Quantities Needed Section */}
                {materialListData.material_calculations && materialListData.material_calculations.length > 0 && (
                  <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg border-2 border-blue-300">
                    <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                      🛒 Materials to Purchase
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {materialListData.material_calculations.map((calc, idx) => (
                        <div key={idx} className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-blue-500">
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-bold text-lg text-gray-900">{calc.material}</h3>
                            <Badge className="ml-auto bg-blue-600 text-white text-lg px-3 py-1">
                              {calc.quantity} {calc.purchaseUnit || calc.unit}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-1">
                            <strong>Calculation:</strong> {calc.calculation}
                          </p>
                          <p className="text-xs text-gray-500 italic">{calc.notes}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Materials Section - UPDATED to show purchase quantities inline */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                      📦 Materials Breakdown
                      <Badge variant="outline">{materialListData.materials.length} items</Badge>
                    </h3>
                    <Badge className="bg-green-100 text-green-700">
                      ${Number(materialListData.totals.materials || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}
                    </Badge>
                  </div>

                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Code</th>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Description</th>
                          <th className="px-4 py-2 text-right text-sm font-semibold">Qty</th>
                          <th className="px-4 py-2 text-right text-sm font-semibold">Unit</th>
                          <th className="px-4 py-2 text-right text-sm font-semibold">Rate</th>
                          <th className="px-4 py-2 text-right text-sm font-semibold">Amount</th>
                        </tr>
                      </thead>
                      <tbody>
                        {materialListData.materials.map((item, idx) => {
                          // Find matching calculation for this item
                          const calc = materialListData.material_calculations?.find(c => {
                            const itemDesc = item.description.toLowerCase();
                            const calcMaterial = c.material.toLowerCase();

                            // Match shingles (excluding cap)
                            if (itemDesc.includes('shingle') && !itemDesc.includes('cap') && calcMaterial.includes('shingle') && !calcMaterial.includes('cap')) {
                              return true;
                            }
                            // Match ridge/hip
                            if ((itemDesc.includes('ridge') || itemDesc.includes('hip')) && (calcMaterial.includes('ridge') || calcMaterial.includes('hip'))) {
                              return true;
                            }
                            // Match valley
                            if (itemDesc.includes('valley') && calcMaterial.includes('valley')) {
                              return true;
                            }
                            // Match underlayment
                            if ((itemDesc.includes('underlayment') || itemDesc.includes('felt') || itemDesc.includes('synthetic')) &&
                                (calcMaterial.includes('underlayment') || calcMaterial.includes('felt') || calcMaterial.includes('synthetic'))) {
                              return true;
                            }
                            // Match drip edge
                            if (itemDesc.includes('drip') && calcMaterial.includes('drip')) {
                              return true;
                            }
                            // Match nails
                            if (itemDesc.includes('nail') && calcMaterial.includes('nail')) {
                              return true;
                            }
                            // Match starter
                            if (itemDesc.includes('starter') && calcMaterial.includes('starter')) {
                              return true;
                            }
                            // Match ice & water shield
                            if ((itemDesc.includes('ice') || itemDesc.includes('water shield')) && calcMaterial.includes('ice')) {
                              return true;
                            }
                            // Match step flashing
                            if (itemDesc.includes('step') && itemDesc.includes('flashing') && calcMaterial.includes('step')) {
                              return true;
                            }
                            return false;
                          });

                          return (
                            <tr key={idx} className="border-b hover:bg-gray-50">
                              <td className="px-4 py-2 text-sm font-mono">{item.code}</td>
                              <td className="px-4 py-2 text-sm">
                                <div>{item.description}</div>
                                {calc && (
                                  <div className="text-xs text-blue-700 mt-1 font-medium">
                                    🛒 Buy: {calc.quantity} {calc.purchaseUnit || calc.unit}
                                  </div>
                                )}
                              </td>
                              <td className="px-4 py-2 text-sm text-right">{Number(item.quantity || 0).toFixed(2)}</td>
                              <td className="px-4 py-2 text-sm text-right">{item.unit}</td>
                              <td className="px-4 py-2 text-sm text-right">${Number(item.rate || 0).toFixed(2)}</td>
                              <td className="px-4 py-2 text-sm text-right font-semibold">${Number(item.amount || 0).toFixed(2)}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Labor Section */}
                {materialListData.labor.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                        👷 Labor & Services
                        <Badge variant="outline">{materialListData.labor.length} items</Badge>
                      </h3>
                      <Badge className="bg-blue-100 text-blue-700">
                        ${Number(materialListData.totals.labor || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}
                      </Badge>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-gray-50 border-b">
                          <tr>
                            <th className="px-4 py-2 text-left text-sm font-semibold">Code</th>
                            <th className="px-4 py-2 text-left text-sm font-semibold">Description</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Qty</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Unit</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Rate</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          {materialListData.labor.map((item, idx) => (
                            <tr key={idx} className="border-b hover:bg-gray-50">
                              <td className="px-4 py-2 text-sm font-mono">{item.code}</td>
                              <td className="px-4 py-2 text-sm">{item.description}</td>
                              <td className="px-4 py-2 text-sm text-right">{Number(item.quantity || 0).toFixed(2)}</td>
                              <td className="px-4 py-2 text-sm text-right">{item.unit}</td>
                              <td className="px-4 py-2 text-sm text-right">${Number(item.rate || 0).toFixed(2)}</td>
                              <td className="px-4 py-2 text-sm text-right font-semibold">${Number(item.amount || 0).toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Other Items Section */}
                {materialListData.other.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                        📋 Other
                        <Badge variant="outline">{materialListData.other.length} items</Badge>
                      </h3>
                      <Badge className="bg-gray-100 text-gray-700">
                        ${Number(materialListData.totals.other || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}
                      </Badge>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-gray-50 border-b">
                          <tr>
                            <th className="px-4 py-2 text-left text-sm font-semibold">Code</th>
                            <th className="px-4 py-2 text-left text-sm font-semibold">Description</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Qty</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Unit</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Rate</th>
                            <th className="px-4 py-2 text-right text-sm font-semibold">Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          {materialListData.other.map((item, idx) => (
                            <tr key={idx} className="border-b hover:bg-gray-50">
                              <td className="px-4 py-2 text-sm font-mono">{item.code}</td>
                              <td className="px-4 py-2 text-sm">{item.description}</td>
                              <td className="px-4 py-2 text-sm text-right">{Number(item.quantity || 0).toFixed(2)}</td>
                              <td className="px-4 py-2 text-sm text-right">{item.unit}</td>
                              <td className="px-4 py-2 text-sm text-right">${Number(item.rate || 0).toFixed(2)}</td>
                              <td className="px-4 py-2 text-sm text-right font-semibold">${Number(item.amount || 0).toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Totals Summary */}
                <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg border-2 border-green-200">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Materials:</span>
                      <span className="font-semibold">${Number(materialListData.totals.materials || 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Labor:</span>
                      <span className="font-semibold">${Number(materialListData.totals.labor || 0).toFixed(2)}</span>
                    </div>
                    {materialListData.totals.other > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Other:</span>
                        <span className="font-semibold">${Number(materialListData.totals.other || 0).toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-lg font-bold pt-3 border-t-2 border-green-300">
                      <span className="text-gray-900">Grand Total:</span>
                      <span className="text-green-700">${Number(materialListData.totals.grand_total || 0).toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button onClick={downloadMaterialList} className="flex-1 bg-green-600 hover:bg-green-700">
                    <Download className="w-4 h-4 mr-2" />
                    Download CSV
                  </Button>
                  <Button onClick={() => setShowMaterialList(false)} variant="outline" className="flex-1">
                    Close
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Duplicate Customer Dialog */}
        <Dialog open={showDuplicateDialog} onOpenChange={setShowDuplicateDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>⚠️ Duplicate Customer Detected</DialogTitle>
              <DialogDescription>
                A customer with this email/phone already exists in your CRM.
              </DialogDescription>
            </DialogHeader>
            
            {duplicateCustomer && (
              <div className="space-y-4">
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <p className="font-semibold text-gray-900 mb-2">Existing Customer:</p>
                  <div className="text-sm space-y-1">
                    <p><strong>Name:</strong> {duplicateCustomer.name}</p>
                    <p><strong>Email:</strong> {duplicateCustomer.email || 'N/A'}</p>
                    <p><strong>Phone:</strong> {duplicateCustomer.phone || 'N/A'}</p>
                    <p><strong>Address:</strong> {[duplicateCustomer.street, duplicateCustomer.city, duplicateCustomer.state, duplicateCustomer.zip].filter(Boolean).join(', ') || 'N/A'}</p>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="font-semibold text-gray-900 mb-2">New Customer Info:</p>
                  <div className="text-sm space-y-1">
                    <p><strong>Name:</strong> {customerInfo.customer_name}</p>
                    <p><strong>Email:</strong> {customerInfo.customer_email || 'N/A'}</p>
                    <p><strong>Phone:</strong> {customerInfo.customer_phone || 'N/A'}</p>
                    <p><strong>Address:</strong> {customerInfo.property_address || 'N/A'}</p>
                  </div>
                </div>

                <p className="text-sm text-gray-600">
                  What would you like to do?
                </p>

                <div className="flex flex-col gap-3">
                  <Button
                    onClick={async () => {
                      // Update existing customer
                      const { companyId } = pendingSaveData;
                      await base44.entities.Customer.update(duplicateCustomer.id, {
                        name: customerInfo.customer_name || duplicateCustomer.name,
                        email: customerInfo.customer_email || duplicateCustomer.email,
                        phone: customerInfo.customer_phone || duplicateCustomer.phone,
                        street: customerInfo.property_address || duplicateCustomer.street,
                        insurance_company: customerInfo.insurance_company || duplicateCustomer.insurance_company,
                      });
                      
                      setShowDuplicateDialog(false);
                      
                      // Continue with save using existing customer ID
                      await completeSaveEstimate(duplicateCustomer.id, pendingSaveData);
                    }}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Update Existing Customer
                  </Button>
                  
                  <Button
                    onClick={async () => {
                      // Create new duplicate customer
                      const { companyId } = pendingSaveData;
                      const newCustomer = await base44.entities.Customer.create({
                        company_id: companyId,
                        name: customerInfo.customer_name,
                        email: customerInfo.customer_email || '',
                        phone: customerInfo.customer_phone || '',
                        street: customerInfo.property_address || '',
                        insurance_company: customerInfo.insurance_company || '',
                      });
                      
                      setShowDuplicateDialog(false);
                      
                      // Continue with save using new customer ID
                      await completeSaveEstimate(newCustomer.id, pendingSaveData);
                    }}
                    variant="outline"
                    className="border-green-600 text-green-700 hover:bg-green-50"
                  >
                    Create New Customer (Allow Duplicate)
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowDuplicateDialog(false);
                      setDuplicateCustomer(null);
                      setPendingSaveData(null);
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <div className="space-y-6">
          {selectedMode === "document" && (
            <Card className="bg-white shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Document Upload Mode
                </CardTitle>
              </CardHeader>

              <CardContent className="p-0">
                {uploadedFiles.length > 0 && !isProcessing && (
                  <div className="p-4 border-b bg-gradient-to-r from-green-50 to-blue-50 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-green-600" />
                      <span className="font-medium text-gray-900">{uploadedFiles[0].name}</span>
                      {currentEstimate && (
                        <Badge className="bg-blue-100 text-blue-700 text-xs">
                          Previously analyzed
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" onClick={async () => {
                          const urls = uploadedFiles.map(f => f.url);
                          await _processEstimateRequest(urls, userInput || "re-analyze", uploadedFiles[0].name);
                      }}>
                        {currentEstimate ? 'Re-analyze' : 'Analyze'}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setUploadedFiles([])}>
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
                
                {uploadedFiles.length > 0 && isProcessing && (
                  <div className="p-8 border-b bg-gradient-to-r from-purple-50 to-blue-50">
                    <div className="text-center">
                      <div className="relative inline-block mb-4">
                        <div className="absolute inset-0 animate-ping opacity-30">
                          <svg className="w-16 h-16 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 80 L50 20 L90 80 Z" fill="currentColor" className="text-purple-600" />
                          </svg>
                        </div>
                        <svg className="w-16 h-16 mx-auto animate-spin" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M10 80 L50 20 L90 80 Z" fill="currentColor" className="text-purple-600" />
                        </svg>
                      </div>
                      <p className="text-lg font-semibold text-gray-900">AI Analyzing Document...</p>
                      <p className="text-sm text-gray-600 mt-1">Reading {uploadedFiles[0].name}</p>
                      <div className="mt-4 space-y-1 text-xs text-gray-500">
                        <p>✓ Extracting measurements and line items</p>
                        <p>✓ Matching with price database</p>
                        <p>✓ Generating estimate</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Status message visible even before an estimate exists */}
                {!isProcessing && !currentEstimate && (() => {
                  const lastAssistant = [...messages].reverse().find(m => m.role === 'assistant');
                  return lastAssistant ? (
                    <div className="px-4 py-3 border-b bg-yellow-50 text-yellow-800">
                      <div className="text-sm font-semibold mb-1">Status</div>
                      <div className="text-sm whitespace-pre-wrap">{lastAssistant.content}</div>
                    </div>
                  ) : null;
                })()}
                
                <div className="p-4 bg-white">
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      onChange={handleFileSelect}
                      className="hidden"
                      accept=".pdf,.PDF,.png,.PNG,.jpg,.JPG,.jpeg,.JPEG"
                      multiple
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isProcessing || uploadedFiles.length > 0}
                    >
                      <Paperclip className="w-5 h-5" />
                    </Button>
                    <Input
                      placeholder="Upload file or type message..."
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      disabled={isProcessing || uploadedFiles.length > 0}
                      className="flex-1"
                    />
                    <Button
                      type="submit"
                      disabled={isProcessing || uploadedFiles.length > 0}
                      className="bg-gradient-to-r from-blue-600 to-purple-600"
                    >
                      <Send className="w-5 h-5" />
                    </Button>
                  </form>
                  {!currentEstimate && (
                    <div className="mt-2 text-sm text-gray-500">
                      Upload a document (e.g., HOVER, Xactimate PDF) or type a message to start an estimate.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {selectedMode === "satellite" && (
            <div className="space-y-6">
              <Card className="bg-white shadow-lg">
                <CardHeader className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                  <CardTitle className="flex items-center gap-2">
                    <Satellite className="w-5 h-5" />
                    AI Satellite Measurement
                  </CardTitle>
                </CardHeader>

                <CardContent className="p-6 space-y-6">
                  {!googleMapsLoaded && !googleMapsError && (
                    <div className="text-center py-12">
                      <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
                      <p className="text-lg font-medium text-gray-900">Loading Google Maps...</p>
                      <p className="text-sm text-gray-500">Please wait</p>
                    </div>
                  )}

                  {googleMapsError && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
                      <p className="text-red-800 font-semibold mb-2">⚠️ {googleMapsError}</p>
                      <Button onClick={() => window.location.reload()} variant="outline">
                        Refresh Page
                      </Button>
                    </div>
                  )}

                  {googleMapsLoaded && (!satelliteAddress || showStructureSelector || isAddingStructure) && (
                    <div>
                      <Label className="text-lg font-semibold mb-3 block">
                        <MapPin className="w-5 h-5 inline mr-2" />
                        {analyzedStructures.length === 0 ? 'Enter Property Address' : 'Add Another Structure'}
                      </Label>
                      
                      {/* NEW: Display analyzed structures */}
                      {analyzedStructures.length > 0 && (
                        <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <p className="font-semibold text-blue-900 mb-2 flex items-center justify-between">
                            <span>✅ Analyzed Structures:</span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                if (window.confirm(`Clear all ${analyzedStructures.length} structures and start over?`)) {
                                  setAnalyzedStructures([]);
                                  setLineItems([]);
                                  setCurrentEstimate(null);
                                  setSatelliteAnalysis(null);
                                  setIncludeGuttersAI(false);
                                  setAiGutterLF(0);
                                  setAiDownspoutCount(0);
                                  setEstimateHistory([]);
                                  setManualMeasurements([]);
                                  setManualAddOnMode(false);
                                  setSatelliteAddress(null);
                                }
                              }}
                              className="h-7 text-xs"
                            >
                              Clear All
                            </Button>
                          </p>
                          {analyzedStructures.map((structure, idx) => (
                            <div key={structure.id} className="text-sm text-blue-800 flex items-center justify-between mb-2 bg-white rounded p-2">
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold">#{idx + 1}</span>
                                  <span>{structure.name}:</span>
                                  <Badge className={`${structure.analysis.overall_confidence < 60 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                    {structure.analysis.roof_area_sq.toFixed(2)} SQ
                                  </Badge>
                                  <Badge variant="outline" className="text-xs">
                                    {structure.analysis.overall_confidence}% confidence
                                  </Badge>
                                </div>
                                {structure.analysis.overall_confidence < 60 && (
                                  <p className="text-xs text-red-600 mt-1 ml-6">⚠️ Low accuracy - consider manual measurement</p>
                                )}
                              </div>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setAnalyzedStructures(prev => {
                                    const updated = prev.filter(s => s.id !== structure.id);
                                    if (prev.length === 1 && updated.length === 0) {
                                      setLineItems([]);
                                      setCurrentEstimate(null);
                                      setSatelliteAnalysis(null);
                                      setIncludeGuttersAI(false);
                                      setAiGutterLF(0);
                                      setAiDownspoutCount(0);
                                      setEstimateHistory([]);
                                      setManualMeasurements([]);
                                      setManualAddOnMode(false);
                                    }
                                    return updated;
                                  });
                                }}
                                className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
                              >
                                <X className="w-3 h-3" />
                              </Button>
                            </div>
                          ))}
                          <div className="mt-3 pt-3 border-t border-blue-200 flex items-center justify-between">
                            <span className="text-sm font-bold text-blue-900">
                              Combined Total: {analyzedStructures.reduce((sum, s) => sum + s.analysis.roof_area_sq, 0).toFixed(2)} SQ
                            </span>
                            {analyzedStructures.some(s => s.analysis.overall_confidence < 60) && (
                              <Badge className="bg-yellow-100 text-yellow-800">
                                ⚠️ Review Needed
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                      
                      <GoogleAddressAutocomplete
                        onAddressSelect={(addr, details) => {
                          handleSatelliteAddressSelect(addr, details);
                          if (analyzedStructures.length > 0) {
                            setIsAddingStructure(true);
                          } else {
                            setIsAddingStructure(false);
                          }
                        }}
                        placeholder={analyzedStructures.length === 0 
                          ? "Enter property address for satellite analysis..." 
                          : "Enter address for garage, shed, or additional structure..."}
                        initialAddress={satelliteAddress?.address || ''} // Pre-fill with current address
                      />
                      
                      <div className="mt-4 space-y-4">
                        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4 border border-purple-200">
                          <h4 className="font-semibold flex items-center gap-2 mb-3">
                            <Sparkles className="w-4 h-4 text-purple-600" />
                            Measurement API:
                          </h4>
                          <Select value={measurementAPI} onValueChange={(val) => {
                            setMeasurementAPI(val);
                            localStorage.setItem('aiEstimatorMeasurementAPI', val);
                          }}>
                            <SelectTrigger className="w-full bg-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="google_solar">
                                <div className="flex items-center gap-2">
                                  <span>🌐 Google Solar API</span>
                                </div>
                              </SelectItem>
                              <SelectItem value="gemini_vision">
                                <div className="flex items-center gap-2">
                                  <span>✨ Gemini Vision (Experimental)</span>
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <p className="text-xs text-gray-600 mt-2">
                            {measurementAPI === 'gemini_vision' 
                              ? '✨ Uses AI vision to analyze satellite images for more accurate ridge/hip/valley detection' 
                              : '🌐 Uses Google Solar API for fast automated measurements'}
                          </p>
                        </div>

                        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4 border border-purple-200">
                          <h4 className="font-semibold flex items-center gap-2 mb-2">
                            <Sparkles className="w-4 h-4 text-purple-600" />
                            Two Ways to Measure:
                          </h4>
                          <div className="space-y-2 text-sm text-gray-700">
                            <div className="flex items-start gap-2">
                              <span className="font-bold text-purple-600">1️⃣ AI Auto-Detect:</span>
                              <span>Fast (30-60s) but may need manual review</span>
                            </div>
                            <div className="flex items-start gap-2">
                              <span className="font-bold text-blue-600">2️⃣ Manual Drawing:</span>
                              <span>Most Accurate • You draw</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {satelliteAddress && !useManualDrawing && !isSatelliteAnalyzing && !satelliteAnalysis && !showStructureSelector && (
                    <div className="space-y-4">
                      <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-6 border-2 border-blue-200">
                        <p className="text-lg font-semibold text-gray-900 mb-4">
                          📍 {satelliteAddress.address}
                        </p>
                        <p className="text-gray-700 mb-4">
                          Choose how you want to measure this roof:
                        </p>
                        <div className="grid md:grid-cols-2 gap-4">
                          <Button
                            onClick={handleAIAutoDetect}
                            className="h-auto py-6 flex-col bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                          >
                            <Sparkles className="w-8 h-8 mb-2" />
                            <span className="text-lg font-bold">AI Auto-Detect</span>
                            <span className="text-xs mt-1 opacity-90">Fast • 30-60 seconds</span>
                          </Button>
                          <Button
                            onClick={() => setUseManualDrawing(true)}
                            className="h-auto py-6 flex-col bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                          >
                            <Pencil className="w-8 h-8 mb-2" />
                            <span className="text-lg font-bold">Manual Drawing</span>
                            <span className="text-xs mt-1 opacity-90">Most Accurate • You draw</span>
                          </Button>
                        </div>
                        <div className="mt-4 text-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSatelliteAddress(null);
                              setUseManualDrawing(false);
                              setAnalyzedStructures([]);
                              setLineItems([]);
                              setCurrentEstimate(null);
                              setManualMeasurements([]);
                            }}
                          >
                            ← Choose Different Address
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {isSatelliteAnalyzing && (
                    <div className="text-center py-12">
                      <div className="relative inline-block mb-6">
                        <div className="absolute inset-0 animate-ping opacity-30">
                          <svg className="w-16 h-16 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 80 L50 20 L90 80 Z" fill="currentColor" className="text-blue-600" />
                          </svg>
                        </div>
                        <svg className="w-16 h-16 mx-auto animate-spin" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M10 80 L50 20 L90 80 Z" fill="currentColor" className="text-blue-600" />
                        </svg>
                      </div>
                      <p className="text-lg font-medium text-gray-900">AI is analyzing the roof...</p>
                      <p className="text-sm text-gray-500 mt-2">This may take 30-60 seconds</p>
                      <div className="mt-4 space-y-2 text-sm text-gray-600">
                        <p>✓ Loading satellite imagery</p>
                        <p>✓ Detecting roof features with Google Solar API</p>
                        <p>✓ Calculating accurate dimensions</p>
                      </div>
                    </div>
                  )}

                  {/* SHOW MESSAGES/ERRORS IN SATELLITE MODE */}
                  {!isSatelliteAnalyzing && !currentEstimate && messages.length > 0 && (
                    <div className="mb-6 space-y-2">
                      {messages.filter(m => m.role === 'assistant').slice(-1).map((msg, idx) => (
                        <div key={idx} className={`rounded-lg p-4 ${
                          msg.content.includes('❌') ? 'bg-red-50 border border-red-200 text-red-900' :
                          msg.content.includes('⚠️') ? 'bg-yellow-50 border border-yellow-200 text-yellow-900' :
                          'bg-blue-50 border border-blue-200 text-blue-900'
                        }`}>
                          <div className="whitespace-pre-wrap text-sm">{msg.content}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  {satelliteAddress && satelliteAnalysis && !isSatelliteAnalyzing && !useManualDrawing && !showStructureSelector && analyzedStructures.length > 0 && (
                  <div className="space-y-4">
                      <Card className="overflow-hidden relative">
                         <div 
                           ref={(el) => {
                             if (!el || !window.google || !satelliteAddress) return;

                             // Only initialize once
                             if (el.querySelector('.gmap-satellite')) return;

                             const mapDiv = document.createElement('div');
                             mapDiv.className = 'gmap-satellite';
                             mapDiv.style.width = '100%';
                             mapDiv.style.height = '400px';
                             el.appendChild(mapDiv);

                             const map = new window.google.maps.Map(mapDiv, {
                               center: satelliteAddress.coordinates,
                               zoom: 20,
                               mapTypeId: 'satellite',
                               tilt: 0,
                               streetViewControl: false,
                               mapTypeControl: false,
                               fullscreenControl: true,
                             });

                             // Add marker
                             new window.google.maps.Marker({
                               position: satelliteAddress.coordinates,
                               map: map,
                               title: satelliteAddress.address,
                               icon: {
                                 path: window.google.maps.SymbolPath.CIRCLE,
                                 scale: 10,
                                 fillColor: '#ef4444',
                                 fillOpacity: 0.9,
                                 strokeColor: '#ffffff',
                                 strokeWeight: 2,
                               }
                             });
                           }}
                           className="w-full"
                         />
                         <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm rounded-lg px-4 py-2 shadow-lg border border-gray-200">
                           <p className="text-sm font-semibold text-gray-900 flex items-center gap-2">
                             <MapPin className="w-4 h-4 text-red-600" />
                             {satelliteAddress.address}
                           </p>
                         </div>
                         </Card>

                         {/* AI CONFIDENCE BANNER */}
                      <div className={`rounded-lg p-4 border-2 ${
                        satelliteAnalysis.overall_confidence >= 80
                          ? 'bg-green-50 border-green-300'
                          : 'bg-yellow-50 border-yellow-300'
                      }`}>
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className={`font-semibold mb-1 flex items-center gap-2 ${
                              satelliteAnalysis.overall_confidence >= 80
                                ? 'text-green-900'
                                : 'text-yellow-900'
                            }`}>
                              <Sparkles className="w-5 h-5" />
                              AI Analysis Results for {satelliteAddress.address}
                            </h3>
                            <p className={`text-sm ${
                              satelliteAnalysis.overall_confidence >= 80
                                ? 'text-green-700'
                                : 'text-yellow-700'
                            }`}>
                              <MapPin className="w-4 h-4 inline mr-1" />
                              {satelliteAddress.address}
                            </p>
                          </div>
                          <div className="text-right">
                            <Badge className={`text-lg px-3 py-1 ${
                              satelliteAnalysis.overall_confidence >= 80
                                ? 'bg-green-600 text-white'
                                : 'bg-yellow-600 text-white'
                            }`}>
                              {satelliteAnalysis.overall_confidence}% Confidence
                            </Badge>
                            {satelliteAnalysis.overall_confidence < 80 && (
                              <p className="text-xs text-yellow-700 mt-1">Below 80% threshold</p>
                            )}
                          </div>
                        </div>

                        {/* Measurements with confidence scores */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                          <div className="bg-white rounded p-3 shadow-sm">
                            <span className="text-gray-600 block mb-1">Base Area:</span>
                            <span className="font-semibold text-xl text-gray-800">{satelliteAnalysis.roof_area_sq}</span>
                            <span className="text-xs text-gray-500 ml-1">SQ</span>
                            <p className="text-xs text-gray-500 mt-1">Map Area</p>
                          </div>
                          
                          {/* Final Order Quantity (if available) */}
                          {satelliteAnalysis.final_order_quantity_sq && (
                            <div className="bg-green-50 rounded p-3 shadow-sm border border-green-100">
                              <span className="text-green-800 block mb-1 font-bold">Final Order Qty:</span>
                              <span className="font-bold text-2xl text-green-700">{satelliteAnalysis.final_order_quantity_sq}</span>
                              <span className="text-xs text-green-600 ml-1">SQ</span>
                              <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                                <span>+{satelliteAnalysis.waste_percentage || 10}% Waste</span>
                              </p>
                            </div>
                          )}

                          <div className="bg-white rounded p-3 shadow-sm">
                            <span className="text-gray-600 block mb-1">Pitch:</span>
                            <span className="font-semibold text-xl">{satelliteAnalysis.pitch || 'Unknown'}</span>
                          </div>

                          {/* Ridge with confidence */}
                          <div className={`bg-white rounded p-3 shadow-sm flex items-center gap-2 ${
                            (satelliteAnalysis.ridge_confidence || 100) < 80 ? 'border-2 border-yellow-300' : ''
                          }`}>
                            <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                            <div>
                              <span className="text-gray-600 block text-xs">Ridge:</span>
                              <span className="font-semibold">{satelliteAnalysis.ridge_lf} LF</span>
                              <p className="text-xs text-gray-500">{satelliteAnalysis.ridge_confidence || 100}% conf.</p>
                            </div>
                          </div>

                          {/* Hip with confidence */}
                          <div className={`bg-white rounded p-3 shadow-sm flex items-center gap-2 ${
                            (satelliteAnalysis.hip_confidence || 100) < 80 ? 'border-2 border-yellow-300' : ''
                          }`}>
                            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                            <div>
                              <span className="text-gray-600 block text-xs">Hip:</span>
                              <span className="font-semibold">{satelliteAnalysis.hip_lf} LF</span>
                              <p className="text-xs text-gray-500">{satelliteAnalysis.hip_confidence || 100}% conf.</p>
                            </div>
                          </div>

                          {/* Valley with confidence */}
                          <div className={`bg-white rounded p-3 shadow-sm flex items-center gap-2 ${
                            (satelliteAnalysis.valley_confidence || 100) < 80 ? 'border-2 border-yellow-300' : ''
                          }`}>
                            <div className="w-3 h-3 rounded-full bg-green-500"></div>
                            <div>
                              <span className="text-gray-600 block text-xs">Valley:</span>
                              <span className="font-semibold">{satelliteAnalysis.valley_lf} LF</span>
                              <p className="text-xs text-gray-500">{satelliteAnalysis.valley_confidence || 100}% conf.</p>
                            </div>
                          </div>

                          {/* Rake with confidence */}
                          <div className={`bg-white rounded p-3 shadow-sm flex items-center gap-2 ${
                            (satelliteAnalysis.rake_confidence || 100) < 80 ? 'border-2 border-yellow-300' : ''
                          }`}>
                            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                            <div>
                              <span className="text-gray-600 block text-xs">Rake:</span>
                              <span className="font-semibold">{satelliteAnalysis.rake_lf} LF</span>
                              <p className="text-xs text-gray-500">{satelliteAnalysis.rake_confidence || 100}% conf.</p>
                            </div>
                          </div>

                          {/* Eave with confidence */}
                          <div className={`bg-white rounded p-3 shadow-sm flex items-center gap-2 ${
                            (satelliteAnalysis.eave_confidence || 100) < 80 ? 'border-2 border-yellow-300' : ''
                          }`}>
                            <div className="w-3 h-3 rounded-full bg-red-500"></div>
                            <div>
                              <span className="text-gray-600 block text-xs">Eave:</span>
                              <span className="font-semibold">{satelliteAnalysis.eave_lf} LF</span>
                              <p className="text-xs text-gray-500">{satelliteAnalysis.eave_confidence || 100}% conf.</p>
                            </div>
                          </div>

                          {/* Step Flashing with confidence */}
                          <div className={`bg-white rounded p-3 shadow-sm flex items-center gap-2 ${
                            (satelliteAnalysis.step_flashing_confidence || 100) < 80 ? 'border-2 border-yellow-300' : ''
                          }`}>
                            <div className="w-3 h-3 rounded-full bg-pink-500"></div>
                            <div>
                              <span className="text-gray-600 block text-xs">Step Flash:</span>
                              <span className="font-semibold">{satelliteAnalysis.step_flashing_lf} LF</span>
                              <p className="text-xs text-gray-500">{satelliteAnalysis.step_flashing_confidence || 100}% conf.</p>
                            </div>
                          </div>
                        </div>

                        {/* AI Analysis Notes */}
                        {satelliteAnalysis.analysis_notes && (
                          <div className="mt-3 bg-white rounded p-3">
                            <p className="text-sm font-semibold text-gray-700 mb-1">AI Notes:</p>
                            <p className="text-xs text-gray-600">{satelliteAnalysis.analysis_notes}</p>
                          </div>
                        )}

                        {/* Specific Obstruction Warning from Backend */}
                        {satelliteAnalysis.warning_message && (
                          <div className="mt-3 bg-orange-100 rounded p-3 border border-orange-300">
                            <p className="text-sm font-semibold text-orange-900 mb-1 flex items-center gap-2">
                              <Wind className="w-4 h-4" />
                              Visibility Warning
                            </p>
                            <p className="text-sm text-orange-800">
                              {satelliteAnalysis.warning_message}
                            </p>
                          </div>
                        )}

                        {/* General Low Confidence Warning (only if no specific warning already shown) */}
                        {satelliteAnalysis.overall_confidence < 80 && !satelliteAnalysis.warning_message && (
                          <div className="mt-3 bg-yellow-100 rounded p-3 border border-yellow-300">
                            <p className="text-sm font-semibold text-yellow-900 mb-1 flex items-center gap-2">
                              <Sparkles className="w-4 h-4" />
                              AI Confidence Below 80% - Aerial Review Recommended
                            </p>
                            <p className="text-xs text-yellow-800 mb-2">
                              For the most accurate linear measurements, consider an aerial report or manual verification.
                            </p>
                          </div>
                        )}
                      </div>

                      {/* NEW: Gutters & Downspouts for AI Mode */}
                      <Card>
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-base">Gutters & Downspouts</CardTitle>
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={includeGuttersAI}
                                onChange={(e) => {
                                  setIncludeGuttersAI(e.target.checked);
                                  if (currentEstimate) {
                                    setTimeout(() => handleRegenerateWithGutters(), 100);
                                  }
                                }}
                                className="w-4 h-4"
                              />
                              <span className="text-sm font-medium">Include in estimate</span>
                            </label>
                          </div>
                        </CardHeader>
                        {includeGuttersAI && (
                          <CardContent className="space-y-4">
                            <div>
                              <Label>Gutter Length (LF)</Label>
                              <Input
                                type="number"
                                value={aiGutterLF}
                                onChange={(e) => setAiGutterLF(Number(e.target.value))}
                                onBlur={() => {
                                  if (currentEstimate) {
                                    handleRegenerateWithGutters();
                                  }
                                }}
                                placeholder="Linear feet of gutters"
                              />
                              <p className="text-xs text-gray-500 mt-1">
                                💡 Auto-filled based on eave measurements ({analyzedStructures.reduce((sum, s) => sum + (s.analysis.eave_lf || 0), 0).toFixed(2) || 0} LF)
                              </p>
                            </div>
                            
                            <div>
                              <Label>Number of Downspouts</Label>
                              <Input
                                type="number"
                                value={aiDownspoutCount}
                                onChange={(e) => setAiDownspoutCount(Number(e.target.value))}
                                onBlur={() => {
                                  if (currentEstimate) {
                                    handleRegenerateWithGutters();
                                  }
                                }}
                                placeholder="Number of downspouts"
                              />
                              <p className="text-xs text-gray-500 mt-1">
                                💡 Estimated: 1 downspout per 35 LF of gutter
                              </p>
                            </div>
                          </CardContent>
                        )}
                      </Card>

                      {/* NEW: Action buttons with multi-structure support */}
                      <div className="flex flex-col gap-2">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSatelliteAddress(null); // Clear the current address input for next structure
                              setSatelliteAnalysis(null); // Clear the current analysis view
                              setAnalyzedStructures([]); // Clear all structures
                              setLineItems([]);
                              setCurrentEstimate(null);
                              setIncludeGuttersAI(false); // Reset gutter state
                              setEstimateHistory([]); // Clear history when starting over
                              setShowStructureSelector(false); // Ensure selector is hidden
                              setManualAddOnMode(false); // Reset manual add-on mode
                              setManualMeasurements([]); // Clear manual add-on measurements
                              setMessages(prev => [...prev, {
                                role: 'assistant',
                                content: `Ready for new satellite analysis! Enter another address.`,
                                timestamp: new Date().toISOString()
                              }]);
                            }}
                          >
                            <ArrowLeft className="w-4 h-4 mr-1" />
                            Start Over
                          </Button>
                          
                          {satelliteAnalysis && !isSatelliteAnalyzing && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setManualAddOnMode(true);
                                setMessages(prev => [...prev, {
                                  role: 'assistant',
                                  content: `🎨 **Manual Add-On Mode Activated**\n\nDraw on the satellite map to measure structures the AI missed (porches, patios, etc.). Your measurements will be added to the AI results.`,
                                  timestamp: new Date().toISOString()
                                }]);
                              }}
                              className="flex-1 bg-green-50 border-green-300 text-green-700 hover:bg-green-100"
                            >
                              <Edit className="w-4 h-4 mr-1" />
                              Add Manual Measurement
                            </Button>
                          )}

                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setShowStructureSelector(true);
                              setIsAddingStructure(true); // Set this true to indicate adding another structure
                              setMessages(prev => [...prev, {
                                role: 'assistant',
                                content: `📍 **Click on the satellite map to select the structure you want to measure** (garage, shed, etc.)\n\nPlace the red marker on the structure and click "Measure This Structure".`,
                                timestamp: new Date().toISOString()
                              }]);
                            }}
                            className="flex-1 bg-purple-50 border-purple-300 text-purple-700 hover:bg-purple-100"
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            Add Another Structure (AI)
                          </Button>
                        </div>

                        {!currentEstimate && (
                          <>
                            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4 border-2 border-purple-200">
                              <Label className="text-sm font-semibold mb-2 block">Select Roof Type:</Label>
                              <div className="grid grid-cols-3 gap-2">
                                <Button
                                  variant={roofTypeSelection === 'shingles' ? 'default' : 'outline'}
                                  size="sm"
                                  onClick={() => setRoofTypeSelection('shingles')}
                                  className={roofTypeSelection === 'shingles' ? 'bg-blue-600' : ''}
                                >
                                  🏠 Shingles
                                </Button>
                                <Button
                                  variant={roofTypeSelection === 'metal' ? 'default' : 'outline'}
                                  size="sm"
                                  onClick={() => setRoofTypeSelection('metal')}
                                  className={roofTypeSelection === 'metal' ? 'bg-orange-600' : ''}
                                >
                                  🔩 Metal
                                </Button>
                                <Button
                                  variant={roofTypeSelection === 'flat' ? 'default' : 'outline'}
                                  size="sm"
                                  onClick={() => setRoofTypeSelection('flat')}
                                  className={roofTypeSelection === 'flat' ? 'bg-gray-600' : ''}
                                >
                                  🏢 Flat
                                </Button>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              onClick={handleGenerateCombinedEstimate}
                              className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                            >
                              <Sparkles className="w-4 h-4 mr-1" />
                              {analyzedStructures.length > 1 || manualMeasurements.length > 0 ? 'Generate Combined Estimate' : 'Generate Estimate'}
                            </Button>
                          </>
                        )}

                        {currentEstimate && (
                          <Button
                            size="sm"
                            onClick={handleRegenerateWithGutters}
                            variant="outline"
                            className="w-full border-blue-500 text-blue-700 hover:bg-blue-50"
                          >
                            🔄 Regenerate Estimate
                          </Button>
                        )}
                      </div>

                      {currentEstimate && lineItems.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-orange-200">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setUseManualDrawing(true);
                                setSatelliteAnalysis(null);
                                setAnalyzedStructures([]);
                                setLineItems([]);
                                setCurrentEstimate(null);
                                setManualMeasurements([]);
                                setManualAddOnMode(false);
                              }}
                              className="w-full border-orange-400 text-orange-700 hover:bg-orange-100"
                            >
                              <Pencil className="w-4 h-4 mr-2" />
                              Switch to Manual Drawing for Better Accuracy
                            </Button>
                          </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* NEW: Structure Selector for Additional Structures */}
              {showStructureSelector && satelliteAddress && (
                <Card className="bg-white shadow-lg">
                  <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      Select Additional Structure at {satelliteAddress.address}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <StructureSelector
                      latitude={satelliteAddress.coordinates.lat}
                      longitude={satelliteAddress.coordinates.lng}
                      address={satelliteAddress.address}
                      googleMapsLoaded={googleMapsLoaded}
                      existingStructuresCount={analyzedStructures.length}
                      onStructureSelect={async (coordsArray) => {
                        if (!Array.isArray(coordsArray) || coordsArray.length === 0) {
                          alert('No structures selected');
                          return;
                        }

                        setShowStructureSelector(false);
                        setIsSatelliteAnalyzing(true);

                        setMessages(prev => [...prev, {
                          role: 'assistant',
                          content: `🤖 **AI is analyzing ${coordsArray.length} structure${coordsArray.length > 1 ? 's' : ''}...**\n\n⏱️ This takes 30-60 seconds per structure...`,
                          timestamp: new Date().toISOString()
                        }]);

                        try {
                          const newStructures = [];
                          
                          for (let i = 0; i < coordsArray.length; i++) {
                            const coords = coordsArray[i];
                            
                            console.log(`Analyzing structure ${i + 1}/${coordsArray.length}:`, coords);
                            
                            const response = await base44.functions.invoke('aiRoofMeasurement', {
                              latitude: coords.lat,
                              longitude: coords.lng,
                              address: satelliteAddress.address
                            });

                            if (!response.data.success) {
                              throw new Error(response.data.error || 'Failed to analyze structure');
                            }

                            const analysis = {
                              roof_area_sq: response.data.roof_area_sq,
                              roof_area_sqft: response.data.roof_area_sqft,
                              ridge_lf: response.data.ridge_lf,
                              hip_lf: response.data.hip_lf,
                              valley_lf: response.data.valley_lf,
                              rake_lf: response.data.rake_lf,
                              eave_lf: response.data.eave_lf,
                              step_flashing_lf: response.data.step_flashing_lf,
                              pitch: response.data.pitch,
                              is_flat_roof: response.data.is_flat_roof || false,
                              satellite_image_url: response.data.satellite_image_url,
                              overall_confidence: response.data.overall_confidence || 100,
                              ridge_confidence: response.data.ridge_confidence || 100,
                              hip_confidence: response.data.hip_confidence || 100,
                              valley_confidence: response.data.valley_confidence || 100,
                              rake_confidence: response.data.rake_confidence || 100,
                              eave_confidence: response.data.eave_confidence || 100,
                              step_flashing_confidence: response.data.step_flashing_confidence || 100,
                              analysis_notes: response.data.analysis_notes || null,
                            };

                            const structureData = {
                              id: Date.now() + i,
                              name: `Structure ${analyzedStructures.length + newStructures.length + 1}`,
                              address: satelliteAddress.address,
                              analysis: analysis
                            };

                            newStructures.push(structureData);

                            setMessages(prev => [...prev, {
                              role: 'assistant',
                              content: `✅ **Analyzed ${structureData.name}!** (${i + 1}/${coordsArray.length})\n\n📊 ${analysis.roof_area_sq.toFixed(2)} SQ • Pitch: ${analysis.pitch}`,
                              timestamp: new Date().toISOString()
                            }]);
                          }

                          // Add all new structures at once
                          setAnalyzedStructures(prev => [...prev, ...newStructures]);

                          setMessages(prev => [...prev, {
                            role: 'assistant',
                            content: `🎉 **All ${coordsArray.length} structures analyzed!**\n\n💡 Click "Generate Combined Estimate" to create estimate with all measurements.`,
                            timestamp: new Date().toISOString()
                          }]);

                        } catch (error) {
                          console.error('Structure analysis error:', error);
                          setMessages(prev => [...prev, {
                            role: 'assistant',
                            content: `❌ **Error analyzing structures:** ${error.message}`,
                            timestamp: new Date().toISOString()
                          }]);
                        }

                        setIsSatelliteAnalyzing(false);
                      }}
                      onCancel={() => {
                        setShowStructureSelector(false);
                        setIsAddingStructure(false); // Reset this flag if cancelled
                        setMessages(prev => [...prev, {
                          role: 'assistant',
                          content: `Cancelled adding structure.`,
                          timestamp: new Date().toISOString()
                        }]);
                      }}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Manual Drawing Mode - Enhanced for Add-On */}
              {(useManualDrawing || manualAddOnMode) && satelliteAddress && googleMapsLoaded && (
                <Card className="bg-white shadow-lg">
                  <CardHeader className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                    <CardTitle className="flex items-center gap-2">
                      <Edit className="w-5 h-5" />
                      {manualAddOnMode ? 'Manual Add-On: Draw Additional Structures' : 'Manual Drawing Mode'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    {manualAddOnMode && satelliteAnalysis && (
                      <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm text-blue-900 font-medium mb-2">
                          ℹ️ AI already measured {analyzedStructures.reduce((sum, s) => sum + s.analysis.roof_area_sq, 0).toFixed(2)} SQ (across {analyzedStructures.length} structures)
                        </p>
                        <p className="text-xs text-blue-700">
                          Draw polygons for structures the AI missed (e.g., small detached sheds, porch roofs, patio covers). Your measurements will be combined automatically.
                        </p>
                      </div>
                    )}

                    <InteractiveRoofMap
                      latitude={satelliteAddress.coordinates.lat}
                      longitude={satelliteAddress.coordinates.lng}
                      address={satelliteAddress.address}
                      onMeasurementsComplete={(measurements) => {
                        if (manualAddOnMode) {
                          // Add to manual measurements array
                          setManualMeasurements(prev => [...prev, {
                            id: Date.now(),
                            name: `Manual ${prev.length + 1}`,
                            ...measurements
                          }]);

                          setMessages(prev => [...prev, {
                            role: 'assistant',
                            content: `✅ **Manual measurement added!**\n\n📊 +${measurements.roof_area_sq.toFixed(2)} SQ added to AI measurements\n\n💡 Draw more structures or click "Done" to see combined estimate.`,
                            timestamp: new Date().toISOString()
                          }]);

                          // Don't close, let them add more
                        } else {
                          // Original manual mode behavior (for the first structure)
                          const analysis = {
                            ...measurements,
                            pitch: measurements.pitch || '7/12',
                            satellite_image_url: null,
                            overall_confidence: 100,
                            analysis_notes: 'Measurements drawn manually by user'
                          };
                          
                          const structureData = {
                            id: Date.now(),
                            name: isAddingStructure ? `Structure ${analyzedStructures.length + 1} (Manual)` : "Main Structure (Manual)",
                            address: satelliteAddress.address,
                            analysis: analysis
                          };

                          if (isAddingStructure) {
                            setAnalyzedStructures(prev => [...prev, structureData]);
                            setSatelliteAnalysis(null); // Clear main analysis to indicate it's part of multi-structure
                            setIsAddingStructure(false);
                            setMessages(prev => [...prev, {
                              role: 'assistant',
                              content: `✅ **Added ${structureData.name} (${analysis.roof_area_sq.toFixed(2)} SQ)!**\n\n💡 Add another structure or click "Generate Estimate" to combine all measurements.`,
                              timestamp: new Date().toISOString()
                            }]);
                          } else {
                            setAnalyzedStructures([structureData]);
                            setSatelliteAnalysis(analysis); // For display of first structure
                            setMessages(prev => [...prev, {
                              role: 'assistant',
                              content: `✅ **Added ${structureData.name} (${analysis.roof_area_sq.toFixed(2)} SQ)!**\n\nReview the measurements, add gutters, or add more structures. When ready, click "Generate Estimate".`,
                              timestamp: new Date().toISOString()
                            }]);
                          }
                          setUseManualDrawing(false); // Close map after initial manual drawing
                        }
                      }}
                      onBack={() => {
                        if (manualAddOnMode) {
                          setManualAddOnMode(false);
                          setMessages(prev => [...prev, {
                            role: 'assistant',
                            content: `Cancelled manual add-on.`,
                            timestamp: new Date().toISOString()
                          }]);
                        } else {
                          setUseManualDrawing(false); // Original behavior for initial manual drawing
                          setAnalyzedStructures([]); // Clear structures if backing out of initial manual draw
                          setSatelliteAnalysis(null);
                        }
                      }}
                      googleMapsLoaded={googleMapsLoaded}
                    />

                    {manualAddOnMode && (
                      <div className="mt-4 flex gap-3">
                        <Button
                          variant="outline"
                          onClick={() => {
                            setManualAddOnMode(false);
                            setManualMeasurements([]); // Clear all manual add-on measurements
                            setMessages(prev => [...prev, {
                              role: 'assistant',
                              content: `Manual add-on cancelled.`,
                              timestamp: new Date().toISOString()
                            }]);
                          }}
                          className="flex-1"
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={() => {
                            setManualAddOnMode(false);
                            setMessages(prev => [...prev, {
                              role: 'assistant',
                              content: `✅ **Manual add-on complete!**\n\nCombined measurements ready. Click "Generate Estimate" below.`,
                              timestamp: new Date().toISOString()
                            }]);
                          }}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                        >
                          Done Adding Manual
                        </Button>
                      </div>
                    )}

                    {manualMeasurements.length > 0 && (
                      <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-sm font-semibold text-green-900 mb-2">
                          Manual Measurements Added:
                        </p>
                        {manualMeasurements.map((m, idx) => (
                          <div key={m.id} className="text-xs text-green-700 flex items-center justify-between">
                            <span>• {m.name}: {m.roof_area_sq.toFixed(2)} SQ</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setManualMeasurements(prev => prev.filter(item => item.id !== m.id))}
                              className="h-6 px-2 text-red-600 hover:text-red-700"
                            >
                              ×
                            </Button>
                          </div>
                        ))}
                        <div className="mt-2 pt-2 border-t border-green-300">
                          <p className="text-sm font-bold text-green-900">
                            Total Manual: {manualMeasurements.reduce((sum, m) => sum + m.roof_area_sq, 0).toFixed(2)} SQ
                          </p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* NEW: Chat Interface for AI Adjustments - Shows after estimate is created */}
          {currentEstimate && (
            <Card className="bg-white shadow-lg">
              <CardContent className="p-0">



                {/* Chat History Display */}
                <div className="h-[300px] overflow-y-auto p-6 space-y-4">
                  {messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[80%] rounded-lg p-4 ${
                        msg.role === 'user'
                          ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}>
                        <div className="whitespace-pre-wrap">{msg.content}</div>
                        
                        {/* Show Add buttons for suggestions inline */}
                        {msg.suggestions && msg.suggestions.length > 0 && (
                          <div className="mt-4 space-y-2">
                            {msg.suggestions.map((suggestion, sidx) => (
                              <Button
                                key={sidx}
                                size="sm"
                                variant="outline"
                                onClick={() => handleAddSuggestedItem(suggestion)}
                                className="w-full justify-start text-left bg-white hover:bg-blue-50 border-blue-300"
                              >
                                <Plus className="w-4 h-4 mr-2 flex-shrink-0" />
                                <span className="text-xs">Add {suggestion.item_description}</span>
                              </Button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}

                  {(isProcessing || isAnalyzing) && (
                    <div className="flex justify-start">
                      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 border-2 border-blue-200">
                        <div className="flex flex-col items-center gap-3">
                          <div className="relative inline-block">
                            <div className="absolute inset-0 animate-ping opacity-30">
                              <svg className="w-12 h-12 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 80 L50 20 L90 80 Z" fill="currentColor" className="text-purple-600" />
                              </svg>
                            </div>
                            <svg className="w-12 h-12 mx-auto animate-spin" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M10 80 L50 20 L90 80 Z" fill="currentColor" className="text-purple-600" />
                            </svg>
                          </div>
                          <p className="text-sm font-medium text-gray-900">AI is analyzing...</p>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Message Input */}
                <div className="p-4 bg-white">
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    {selectedMode === 'document' && (
                      <>
                        <input
                          ref={fileInputRef}
                          type="file"
                          onChange={handleFileSelect}
                          className="hidden"
                          accept=".pdf,.PDF,.png,.PNG,.jpg,.JPG,.jpeg,.JPEG"
                          multiple
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => fileInputRef.current?.click()}
                          disabled={isProcessing}
                        >
                          <Paperclip className="w-5 h-5" />
                        </Button>
                      </>
                    )}
                    <Input
                      placeholder="Ask AI to adjust estimate (e.g., 'add 10% waste', 'apply steep roof')..."
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      disabled={isProcessing}
                      className="flex-1"
                    />
                    <Button
                      type="submit"
                      disabled={isProcessing}
                      className="bg-gradient-to-r from-blue-600 to-purple-600"
                    >
                      <Send className="w-5 h-5" />
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          )}

          {currentEstimate && (
            <>
              <Card className="bg-white shadow-lg">
                <CardHeader className={`${getHeaderColorClass(currentFormat)} text-white`}>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <UserCircle className="w-5 h-5" />
                        Customer Information
                      </CardTitle>
                    </div>

                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                      <span className="text-sm text-white/90">Template:</span>
                      <Select value={selectedFormatId || ''} onValueChange={handleFormatChange}>
                        <SelectTrigger className="w-full sm:w-64 bg-white/20 text-white border-white/30">
                          <SelectValue placeholder="Auto (based on pricing)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>None (Default)</SelectItem>
                          {formats.map(format => (
                            <SelectItem key={format.id} value={format.id}>
                              {format.format_name} {format.insurance_company ? `(${format.insurance_company})` : ''}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <span className="text-sm text-white/90">Pricing:</span>
                      <Select value={pricingSource} onValueChange={handlePricingSourceChange}>
                        <SelectTrigger className="w-full sm:w-40 bg-white/20 text-white border-white/30">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="xactimate">Xactimate (Old)</SelectItem>
                          <SelectItem value="xactimate_new">Xactimate New 🆕</SelectItem>
                          <SelectItem value="symbility">Symbility</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label>Select Existing Contact (Optional)</Label>
                      <Select value={selectedContactId} onValueChange={handleSelectContact}>
                        <SelectTrigger>
                          <SelectValue placeholder="Search customers & leads..." />
                        </SelectTrigger>
                        <SelectContent>
                          {allContacts.map(contact => (
                            <SelectItem key={contact.id} value={contact.id}>
                              {contact.displayName} ({contact.type})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label>Link CrewCam Job (Optional)</Label>
                      <Select value={linkedInspectionJobId || ''} onValueChange={(value) => {
                        setLinkedInspectionJobId(value || null);
                        if (value) {
                          const fetchPhotos = async () => {
                            const photos = await base44.entities.JobMedia.filter({ 
                              related_entity_id: value, 
                              related_entity_type: 'InspectionJob',
                              file_type: 'photo'
                            });
                            setMessages(prev => [...prev, {
                              role: 'assistant',
                              content: `🔗 **Linked to inspection job!**\n\n📸 ${photos.length} photos will be included in PDF exports.`,
                              timestamp: new Date().toISOString()
                            }]);
                          };
                          fetchPhotos();
                        }
                      }}>
                        <SelectTrigger>
                          <SelectValue placeholder="None - No inspection photos" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>None - No inspection photos</SelectItem>
                          {allInspectionJobs.map(job => (
                            <SelectItem key={job.id} value={job.id}>
                              {job.property_address || job.client_name || `Job ${job.id.slice(0, 8)}`}
                              {job.status && ` (${job.status})`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {linkedInspectionJobId && linkedJobMedia.length > 0 && (
                        <p className="text-xs text-green-600 mt-1">
                          ✓ {linkedJobMedia.length} inspection photos linked
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Customer Name</Label>
                      <Input
                        value={customerInfo.customer_name}
                        onChange={(e) => setCustomerInfo({...customerInfo, customer_name: e.target.value})}
                        placeholder="John Smith"
                      />
                    </div>
                    <div>
                      <Label>Email</Label>
                      <Input
                        type="email"
                        value={customerInfo.customer_email}
                        onChange={(e) => setCustomerInfo({...customerInfo, customer_email: e.target.value})}
                        placeholder="john@example.com"
                      />
                    </div>
                    <div>
                      <Label>Phone</Label>
                      <Input
                        value={customerInfo.customer_phone}
                        onChange={(e) => setCustomerInfo({...customerInfo, customer_phone: e.target.value})}
                        placeholder="(555) 123-4567"
                      />
                    </div>
                    <div>
                      <Label>Property Address</Label>
                      <Input
                        value={customerInfo.property_address}
                        onChange={(e) => setCustomerInfo({...customerInfo, property_address: e.target.value})}
                        placeholder="123 Main St, City, ST 12345"
                      />
                    </div>
                    <div>
                      <Label>Claim Number</Label>
                      <Input
                        value={customerInfo.claim_number}
                        onChange={(e) => setCustomerInfo({...customerInfo, claim_number: e.target.value})}
                        placeholder="CLM-2024-001"
                      />
                    </div>
                    <div>
                      <Label>Insurance Company</Label>
                      <Input
                        value={customerInfo.insurance_company}
                        onChange={(e) => setCustomerInfo({...customerInfo, insurance_company: e.target.value})}
                        placeholder="State Farm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div>
                      <Label>Adjuster Name</Label>
                      <Input
                        value={customerInfo.adjuster_name}
                        onChange={(e) => setCustomerInfo({...customerInfo, adjuster_name: e.target.value})}
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <Label>Adjuster Phone</Label>
                      <Input
                        value={customerInfo.adjuster_phone}
                        onChange={(e) => setCustomerInfo({...customerInfo, adjuster_phone: e.target.value})}
                        placeholder="(555) 123-4567"
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <Label>Notes</Label>
                    <Textarea
                      value={customerInfo.notes}
                      onChange={(e) => setCustomerInfo({...customerInfo, notes: e.target.value})}
                      placeholder="Additional project notes..."
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white shadow-lg">
                <CardHeader className={`${getHeaderColorClass(currentFormat)} text-white`}>
                  <div className="flex justify-between items-center">
                    <CardTitle>Current Estimate</CardTitle>
                    <div className="flex gap-2">
                      <Badge className="bg-white/30 text-white text-xs">
                        {roofTypeSelection === 'shingles' ? '🏠 Shingles' : roofTypeSelection === 'metal' ? '🔩 Metal' : '🏢 Flat Roof'}
                      </Badge>
                      <Badge className="bg-white/20 text-white">
                        {lineItems.length} items
                      </Badge>
                      <Badge className="bg-white/20 text-white">
                        ${lineItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0).toLocaleString()}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <LineItemEditor
                    items={lineItems}
                    onChange={setLineItems}
                    format={currentFormat}
                  />

                  <div className="p-4 bg-gray-50 border-t flex items-center justify-between gap-3 sticky bottom-[80px] md:bottom-0 z-50 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
                    {/* LEFT: Tools & Exports Dropdowns */}
                    <div className="flex gap-2">
                      {/* TOOLS MENU */}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" className="gap-2 bg-white">
                            <Hammer className="w-4 h-4" />
                            <span className="hidden sm:inline">Tools</span>
                            <ChevronDown className="w-3 h-3 opacity-50" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" side="top" className="w-56">
                          <DropdownMenuLabel>Roof Type</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => {
                            setRoofTypeSelection('shingles');
                            if (currentEstimate) setTimeout(() => handleRegenerateWithGutters(), 100);
                          }}>
                            {roofTypeSelection === 'shingles' && <span className="mr-2">✓</span>}
                            🏠 Shingles
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => {
                            setRoofTypeSelection('metal');
                            if (currentEstimate) setTimeout(() => handleRegenerateWithGutters(), 100);
                          }}>
                            {roofTypeSelection === 'metal' && <span className="mr-2">✓</span>}
                            🔩 Metal Roof
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => {
                            setRoofTypeSelection('flat');
                            if (currentEstimate) setTimeout(() => handleRegenerateWithGutters(), 100);
                          }}>
                            {roofTypeSelection === 'flat' && <span className="mr-2">✓</span>}
                            🏢 Flat Roof
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuLabel>Smart Tools</DropdownMenuLabel>
                          <DropdownMenuItem onClick={handleReviewEstimate} disabled={isAnalyzing}>
                            <Sparkles className="w-4 h-4 mr-2 text-purple-600" />
                            AI Review
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setShowVentilationCalc(true)}>
                            <Wind className="w-4 h-4 mr-2 text-blue-600" />
                            Ventilation Calculator
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleGenerateMaterialList} disabled={isGeneratingMaterials}>
                            <ClipboardList className="w-4 h-4 mr-2 text-green-600" />
                            Material List
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setShowMergeDialog(true)}>
                            <Upload className="w-4 h-4 mr-2 text-blue-600" />
                            Merge Documents
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuLabel>Quick Adjustments</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => processWithAI('add 10% waste')}>
                            <Package className="w-4 h-4 mr-2 text-orange-600" />
                            Add 10% Waste
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => processWithAI('apply steep roof')}>
                            <TrendingUp className="w-4 h-4 mr-2 text-red-600" />
                            Apply Steep Charge
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => processWithAI('apply high roof')}>
                            <ArrowUp className="w-4 h-4 mr-2 text-blue-600" />
                            Apply High Charge
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => processWithAI('add 10% overhead and 10% profit')}>
                            <DollarSign className="w-4 h-4 mr-2 text-purple-600" />
                            Add O&P (21%)
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuLabel>Field Operations</DropdownMenuLabel>
                          <DropdownMenuItem onClick={async () => {
                            try {
                              if (!user || !myCompany) {
                                alert('User or company information not available.');
                                return;
                              }
                              const newJob = await base44.entities.InspectionJob.create({
                                property_address: customerInfo.property_address || satelliteAddress?.address,
                                client_name: customerInfo.customer_name,
                                client_email: customerInfo.customer_email,
                                client_phone: customerInfo.customer_phone,
                                insurance_claim_number: customerInfo.claim_number,
                                status: 'in_progress',
                                assigned_to_email: user.email,
                                lead_source: 'ai_estimator',
                                company_id: myCompany?.id,
                                notes: `Inspection for estimate: ${currentEstimate?.title || 'AI Generated Estimate'}`,
                                inspection_type: 'Property Damage Assessment'
                              });
                              navigate(createPageUrl(`InspectionCapture?id=${newJob.id}`));
                            } catch (error) {
                              alert('Failed to create inspection: ' + error.message);
                            }
                          }}>
                            <Satellite className="w-4 h-4 mr-2" />
                            Start On-Site Inspection
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>

                      {/* EXPORTS MENU */}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" className="gap-2 bg-white">
                            <Share2 className="w-4 h-4" />
                            <span className="hidden sm:inline">Export</span>
                            <ChevronDown className="w-3 h-3 opacity-50" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" side="top" className="w-56">
                          <DropdownMenuLabel>Documents</DropdownMenuLabel>
                          <DropdownMenuItem onClick={async () => {
                            // PDF Generation Logic (reused)
                            try {
                              let inspectionPhotos = [];
                              if (linkedInspectionJobId && linkedJobMedia.length > 0) {
                                inspectionPhotos = linkedJobMedia.map(media => ({
                                  url: media.file_url,
                                  caption: media.caption || 'Inspection Photo',
                                  section: media.section
                                }));
                              }
                              
                              // Get impersonated company ID if set
                              const impersonatedId = typeof window !== 'undefined' ? sessionStorage.getItem('impersonating_company_id') : null;
                              
                              const response = await base44.functions.invoke('generateEstimatePDF', {
                                estimate: {
                                  line_items: lineItems,
                                  total_rcv: lineItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0),
                                  total_acv: lineItems.reduce((acc, i) => acc + (Number(i.acv) || 0), 0)
                                },
                                customerInfo: customerInfo,
                                format: currentFormat,
                                satelliteImageUrl: satelliteAnalysis?.satellite_image_url || null,
                                inspectionPhotos: inspectionPhotos,
                                impersonated_company_id: impersonatedId || myCompany?.id
                              });
                              const blob = new Blob([response.data], { type: 'application/pdf' });
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `estimate-${customerInfo.customer_name || 'draft'}.pdf`;
                              document.body.appendChild(a);
                              a.click();
                              window.URL.revokeObjectURL(url);
                              a.remove();
                              setMessages(prev => [...prev, {
                                role: 'assistant', content: `✅ PDF downloaded!`, timestamp: new Date().toISOString()
                              }]);
                            } catch (error) { alert('Failed: ' + error.message); }
                          }}>
                            <Download className="w-4 h-4 mr-2" />
                            Download PDF Estimate
                          </DropdownMenuItem>
                          
                          <DropdownMenuItem onClick={async () => {
                            if (!linkedInspectionJobId) {
                              alert('Link an inspection job first.');
                              return;
                            }
                            try {
                              const response = await base44.functions.invoke('generateAdjusterReport', {
                                inspectionJobId: linkedInspectionJobId,
                                estimateId: null
                              });
                              const blob = new Blob([response.data], { type: 'application/pdf' });
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `adjuster-report.pdf`;
                              document.body.appendChild(a);
                              a.click();
                              window.URL.revokeObjectURL(url);
                              a.remove();
                            } catch (error) { alert('Failed: ' + error.message); }
                          }}>
                            <FileText className="w-4 h-4 mr-2" />
                            Adjuster Report
                          </DropdownMenuItem>

                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={handleExportToXactimate} disabled={isExporting}>
                            {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                            Export XML (Xactimate)
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    {/* RIGHT: Primary Actions */}
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={async () => {
                          if (!customerInfo.customer_email) {
                            alert('Enter customer email first');
                            return;
                          }
                          if (!window.confirm(`Send to ${customerInfo.customer_email}?`)) return;
                          try {
                            const totalRcv = lineItems.reduce((acc, i) => acc + (Number(i.rcv) || 0), 0);
                            const totalAcv = lineItems.reduce((acc, i) => acc + (Number(i.acv) || 0), 0);
                            await base44.functions.invoke('sendEstimateEmail', {
                              to: customerInfo.customer_email,
                              customerName: customerInfo.customer_name,
                              estimateData: {
                                estimate_number: 'DRAFT',
                                estimate_title: currentEstimate?.title || 'Estimate',
                                line_items: lineItems,
                                total_rcv: totalRcv,
                                total_acv: totalAcv,
                                property_address: customerInfo.property_address,
                                notes: customerInfo.notes
                              },
                              format: currentFormat
                            });
                            alert(`✅ Sent!`);
                          } catch (error) { alert('Failed: ' + error.message); }
                        }}
                        disabled={!customerInfo.customer_email}
                        className="hidden sm:flex"
                      >
                        <Mail className="w-4 h-4 mr-2" />
                        Email
                      </Button>
                      
                      <Button
                        onClick={handleSaveEstimate}
                        className="bg-green-600 hover:bg-green-700 text-white shadow-md"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}