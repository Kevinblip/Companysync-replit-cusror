import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Camera, Users, FileText, Settings, Video, Loader2, Eye, Send, Trash2, MoreVertical, UserPlus } from 'lucide-react';
import AssignmentDialog from '../components/inspections/AssignmentDialog';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';

const StatCard = ({ title, value, icon: Icon, linkTo, linkText }) => (
  <Card className="hover:shadow-lg transition-shadow">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      {linkTo ? (
        <Button asChild variant="link" className="p-0 h-auto text-2xl font-bold">
            <Link to={linkTo}>{value}</Link>
        </Button>
      ) : (
        <div className="text-2xl font-bold">{value}</div>
      )}
      {linkText && <p className="text-xs text-muted-foreground">{linkText}</p>}
    </CardContent>
  </Card>
);

const ActionCard = ({ title, description, icon: Icon, linkTo }) => {
    const navigate = useNavigate();
    return (
        <Card onClick={() => navigate(linkTo)} className="cursor-pointer hover:bg-gray-50 transition-colors flex flex-col items-center justify-center text-center p-6">
            <Icon className="w-8 h-8 text-blue-600 mb-2" />
            <h3 className="font-semibold">{title}</h3>
            <p className="text-sm text-gray-500">{description}</p>
        </Card>
    );
};

export default function InspectionsDashboard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);

  const [user, setUser] = useState(null);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
    enabled: !!user,
  });

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles'],
    queryFn: () => base44.entities.StaffProfile.list(),
    initialData: [],
  });

  const myCompany = React.useMemo(() => {
    if (!user) return null;
    const impersonatedId = sessionStorage.getItem('impersonating_company_id');
    if (impersonatedId) return companies.find(c => c.id === impersonatedId);
    
    // Check ownership
    const owned = companies.find(c => c.created_by === user.email);
    if (owned) return owned;
    
    // Check staff profile
    const profile = staffProfiles.find(s => s.user_email === user.email);
    if (profile) return companies.find(c => c.id === profile.company_id);
    
    return companies[0];
  }, [user, companies, staffProfiles]);

  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['inspectionJobs', myCompany?.id],
    queryFn: () => myCompany?.id ? base44.entities.InspectionJob.filter({ company_id: myCompany.id }, '-created_date', 100) : [],
    initialData: [],
    enabled: !!myCompany?.id
  });

  const { data: media = [], isLoading: isLoadingMedia } = useQuery({
    queryKey: ['inspectionMedia', myCompany?.id],
    queryFn: () => myCompany?.id ? base44.entities.JobMedia.filter({ related_entity_type: 'InspectionJob', company_id: myCompany.id }, '-created_date', 5000) : [],
    initialData: [],
    enabled: !!myCompany?.id
  });

  const { data: users = [] } = useQuery({ // Added for assignee info
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const deleteJobMutation = useMutation({
    mutationFn: async (jobId) => {
      // Delete associated media first
      const jobMedia = await base44.entities.JobMedia.filter({ 
        related_entity_id: jobId, 
        related_entity_type: 'InspectionJob' 
      });
      
      for (const media of jobMedia) {
        await base44.entities.JobMedia.delete(media.id);
      }
      
      // Then delete the job
      await base44.entities.InspectionJob.delete(jobId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inspectionJobs'] });
      queryClient.invalidateQueries({ queryKey: ['inspectionMedia'] });
    },
  });

  const completedJobs = jobs.filter(j => j.status === 'completed').length;
  const totalPhotos = media.filter(m => m.file_type === 'photo').length;
  const totalVideos = media.filter(m => m.file_type === 'video').length;

  const filteredJobs = jobs.slice(0, 5); // Renamed recentJobs to filteredJobs for consistency with outline

  const getAssigneeInfo = (job) => {
    if (!job.assigned_to_email) return null;
    const staff = staffProfiles.find(s => s.user_email === job.assigned_to_email);
    const user = users.find(u => u.email === job.assigned_to_email);
    return {
        email: job.assigned_to_email,
        name: staff?.full_name || user?.full_name || job.assigned_to_email,
        avatar: staff?.avatar_url || user?.avatar_url
    };
  };

  const getJobPhotoCount = (jobId) => {
    return media.filter(m => m.related_entity_id === jobId && m.file_type === 'photo').length;
  };

  const handleDeleteJob = (jobId) => { // Renamed from handleDelete
    if (window.confirm('Are you sure you want to delete this inspection job?')) {
      deleteJobMutation.mutate(jobId);
    }
  };

  return (
    <div className="p-2 md:p-6 bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-800">CrewCam Dashboard</h1>
            <Button asChild>
                <Link to={createPageUrl('InspectionCapture')}>
                    <Plus className="mr-2 h-4 w-4" /> Start New Job
                </Link>
            </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <ActionCard title="New CrewCam Job" description="Create and assign a new job" icon={Plus} linkTo={createPageUrl('NewInspection')} />
            <ActionCard title="Manage Team" description="Manage your certified inspectors" icon={Users} linkTo={createPageUrl('Inspectors')} />
            <ActionCard title="View AI Reports" description="See AI-analyzed damage reports" icon={FileText} linkTo={createPageUrl('DroneInspections')} />
            <ActionCard title="CrewCam Settings" description="Configure job details" icon={Settings} linkTo={createPageUrl('Settings')} />
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Total Jobs" value={isLoadingJobs ? <Loader2 className="animate-spin" /> : jobs.length} icon={FileText} />
          <StatCard title="Completed" value={isLoadingJobs ? <Loader2 className="animate-spin" /> : completedJobs} icon={FileText} />
          <StatCard title="Total Photos" value={isLoadingMedia ? <Loader2 className="animate-spin" /> : totalPhotos} icon={Camera} />
          <StatCard title="Total Videos" value={isLoadingMedia ? <Loader2 className="animate-spin" /> : totalVideos} icon={Video} />
        </div>

        {/* Recent Jobs List */}
        <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">Recent CrewCam Jobs</h2>
                <Button onClick={() => { setSelectedJob(null); setShowAssignDialog(true); }} className="bg-green-600 hover:bg-green-700 text-white">
                    <Send className="w-4 h-4 mr-2" />
                    Send Assignment
                </Button>
            </div>

            {isLoadingJobs ? (
                <div className="text-center py-8"><Loader2 className="animate-spin inline-block text-gray-600"/></div>
            ) : (
                <div className="space-y-4">
                    {filteredJobs.length === 0 && <p className="text-gray-500 text-center py-8">No inspection jobs found.</p>}
                    {filteredJobs.map(job => {
                        const assignee = getAssigneeInfo(job);
                        const photoCount = getJobPhotoCount(job.id);
                        
                        return (
                            <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                                <div className="flex-1">
                                    <h3 className="font-semibold text-gray-900">
                                        {job.property_address || 'Unassigned Inspection'}
                                    </h3>
                                    {!job.property_address && (
                                        <p className="text-xs text-orange-600 mt-0.5">No address provided</p>
                                    )}
                                    <div className="flex items-center gap-4 mt-1 flex-wrap">
                                        <p className="text-sm text-gray-600">{job.client_name || 'No client specified'}</p>

                                        {photoCount > 0 && (
                                            <div className="flex items-center gap-1.5 bg-blue-50 px-2 py-1 rounded-md">
                                                <Camera className="w-3.5 h-3.5 text-blue-600" />
                                                <span className="text-xs font-semibold text-blue-700">{photoCount} photo{photoCount !== 1 ? 's' : ''}</span>
                                            </div>
                                        )}

                                        {assignee && (
                                            <div className="flex items-center gap-1.5 bg-green-50 px-2 py-1 rounded-md border border-green-200">
                                                {assignee.avatar ? (
                                                    <img 
                                                        src={assignee.avatar} 
                                                        alt={assignee.name}
                                                        className="w-5 h-5 rounded-full border border-white shadow-sm"
                                                    />
                                                ) : (
                                                    <div 
                                                        className="w-5 h-5 rounded-full bg-green-600 flex items-center justify-center text-white text-xs font-bold border border-white shadow-sm"
                                                    >
                                                        {assignee.name[0]}
                                                    </div>
                                                )}
                                                <span className="text-xs font-semibold text-green-900">{assignee.name}</span>
                                            </div>
                                        )}
                                    </div>
                                    <p className="text-xs text-gray-400 mt-1">Created: {format(new Date(job.created_date), 'MM/dd/yyyy')}</p>
                                    {job.ladder_assist_needed && (
                                        <Badge variant="outline" className="bg-yellow-50 border-yellow-300 text-yellow-800 text-xs mt-1">
                                            💵 Ladder Assist ${job.ladder_assist_cost}
                                        </Badge>
                                    )}
                                </div>
                                <div className="flex items-center gap-3">
                                    {job.status === 'assigned' && (
                                        <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">assigned</Badge>
                                    )}
                                    {job.status === 'completed' && (
                                        <Badge className="bg-green-100 text-green-800 border-green-300">completed</Badge>
                                    )}
                                    {job.status === 'in_progress' && (
                                        <Badge className="bg-blue-100 text-blue-800 border-blue-300">in progress</Badge>
                                    )}
                                    {job.status === 'draft' && (
                                        <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">draft</Badge>
                                    )}
                                    
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => navigate(createPageUrl('InspectionReports') + `?jobId=${job.id}`)}
                                    >
                                        <Eye className="w-4 h-4 mr-1" />
                                        View
                                    </Button>
                                    
                                    <Button
                                        size="sm"
                                        onClick={() => navigate(createPageUrl('InspectionCapture') + `?jobId=${job.id}`)}
                                        className="bg-gray-900 hover:bg-gray-800 text-white"
                                    >
                                        Continue
                                    </Button>

                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="outline" size="sm">
                                                <MoreVertical className="w-4 h-4" />
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuItem onClick={() => {
                                                setSelectedJob(job);
                                                setShowAssignDialog(true);
                                            }}>
                                                <UserPlus className="w-4 h-4 mr-2" />
                                                {job.status === 'assigned' ? 'Reassign' : 'Assign'}
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => handleDeleteJob(job.id)} className="text-red-600">
                                                <Trash2 className="w-4 h-4 mr-2" />
                                                Delete
                                            </DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
      </div>

      <AssignmentDialog
        isOpen={showAssignDialog}
        onOpenChange={setShowAssignDialog}
        existingJob={selectedJob}
        onAssignmentSent={() => {
          setShowAssignDialog(false);
          setSelectedJob(null);
          queryClient.invalidateQueries({ queryKey: ['inspectionJobs'] });
        }}
      />
    </div>
  );
}