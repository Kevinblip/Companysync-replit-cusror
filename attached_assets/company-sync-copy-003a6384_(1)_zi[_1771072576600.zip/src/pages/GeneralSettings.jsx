import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Calendar, CheckCircle2, RefreshCw, LinkIcon, XCircle, Clock, Edit, Save, X, Globe, User, Plus, Trash2, GripVertical, AlertTriangle, Bell } from "lucide-react";
import { format } from "date-fns";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// List of common timezones
const TIMEZONES = [
  { value: 'America/New_York', label: 'Eastern Time (ET)' },
  { value: 'America/Chicago', label: 'Central Time (CT)' },
  { value: 'America/Denver', label: 'Mountain Time (MT)' },
  { value: 'America/Phoenix', label: 'Arizona (no DST)' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
  { value: 'America/Anchorage', label: 'Alaska Time (AKT)' },
  { value: 'Pacific/Honolulu', label: 'Hawaii Time (HST)' },
  { value: 'UTC', label: 'UTC (Coordinated Universal Time)' },
];

export default function GeneralSettings() {
  const [user, setUser] = useState(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [editingAccount, setEditingAccount] = useState(false);
  const [accountForm, setAccountForm] = useState({
    full_name: '',
    email: '',
    phone: ''
  });
  const [newSourceName, setNewSourceName] = useState('');
  const [diagnosis, setDiagnosis] = useState(null);
  const [diagnosing, setDiagnosing] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setAccountForm({
        full_name: u?.full_name || '',
        email: u?.email || '',
        phone: u?.phone || ''
      });
    }).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
    enabled: !!user,
  });

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles-settings', user?.email],
    queryFn: () => user ? base44.entities.StaffProfile.filter({ user_email: user.email }) : [],
    enabled: !!user,
    initialData: [],
  });

  const myCompany = React.useMemo(() => {
    if (!user) return null;

    // Priority 1: Impersonation
    const impersonatedId = typeof window !== 'undefined' ? sessionStorage.getItem('impersonating_company_id') : null;
    if (impersonatedId) {
      const target = companies.find(c => c.id === impersonatedId);
      if (target) return target;
    }

    // Priority 2: Staff profile company
    const staffProfile = staffProfiles[0];
    if (staffProfile?.company_id) {
      const profileCompany = companies.find(c => c.id === staffProfile.company_id);
      if (profileCompany) return profileCompany;
    }
    
    // Priority 3: Owned company
    const ownedCompany = companies.find(c => c.created_by === user.email);
    if (ownedCompany) return ownedCompany;
    
    return null;
  }, [user, companies, staffProfiles]);

  // Once staff profiles load, use staff profile name as the authoritative display name
  useEffect(() => {
    if (staffProfiles.length > 0 && staffProfiles[0].full_name) {
      setAccountForm(prev => ({
        ...prev,
        full_name: staffProfiles[0].full_name || prev.full_name,
        phone: staffProfiles[0].phone || prev.phone
      }));
    }
  }, [staffProfiles]);

  const { data: leadSources = [] } = useQuery({
    queryKey: ['lead-sources', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.LeadSource.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: notificationPrefs = [] } = useQuery({
    queryKey: ['notification-prefs', user?.email],
    queryFn: () => user ? base44.entities.NotificationPreference.filter({ user_email: user.email }) : [],
    enabled: !!user,
  });

  const myPrefs = notificationPrefs[0] || {
    notify_on_lead_created: true,
    notify_on_lead_created_by_others_only: false,
    notify_on_customer_created: true,
    notify_on_customer_created_by_others_only: false,
    notify_on_estimate_created: true,
    notify_on_estimate_accepted: true,
    notify_on_invoice_created: true,
    notify_on_invoice_paid: true,
    notify_on_task_assigned: true,
    notify_on_task_completed: true,
    notify_on_payment_received: true,
    mute_all_notifications: false
  };

  const updatePrefsMutation = useMutation({
    mutationFn: (newPrefs) => {
      if (notificationPrefs[0]) {
        return base44.entities.NotificationPreference.update(notificationPrefs[0].id, newPrefs);
      } else {
        return base44.entities.NotificationPreference.create({
          ...newPrefs,
          company_id: myCompany?.id,
          user_email: user.email
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notification-prefs'] });
    }
  });

  const handleTogglePref = (key) => {
    updatePrefsMutation.mutate({
      [key]: !myPrefs[key]
    });
  };

  const handleSaveAccountAsync = async (data) => {
    try {
      // Use backend function with service role to update StaffProfile (works for all users)
      const result = await base44.functions.invoke('updateMyProfile', {
        full_name: data.full_name,
        phone: data.phone
      });
      
      if (result.data?.error) {
        throw new Error(result.data.error);
      }
      
      // Refresh user data
      const updatedUser = await base44.auth.me();
      setUser(updatedUser);
      
      setAccountForm({
        full_name: data.full_name,
        email: updatedUser.email || '',
        phone: data.phone || updatedUser.phone || ''
      });
      setEditingAccount(false);
      queryClient.invalidateQueries({ queryKey: ['staff-profiles-settings'] });
      alert('✅ Account updated successfully!');
    } catch (error) {
      console.error('Update failed:', error);
      alert('Failed to update account: ' + (error?.response?.data?.message || error?.message || JSON.stringify(error)));
    }
  };

  const updateCompanyMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Company.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      alert('✅ Company settings updated!');
    },
  });

  // App connector is always connected if authorized at platform level
  const googleCalendarConnected = true;
  const lastSync = user?.last_google_sync;

  const handleGoogleConnect = async () => {
    setIsConnecting(true);
    try {
      const result = await base44.functions.invoke('connectUserGoogleCalendar', {});
      if (result.data?.authUrl) {
        window.location.href = result.data.authUrl;
      }
    } catch (error) {
      alert('Failed to connect: ' + error.message);
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDiagnoseSync = async () => {
    try {
      setDiagnosing(true);
      const { data } = await base44.functions.invoke('diagnoseGoogleCalendarSync', {});
      setDiagnosis(data);
    } catch (error) {
      alert('❌ Diagnosis failed: ' + error.message);
    } finally {
      setDiagnosing(false);
    }
  };

  const handleSetupWebhook = async () => {
    try {
      const { data } = await base44.functions.invoke('setupGoogleCalendarWatch', {});
      alert('✅ Instant sync enabled! Your calendar will now sync automatically when you make changes in Google Calendar.\n\nExpires: ' + new Date(data.expires).toLocaleString());
      handleDiagnoseSync();
    } catch (error) {
      alert('❌ Failed to setup instant sync: ' + error.message);
    }
  };

  const handleGoogleSync = async () => {
    setIsConnecting(true);
    try {
      const result = await base44.functions.invoke('syncUserGoogleCalendar', {});
      alert(`✅ Sync complete!\n\nFrom Google: ${result.data.fromGoogle.created} created, ${result.data.fromGoogle.updated} updated, ${result.data.fromGoogle.deleted} deleted\nTo Google: ${result.data.toGoogle.created} created, ${result.data.toGoogle.updated} updated`);
      
      const updatedUser = await base44.auth.me();
      setUser(updatedUser);
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
      handleDiagnoseSync();
    } catch (error) {
      alert('Sync failed: ' + error.message);
    } finally {
      setIsConnecting(false);
    }
  };

  useEffect(() => {
    if (googleCalendarConnected) {
      handleDiagnoseSync();
    }
  }, [googleCalendarConnected]);

  const handleGoogleDisconnect = async () => {
    if (!confirm('Disconnect your Google Calendar? Your CRM events will remain.')) return;

    setIsConnecting(true);
    try {
      await base44.functions.invoke('disconnectUserGoogleCalendar', {});
      const updatedUser = await base44.auth.me();
      setUser(updatedUser);
      alert('✅ Disconnected!');
    } catch (error) {
      alert('Failed: ' + error.message);
    } finally {
      setIsConnecting(false);
    }
  };

  const [isSaving, setIsSaving] = useState(false);
  
  const handleSaveAccount = () => {
    if (!accountForm.full_name.trim()) {
      alert('❌ Name is required');
      return;
    }

    setIsSaving(true);
    handleSaveAccountAsync({
      full_name: accountForm.full_name,
      phone: accountForm.phone
    }).finally(() => setIsSaving(false));
  };

  const handleCancelEdit = () => {
    setEditingAccount(false);
    setAccountForm({
      full_name: user?.full_name || '',
      email: user?.email || '',
      phone: user?.phone || ''
    });
  };

  const handleTimezoneChange = (timezone) => {
    if (!myCompany?.id) {
      alert('❌ Please complete company setup first');
      return;
    }

    updateCompanyMutation.mutate({
      id: myCompany.id,
      data: { timezone: timezone }
    });
  };

  const addLeadSourceMutation = useMutation({
    mutationFn: (sourceName) => base44.entities.LeadSource.create({
      company_id: myCompany.id,
      source_name: sourceName,
      is_active: true,
      display_order: leadSources.length
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lead-sources'] });
      setNewSourceName('');
      alert('✅ Lead source added!');
    },
    onError: (error) => {
      alert('❌ Failed to add: ' + error.message);
    }
  });

  const deleteLeadSourceMutation = useMutation({
    mutationFn: (id) => base44.entities.LeadSource.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lead-sources'] });
      alert('✅ Lead source deleted!');
    },
    onError: (error) => {
      alert('❌ Failed to delete: ' + error.message);
    }
  });

  const handleAddLeadSource = () => {
    if (!newSourceName.trim()) {
      alert('❌ Please enter a source name');
      return;
    }
    if (!myCompany?.id) {
      alert('❌ Please complete company setup first');
      return;
    }
    addLeadSourceMutation.mutate(newSourceName.trim());
  };

  const handleDeleteLeadSource = (source) => {
    if (!confirm(`Delete "${source.source_name}"? This cannot be undone.`)) return;
    deleteLeadSourceMutation.mutate(source.id);
  };

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">General Settings</h1>
        <p className="text-gray-500 mt-1">Manage your personal preferences and integrations</p>
      </div>

      {/* Google Calendar Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            Google Calendar Integration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
              <div>
                <p className="font-semibold">Connected via App Connector</p>
                <p className="text-sm text-gray-500">
                  Calendar sync is managed at the platform level
                </p>
                {lastSync && (
                  <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Last synced: {format(new Date(lastSync), 'MMM d, h:mm a')}
                  </p>
                )}
              </div>
            </div>

            <div className="flex gap-2 flex-wrap">
              <Button
                onClick={handleDiagnoseSync}
                disabled={diagnosing}
                variant="outline"
                size="sm"
              >
                {diagnosing ? 'Checking...' : 'Check Status'}
              </Button>
              <Button
                onClick={handleGoogleSync}
                disabled={isConnecting}
                variant="outline"
                size="sm"
              >
                {isConnecting ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Sync Now
              </Button>
            </div>
          </div>

          {diagnosis && diagnosis.issues && diagnosis.issues.length > 0 && (
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
              <AlertDescription className="text-yellow-900">
                <div className="font-semibold mb-2">Sync Issues Detected:</div>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  {diagnosis.issues.map((issue, idx) => (
                    <li key={idx}>{issue}</li>
                  ))}
                </ul>
                <div className="font-semibold mt-3 mb-2">Recommendations:</div>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  {diagnosis.recommendations.map((rec, idx) => (
                    <li key={idx}>{rec}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {diagnosis && diagnosis.status === 'healthy' && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              <AlertDescription className="text-green-900">
                <div className="font-semibold mb-2">✅ Sync Status: Healthy</div>
                {diagnosis.last_sync && (
                  <p className="text-sm">Last synced: {new Date(diagnosis.last_sync).toLocaleString()}</p>
                )}
                {diagnosis.webhook_expiration && !diagnosis.webhook_expired && (
                  <p className="text-sm">Instant sync expires: {new Date(diagnosis.webhook_expiration).toLocaleString()}</p>
                )}
              </AlertDescription>
            </Alert>
          )}

          <Alert>
            <AlertDescription>
              <strong>How it works:</strong> Once connected, events sync between CRM and Google Calendar. Click "Setup Instant Sync" for automatic syncing, or use "Sync Now" to manually sync. Each team member connects their own calendar.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Company Timezone Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-purple-600" />
            Company Timezone
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex-1">
              <Label htmlFor="timezone-select" className="font-semibold mb-2 block">Default Timezone</Label>
              <p className="text-sm text-gray-500 mb-3">
                Sets the timezone for all calendar events, reminders, and reports
              </p>
              <Select 
                value={myCompany?.timezone || 'America/New_York'}
                onValueChange={handleTimezoneChange}
                disabled={!myCompany?.id}
              >
                <SelectTrigger id="timezone-select" className="max-w-sm">
                  <SelectValue placeholder="Select timezone" />
                </SelectTrigger>
                <SelectContent>
                  {TIMEZONES.map(tz => (
                    <SelectItem key={tz.value} value={tz.value}>
                      {tz.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!myCompany?.id && (
                <p className="text-xs text-orange-600 mt-2">
                  Please complete company setup first
                </p>
              )}
            </div>
          </div>

          <Alert className="bg-blue-50 border-blue-200">
            <AlertDescription className="text-blue-900">
              <strong>Tip:</strong> Setting the correct timezone ensures:
              <ul className="list-disc list-inside mt-2 text-sm">
                <li>Calendar events show at the right time</li>
                <li>Reminders trigger at correct hours</li>
                <li>Daily reports generate at end of business day</li>
                <li>No more midnight notifications for yesterday's events!</li>
              </ul>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Lead Sources Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-green-600" />
            Lead Sources
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-500">
            Manage custom lead sources for your organization. These will appear in lead creation dropdowns.
          </p>

          <div className="flex gap-2">
            <Input
              placeholder="Enter new lead source (e.g., Door Knocking, Facebook Ads)"
              value={newSourceName}
              onChange={(e) => setNewSourceName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleAddLeadSource();
                }
              }}
            />
            <Button
              onClick={handleAddLeadSource}
              disabled={!newSourceName.trim() || addLeadSourceMutation.isPending}
              className="bg-green-600 hover:bg-green-700 whitespace-nowrap"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add
            </Button>
          </div>

          {leadSources.length === 0 ? (
            <Alert>
              <AlertDescription>
                No custom lead sources yet. Add your first one above!
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-2">
              {leadSources.map((source) => (
                <div
                  key={source.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <GripVertical className="w-4 h-4 text-gray-400" />
                    <span className="font-medium">{source.source_name}</span>
                    {!source.is_active && (
                      <Badge variant="secondary">Inactive</Badge>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteLeadSource(source)}
                    disabled={deleteLeadSourceMutation.isPending}
                    className="text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          <Alert className="bg-blue-50 border-blue-200">
            <AlertDescription className="text-blue-900 text-sm">
              <strong>Default sources:</strong> Website, Referral, Social Media, Storm Tracker, Property Importer, and others are always available.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Notification Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-orange-600" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
            <div>
              <Label className="text-base font-semibold">Mute All Notifications</Label>
              <p className="text-sm text-gray-500">Temporarily disable all email and push notifications</p>
            </div>
            <Switch
              checked={myPrefs.mute_all_notifications}
              onCheckedChange={() => handleTogglePref('mute_all_notifications')}
            />
          </div>

          <div className={`space-y-4 ${myPrefs.mute_all_notifications ? 'opacity-50 pointer-events-none' : ''}`}>
            <div>
              <h3 className="font-semibold mb-3 text-sm text-gray-900 uppercase tracking-wider">Leads & Customers</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify_on_lead_created" className="font-normal">New Lead Created</Label>
                  <Switch
                    id="notify_on_lead_created"
                    checked={myPrefs.notify_on_lead_created}
                    onCheckedChange={() => handleTogglePref('notify_on_lead_created')}
                  />
                </div>
                {myPrefs.notify_on_lead_created && (
                  <div className="flex items-center justify-between pl-4 border-l-2 border-gray-200 ml-1">
                    <Label htmlFor="notify_on_lead_created_by_others_only" className="font-normal text-sm text-gray-600">Only when created by others</Label>
                    <Switch
                      id="notify_on_lead_created_by_others_only"
                      checked={myPrefs.notify_on_lead_created_by_others_only}
                      onCheckedChange={() => handleTogglePref('notify_on_lead_created_by_others_only')}
                    />
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify_on_customer_created" className="font-normal">New Customer Created</Label>
                  <Switch
                    id="notify_on_customer_created"
                    checked={myPrefs.notify_on_customer_created}
                    onCheckedChange={() => handleTogglePref('notify_on_customer_created')}
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3 text-sm text-gray-900 uppercase tracking-wider">Sales & Finance</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify_on_estimate_created" className="font-normal">New Estimate Created</Label>
                  <Switch
                    id="notify_on_estimate_created"
                    checked={myPrefs.notify_on_estimate_created}
                    onCheckedChange={() => handleTogglePref('notify_on_estimate_created')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify_on_invoice_created" className="font-normal">New Invoice Created</Label>
                  <Switch
                    id="notify_on_invoice_created"
                    checked={myPrefs.notify_on_invoice_created}
                    onCheckedChange={() => handleTogglePref('notify_on_invoice_created')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify_on_payment_received" className="font-normal">Payment Received</Label>
                  <Switch
                    id="notify_on_payment_received"
                    checked={myPrefs.notify_on_payment_received}
                    onCheckedChange={() => handleTogglePref('notify_on_payment_received')}
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3 text-sm text-gray-900 uppercase tracking-wider">Tasks</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify_on_task_assigned" className="font-normal">Task Assigned to Me</Label>
                  <Switch
                    id="notify_on_task_assigned"
                    checked={myPrefs.notify_on_task_assigned}
                    onCheckedChange={() => handleTogglePref('notify_on_task_assigned')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify_on_task_completed" className="font-normal">Task Completed</Label>
                  <Switch
                    id="notify_on_task_completed"
                    checked={myPrefs.notify_on_task_completed}
                    onCheckedChange={() => handleTogglePref('notify_on_task_completed')}
                  />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* User Account Section - Editable */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-gray-600" />
              Your Account
            </div>
            {!editingAccount && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEditingAccount(true)}
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {editingAccount ? (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-full-name">Full Name *</Label>
                <Input
                  id="edit-full-name"
                  value={accountForm.full_name}
                  onChange={(e) => setAccountForm({ ...accountForm, full_name: e.target.value })}
                  placeholder="John Doe"
                />
              </div>

              <div>
                <Label htmlFor="edit-email">Email Address</Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={accountForm.email}
                  disabled
                  className="bg-gray-100"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Email cannot be changed
                </p>
              </div>

              <div>
                <Label htmlFor="edit-phone">Phone Number</Label>
                <Input
                  id="edit-phone"
                  type="tel"
                  value={accountForm.phone}
                  onChange={(e) => setAccountForm({ ...accountForm, phone: e.target.value })}
                  placeholder="(555) 123-4567"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Used for call bridging and notifications
                </p>
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  onClick={handleSaveAccount}
                  disabled={isSaving}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={handleCancelEdit}
                  disabled={isSaving}
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <span className="text-sm text-gray-500">Name:</span>
                <p className="font-medium">{staffProfiles[0]?.full_name || user?.full_name || 'Loading...'}</p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Email:</span>
                <p className="font-medium">{user?.email || 'Loading...'}</p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Phone:</span>
                <p className="font-medium">{staffProfiles[0]?.phone || user?.phone || 'Not set'}</p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Role:</span>
                <Badge>{user?.role || 'user'}</Badge>
              </div>
              <div className="pt-2 flex justify-end">
                <Button variant="outline" size="sm" onClick={() => setEditingAccount(true)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Details
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}