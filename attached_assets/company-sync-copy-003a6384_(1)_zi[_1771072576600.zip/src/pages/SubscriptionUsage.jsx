import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Zap, ShoppingCart } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function SubscriptionUsage() {
  const [user, setUser] = useState(null);
  const [myCompany, setMyCompany] = useState(null);

  React.useEffect(() => {
    const init = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const impersonatedId = typeof window !== 'undefined' ? sessionStorage.getItem('impersonating_company_id') : null;
      if (impersonatedId) {
        const companies = await base44.entities.Company.filter({ id: impersonatedId });
        if (companies.length > 0) {
          setMyCompany(companies[0]);
          return;
        }
      }

      const companies = await base44.entities.Company.filter({ created_by: currentUser.email });
      if (companies.length > 0) {
        setMyCompany(companies[0]);
      }
    };
    init();
  }, []);

  const { data: currentUsage } = useQuery({
    queryKey: ['subscription-usage', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.SubscriptionUsage.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany?.id,
  });

  const usage = currentUsage?.[0];

  if (!usage) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center py-12">
            <p className="text-gray-600">No subscription data found.</p>
          </div>
        </div>
      </div>
    );
  }

  // Use ACTUAL limits stored on the SubscriptionUsage record (set during initialization from SubscriptionPlan entity)
  // This is the single source of truth - no hardcoded plan limits needed here
  const aiLimit = usage.ai_limit ?? 1000;        // from SubscriptionUsage record
  const smsLimit = usage.sms_limit ?? 200;        // from SubscriptionUsage record
  const callLimit = usage.call_minutes_limit ?? 50; // from SubscriptionUsage record

  const isAiUnlimited = aiLimit < 0;
  const isSmsUnlimited = smsLimit < 0;
  const isCallUnlimited = callLimit < 0;

  const aiTotal = isAiUnlimited ? -1 : aiLimit + (usage.ai_credits_purchased || 0);
  const smsTotal = isSmsUnlimited ? -1 : smsLimit + (usage.sms_credits_purchased || 0);
  const callTotal = isCallUnlimited ? -1 : callLimit + (usage.call_credits_purchased || 0);

  const aiAvailable = isAiUnlimited ? -1 : Math.max(0, aiTotal - usage.ai_used);
  const smsAvailable = isSmsUnlimited ? -1 : Math.max(0, smsTotal - usage.sms_used);
  const callAvailable = isCallUnlimited ? -1 : Math.max(0, callTotal - usage.call_minutes_used);

  const aiPercent = isAiUnlimited ? 0 : (aiTotal > 0 ? (usage.ai_used / aiTotal) * 100 : 0);
  const smsPercent = isSmsUnlimited ? 0 : (smsTotal > 0 ? (usage.sms_used / smsTotal) * 100 : 0);
  const callPercent = isCallUnlimited ? 0 : (callTotal > 0 ? (usage.call_minutes_used / callTotal) * 100 : 0);

  const isAiWarning = aiPercent >= 80 && !isAiUnlimited;
  const isSmsWarning = smsPercent >= 80 && !isSmsUnlimited;
  const isCallWarning = callPercent >= 80 && !isCallUnlimited;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Subscription Usage</h1>
          <p className="text-gray-600">Current plan: <strong>{usage.plan_name.toUpperCase()}</strong></p>
        </div>

        {/* Plan Card */}
        <Card className="mb-8 bg-gradient-to-r from-blue-600 to-purple-600 text-white border-0">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold mb-2">{usage.plan_name.charAt(0).toUpperCase() + usage.plan_name.slice(1)} Plan</h2>
                <p className="text-blue-100">
                  Billing cycle: {usage.billing_cycle_start} to {usage.billing_cycle_end}
                </p>
              </div>
              <Button 
                onClick={() => window.location.href = createPageUrl('SubscriptionPackages')}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                Change Plan
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Usage Metrics */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* AI Interactions */}
          <Card className={isAiWarning ? 'border-2 border-yellow-300 bg-yellow-50' : ''}>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-600" />
                AI Interactions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Usage</span>
                  <span className="text-2xl font-bold text-gray-900">
                    {usage.ai_used}
                    {isAiUnlimited ? '' : `/${aiTotal}`}
                  </span>
                </div>
                {!isAiUnlimited && (
                  <>
                    <Progress value={Math.min(aiPercent, 100)} className="h-2 mb-2" />
                    <p className="text-sm text-gray-600">
                      {aiAvailable >= 0 ? `${aiAvailable} remaining` : 'Unlimited'}
                    </p>
                  </>
                )}
              </div>

              {isAiWarning && (
                <div className="flex items-start gap-2 p-3 bg-yellow-100 rounded-lg">
                  <AlertCircle className="w-4 h-4 text-yellow-800 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-800">You're approaching your limit</p>
                </div>
              )}

              {!isAiUnlimited && (
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="w-full"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy More
                </Button>
              )}
            </CardContent>
          </Card>

          {/* SMS Messages */}
          <Card className={isSmsWarning ? 'border-2 border-yellow-300 bg-yellow-50' : ''}>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <span>💬</span>
                SMS Messages
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Usage</span>
                  <span className="text-2xl font-bold text-gray-900">
                    {usage.sms_used}
                    {isSmsUnlimited ? '' : `/${smsTotal}`}
                  </span>
                </div>
                {!isSmsUnlimited && (
                  <>
                    <Progress value={Math.min(smsPercent, 100)} className="h-2 mb-2" />
                    <p className="text-sm text-gray-600">
                      {smsAvailable >= 0 ? `${smsAvailable} remaining` : 'Unlimited'}
                    </p>
                  </>
                )}
              </div>

              {isSmsWarning && (
                <div className="flex items-start gap-2 p-3 bg-yellow-100 rounded-lg">
                  <AlertCircle className="w-4 h-4 text-yellow-800 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-800">You're approaching your limit</p>
                </div>
              )}

              {!isSmsUnlimited && (
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="w-full"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy More
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Call Minutes */}
          <Card className={isCallWarning ? 'border-2 border-yellow-300 bg-yellow-50' : ''}>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <span>☎️</span>
                Call Minutes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Usage</span>
                  <span className="text-2xl font-bold text-gray-900">
                    {Math.round(usage.call_minutes_used)}
                    {isCallUnlimited ? '' : `/${callTotal}`}
                  </span>
                </div>
                {!isCallUnlimited && (
                  <>
                    <Progress value={Math.min(callPercent, 100)} className="h-2 mb-2" />
                    <p className="text-sm text-gray-600">
                      {callAvailable >= 0 ? `${Math.round(callAvailable)} remaining` : 'Unlimited'}
                    </p>
                  </>
                )}
              </div>

              {isCallWarning && (
                <div className="flex items-start gap-2 p-3 bg-yellow-100 rounded-lg">
                  <AlertCircle className="w-4 h-4 text-yellow-800 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-800">You're approaching your limit</p>
                </div>
              )}

              {!isCallUnlimited && (
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="w-full"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy More
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Additional Credits */}
        {(usage.ai_credits_purchased > 0 || usage.sms_credits_purchased > 0 || usage.call_credits_purchased > 0) && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Purchased Credits</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {usage.ai_credits_purchased > 0 && (
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-gray-600">AI Interactions</p>
                    <p className="text-2xl font-bold text-gray-900">{usage.ai_credits_purchased}</p>
                  </div>
                )}
                {usage.sms_credits_purchased > 0 && (
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-gray-600">SMS Messages</p>
                    <p className="text-2xl font-bold text-gray-900">{usage.sms_credits_purchased}</p>
                  </div>
                )}
                {usage.call_credits_purchased > 0 && (
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-gray-600">Call Minutes</p>
                    <p className="text-2xl font-bold text-gray-900">{usage.call_credits_purchased}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}