import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Mail, Phone, DollarSign, TrendingUp, Target, Users, Calendar, Filter, Search, Download, User, Award } from "lucide-react";
import { format } from "date-fns";

export default function SalesTracking() {
  const [user, setUser] = useState(null);
  const [myCompany, setMyCompany] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterAssignee, setFilterAssignee] = useState("all");
  const [filterSource, setFilterSource] = useState("all");
  const [dateRange, setDateRange] = useState("all");

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
    enabled: !!user,
  });

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles-for-company', user?.email],
    queryFn: () => user ? base44.entities.StaffProfile.filter({ user_email: user.email }) : [],
    enabled: !!user,
    initialData: [],
  });

  useEffect(() => {
    if (user && companies.length > 0) {
      const ownedCompany = companies.find(c => c.created_by === user.email);
      if (ownedCompany) {
        setMyCompany(ownedCompany);
        return;
      }
      
      const staffProfile = staffProfiles[0];
      if (staffProfile?.company_id) {
        const staffCompany = companies.find(c => c.id === staffProfile.company_id);
        setMyCompany(staffCompany);
      }
    }
  }, [user, companies, staffProfiles]);

  const { data: allStaffProfiles = [] } = useQuery({
    queryKey: ['all-staff-profiles', myCompany?.id],
    queryFn: () => myCompany?.id ? base44.entities.StaffProfile.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany?.id,
    initialData: [],
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date"),
    initialData: [],
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list("-created_date"),
    initialData: [],
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Lead.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
    },
  });

  const columns = [
    { id: 'new', title: 'New Leads', color: '#3b82f6', bgColor: 'bg-blue-50', borderColor: 'border-blue-300' },
    { id: 'contacted', title: 'Contacted', color: '#f59e0b', bgColor: 'bg-amber-50', borderColor: 'border-amber-300' },
    { id: 'qualified', title: 'Qualified', color: '#8b5cf6', bgColor: 'bg-purple-50', borderColor: 'border-purple-300' },
    { id: 'proposal', title: 'Proposal', color: '#ec4899', bgColor: 'bg-pink-50', borderColor: 'border-pink-300' },
    { id: 'negotiation', title: 'Negotiation', color: '#f97316', bgColor: 'bg-orange-50', borderColor: 'border-orange-300' },
    { id: 'won', title: 'Won', color: '#22c55e', bgColor: 'bg-green-50', borderColor: 'border-green-300' },
  ];

  // Apply filters
  const filteredLeads = leads.filter(lead => {
    // Search filter
    if (searchTerm && !lead.name?.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !lead.company?.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }

    // Assignee filter
    if (filterAssignee !== "all" && lead.assigned_to !== filterAssignee) {
      return false;
    }

    // Source filter
    if (filterSource !== "all" && lead.source !== filterSource) {
      return false;
    }

    // Date range filter
    if (dateRange !== "all" && lead.created_date) {
      const leadDate = new Date(lead.created_date);
      const now = new Date();
      const daysDiff = Math.floor((now - leadDate) / (1000 * 60 * 60 * 24));
      
      if (dateRange === "7days" && daysDiff > 7) return false;
      if (dateRange === "30days" && daysDiff > 30) return false;
      if (dateRange === "90days" && daysDiff > 90) return false;
    }

    return true;
  });

  // Calculate metrics
  const totalLeads = filteredLeads.length;
  const totalValue = filteredLeads.reduce((sum, l) => sum + (l.value || 0), 0);
  const wonLeads = filteredLeads.filter(l => l.status === 'won').length;
  const conversionRate = totalLeads > 0 ? ((wonLeads / totalLeads) * 100).toFixed(1) : 0;
  const avgDealSize = wonLeads > 0 ? (filteredLeads.filter(l => l.status === 'won').reduce((sum, l) => sum + (l.value || 0), 0) / wonLeads).toFixed(0) : 0;

  // Team performance
  const teamPerformance = allStaffProfiles.map(staff => {
    const staffLeads = filteredLeads.filter(l => l.assigned_to === staff.user_email);
    const staffWon = staffLeads.filter(l => l.status === 'won').length;
    const staffRevenue = invoices.filter(i => i.sale_agent === staff.user_email && i.status === 'paid').reduce((sum, i) => sum + (i.amount || 0), 0);
    
    return {
      name: staff.full_name,
      email: staff.user_email,
      avatar: staff.avatar_url,
      leads: staffLeads.length,
      won: staffWon,
      revenue: staffRevenue,
      conversionRate: staffLeads.length > 0 ? ((staffWon / staffLeads.length) * 100).toFixed(1) : 0
    };
  }).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const leadId = result.draggableId;
    const newStatus = result.destination.droppableId;
    const lead = leads.find(l => l.id === leadId);

    if (lead && lead.status !== newStatus) {
      updateMutation.mutate({
        id: leadId,
        data: { ...lead, status: newStatus }
      });
    }
  };

  const exportToCSV = () => {
    const headers = ['Name', 'Company', 'Status', 'Value', 'Source', 'Assigned To', 'Created Date'];
    const rows = filteredLeads.map(lead => [
      lead.name,
      lead.company || '',
      lead.status,
      lead.value || 0,
      lead.source || '',
      allStaffProfiles.find(s => s.user_email === lead.assigned_to)?.full_name || '',
      lead.created_date ? format(new Date(lead.created_date), 'yyyy-MM-dd') : ''
    ]);

    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sales-pipeline-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Target className="w-8 h-8 text-blue-600" />
            Sales Pipeline Tracker
          </h1>
          <p className="text-gray-500 mt-1">Drag and drop leads to update their status • Real-time team performance</p>
        </div>
        <Button onClick={exportToCSV} variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Export CSV
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Target className="w-8 h-8 opacity-80" />
              <span className="text-sm opacity-80">Total Pipeline</span>
            </div>
            <h3 className="text-3xl font-bold">{totalLeads}</h3>
            <p className="text-sm opacity-80 mt-1">${totalValue.toLocaleString()} in value</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8 opacity-80" />
              <span className="text-sm opacity-80">Conversion Rate</span>
            </div>
            <h3 className="text-3xl font-bold">{conversionRate}%</h3>
            <p className="text-sm opacity-80 mt-1">{wonLeads} deals won</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <DollarSign className="w-8 h-8 opacity-80" />
              <span className="text-sm opacity-80">Avg Deal Size</span>
            </div>
            <h3 className="text-3xl font-bold">${avgDealSize}</h3>
            <p className="text-sm opacity-80 mt-1">Per closed deal</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <Users className="w-8 h-8 opacity-80" />
              <span className="text-sm opacity-80">Active Reps</span>
            </div>
            <h3 className="text-3xl font-bold">{allStaffProfiles.length}</h3>
            <p className="text-sm opacity-80 mt-1">Sales team members</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="shadow-md">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search leads..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterAssignee} onValueChange={setFilterAssignee}>
              <SelectTrigger>
                <SelectValue placeholder="All Assignees" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Assignees</SelectItem>
                {allStaffProfiles.map(staff => (
                  <SelectItem key={staff.user_email} value={staff.user_email}>
                    {staff.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterSource} onValueChange={setFilterSource}>
              <SelectTrigger>
                <SelectValue placeholder="All Sources" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sources</SelectItem>
                <SelectItem value="website">Website</SelectItem>
                <SelectItem value="referral">Referral</SelectItem>
                <SelectItem value="social_media">Social Media</SelectItem>
                <SelectItem value="advertisement">Advertisement</SelectItem>
                <SelectItem value="cold_call">Cold Call</SelectItem>
                <SelectItem value="storm_tracker">Storm Tracker</SelectItem>
              </SelectContent>
            </Select>

            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger>
                <SelectValue placeholder="All Time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="90days">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Pipeline Board */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {columns.map((column) => {
            const columnLeads = filteredLeads.filter(l => l.status === column.id);
            const totalValue = columnLeads.reduce((sum, l) => sum + (l.value || 0), 0);

            return (
              <Droppable key={column.id} droppableId={column.id}>
                {(provided, snapshot) => (
                  <Card className={`${snapshot.isDraggingOver ? 'ring-2 ring-blue-400 shadow-xl' : 'shadow-md'} border-t-4 transition-all`} style={{ borderTopColor: column.color }}>
                    <CardHeader className={`${column.bgColor} border-b ${column.borderColor}`}>
                      <CardTitle className="text-sm font-bold flex items-center justify-between">
                        <span style={{ color: column.color }}>{column.title}</span>
                        <Badge variant="secondary" className="bg-white">{columnLeads.length}</Badge>
                      </CardTitle>
                      <div className="text-xs font-bold mt-1" style={{ color: column.color }}>
                        ${totalValue.toLocaleString()}
                      </div>
                    </CardHeader>
                    <CardContent
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className="p-2 min-h-[500px] space-y-2 bg-gray-50"
                    >
                      {columnLeads.map((lead, index) => {
                        const assignedStaff = allStaffProfiles.find(s => s.user_email === lead.assigned_to);
                        
                        return (
                          <Draggable key={lead.id} draggableId={lead.id} index={index}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                className={`bg-white p-3 rounded-lg shadow border hover:shadow-lg transition-all ${
                                  snapshot.isDragging ? 'ring-2 ring-blue-400 shadow-2xl rotate-2' : ''
                                }`}
                              >
                                <div className="flex items-start justify-between mb-2">
                                  <div className="font-semibold text-sm text-gray-900 flex-1">{lead.name}</div>
                                  {lead.value > 0 && (
                                    <Badge className="bg-green-100 text-green-700 text-xs">
                                      ${lead.value.toLocaleString()}
                                    </Badge>
                                  )}
                                </div>

                                {lead.company && (
                                  <div className="text-xs text-gray-500 mb-2">{lead.company}</div>
                                )}

                                <div className="flex items-center gap-2 text-xs text-gray-600 mb-2">
                                  {lead.email && <Mail className="w-3 h-3" />}
                                  {lead.phone && <Phone className="w-3 h-3" />}
                                  {lead.source && (
                                    <Badge variant="outline" className="text-xs">
                                      {lead.source}
                                    </Badge>
                                  )}
                                </div>

                                {assignedStaff && (
                                  <div className="flex items-center gap-2 mt-2 pt-2 border-t">
                                    {assignedStaff.avatar_url ? (
                                      <img src={assignedStaff.avatar_url} alt={assignedStaff.full_name} className="w-5 h-5 rounded-full" />
                                    ) : (
                                      <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center text-white text-xs">
                                        {assignedStaff.full_name?.[0] || '?'}
                                      </div>
                                    )}
                                    <span className="text-xs text-gray-600">{assignedStaff.full_name}</span>
                                  </div>
                                )}
                              </div>
                            )}
                          </Draggable>
                        );
                      })}
                      {provided.placeholder}
                      {columnLeads.length === 0 && (
                        <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                          <Target className="w-8 h-8 mb-2" />
                          <p className="text-sm">No leads yet</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </Droppable>
            );
          })}
        </div>
      </DragDropContext>

      {/* Team Performance Leaderboard */}
      {teamPerformance.length > 0 && (
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-500" />
              Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {teamPerformance.map((member, index) => (
                <div key={member.email} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-center gap-3 flex-1">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                      index === 0 ? 'bg-yellow-100 text-yellow-600' :
                      index === 1 ? 'bg-gray-100 text-gray-600' :
                      index === 2 ? 'bg-orange-100 text-orange-600' :
                      'bg-blue-50 text-blue-600'
                    }`}>
                      {index + 1}
                    </div>
                    
                    {member.avatar ? (
                      <img src={member.avatar} alt={member.name} className="w-10 h-10 rounded-full" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                        {member.name?.[0] || '?'}
                      </div>
                    )}
                    
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900">{member.name}</div>
                      <div className="text-sm text-gray-500">{member.leads} leads • {member.won} won</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">${member.revenue.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">{member.conversionRate}% conversion</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}