import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { CheckCircle2, X, Loader2, Send } from 'lucide-react';

export default function ReviewRequests() {
  const qc = useQueryClient();
  const [user, setUser] = React.useState(null);
  React.useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);

  const [running, setRunning] = React.useState(false);
  const runNow = async () => {
    try {
      setRunning(true);
      const res = await base44.functions.invoke('runReviewRequestsNow', {});
      const sent = res?.data?.sent || 0;
      const autoApproved = res?.data?.autoApproved || 0;
      alert(`Auto-approved ${autoApproved}, sent ${sent} message(s).`);
      qc.invalidateQueries({ queryKey: ['review-requests'] });
    } catch (e) {
      alert(`Failed to run: ${e?.message || e}`);
    } finally {
      setRunning(false);
    }
  };

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ['review-requests', user?.email],
    queryFn: async () => {
      if (!user) return [];
      // Admins see all, reps see their own
      const staff = await base44.entities.StaffProfile.filter({ user_email: user.email });
      const isAdmin = staff[0]?.is_administrator;
      if (isAdmin) return base44.entities.ReviewRequest.list('-created_date', 1000);
      return base44.entities.ReviewRequest.filter({ sale_agent_email: user.email });
    },
    enabled: !!user,
    initialData: []
  });

  const approveMutation = useMutation({
    mutationFn: ({ id, approved }) => base44.functions.invoke('approveReviewRequest', { id, approved }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['review-requests'] })
  });

  const [showApprovalDialog, setShowApprovalDialog] = React.useState(false);
  const [activePending, setActivePending] = React.useState(null);

  const pending = requests.filter(r => r.status === 'pending_approval');
  const active = requests.filter(r => r.status === 'approved');
  const done = requests.filter(r => r.status === 'completed' || r.status === 'declined');

  React.useEffect(() => {
    if (pending.length > 0 && !showApprovalDialog) {
      setActivePending(pending[0]);
      setShowApprovalDialog(true);
    }
  }, [pending.length]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">Review Requests</h1>
          <p className="text-gray-500 text-sm">Automations send email/SMS every 3 days (up to 5). SMS + Email = Better results! Use Run Now to test.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={runNow} disabled={running}>
            {running ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Send className="w-4 h-4 mr-1" />}
            Run Now
          </Button>
        </div>
      </div>

      {pending.length > 0 && (
        <div className="flex justify-end">
          <Button size="sm" variant="outline" onClick={() => { setActivePending(pending[0]); setShowApprovalDialog(true); }}>
            Review Pending ({pending.length})
          </Button>
        </div>
      )}

      <Alert>
        <AlertDescription>
          Make sure your Google review link is set in Settings → General. Requests won't send without it. If you just recorded a payment, refresh this page in a few seconds to see the pending approval.
        </AlertDescription>
      </Alert>

      <Dialog open={showApprovalDialog} onOpenChange={setShowApprovalDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve review request</DialogTitle>
            <DialogDescription>
              {activePending ? `Review request for ${activePending.customer_name} (Invoice ${activePending.invoice_number || ''})` : 'No pending requests'}
            </DialogDescription>
          </DialogHeader>
          {activePending && (
            <div className="space-y-2 text-sm">
              <div><strong>Customer:</strong> {activePending.customer_name}</div>
              {activePending.customer_email && <div><strong>Email:</strong> {activePending.customer_email}</div>}
              {activePending.customer_phone && <div><strong>Phone:</strong> {activePending.customer_phone}</div>}
              <div><strong>Sales Rep:</strong> {activePending.sale_agent_name || activePending.sale_agent_email}</div>
            </div>
          )}
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setShowApprovalDialog(false)}>Later</Button>
            <Button variant="outline" className="text-red-600" onClick={() => activePending && approveMutation.mutate({ id: activePending.id, approved: false }, { onSuccess: () => setShowApprovalDialog(false) })}>
              <X className="w-4 h-4 mr-1"/> Decline
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={() => activePending && approveMutation.mutate({ id: activePending.id, approved: true }, { onSuccess: () => setShowApprovalDialog(false) })}>
              <CheckCircle2 className="w-4 h-4 mr-1"/> Approve & Start
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Pending Approval ({pending.length})</CardTitle>
            {pending.length > 0 && (
              <div className="mt-2">
                <Button size="sm" variant="outline" onClick={() => { setActivePending(pending[0]); setShowApprovalDialog(true); }}>
                  Open Approval Popup
                </Button>
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-3">
            {pending.map(rr => (
              <div key={rr.id} className="border rounded p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{rr.customer_name}</div>
                    <div className="text-xs text-gray-500">Invoice {rr.invoice_number}</div>
                  </div>
                  <Badge>Pending</Badge>
                </div>
                <div className="mt-2 flex gap-2">
                  <Button size="sm" className="bg-green-600 hover:bg-green-700" disabled={approveMutation.isPending}
                    onClick={() => approveMutation.mutate({ id: rr.id, approved: true })}>
                    {approveMutation.isPending ? <Loader2 className="w-4 h-4 mr-1 animate-spin"/> : <CheckCircle2 className="w-4 h-4 mr-1"/>}
                    Approve & Start
                  </Button>
                  <Button size="sm" variant="outline" disabled={approveMutation.isPending}
                    onClick={() => approveMutation.mutate({ id: rr.id, approved: false })}>
                    <X className="w-4 h-4 mr-1"/>
                    Decline
                  </Button>
                </div>
              </div>
            ))}
            {pending.length === 0 && <div className="text-sm text-gray-500">No pending requests</div>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Active (Approved) ({active.length})</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {active.map(rr => (
              <div key={rr.id} className="border rounded p-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium">{rr.customer_name}</div>
                    <div className="text-xs text-gray-500">Next send: {rr.next_send_at ? new Date(rr.next_send_at).toLocaleString() : '—'}</div>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {rr.customer_email && <Badge variant="outline" className="text-xs">📧 Email</Badge>}
                      {rr.customer_phone && <Badge variant="outline" className="text-xs">📱 SMS</Badge>}
                    </div>
                    <div className="flex gap-2 mt-2">
                      {rr.email_delivered && <Badge className="bg-blue-100 text-blue-700 text-xs">✓ Delivered</Badge>}
                      {rr.email_opened && <Badge className="bg-green-100 text-green-700 text-xs">👁️ Opened</Badge>}
                      {rr.link_clicked && <Badge className="bg-purple-100 text-purple-700 text-xs">🔗 Clicked</Badge>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{rr.total_sent_count || 0}/5 sent</Badge>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      onClick={async () => {
                        if (window.confirm(`Stop review request for ${rr.customer_name}?`)) {
                          await base44.entities.ReviewRequest.update(rr.id, {
                            status: 'cancelled',
                            next_send_at: null
                          });
                          qc.invalidateQueries({ queryKey: ['review-requests'] });
                        }
                      }}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            {active.length === 0 && <div className="text-sm text-gray-500">No active requests</div>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Completed / Declined ({done.length})</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {done.map(rr => (
              <div key={rr.id} className="border rounded p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{rr.customer_name}</div>
                    <div className="text-xs text-gray-500">{rr.status}</div>
                  </div>
                  <Send className="w-4 h-4 text-gray-400"/>
                </div>
              </div>
            ))}
            {done.length === 0 && <div className="text-sm text-gray-500">Nothing here yet</div>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}