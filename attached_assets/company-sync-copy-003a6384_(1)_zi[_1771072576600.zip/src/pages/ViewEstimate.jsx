import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileText, ThumbsUp, ThumbsDown, CheckCircle2, XCircle, Download, MapPin, Calendar, Phone, Mail } from "lucide-react";
import { format } from "date-fns";

export default function ViewEstimate() {
  const [estimateId, setEstimateId] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setEstimateId(params.get('id'));
  }, []);

  const { data, isLoading, error } = useQuery({
    queryKey: ['public-estimate', estimateId],
    queryFn: async () => {
      const response = await base44.functions.invoke('getPublicEstimate', { id: estimateId });
      if (response.data.error) throw new Error(response.data.error);
      return response.data;
    },
    enabled: !!estimateId,
  });

  const estimate = data?.estimate;
  const company = data?.company;

  const updateStatusMutation = useMutation({
    mutationFn: async (status) => {
        // We need a public function to update status without auth
        // For now, we'll reuse getPublicEstimate or create a new one? 
        // Actually, let's try to use a new function or just assume we can't update securely without a token.
        // But user asked for "Accept/Decline".
        // I'll create 'updatePublicEstimateStatus' function quickly.
        return await base44.functions.invoke('updatePublicEstimateStatus', { 
            id: estimateId, 
            status: status 
        });
    },
    onSuccess: () => {
        // Refetch
        window.location.reload();
    },
    onError: (err) => {
        alert('Failed to update status: ' + err.message);
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error || !estimate) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md text-center p-8">
          <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900">Estimate Not Found</h2>
          <p className="text-gray-500 mt-2">The estimate you are looking for does not exist or has been removed.</p>
        </Card>
      </div>
    );
  }

  const subtotal = estimate.items?.reduce((sum, item) => sum + (item.amount || item.rcv || 0), 0) || 0;
  
  // Reconstruct discount logic if not saved in amounts (simplified)
  // Assuming 'amount' on estimate is final.
  
  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header / Company Info */}
        <Card>
            <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8 border-b pb-8">
                    <div>
                        {company?.logo_url ? (
                            <img src={company.logo_url} alt={company.company_name} className="h-16 object-contain mb-4" />
                        ) : (
                            <h1 className="text-2xl font-bold text-gray-900">{company?.company_name || 'Company Name'}</h1>
                        )}
                        <div className="text-sm text-gray-500 space-y-1">
                            {(company?.address || company?.company_address) && (
                                <p className="flex items-center gap-2">
                                    <MapPin className="w-4 h-4" /> 
                                    {company.address ? `${company.address}, ${company.city}, ${company.state} ${company.zip}` : company.company_address}
                                </p>
                            )}
                            {(company?.phone || company?.phone_number) && (
                                <p className="flex items-center gap-2">
                                    <Phone className="w-4 h-4" /> 
                                    {company.phone || company.phone_number}
                                </p>
                            )}
                            {(company?.email || company?.email_address) && (
                                <p className="flex items-center gap-2">
                                    <Mail className="w-4 h-4" /> 
                                    {company.email || company.email_address}
                                </p>
                            )}
                        </div>
                    </div>
                    <div className="text-right">
                        <h2 className="text-3xl font-bold text-gray-900">ESTIMATE</h2>
                        <p className="text-gray-500 font-medium">#{estimate.estimate_number}</p>
                        <div className="mt-2">
                            <Badge className={`text-base px-3 py-1 ${
                                estimate.status === 'accepted' ? 'bg-green-100 text-green-700' :
                                estimate.status === 'declined' ? 'bg-red-100 text-red-700' :
                                'bg-blue-100 text-blue-700'
                            }`}>
                                {estimate.status.toUpperCase()}
                            </Badge>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                    <div>
                        <h3 className="text-sm font-semibold text-gray-500 uppercase mb-2">Estimate For</h3>
                        <p className="text-lg font-bold text-gray-900">{estimate.customer_name}</p>
                        {estimate.property_address && (
                            <p className="text-gray-600 mt-1">{estimate.property_address}</p>
                        )}
                        {estimate.customer_email && <p className="text-gray-600">{estimate.customer_email}</p>}
                        {estimate.customer_phone && <p className="text-gray-600">{estimate.customer_phone}</p>}
                    </div>
                    <div className="md:text-right">
                        <h3 className="text-sm font-semibold text-gray-500 uppercase mb-2">Details</h3>
                        {estimate.created_date && (
                            <p className="text-gray-600"><span className="font-medium">Date:</span> {format(new Date(estimate.created_date), 'MMM d, yyyy')}</p>
                        )}
                        {estimate.valid_until && (
                            <p className="text-gray-600"><span className="font-medium">Valid Until:</span> {format(new Date(estimate.valid_until), 'MMM d, yyyy')}</p>
                        )}
                    </div>
                </div>

                {/* Line Items */}
                <div className="mb-8">
                    <h3 className="font-bold text-gray-900 mb-4 text-lg">Line Items</h3>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="bg-gray-50 border-y">
                                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Description</th>
                                    <th className="text-center py-3 px-4 font-semibold text-gray-700 w-24">Qty</th>
                                    <th className="text-right py-3 px-4 font-semibold text-gray-700 w-32">Amount</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y">
                                {estimate.items?.map((item, idx) => (
                                    <tr key={idx}>
                                        <td className="py-4 px-4">
                                            <p className="font-medium text-gray-900">{item.name || item.description}</p>
                                            {item.description && item.name !== item.description && (
                                                <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                                            )}
                                        </td>
                                        <td className="py-4 px-4 text-center text-gray-600">{item.quantity}</td>
                                        <td className="py-4 px-4 text-right font-medium text-gray-900">
                                            ${(item.amount || item.rcv || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Totals */}
                <div className="flex justify-end mb-8">
                    <div className="w-full md:w-1/2 lg:w-1/3 space-y-3">
                        <div className="flex justify-between text-gray-600">
                            <span>Subtotal</span>
                            <span>${subtotal.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
                        </div>
                        {/* Basic logic to infer discount/adjustments if not explicitly clear, or just show total */}
                        <div className="flex justify-between text-2xl font-bold text-gray-900 pt-3 border-t">
                            <span>Total</span>
                            <span>${(estimate.amount || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
                        </div>
                    </div>
                </div>

                {/* Notes and Terms */}
                <div className="space-y-8 mb-12 border-t pt-8">
                    {estimate.notes && (
                        <div>
                            <h4 className="font-bold text-gray-900 mb-2 uppercase text-sm">Note:</h4>
                            <p className="text-gray-700 whitespace-pre-wrap text-sm leading-relaxed">{estimate.notes}</p>
                        </div>
                    )}
                    
                    {company?.pdf_terms_conditions && (
                        <div>
                            <h4 className="font-bold text-gray-900 mb-2 uppercase text-sm">Terms & Conditions:</h4>
                            <p className="text-gray-600 whitespace-pre-wrap text-sm leading-relaxed text-justify">{company.pdf_terms_conditions}</p>
                        </div>
                    )}
                </div>

                {/* Footer Signature Area */}
                <div className="mb-12">
                    <h4 className="font-bold text-gray-900 mb-1 capitalize">{company?.company_name}</h4>
                    <div className="text-sm text-gray-600">
                         {company?.address && <p>{company.address}</p>}
                         {company?.city && <p>{company.city}, {company.state} {company.zip}</p>}
                    </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col md:flex-row gap-4 justify-center pt-4 border-t">
                    {estimate.status === 'sent' || estimate.status === 'viewed' ? (
                        <>
                            <Button 
                                onClick={() => updateStatusMutation.mutate('accepted')}
                                disabled={updateStatusMutation.isPending}
                                className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 text-lg h-auto"
                            >
                                {updateStatusMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <ThumbsUp className="w-5 h-5 mr-2" />}
                                Accept Estimate
                            </Button>
                            <Button 
                                onClick={() => updateStatusMutation.mutate('declined')}
                                disabled={updateStatusMutation.isPending}
                                variant="outline" 
                                className="border-red-200 text-red-600 hover:bg-red-50 px-8 py-6 text-lg h-auto"
                            >
                                {updateStatusMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <ThumbsDown className="w-5 h-5 mr-2" />}
                                Decline
                            </Button>
                        </>
                    ) : estimate.status === 'accepted' ? (
                        <div className="flex items-center text-green-600 bg-green-50 px-6 py-4 rounded-lg">
                            <CheckCircle2 className="w-6 h-6 mr-2" />
                            <span className="font-semibold text-lg">Estimate Accepted</span>
                        </div>
                    ) : estimate.status === 'declined' ? (
                        <div className="flex items-center text-red-600 bg-red-50 px-6 py-4 rounded-lg">
                            <XCircle className="w-6 h-6 mr-2" />
                            <span className="font-semibold text-lg">Estimate Declined</span>
                        </div>
                    ) : null}
                </div>

            </CardContent>
        </Card>
      </div>
    </div>
  );
}