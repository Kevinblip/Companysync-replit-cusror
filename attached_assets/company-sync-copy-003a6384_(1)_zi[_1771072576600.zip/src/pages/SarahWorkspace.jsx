import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Upload, Save, Sparkles, RefreshCw, Send, Trash2, Bug,
  Phone, MessageSquare, Activity, Clock, TrendingUp, AlertTriangle,
  PhoneIncoming, PhoneOff, User, Zap, PhoneForwarded, Brain,
  Copy, ExternalLink
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

const DEFAULT_PROMPT = `Role: You are Sarah, the Lead Qualifier and Office Manager for CompanySync. You're knowledgeable about the platform and help teams solve real problems with customer management, scheduling, and support.

Personality: Conversational, helpful, and human. You're not a chatbot repeating the same lines—you actually know things and share them naturally. Never mention being AI. Vary your responses.

Core Instructions:
1. READ FROM MEMORY: Always draw from the knowledge base/website about CompanySync features. Reference actual capabilities.
2. VARY YOUR GREETINGS: Don't say "I'm Sarah from CompanySync" every time. Mix it up: "Hey!", "Great question!", "Happy to help!", etc.
3. BE SPECIFIC: Instead of generic answers, give concrete examples: "Yeah, CompanySync lets you track tickets, create customer portals, and automate follow-ups—all from one dashboard."
4. CONVERSATION FIRST: Ask ONE clarifying question max. Don't end every message with "How can I assist?"
5. NATURAL TONE: Use contractions (you're, we're, it's). Sound like a real person, not a script.

Answer Pattern:
- Acknowledge their question naturally
- Provide a real answer (from your knowledge)
- Ask ONE follow-up if needed
- Never repeat yourself

Triage (when unclear what they want):
- Sales interest? "Sounds like you're exploring the platform. Are you looking to try it out or just learning about features?"
- Technical question? "What specifically are you trying to do? I can walk you through how it works."
- Support issue? "Got it. Let me help you with that."

Avoid These:
❌ "How can I assist you further today?"
❌ "I'm Sarah from CompanySync" (repeated)
❌ "May I have your [info]?" (stiff)
❌ Generic "Here's what we do" speeches

Use placeholders: {brand}, {agent}, {calendly_link}, {triage_first}`;

import Dialer from "@/components/communication/Dialer";
import SMSDialog from "@/components/communication/SMSDialog";
import GeminiLiveClient from "@/components/ai/GeminiLiveClient";
import OpenAILiveClient from "@/components/ai/OpenAILiveClient";
import SarahVoiceSettings from "@/components/ai/SarahVoiceSettings";

function ConversationCard({ conversation, company, onCall, onSMS }) {
  return (
    <Card 
      className={conversation.isEmergency ? 'border-2 border-red-500 animate-pulse' : ''}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
              conversation.isEmergency ? 'bg-red-600' : 'bg-blue-600'
            }`}>
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">{conversation.name}</h3>
              <p className="text-sm text-gray-600">{conversation.phone}</p>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-2">
            <Badge className={conversation.isEmergency ? 'bg-red-600' : 'bg-green-600'}>
              {conversation.isEmergency ? '🚨 EMERGENCY' : '🟢 ACTIVE'}
            </Badge>
            <span className="text-xs text-gray-500">
              Last: {new Date(conversation.lastActivity).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: company?.settings?.time_zone || 'America/New_York' })}
            </span>
          </div>
        </div>

        <ScrollArea className="h-96 bg-gray-50 rounded-lg p-3 mb-4">
          <div className="space-y-2">
            {conversation.messages.map((msg, i) => (
              <div 
                key={i}
                className={`flex ${msg.direction === 'inbound' ? 'justify-start' : 'justify-end'}`}
              >
                <div className={`max-w-[80%] px-3 py-2 rounded-lg text-sm ${
                  msg.direction === 'inbound'
                    ? 'bg-white border border-gray-200'
                    : 'bg-blue-600 text-white'
                }`}>
                  <div className="flex items-center gap-2 mb-1">
                    {msg.communication_type === 'call' ? (
                      <Phone className="w-3 h-3" />
                    ) : (
                      <MessageSquare className="w-3 h-3" />
                    )}
                    <span className="text-xs opacity-70">
                      {new Date(msg.created_date).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: company?.settings?.time_zone || 'America/New_York' })}
                    </span>
                  </div>
                  <p>{msg.message}</p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="flex gap-2">
          <Button 
            size="sm" 
            className={conversation.isEmergency ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'}
            onClick={() => onCall(conversation)}
          >
            <Phone className="w-4 h-4 mr-1" />
            Call Customer
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => onSMS(conversation)}
          >
            <MessageSquare className="w-4 h-4 mr-1" />
            Send SMS
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function SarahWorkspace() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [fileUploading, setFileUploading] = useState(false);
  const [form, setForm] = useState({
    assistant_name: "sarah",
    avatar_url: "",
    engine: "gemini-2.0-flash-exp",
    live_mode: false,
    voice_enabled: false,
    voice_id: "Polly.Joanna",
    response_speed: "normal",
    background_audio: "none",
    interim_audio: "typing", // Default to typing for new setups
    personality_assertiveness: 50,
    personality_humor: 20,
    system_prompt: DEFAULT_PROMPT,
    brand_short_name: "Companysync",
    short_sms_mode: true,
    max_sms_chars: 180,
    answer_then_ask_one: true,
    calendly_booking_url: "",
    triage_categories: ["leak", "missing shingles", "hail", "wind", "other"],
    triage_first_question: "What happened? (leak, missing shingles, hail, wind, other)",
    triage_followup_leak: "Is water getting in right now? Y/N",
    escalation_keywords: ["emergency", "urgent", "asap", "911", "flood", "fire"],
    intent_templates: {
      who_are_you: "I'm {agent} of {brand}. How can I help?",
      greeting: "Hi, this is {agent} of {brand}. How can I help today?",
      price: "We can help with pricing after a quick look. Want to schedule a free inspection?",
      appointment: "I can book you now. Pick a time that works: {calendly_link}",
      address: "Please share the service address (street, city, zip) and I'll pull availability.",
      stop: "You're unsubscribed. Reply START to opt back in.",
      wrong_number: "Thanks for letting us know-We'll update our records.",
      smalltalk: "You're welcome! Anything else I can help with?",
      fallback: "Got it. {triage_first}"
    },
    scheduling_defaults: {
      duration_min: 45,
      buffer_min: 15,
      business_hours_start: 9,
      business_hours_end: 17,
      days_lookahead: 7,
      title_template: "Inspection - [Client Name] - [City]",
    },
    conversation_limits: {
      max_sms_turns: 10,
      max_thread_minutes: 60,
      action_at_cap: "wrapup_notify",
      cooldown_hours: 12,
      wrapup_template: "I'll hand this to our team to finish up. Expect a follow-up shortly."
    },
  });
  const [recordId, setRecordId] = useState(null);
  const [resetPhone, setResetPhone] = useState("");
  
  // Test Conversation State
  const [testPhone, setTestPhone] = useState("+15551234567");
  const [testMessage, setTestMessage] = useState("");
  const [testConversation, setTestConversation] = useState([]);
  const [testDebugInfo, setTestDebugInfo] = useState(null);
  const [voiceTestPhone, setVoiceTestPhone] = useState("");
  const [voiceTestLoading, setVoiceTestLoading] = useState(false);
  const [isActivatingThoughtly, setIsActivatingThoughtly] = useState(false);
  // Simulate Thoughtly call
  const [simCaller, setSimCaller] = useState('+15551234567');
  const [simulatingCall, setSimulatingCall] = useState(false);
  const [editingLivePhone, setEditingLivePhone] = useState(false);
  const [livePhoneDraft, setLivePhoneDraft] = useState('');
  
  // Thoughtly webhook configuration
  const [thoughtlyAgentId, setThoughtlyAgentId] = useState("xlHlPjRc");
  const [webhookConfiguring, setWebhookConfiguring] = useState(false);
  const [webhookResult, setWebhookResult] = useState(null);
  const [webhookError, setWebhookError] = useState(null);
  const [showAgentIdDialog, setShowAgentIdDialog] = useState(false);
  const [newAgentId, setNewAgentId] = useState("");
  const [thoughtlyPhone, setThoughtlyPhone] = useState("");

  // Dialer & SMS State
  const [showDialer, setShowDialer] = useState(false);
  const [showSMS, setShowSMS] = useState(false);
  const [selectedContact, setSelectedContact] = useState({ name: "", phone: "" });

  // Display name from the assistant_name field (capitalized)
  const agentName = React.useMemo(() => {
    const name = form.assistant_name || "sarah";
    return name.charAt(0).toUpperCase() + name.slice(1);
  }, [form.assistant_name]);

  const handleCallContact = (conv) => {
    setSelectedContact({ name: conv.name, phone: conv.phone });
    setShowDialer(true);
  };

  const handleSMSContact = (conv) => {
    setSelectedContact({ name: conv.name, phone: conv.phone });
    setShowSMS(true);
  };

  const configureThoughtlyWebhook = async () => {
    setWebhookConfiguring(true);
    setWebhookResult(null);
    setWebhookError(null);
    try {
      const response = await base44.functions.invoke('configureThoughtlyWebhook', {
        agent_id: thoughtlyAgentId
      });
      setWebhookResult(response.data);
    } catch (err) {
      console.error('Full error:', err);
      const d = err?.response?.data;
      const details = d?.details ?? d?.error ?? err.message ?? "Failed to configure webhook";
      setWebhookError(typeof details === 'string' ? details : JSON.stringify(details, null, 2));
    } finally {
      setWebhookConfiguring(false);
    }
  };

  const testThoughtlyConnection = async () => {
    setWebhookConfiguring(true);
    setWebhookResult(null);
    setWebhookError(null);
    try {
      const response = await base44.functions.invoke('listThoughtlyAgents', {});
      const agents = response.data?.agents || [];
      if (agents.length > 0) {
        setWebhookResult({ 
          success: true, 
          message: `✅ API Key Valid! Found ${agents.length} agent(s)`,
          agents: agents
        });
        // Auto-fill first agent ID
        if (agents[0]?.id) {
          setThoughtlyAgentId(agents[0].id);
        }
      } else {
        setWebhookResult({ 
          success: true, 
          message: `✅ API Key Valid! (No agents found)`, 
          agents: []
        });
      }
    } catch (err) {
      console.error('Connection test error:', err);
      const d = err?.response?.data;
      const details = d?.details ?? d?.error ?? err.message ?? "Unknown error";
      
      if (d?.details && (d.details.hasApiKey === false || d.details.hasTeamId === false)) {
        setWebhookError(`Missing Credentials: API Key (${d.details.hasApiKey ? 'OK' : 'Missing'}), Team ID (${d.details.hasTeamId ? 'OK' : 'Missing'}). Please check your Secrets settings.`);
      } else {
        setWebhookError('Connection Failed: ' + (typeof details === 'string' ? details : JSON.stringify(details)));
      }
    } finally {
      setWebhookConfiguring(false);
    }
  };

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const { data: twilioSettings = [] } = useQuery({
    queryKey: ["twilio-settings", company?.id],
    queryFn: () => company ? base44.entities.TwilioSettings.filter({ company_id: company.id }, "-updated_date", 50) : [],
    enabled: !!company,
    initialData: [],
  });

  const twilioConfig = React.useMemo(() => {
  if (!twilioSettings?.length) return null;
  // Prefer the active Thoughtly config first, then any record with a thoughtly_phone, else most recent
  return (
    twilioSettings.find(s => s.use_thoughtly_ai === true) ||
    twilioSettings.find(s => !!s.thoughtly_phone) ||
    twilioSettings[0]
  );
}, [twilioSettings]);

  const timeZone = React.useMemo(() => {
    return company?.settings?.time_zone || 'America/New_York';
  }, [company]);

  useEffect(() => {
    if (!user || companies.length === 0) return;
    const owned = companies.find((c) => c.created_by === user.email);
    setCompany(owned || companies[0]);
  }, [user, companies]);

  useEffect(() => {
    // Keep phone and agent ID state in sync with Twilio config
    // When not editing, we want to reflect the latest saved value
    if (twilioConfig?.thoughtly_phone) {
      setThoughtlyPhone(twilioConfig.thoughtly_phone);
    } else if (twilioConfig?.main_phone_number) {
      setThoughtlyPhone(twilioConfig.main_phone_number);
    }

    if (twilioConfig?.thoughtly_agent_id) {
      setThoughtlyAgentId(twilioConfig.thoughtly_agent_id);
    }
  }, [twilioConfig]);

  // Load existing settings
  useQuery({
    queryKey: ["assistant-settings-sarah", company?.id],
    enabled: !!company?.id,
    queryFn: async () => {
      // First try to find any assistant settings for this company
      let rows = await base44.entities.AssistantSettings.filter({ company_id: company.id });
      // If no results, try the legacy "sarah" filter as fallback
      if (!rows || rows.length === 0) {
        rows = await base44.entities.AssistantSettings.filter({ company_id: company.id, assistant_name: "sarah" });
      }
      const rec = rows[0];
      if (rec) {
        setRecordId(rec.id);
        setForm({
          assistant_name: rec.assistant_name || "sarah",
          avatar_url: rec.avatar_url || "",
          engine: rec.engine || "gemini-2.5-flash",
          live_mode: !!rec.live_mode,
          voice_enabled: !!rec.voice_enabled,
          // Ensure we don't load old ElevenLabs IDs into the UI
          voice_id: rec.voice_id || "Polly.Joanna",
          response_speed: rec.response_speed || "normal",
          system_prompt: rec.system_prompt || DEFAULT_PROMPT,
          background_audio: rec.background_audio || "none",
          interim_audio: rec.interim_audio || "none",
          personality_assertiveness: rec.personality_assertiveness ?? 50,
          personality_humor: rec.personality_humor ?? 20,
          brand_short_name: rec.brand_short_name || "",
          short_sms_mode: rec.short_sms_mode ?? true,
          max_sms_chars: rec.max_sms_chars ?? 180,
          answer_then_ask_one: rec.answer_then_ask_one ?? true,
          calendly_booking_url: rec.calendly_booking_url || "",
          triage_categories: rec.triage_categories?.length ? rec.triage_categories : ["leak", "missing shingles", "hail", "wind", "other"],
          triage_first_question: rec.triage_first_question || "What happened? (leak, missing shingles, hail, wind, other)",
          triage_followup_leak: rec.triage_followup_leak || "Is water getting in right now? Y/N",
          escalation_keywords: rec.escalation_keywords?.length ? rec.escalation_keywords : ["emergency", "urgent", "asap", "911", "flood", "fire"],
          intent_templates: rec.intent_templates || form.intent_templates,
          scheduling_defaults: rec.scheduling_defaults || form.scheduling_defaults,
          conversation_limits: rec.conversation_limits || form.conversation_limits,
        });
      }
      return rows;
    },
  });

  // Fetch communications for active conversations
  const { data: activeComms = [] } = useQuery({
    queryKey: ['active-communications', company?.id],
    queryFn: async () => {
      if (!company) return [];
      // Fetch more history (1000 items) to show context
      const all = await base44.entities.Communication.filter({
        company_id: company.id
      }, "-created_date", 1000);
      
      const relevant = all.filter(c => c.communication_type === 'call' || c.communication_type === 'sms');
      
      // Identify participants active in the last 24 hours
      const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).getTime();
      const activeParticipants = new Set();
      
      relevant.forEach(c => {
        if (new Date(c.created_date).getTime() > twentyFourHoursAgo) {
          activeParticipants.add(c.contact_phone || c.contact_email);
        }
      });

      // Return ALL messages for active participants (showing full history from the fetched batch)
      return relevant.filter(c => activeParticipants.has(c.contact_phone || c.contact_email));
    },
    enabled: !!company,
    initialData: [],
    refetchInterval: 10000
  });

  // Fetch today's stats
  const { data: todayComms = [] } = useQuery({
    queryKey: ['today-communications', company?.id],
    queryFn: async () => {
      if (!company) return [];
      const all = await base44.entities.Communication.filter({
        company_id: company.id
      }, "-created_date", 1000);
      
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      
      return all.filter(c => new Date(c.created_date) >= todayStart);
    },
    enabled: !!company,
    initialData: [],
    refetchInterval: 10000
  });

  const stats = React.useMemo(() => {
    const calls = todayComms.filter(c => c.communication_type === 'call');
    const inboundCalls = calls.filter(c => c.direction === 'inbound');
    const totalCallMinutes = calls.reduce((sum, c) => sum + (c.duration_minutes || 0), 0);
    const emergencyCalls = calls.filter(c => c.outcome === 'emergency' || c.intent === 'emergency');
    
    return {
      totalCalls: calls.length,
      inboundCalls: inboundCalls.length,
      totalSMS: todayComms.filter(c => c.communication_type === 'sms').length,
      avgCallDuration: calls.length > 0 ? totalCallMinutes / calls.length : 0,
      emergencies: emergencyCalls.length,
      aiHandled: calls.filter(c => c.message?.includes('Sarah') || c.message?.includes(agentName) || c.ai_analyzed).length
    };
  }, [todayComms]);

  const activeByPhone = React.useMemo(() => {
    const grouped = {};
    activeComms.forEach(comm => {
      const key = comm.contact_phone || comm.contact_email;
      if (!grouped[key]) {
        grouped[key] = [];
      }
      grouped[key].push(comm);
    });
    return Object.entries(grouped).map(([phone, comms]) => ({
      phone,
      name: comms[0].contact_name || 'Unknown',
      messages: comms.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)),
      isEmergency: comms.some(c => c.outcome === 'emergency' || c.intent === 'emergency'),
      lastActivity: Math.max(...comms.map(c => new Date(c.created_date).getTime()))
    })).sort((a, b) => b.lastActivity - a.lastActivity);
  }, [activeComms]);

  const resetConversationMutation = useMutation({
    mutationFn: async (phone) => {
      return await base44.functions.invoke('resetSarahConversation', { phone_number: phone });
    },
    onSuccess: (data) => {
      alert(`✅ ${data.data?.message || 'Conversation reset!'}`);
      setResetPhone("");
    },
    onError: (error) => {
      alert(`❌ ${error.message || 'Reset failed'}`);
    }
  });

  const testSarahMutation = useMutation({
    mutationFn: async ({ phone, message }) => {
      const response = await base44.functions.invoke('testSarahConversation', {
        phone_number: phone,
        message: message,
        company_id: company?.id
      });
      return response.data || response;
    },
    onSuccess: (data) => {
      setTestConversation(prev => [
        ...prev,
        { role: 'customer', message: testMessage, timestamp: new Date().toISOString() },
        { role: 'sarah', message: data.response, timestamp: new Date().toISOString() }
      ]);
      setTestDebugInfo(data.debug);
      setTestMessage("");
    },
    onError: (error) => {
      setTestConversation(prev => [
        ...prev,
        { role: 'customer', message: testMessage, timestamp: new Date().toISOString() },
        { role: 'error', message: error.message || 'Test failed', timestamp: new Date().toISOString() }
      ]);
      setTestMessage("");
    }
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        company_id: company?.id,
        ...form,
      };
      if (recordId) {
        await base44.entities.AssistantSettings.update(recordId, payload);
        return { updated: true };
      } else {
        const created = await base44.entities.AssistantSettings.create(payload);
        setRecordId(created.id);
        return { created: true };
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["assistant-settings-sarah", company?.id] });
      alert(`✅ ${agentName} settings saved`);
    },
  });

  const testVoice = async () => {
    // Check for Twilio/Polly voices
    if (form.voice_id && form.voice_id.startsWith('Polly.')) {
      const phone = prompt("📞 Call Me to Test Voice\n\nEnter your phone number to receive a quick test call with this voice:", user?.phone || "");
      
      if (!phone) return;

      try {
        alert(" Initiating call to " + phone + "...");
        const res = await base44.functions.invoke('testVoiceCall', {
          to: phone,
          voice_id: form.voice_id,
          text: "Hi! This is " + agentName + " from " + (form.brand_short_name || "our company") + ". I am testing my new voice settings. If you like this voice, go ahead and save the settings.",
          company_id: company?.id
        });
        
        if (res.data.success) {
          alert("✅ Calling you now! Pick up to hear the voice.");
        } else {
          throw new Error(res.data.error);
        }
      } catch (err) {
        alert("❌ Test call failed: " + err.message);
      }
      return;
    }

    try {
      alert('🔊 Testing voice...');
      
      // Use ElevenLabs for other voices
      const response = await base44.functions.invoke('elevenLabsSpeak', {
        text: "Hi! I'm " + (form.brand_short_name || "Sarah") + ". This is how I sound.",
        voiceId: form.voice_id
      });

      let audioBlob;
      if (response.data?.audio_url) {
        const res = await fetch(response.data.audio_url);
        audioBlob = await res.blob();
      } else if (response.data instanceof Blob) {
        audioBlob = response.data;
      } else if (response.data instanceof ArrayBuffer) {
        audioBlob = new Blob([response.data], { type: 'audio/mpeg' });
      } else {
        throw new Error('Invalid audio format');
      }

      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      await audio.play();
      alert('✅ Voice test played!');
    } catch (error) {
      alert('❌ Voice test failed: ' + error.message);
    }
  };

  const twilioVoices = [
    { id: "Polly.Joanna", name: "Joanna (US Female - Professional)" },
    { id: "Polly.Salli", name: "Salli (US Female - Energetic)" },
    { id: "Polly.Kimberly", name: "Kimberly (US Female - Cheerful)" },
    { id: "Polly.Kendra", name: "Kendra (US Female - Mature)" },
    { id: "Polly.Ivy", name: "Ivy (US Child - Young)" },
    { id: "Polly.Matthew", name: "Matthew (US Male - Professional)" },
    { id: "Polly.Joey", name: "Joey (US Male - Energetic)" },
    { id: "Polly.Justin", name: "Justin (US Male - Young)" },
    { id: "Polly.Amy", name: "Amy (UK Female)" },
    { id: "Polly.Emma", name: "Emma (UK Female)" },
    { id: "Polly.Brian", name: "Brian (UK Male)" }
  ];

  const handleFile = async (file) => {
    if (!file) return;
    setFileUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm((f) => ({ ...f, avatar_url: file_url }));
    } finally {
      setFileUploading(false);
    }
  };

  const handleTestSend = () => {
    if (!testMessage.trim()) return;
    testSarahMutation.mutate({ phone: testPhone, message: testMessage });
  };

  const clearTestConversation = () => {
    setTestConversation([]);
    setTestDebugInfo(null);
  };

  const simulateThoughtlyCall = async () => {
    const toNumber = thoughtlyPhone || twilioConfig?.thoughtly_phone || twilioConfig?.main_phone_number;
    if (!toNumber) {
      alert('❌ Please set the Thoughtly Phone first.');
      return;
    }
    try {
      setSimulatingCall(true);
      const payload = {
        data: {
          type: 'NEW_RESPONSE',
          from: simCaller,
          to: toNumber,
          agent_id: thoughtlyAgentId || twilioConfig?.thoughtly_agent_id,
          customer_name: 'Test Caller',
          transcript: 'This is a simulated test call from Sarah Workspace.',
          intent: 'test_call',
          duration: 60
        }
      };
      const res = await base44.functions.invoke('thoughtlyWebhook', payload);
      const ok = res?.data?.success !== false;
      alert(ok ? '✅ Simulated call logged. Check Active Conversations and Communication.' : ('❌ Simulation failed: ' + (res?.data?.error || 'Unknown error')));
    } catch (e) {
      alert('❌ Simulation error: ' + (e.message || 'Unknown'));
    } finally {
      setSimulatingCall(false);
    }
  };

  const onChange = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const onSchedChange = (key, value) => setForm((f) => ({ ...f, scheduling_defaults: { ...f.scheduling_defaults, [key]: value } }));
  const onConvChange = (key, value) => setForm((f) => ({ ...f, conversation_limits: { ...f.conversation_limits, [key]: value } }));

  const updateAgentIdMutation = useMutation({
    mutationFn: async (agentId) => {
      if (!company?.id) throw new Error('Company ID missing');
      const response = await base44.functions.invoke('configureThoughtlyWebhook', {
        agent_id: agentId,
        company_id: company.id
      });
      return response.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['twilio-settings'] });
      setShowAgentIdDialog(false);
      setNewAgentId("");
      alert('✅ Agent ID updated and webhook configured!');
    },
    onError: (error) => {
      console.error(error);
      const msg = error?.response?.data?.error || error.message || "Failed to update";
      alert('❌ Failed to update: ' + msg);
    }
  });

  const handleActivateThoughtly = async () => {
    if (!company?.id) {
      alert('❌ Company not found');
      return;
    }

    // Step 1: Get Agent ID
    const agentId = prompt("Please enter your Thoughtly Agent ID (e.g., xlHlPjRc):", thoughtlyAgentId || "");
    if (!agentId) return;

    // Step 2: Get Thoughtly Phone Number
    const thoughtlyNum = prompt("Please enter the Thoughtly Agent Phone Number (e.g., +1888...):\n\n⚠️ IMPORTANT: This must be the number Thoughtly assigned to your agent, NOT your Twilio number.", thoughtlyPhone || "");
    if (!thoughtlyNum) return;

    if (twilioConfig?.main_phone_number && thoughtlyNum.replace(/\D/g, '') === twilioConfig.main_phone_number.replace(/\D/g, '')) {
      alert("❌ Error: The Thoughtly Phone Number cannot be the same as your Twilio Number.\n\nPlease enter the forwarding number provided by Thoughtly.");
      return;
    }

    setIsActivatingThoughtly(true);
    try {
      // Use configureThoughtlyWebhook to link agent and set forwarding number
      const response = await base44.functions.invoke('configureThoughtlyWebhook', {
        agent_id: agentId,
        company_id: company.id,
        phone_number: thoughtlyNum 
      });

      const data = response.data;

      if (data.success) {
         alert(`✅ Thoughtly agent linked successfully!\n\nCalls to your Twilio number will now forward to Thoughtly (${thoughtlyNum}).`);
         setThoughtlyAgentId(agentId);
         setThoughtlyPhone(thoughtlyNum);
         queryClient.invalidateQueries({ queryKey: ["twilio-settings"] });
         queryClient.invalidateQueries({ queryKey: ["assistant-settings-sarah"] });
      } else {
         alert('❌ Failed: ' + (data.error || 'Unknown error'));
      }
    } catch (error) {
      console.error(error);
      const msg = error?.response?.data?.error || error.message || "Unknown error";
      alert('❌ Error: ' + msg);
    } finally {
      setIsActivatingThoughtly(false);
    }
  };

  return (
    <>
      <Dialog open={showAgentIdDialog} onOpenChange={setShowAgentIdDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Thoughtly Agent ID</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Agent ID</Label>
              <Input
                value={newAgentId}
                onChange={(e) => setNewAgentId(e.target.value)}
                placeholder="e.g., e25d96bd-a768-40eb-a330-b0e8e3ade0b8"
                className="mt-2"
              />
              <p className="text-xs text-gray-500 mt-2">
                Get your Agent ID from Thoughtly dashboard
              </p>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowAgentIdDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => updateAgentIdMutation.mutate(newAgentId)}
                disabled={!newAgentId.trim() || updateAgentIdMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
              >
                {updateAgentIdMutation.isPending ? "Updating..." : "Update"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <div className="p-6 space-y-6 bg-gradient-to-br from-blue-50 to-purple-50 min-h-screen">
      <div className="flex items-center justify-between">
      <div>
        <div className="flex items-center gap-3">
          {form.avatar_url && (
            <img src={form.avatar_url} alt={agentName} className="w-16 h-16 rounded-full object-cover border-4 border-white shadow-lg" />
          )}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{agentName} Workspace</h1>
            <p className="text-gray-600">Sales Assistant • Lead Qualifier • Follow-up</p>
          </div>
        </div>
      </div>
      <Badge className="bg-blue-600 text-white">Active</Badge>
      </div>

      {/* Thoughtly Status Banner */}
      {twilioConfig?.use_thoughtly_ai && twilioConfig?.thoughtly_agent_id ? (
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-green-900">🚀 Thoughtly AI Active</h3>
                  <p className="text-sm text-green-700">Zero-latency voice responses • Agent ID: {twilioConfig.thoughtly_agent_id}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setNewAgentId(twilioConfig.thoughtly_agent_id || "");
                    setShowAgentIdDialog(true);
                  }}
                  className="text-green-700 border-green-700 hover:bg-green-100"
                >
                  Change Agent ID
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={async () => {
                    if (!confirm("Are you sure? This will disconnect Thoughtly and restore standard Sarah voice handling.")) return;
                    try {
                      setWebhookConfiguring(true);
                      const res = await base44.functions.invoke('resetTwilioToDefault', { company_id: company.id });
                      if (res.data.success) {
                        alert("✅ " + res.data.message);
                        queryClient.invalidateQueries({ queryKey: ["twilio-settings"] });
                        setWebhookResult(null);
                        setWebhookError(null);
                        setThoughtlyAgentId(""); 
                        setThoughtlyPhone("");
                      } else {
                        alert("❌ Reset failed: " + (res.data.error || "Unknown error"));
                      }
                    } catch (e) {
                      alert("❌ Error: " + e.message);
                    } finally {
                      setWebhookConfiguring(false);
                    }
                  }}
                  className="text-red-600 border-red-200 hover:bg-red-50"
                  disabled={webhookConfiguring}
                >
                  Disconnect
                </Button>
                <Badge className="bg-green-600 text-white">Live</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-gradient-to-r from-orange-50 to-yellow-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-orange-900">⚡ Experiencing Latency?</h3>
                  <p className="text-sm text-orange-700">Switch to Thoughtly for instant, natural voice responses</p>
                </div>
              </div>
              <Button 
                onClick={handleActivateThoughtly}
                disabled={isActivatingThoughtly}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isActivatingThoughtly ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Activating...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Switch to Thoughtly
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="live" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="live">📞 Live Dashboard</TabsTrigger>
          <TabsTrigger value="performance">📊 Performance</TabsTrigger>
          <TabsTrigger value="test">🧪 Test & Debug</TabsTrigger>
          <TabsTrigger value="settings">⚙️ Settings</TabsTrigger>
        </TabsList>

        {/* Live Dashboard Tab */}
        <TabsContent value="live" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Active Conversations (Today)</h2>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">Live</span>
            </div>
          </div>

          {activeByPhone.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center text-gray-500">
                <PhoneOff className="w-16 h-16 mx-auto mb-3 text-gray-300" />
                <p className="font-medium">No active conversations</p>
                <p className="text-sm mt-1">When calls or messages come in, they'll appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {activeByPhone.map((conversation, idx) => (
                <ConversationCard 
                  key={idx}
                  conversation={conversation}
                  company={company}
                  onCall={handleCallContact}
                  onSMS={handleSMSContact}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Phone className="w-4 h-4 text-blue-600" />
                  <span className="text-xs text-gray-600">Total Calls</span>
                </div>
                <div className="text-2xl font-bold">{stats.totalCalls}</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <PhoneIncoming className="w-4 h-4 text-green-600" />
                  <span className="text-xs text-gray-600">Inbound</span>
                </div>
                <div className="text-2xl font-bold text-green-700">{stats.inboundCalls}</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquare className="w-4 h-4 text-purple-600" />
                  <span className="text-xs text-gray-600">SMS</span>
                </div>
                <div className="text-2xl font-bold text-purple-700">{stats.totalSMS}</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs text-gray-600">Avg Duration</span>
                </div>
                <div className="text-2xl font-bold text-indigo-700">
                  {stats.avgCallDuration.toFixed(1)}m
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-yellow-600" />
                  <span className="text-xs text-gray-600">AI Handled</span>
                </div>
                <div className="text-2xl font-bold text-yellow-700">{stats.aiHandled}</div>
              </CardContent>
            </Card>

            <Card className="bg-red-50 border-red-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span className="text-xs text-red-600">Emergencies</span>
                </div>
                <div className="text-2xl font-bold text-red-700">{stats.emergencies}</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  AI Performance Today
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Answer Rate</span>
                  <div className="flex items-center gap-2">
                    <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-green-500"
                        style={{ 
                          width: `${stats.inboundCalls > 0 ? (stats.aiHandled / stats.inboundCalls * 100) : 0}%` 
                        }}
                      />
                    </div>
                    <span className="text-sm font-semibold">
                      {stats.inboundCalls > 0 ? ((stats.aiHandled / stats.inboundCalls * 100).toFixed(0)) : 0}%
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Avg Handle Time</span>
                  <span className="text-sm font-semibold">{stats.avgCallDuration.toFixed(1)} min</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Total Volume</span>
                  <span className="text-sm font-semibold">{stats.totalCalls} calls</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">SMS Responses</span>
                  <span className="text-sm font-semibold">{stats.totalSMS}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-purple-600" />
                  Quick Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg">
                  <div className="text-sm text-blue-700 font-medium mb-1">AI Automation Rate</div>
                  <div className="text-2xl font-bold text-blue-900">
                    {stats.inboundCalls > 0 ? ((stats.aiHandled / stats.inboundCalls * 100).toFixed(0)) : 0}%
                  </div>
                  <p className="text-xs text-blue-600 mt-1">
                    {stats.aiHandled} of {stats.inboundCalls} calls handled by {agentName}
                  </p>
                </div>

                <div className={`p-3 rounded-lg ${
                  stats.emergencies > 0 
                    ? 'bg-gradient-to-r from-red-50 to-red-100' 
                    : 'bg-gradient-to-r from-green-50 to-green-100'
                }`}>
                  <div className={`text-sm font-medium mb-1 ${
                    stats.emergencies > 0 ? 'text-red-700' : 'text-green-700'
                  }`}>
                    Emergency Calls
                  </div>
                  <div className={`text-2xl font-bold ${
                    stats.emergencies > 0 ? 'text-red-900' : 'text-green-900'
                  }`}>
                    {stats.emergencies}
                  </div>
                  <p className={`text-xs mt-1 ${
                    stats.emergencies > 0 ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {stats.emergencies > 0 ? 'Requires immediate attention' : 'No emergencies today'}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Test & Debug Tab */}
        <TabsContent value="test" className="space-y-6">
          <Card className="bg-purple-50 border-purple-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bug className="w-5 h-5 text-purple-600" />
                  <CardTitle>Test Sarah Conversation</CardTitle>
                </div>
                <Button variant="ghost" size="sm" onClick={clearTestConversation} className="text-purple-600">
                  <Trash2 className="w-4 h-4 mr-1" /> Clear
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                Simulate a customer SMS conversation to test Sarah's responses and see debug info.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white rounded-lg border p-4">
                  <Input 
                    placeholder="Test Phone: +15551234567" 
                    value={testPhone}
                    onChange={(e) => setTestPhone(e.target.value)}
                    className="mb-3"
                  />
                  
                  <ScrollArea className="h-64 mb-3 pr-2">
                    <div className="space-y-3">
                      {testConversation.length === 0 && (
                        <p className="text-center text-gray-400 text-sm py-8">
                          Send a test message to start...
                        </p>
                      )}
                      {testConversation.map((msg, i) => (
                        <div key={i} className={`flex ${msg.role === 'customer' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                            msg.role === 'customer' ? 'bg-blue-500 text-white' :
                            msg.role === 'sarah' ? 'bg-gray-100 text-gray-900' :
                            'bg-red-100 text-red-700'
                          }`}>
                            {msg.role === 'sarah' && <span className="font-semibold text-purple-600">{agentName}: </span>}
                            {msg.message}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Type a test message..." 
                      value={testMessage}
                      onChange={(e) => setTestMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleTestSend()}
                      disabled={testSarahMutation.isPending}
                    />
                    <Button 
                      onClick={handleTestSend}
                      disabled={!testMessage.trim() || testSarahMutation.isPending}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      {testSarahMutation.isPending ? "..." : <Send className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
                
                <div className="bg-gray-900 rounded-lg p-4 text-xs font-mono">
                  <div className="flex items-center gap-2 mb-3 text-gray-400">
                    <Bug className="w-4 h-4" />
                    <span>Debug Info</span>
                  </div>
                  <ScrollArea className="h-72">
                    {testDebugInfo ? (
                      <div className="space-y-2 text-gray-300">
                        <div>
                          <span className="text-purple-400">Contact:</span> {testDebugInfo.contactName || 'Unknown'}
                          {testDebugInfo.isNewContact && <Badge className="ml-2 bg-green-600">NEW</Badge>}
                        </div>
                        <div>
                          <span className="text-purple-400">Lead Info:</span>
                          <pre className="mt-1 text-green-400 whitespace-pre-wrap text-xs">
                            {JSON.stringify(testDebugInfo.extractedInfo, null, 2)}
                          </pre>
                        </div>
                        <div>
                          <span className="text-purple-400">Missing:</span>
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {testDebugInfo.missingInfo?.map(m => (
                              <Badge key={m} variant="outline" className="text-yellow-400 border-yellow-400">{m}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-500">Send a message to see debug info...</p>
                    )}
                  </ScrollArea>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <div className="flex items-center gap-3">
                <RefreshCw className="w-5 h-5 text-blue-600" />
                <CardTitle>Reset Conversation Cap</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                If {agentName} stopped responding due to hitting the conversation limit, reset it here.
              </p>
              <div className="flex gap-3">
                <Input 
                  placeholder="+1234567890" 
                  value={resetPhone}
                  onChange={(e) => setResetPhone(e.target.value)}
                  className="max-w-xs"
                />
                <Button 
                  onClick={() => resetConversationMutation.mutate(resetPhone)}
                  disabled={!resetPhone || resetConversationMutation.isPending}
                >
                  <RefreshCw className="w-4 h-4 mr-1" />
                  {resetConversationMutation.isPending ? "Resetting..." : "Reset"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-green-600" />
                <CardTitle>Thoughtly Webhook Configuration</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">
                Configure your Thoughtly AI agent to send call logs to the CRM automatically.
              </p>
              
              <div>
                <Label htmlFor="thoughtly_agent_id">Thoughtly Agent ID</Label>
                <Input
                  id="thoughtly_agent_id"
                  value={thoughtlyAgentId}
                  onChange={(e) => setThoughtlyAgentId(e.target.value)}
                  placeholder="xlHlPjRc"
                  className="mt-2"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Find this in your Thoughtly dashboard URL
                </p>
              </div>

              <div>
                <Label htmlFor="thoughtly_phone">Thoughtly Phone</Label>
                <Input
                  id="thoughtly_phone"
                  value={thoughtlyPhone}
                  onChange={(e) => setThoughtlyPhone(e.target.value)}
                  placeholder="e.g., 216-999-4342"
                  className="mt-2"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Number your Thoughtly agent answers; calls to this number will sync here.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Button
                  onClick={testThoughtlyConnection}
                  disabled={webhookConfiguring}
                  variant="outline"
                >
                  {webhookConfiguring ? "Testing..." : "1️⃣ Test API Key"}
                </Button>
                <Button
                  onClick={async () => {
                    setWebhookConfiguring(true);
                    setWebhookResult(null);
                    setWebhookError(null);
                    try {
                      const response = await base44.functions.invoke('configureThoughtlyWebhook', {
                        agent_id: thoughtlyAgentId,
                        company_id: company?.id,
                        phone_number: thoughtlyPhone
                      });
                      setWebhookResult(response.data);
                      queryClient.invalidateQueries({ queryKey: ["twilio-settings"] });
                    } catch (err) {
                      const d = err?.response?.data;
                      const details = d?.details ?? d?.error ?? err.message ?? "Failed";
                      setWebhookError(typeof details === 'string' ? details : JSON.stringify(details, null, 2));
                    } finally {
                      setWebhookConfiguring(false);
                    }
                  }}
                  disabled={webhookConfiguring || !thoughtlyAgentId || !company?.id}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {webhookConfiguring ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    <>
                      <Phone className="w-4 h-4 mr-2" />
                      2️⃣ Connect Thoughtly
                    </>
                  )}
                </Button>
                <Button
                  onClick={async () => {
                    try {
                      setWebhookConfiguring(true);
                      setWebhookResult(null);
                      setWebhookError(null);
                      const res = await base44.functions.invoke('testThoughtlyWebhook', { company_id: company.id });
                      setWebhookResult(res.data);
                    } catch (err) {
                      setWebhookError(err?.response?.data?.error || err.message || 'Test failed');
                    } finally {
                      setWebhookConfiguring(false);
                    }
                  }}
                  disabled={webhookConfiguring || !company?.id}
                  variant="outline"
                >
                  <Bug className="w-4 h-4 mr-2" />
                  3️⃣ Test Webhook
                </Button>
              </div>

              <div className="pt-2 border-t mt-4">
                <Button 
                  variant="destructive" 
                  className="w-full"
                  onClick={async () => {
                    if (!confirm("Are you sure? This will disconnect Thoughtly and restore standard Sarah voice handling.")) return;
                    try {
                      setWebhookConfiguring(true);
                      const res = await base44.functions.invoke('resetTwilioToDefault', { company_id: company.id });
                      if (res.data.success) {
                        alert("✅ " + res.data.message);
                        queryClient.invalidateQueries({ queryKey: ["twilio-settings"] });
                        setWebhookResult(null);
                        setWebhookError(null);
                        // Also clear local state
                        setThoughtlyAgentId(""); 
                        setThoughtlyPhone("");
                      } else {
                        alert("❌ Reset failed: " + (res.data.error || "Unknown error"));
                      }
                    } catch (e) {
                      alert("❌ Error: " + e.message);
                    } finally {
                      setWebhookConfiguring(false);
                    }
                  }}
                  disabled={webhookConfiguring}
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reset to Original (Disconnect Thoughtly)
                </Button>
              </div>

              {webhookResult && (
                <div className="bg-green-100 border border-green-300 rounded-lg p-3">
                  {webhookResult.webhook_url ? (
                    <>
                      <p className="text-green-900 font-semibold mb-2">✅ Webhook Configured!</p>
                      <div className="text-xs text-green-800 space-y-1">
                        <p><strong>Webhook URL:</strong> {webhookResult.webhook_url}</p>
                        <p><strong>Agent ID:</strong> {webhookResult.agent_id}</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <p className="text-green-900 font-semibold mb-2">{webhookResult.message}</p>
                      <div className="text-xs text-green-800 space-y-1">
                        <p><strong>Your Agents:</strong></p>
                        {webhookResult.agents?.map((agent, i) => (
                          <div key={i} className="flex items-center justify-between bg-white rounded p-2 mt-1">
                            <div>
                              <p className="font-semibold">{agent.name || 'Unnamed Agent'}</p>
                              <p className="text-gray-600">ID: {agent.id}</p>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => setThoughtlyAgentId(agent.id)}
                              variant={thoughtlyAgentId === agent.id ? "default" : "outline"}
                            >
                              {thoughtlyAgentId === agent.id ? "Selected" : "Select"}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}

              {webhookError && (
                <div className="bg-red-100 border border-red-300 rounded-lg p-3">
                  <p className="text-red-900 font-semibold">❌ Error</p>
                  <pre className="text-xs text-red-800 whitespace-pre-wrap break-all">{typeof webhookError === 'string' ? webhookError : JSON.stringify(webhookError, null, 2)}</pre>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-emerald-50 border-emerald-200">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-emerald-600" />
                <CardTitle>Simulate Thoughtly Call (no real call)</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-gray-600">Creates a test call via the Thoughtly webhook and logs it to the CRM.</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
                <div className="md:col-span-2">
                  <Label>Caller Number</Label>
                  <Input value={simCaller} onChange={(e) => setSimCaller(e.target.value)} placeholder="+12165550123" className="mt-1" />
                </div>
                <Button onClick={simulateThoughtlyCall} disabled={simulatingCall} className="bg-emerald-600 hover:bg-emerald-700">
                  {simulatingCall ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Simulating...</>) : (<><Phone className="w-4 h-4 mr-2" />Simulate Thoughtly Call</>)}
                </Button>
              </div>
              <p className="text-xs text-emerald-700">Target number: {thoughtlyPhone || twilioConfig?.thoughtly_phone || twilioConfig?.main_phone_number || 'Not configured'}</p>
            </CardContent>
          </Card>

          <Card className="bg-pink-50 border-pink-200">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-pink-600" />
                <CardTitle>📞 Test Sarah Voice Call</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-gray-600">Twilio will call you to hear Sarah's voice in action.</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
                <div className="md:col-span-2">
                  <Label>Your Phone Number</Label>
                  <Input 
                    value={voiceTestPhone} 
                    onChange={(e) => setVoiceTestPhone(e.target.value)} 
                    placeholder="+12165551234" 
                    className="mt-1"
                  />
                </div>
                <Button 
                  onClick={async () => {
                    if (!voiceTestPhone.trim()) {
                      alert('Please enter a phone number');
                      return;
                    }
                    try {
                      setVoiceTestLoading(true);
                      const res = await base44.functions.invoke('testSarahVoiceCall', {
                        phone_number: voiceTestPhone,
                        company_id: company?.id
                      });
                      if (res.data?.success) {
                        alert(`✅ Calling ${voiceTestPhone} with Sarah's voice...`);
                      } else {
                        alert('❌ ' + (res.data?.error || 'Failed to initiate call'));
                      }
                    } catch (e) {
                      alert('❌ Error: ' + (e.message || 'Unknown error'));
                    } finally {
                      setVoiceTestLoading(false);
                    }
                  }}
                  disabled={voiceTestLoading}
                  className="bg-pink-600 hover:bg-pink-700"
                >
                  {voiceTestLoading ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Calling...
                    </>
                  ) : (
                    <>
                      <Phone className="w-4 h-4 mr-2" />
                      Call Me Now
                    </>
                  )}
                </Button>
              </div>
              <p className="text-xs text-pink-700">You'll receive a call with Sarah's configured voice</p>
            </CardContent>
          </Card>

          {(twilioConfig?.thoughtly_agent_id || twilioConfig?.main_phone_number) && (
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-green-600" />
                  <CardTitle>📞 Test Live Call</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Call your assistant to test the voice AI in action.
                </p>
                <div className="bg-white rounded-lg border-2 border-green-300 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-xs text-gray-500">Assistant Phone Number</Label>
                      <div className="text-2xl font-bold text-green-700 mt-1">
                        {editingLivePhone ? (
                          <div className="flex items-center gap-2">
                            <Input
                              value={livePhoneDraft}
                              onChange={(e) => setLivePhoneDraft(e.target.value)}
                              placeholder="+12165550123"
                              className="max-w-xs"
                            />
                            <Button
                              size="sm"
                              onClick={async () => {
                                if (!company?.id || !livePhoneDraft) return;
                                try {
                                  const res = await base44.functions.invoke('updateThoughtlyPhone', {
                                    company_id: company.id,
                                    phone: livePhoneDraft,
                                  });
                                  
                                  if (res.data?.success) {
                                    setEditingLivePhone(false);
                                    queryClient.invalidateQueries({ queryKey: ["twilio-settings"] });
                                    alert('✅ Phone number updated!');
                                  } else {
                                    alert('❌ Error updating phone: ' + (res.data?.error || 'Unknown error'));
                                  }
                                } catch (err) {
                                  console.error(err);
                                  alert('❌ Error updating phone: ' + err.message);
                                }
                              }}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              Save
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => setEditingLivePhone(false)}>Cancel</Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-3">
                            <span>{twilioConfig?.main_phone_number || 'Not configured'}</span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setLivePhoneDraft(twilioConfig?.main_phone_number || '');
                                setEditingLivePhone(true);
                              }}
                            >
                              Edit
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => {
                        // Use main Twilio number for testing Sarah voice (not Thoughtly)
                        const num = twilioConfig?.main_phone_number;
                        if (num) {
                          window.open(`tel:${num}`,'_self');
                        } else {
                          alert('No Twilio phone number configured. Check TwilioSettings.');
                        }
                      }}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Phone className="w-4 h-4 mr-2" />
                      Call Now
                    </Button>
                  </div>
                </div>
                <Button
                  onClick={async () => {
                    try {
                      const result = await base44.functions.invoke('testThoughtlyCall', {
                        companyId: company?.id
                      });
                      const data = result.data;
                      if (data.success) {
                        alert(`✅ Thoughtly is ready!\n\n📞 Phone Number: ${data.details.phone_number}\n\n📋 Next Steps:\n${data.details.next_steps.join('\n')}`);
                      } else {
                        alert(`❌ Error: ${data.error}\n\nStep: ${data.step}`);
                      }
                    } catch (error) {
                      alert('❌ Test failed: ' + error.message);
                    }
                  }}
                  variant="outline"
                  className="w-full"
                >
                  <Bug className="w-4 h-4 mr-2" />
                  Run Diagnostic Test
                </Button>
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-xs text-blue-800">
                    <strong>💡 Tip:</strong> This calls directly to Thoughtly - ultra-low latency with natural voice responses!
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          {/* Assistant Name */}
          <Card className="border-blue-200 bg-blue-50/30">
            <CardHeader>
              <CardTitle>Assistant Name</CardTitle>
              <CardDescription>Change the name of your AI assistant. This affects how it introduces itself and appears throughout the app.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-3 items-end">
                <div className="flex-1">
                  <Label>Name</Label>
                  <Input 
                    value={form.assistant_name || ""} 
                    onChange={(e) => onChange('assistant_name', e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))} 
                    placeholder="e.g. john, sarah, alex"
                    className="mt-1 bg-white"
                  />
                  <p className="text-xs text-gray-500 mt-1">Lowercase, no spaces. This is the internal identifier.</p>
                </div>
                <div className="text-lg font-semibold text-blue-700 pb-1">
                  Display: {agentName}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Avatar</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-6">
                {form.avatar_url ? (
                  <img src={form.avatar_url} alt={agentName} className="w-24 h-24 rounded-full object-cover border-4 border-blue-200" />
                ) : (
                  <div className="w-24 h-24 rounded-full border-4 border-gray-200 flex items-center justify-center text-gray-400">
                    <Sparkles className="w-8 h-8" />
                  </div>
                )}
                <div>
                  <input type="file" id="sarah-avatar" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
                  <label htmlFor="sarah-avatar">
                    <Button variant="outline" className="gap-2" disabled={fileUploading} type="button" asChild>
                      <span className="cursor-pointer">
                        <Upload className="w-4 h-4" /> {fileUploading ? "Uploading..." : "Upload New Avatar"}
                      </span>
                    </Button>
                  </label>
                  <p className="text-xs text-gray-500 mt-2">Recommended: Square image, 500x500px or larger</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>AI Engine (Beta)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Engine</Label>
                <Select value={form.engine} onValueChange={(v) => onChange('engine', v)}>
                  <SelectTrigger className="w-full mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gemini-2.0-flash-exp">Gemini 2.0 Flash Experimental</SelectItem>
                    <SelectItem value="gemini-2.0-flash-live-preview-04-09">Gemini 2.0 Flash Live Preview</SelectItem>
                    <SelectItem value="gemini-2.5-flash-native-audio-preview-12-2025">Gemini 2.5 Flash Native Audio</SelectItem>
                    <SelectItem value="gemini-2.0-flash">Gemini 2.0 Flash (Stable)</SelectItem>
                    <SelectItem value="gemini-1.5-flash">Gemini 1.5 Flash</SelectItem>
                    <SelectItem value="gpt-4o">OpenAI (GPT-4o)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-2">
                  Gemini enables low-latency voice and better realtime performance.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
           <CardHeader>
             <CardTitle>Live (Real-time) - Beta</CardTitle>
           </CardHeader>
           <CardContent className="space-y-3">
             <p className="text-sm text-gray-600">Enable Gemini Multimodal Live API for push-to-talk voice</p>
             <div className="flex items-center justify-between mb-4">
               <Label>Enable Live Mode</Label>
               <Switch checked={form.live_mode} onCheckedChange={(v) => {
                 console.log('🎙️ [SARAH LIVE MODE] Toggle:', v ? 'ENABLED' : 'DISABLED');
                 onChange('live_mode', v);

                 if (v) {
                   console.log('📢 [SARAH GREETING] Playing greeting using Web Speech API');
                   const greetingText = `Hello! I'm live now. How can I help you today?`;

                   // Function to speak when voices are ready
                   const speak = () => {
                     const utterance = new SpeechSynthesisUtterance(greetingText);
                     utterance.rate = 1.0;
                     utterance.pitch = 1.0;
                     utterance.volume = 1.0;

                     let voices = window.speechSynthesis.getVoices();
                     console.log('🔊 [SARAH GREETING] Voices loaded:', voices.length);

                     if (voices.length > 0) {
                       // Prefer a female voice
                       let selectedVoice = voices.find(v => 
                         v.name.includes('Female') || 
                         v.name.includes('woman') ||
                         v.name.includes('Samantha') || 
                         v.name.includes('Victoria') ||
                         v.name.includes('Zira') ||
                         v.name.includes('Google US English Female')
                       );

                       // Fallback to any available voice
                       if (!selectedVoice) selectedVoice = voices[0];

                       utterance.voice = selectedVoice;
                       console.log('🎤 [SARAH GREETING] Using voice:', selectedVoice.name, selectedVoice.lang);
                     } else {
                       console.warn('⚠️ [SARAH GREETING] No voices available');
                     }

                     utterance.onstart = () => console.log('▶️ [SARAH GREETING] Speech STARTED NOW');
                     utterance.onend = () => console.log('⏹️ [SARAH GREETING] Speech ENDED');
                     utterance.onerror = (e) => console.error('❌ [SARAH GREETING] Error:', e.error);

                     console.log('🗣️ [SARAH GREETING] Speaking text:', greetingText);
                     window.speechSynthesis.cancel(); // Clear any existing utterances
                     window.speechSynthesis.speak(utterance);
                   };

                   // Check if voices are already loaded
                   if (window.speechSynthesis.getVoices().length > 0) {
                     console.log('✅ [SARAH GREETING] Voices ready, speaking now');
                     speak();
                   } else {
                     // Wait for voices to load
                     console.log('⏳ [SARAH GREETING] Waiting for voices to load...');
                     window.speechSynthesis.onvoiceschanged = () => {
                       console.log('✅ [SARAH GREETING] Voices loaded!');
                       speak();
                     };
                   }
                 }
               }} />
             </div>

             {form.live_mode && (
               <div className="pt-4 border-t">
                 <Label className="mb-2 block">Live Voice Preview</Label>
                 {form.engine === 'gpt-4o' || form.engine === 'gpt-4o-realtime' ? (
                   <OpenAILiveClient systemPrompt={form.system_prompt} />
                 ) : (
                   <GeminiLiveClient 
                     systemPrompt={form.system_prompt} 
                     model={form.engine}
                   />
                 )}
               </div>
             )}
           </CardContent>
          </Card>

          <SarahVoiceSettings companyId={company?.id} />

          {/* Response Speed */}
          <Card className="bg-blue-50 border-blue-200 shadow-sm">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-blue-600" />
                  <Label className="text-lg font-bold text-blue-900">Response Speed & Latency</Label>
                  <Badge className="bg-blue-600 text-white hover:bg-blue-700">New</Badge>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4 items-center">
                <div className="space-y-2">
                  <Select
                    value={form.response_speed}
                    onValueChange={(value) => onChange("response_speed", value)}
                  >
                    <SelectTrigger className="bg-white border-blue-300 h-10 font-medium">
                      <SelectValue placeholder="Select speed" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="normal">Normal (Balanced - Includes Typing Sounds)</SelectItem>
                      <SelectItem value="fast">Fast (Reduced Latency - No Sounds)</SelectItem>
                      <SelectItem value="ultra_fast">Ultra Fast (Instant - Minimal Memory)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-sm text-blue-800">
                  {form.response_speed === 'normal' && "✅ Uses typing sounds and full memory. Best for natural feel."}
                  {form.response_speed === 'fast' && "⚡ Skips audio effects to reply faster. Good for efficient calls."}
                  {form.response_speed === 'ultra_fast' && "🚀 Maximum speed. Skips Knowledge Base and limits memory."}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-100 bg-purple-50/30">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <CardTitle className="text-base">Presence (Beta)</CardTitle>
              </div>
              <CardDescription className="text-xs">
                Customize the experience to mimic human conversation.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Background Audio</Label>
                  <Select
                    value={form.background_audio}
                    onValueChange={(value) => onChange("background_audio", value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Select ambient noise" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None (Silent)</SelectItem>
                      <SelectItem value="call_center">Call Center</SelectItem>
                      <SelectItem value="office">Office Environment</SelectItem>
                      <SelectItem value="cafe">Coffee Shop</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500">
                    Subtle background noise to mimic a real environment.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Interim Audio</Label>
                  <Select
                    value={form.interim_audio}
                    onValueChange={(value) => onChange("interim_audio", value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Select waiting sound" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None (Silence)</SelectItem>
                      <SelectItem value="typing">Typing on Keyboard</SelectItem>
                      <SelectItem value="thinking">"Hmm..." / Thinking Sounds</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500">
                    Sound played while AI is generating a response. 
                    <strong className="text-blue-600 block mt-1">Note: Only audible when Response Speed is set to 'Normal'.</strong>
                  </p>
                </div>
              </div>

              <div className="space-y-6 pt-4 border-t border-purple-100">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Assertiveness Level</Label>
                    <span className="text-sm text-gray-500">
                      {form.personality_assertiveness}%
                    </span>
                  </div>
                  <Slider
                    defaultValue={[50]}
                    value={[form.personality_assertiveness]}
                    max={100}
                    step={1}
                    onValueChange={(vals) => onChange("personality_assertiveness", vals[0])}
                    className="w-full"
                  />
                  <p className="text-xs text-gray-500 flex justify-between">
                    <span>Soft suggestions</span>
                    <span>Direct & confident</span>
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Humor Level</Label>
                    <span className="text-sm text-gray-500">
                      {form.personality_humor}%
                    </span>
                  </div>
                  <Slider
                    defaultValue={[20]}
                    value={[form.personality_humor]}
                    max={100}
                    step={1}
                    onValueChange={(vals) => onChange("personality_humor", vals[0])}
                    className="w-full"
                  />
                  <p className="text-xs text-gray-500 flex justify-between">
                    <span>Serious</span>
                    <span>Witty</span>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Personality & Behavior</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
                <Brain className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-blue-900 text-sm">Connected to AI Memory</h4>
                  <p className="text-xs text-blue-700 mt-1">
                   {agentName} automatically reads from your <strong>AI Memory</strong> (website, PDFs, docs). 
                   You don't need to paste that info here.
                  </p>
                  <Link to={createPageUrl('AITraining')} className="text-xs text-blue-600 underline mt-2 inline-block font-medium">
                    Manage AI Memory →
                  </Link>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Core Instructions (System Prompt)</Label>
                  <Button 
                    type="button"
                    variant="outline" 
                    size="sm"
                    onClick={() => onChange("system_prompt", DEFAULT_PROMPT)}
                  >
                    Reset to Professional Default
                  </Button>
                </div>
                <Textarea rows={10} className="mt-2 font-mono text-sm" value={form.system_prompt} onChange={(e) => onChange("system_prompt", e.target.value)} />
                <p className="text-xs text-gray-500 mt-2">
                  Customize {agentName}'s voice, tone, and operating rules. The default focuses on empathetic, triage-first roofing support.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Business Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Brand Short Name</Label>
                <Input value={form.brand_short_name} onChange={(e) => onChange('brand_short_name', e.target.value)} placeholder="YICN Roofing" />
                <p className="text-xs text-gray-500 mt-1">How {agentName} introduces your company</p>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label className="text-base font-semibold">Short SMS Mode</Label>
                  <p className="text-sm text-gray-500 mt-1">Keep messages concise for SMS</p>
                </div>
                <Switch checked={form.short_sms_mode} onCheckedChange={(v) => onChange('short_sms_mode', v)} />
              </div>

              <div>
                <Label>Max SMS Characters</Label>
                <Input type="number" value={form.max_sms_chars} onChange={(e) => onChange('max_sms_chars', parseInt(e.target.value))} />
                <p className="text-xs text-gray-500 mt-1">Character limit for SMS responses (default: 180)</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Scheduling</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Calendly Booking URL</Label>
                <div className="flex gap-2 mt-1">
                  <Input className="flex-1" value={form.calendly_booking_url} onChange={(e) => onChange('calendly_booking_url', e.target.value)} placeholder="https://your-app.base44.app/BookAppointment?company_id=..." />
                  {form.calendly_booking_url && (
                    <>
                      <Button 
                        variant="outline" 
                        size="icon"
                        type="button"
                        onClick={() => { navigator.clipboard.writeText(form.calendly_booking_url); alert('Link copied!'); }}
                        title="Copy link"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="icon"
                        type="button"
                        onClick={() => window.open(form.calendly_booking_url, '_blank')}
                        title="Preview booking page"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">{agentName} will send this link when customers ask to schedule appointments</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <Label>Duration (min)</Label>
                  <Input type="number" value={form.scheduling_defaults.duration_min} onChange={(e) => onSchedChange('duration_min', parseInt(e.target.value))} />
                </div>
                <div>
                  <Label>Buffer (min)</Label>
                  <Input type="number" value={form.scheduling_defaults.buffer_min} onChange={(e) => onSchedChange('buffer_min', parseInt(e.target.value))} />
                </div>
                <div>
                  <Label>Start Hour</Label>
                  <Input type="number" value={form.scheduling_defaults.business_hours_start} onChange={(e) => onSchedChange('business_hours_start', parseInt(e.target.value))} />
                </div>
                <div>
                  <Label>End Hour</Label>
                  <Input type="number" value={form.scheduling_defaults.business_hours_end} onChange={(e) => onSchedChange('business_hours_end', parseInt(e.target.value))} />
                </div>
                <div>
                  <Label>Days Lookahead</Label>
                  <Input type="number" value={form.scheduling_defaults.days_lookahead} onChange={(e) => onSchedChange('days_lookahead', parseInt(e.target.value))} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Triage Process</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label className="text-base font-semibold">Answer then ask one</Label>
                  <p className="text-sm text-gray-500 mt-1">Respond to their question FIRST, then ask for one piece of info</p>
                </div>
                <Switch checked={form.answer_then_ask_one} onCheckedChange={(v) => onChange('answer_then_ask_one', v)} />
              </div>

              <div>
                <Label>Triage Categories (comma separated)</Label>
                <Input 
                  value={(form.triage_categories || []).join(', ')} 
                  onChange={(e) => onChange('triage_categories', e.target.value.split(',').map(s => s.trim()).filter(Boolean))} 
                  placeholder="leak, missing shingles, hail, wind"
                />
              </div>

              <div>
                <Label>First Triage Question</Label>
                <Textarea 
                  rows={2}
                  value={form.triage_first_question} 
                  onChange={(e) => onChange('triage_first_question', e.target.value)} 
                  placeholder="What happened? (leak, missing shingles, hail, wind, other)"
                />
                <p className="text-xs text-gray-500 mt-1">Use placeholders: {'{brand}'}, {'{agent}'}, {'{calendly_link}'}, {'{triage_first}'}</p>
              </div>

              <div>
                <Label>Leak Follow-up Question</Label>
                <Textarea 
                  rows={2}
                  value={form.triage_followup_leak} 
                  onChange={(e) => onChange('triage_followup_leak', e.target.value)} 
                  placeholder="Is water getting in right now? Y/N"
                />
                <p className="text-xs text-gray-500 mt-1">Used when customer mentions a leak</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Conversation Limits</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <Label>Max SMS turns</Label>
                  <Input type="number" value={form.conversation_limits.max_sms_turns} onChange={(e) => onConvChange('max_sms_turns', parseInt(e.target.value))} />
                </div>
                <div>
                  <Label>Max thread duration (min)</Label>
                  <Input type="number" value={form.conversation_limits.max_thread_minutes} onChange={(e) => onConvChange('max_thread_minutes', parseInt(e.target.value))} />
                </div>
                <div>
                  <Label>Cooldown (hours)</Label>
                  <Input type="number" value={form.conversation_limits.cooldown_hours} onChange={(e) => onConvChange('cooldown_hours', parseInt(e.target.value))} />
                </div>
              </div>

              <div>
                <Label>Action at cap</Label>
                <Select value={form.conversation_limits.action_at_cap} onValueChange={(v) => onConvChange('action_at_cap', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="wrapup_notify">Wrap-up + notify admins</SelectItem>
                    <SelectItem value="wrapup_only">Wrap-up only</SelectItem>
                    <SelectItem value="silent">Silent (stop responding)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Wrap-up message</Label>
                <Textarea 
                  rows={2}
                  value={form.conversation_limits.wrapup_template} 
                  onChange={(e) => onConvChange('wrapup_template', e.target.value)} 
                  placeholder="I'll hand this to our team to finish up. Expect a follow-up shortly."
                />
                <p className="text-xs text-gray-500 mt-1">Use placeholders: {'{brand}'}, {'{agent}'}, {'{calendly_link}'}, {'{triage_first}'}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Emergency Detection</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Escalation Keywords (comma-separated)</Label>
                <Input 
                  value={(form.escalation_keywords || []).join(', ')} 
                  onChange={(e) => onChange('escalation_keywords', e.target.value.split(',').map(s => s.trim()).filter(Boolean))} 
                  placeholder="emergency, urgent, fire, flood, leak"
                />
                <p className="text-xs text-gray-500 mt-1">🚨 When detected, {agentName} alerts admins and attempts transfer</p>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="bg-blue-600 hover:bg-blue-700">
              <Save className="w-4 h-4 mr-2" /> {saveMutation.isPending ? 'Saving...' : 'Save Settings'}
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      <Dialer 
        open={showDialer} 
        onOpenChange={setShowDialer}
        defaultNumber={selectedContact.phone}
        defaultName={selectedContact.name}
      />

      <SMSDialog
        open={showSMS}
        onOpenChange={setShowSMS}
        defaultTo={selectedContact.phone}
        defaultName={selectedContact.name}
      />
    </div>
    </>
  );
}