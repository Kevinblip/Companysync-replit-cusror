import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowLeft, Trash2, Image as ImageIcon, Video } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function InspectionReports() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedJob, setSelectedJob] = useState(null);
  const [showMediaDialog, setShowMediaDialog] = useState(false);
  
  const [user, setUser] = useState(null);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
    enabled: !!user,
  });

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles'],
    queryFn: () => base44.entities.StaffProfile.list(),
    initialData: [],
  });

  const myCompany = React.useMemo(() => {
    if (!user) return null;
    const impersonatedId = sessionStorage.getItem('impersonating_company_id');
    if (impersonatedId) return companies.find(c => c.id === impersonatedId);
    
    const owned = companies.find(c => c.created_by === user.email);
    if (owned) return owned;
    
    const profile = staffProfiles.find(s => s.user_email === user.email);
    if (profile) return companies.find(c => c.id === profile.company_id);
    
    return companies[0];
  }, [user, companies, staffProfiles]);

  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['inspectionJobs', myCompany?.id],
    queryFn: () => myCompany?.id ? base44.entities.InspectionJob.filter({ company_id: myCompany.id }, '-created_date') : [],
    enabled: !!myCompany?.id
  });

  const { data: media = [] } = useQuery({
    queryKey: ['inspectionMedia', myCompany?.id],
    queryFn: () => myCompany?.id ? base44.entities.JobMedia.filter({ company_id: myCompany.id }) : [],
    initialData: [],
    enabled: !!myCompany?.id
  });

  const deleteMediaMutation = useMutation({
    mutationFn: (mediaId) => base44.entities.JobMedia.delete(mediaId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inspectionMedia'] });
    },
  });
  
  const filteredJobs = jobs
    .filter(job => job.property_address?.toLowerCase().includes(searchTerm.toLowerCase()))
    .filter(job => statusFilter === 'all' || job.status === statusFilter);

  const getJobMedia = (jobId) => {
    return media.filter(m => m.related_entity_id === jobId);
  };

  const getJobMediaCount = (jobId) => {
    return getJobMedia(jobId).length;
  };

  const handleDeleteMedia = async (mediaId) => {
    if (window.confirm('Delete this media file?')) {
      await deleteMediaMutation.mutateAsync(mediaId);
    }
  };

  const completedJobs = jobs.filter(j => j.status === 'completed').length;
  const totalPhotos = media.filter(m => m.file_type === 'photo' || m.media_type === 'photo').length;
  const totalVideos = media.filter(m => m.file_type === 'video' || m.media_type === 'video').length;

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <Button variant="ghost" onClick={() => navigate(createPageUrl('InspectionsDashboard'))} className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
        </Button>
        <h1 className="text-3xl font-bold text-gray-800">Inspection Reports</h1>

        <Card>
            <CardHeader>
                <CardTitle>Report Summary</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-4">
                <div className="p-4 bg-gray-100 rounded-lg">
                    <h4 className="text-sm text-gray-600">Total Jobs</h4>
                    <p className="text-2xl font-bold">{jobs.length}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="text-sm text-green-700">Completed</h4>
                    <p className="text-2xl font-bold">{completedJobs}</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="text-sm text-blue-700">Total Photos</h4>
                    <p className="text-2xl font-bold">{totalPhotos}</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                    <h4 className="text-sm text-purple-700">Total Videos</h4>
                    <p className="text-2xl font-bold">{totalVideos}</p>
                </div>
            </CardContent>
        </Card>

        <div className="flex gap-4">
            <Input 
                placeholder="Search by address..." 
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="max-w-sm"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="assigned">Assigned</SelectItem>
                </SelectContent>
            </Select>
        </div>

        {isLoadingJobs ? (
            <div className="text-center"><Loader2 className="animate-spin inline-block"/></div>
        ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredJobs.map(job => (
                    <Card key={job.id}>
                        <CardHeader>
                            <CardTitle className="text-base">{job.property_address || 'Unassigned Inspection'}</CardTitle>
                            <p className="text-sm text-gray-500">{job.client_name}</p>
                            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${job.status === 'completed' ? 'bg-green-100 text-green-800' : job.status === 'in_progress' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'}`}>
                              {job.status || 'pending'}
                            </span>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="text-sm text-gray-600">
                                <p>{getJobMediaCount(job.id)} media items</p>
                                <p>Created: {new Date(job.created_date).toLocaleDateString()}</p>
                            </div>
                            <div className="flex gap-2">
                                <Button 
                                  asChild 
                                  variant="outline"
                                  className="flex-1"
                                >
                                    <Link to={createPageUrl(`InspectionCapture?id=${job.id}`)}>View Details</Link>
                                </Button>
                                {getJobMediaCount(job.id) > 0 && (
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    onClick={() => {
                                      setSelectedJob(job);
                                      setShowMediaDialog(true);
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 text-red-600" />
                                  </Button>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        )}

        <Dialog open={showMediaDialog} onOpenChange={setShowMediaDialog}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Manage Media - {selectedJob?.property_address || 'Inspection'}</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
              {selectedJob && getJobMedia(selectedJob.id).map((item) => (
                <div key={item.id} className="relative group border rounded-lg overflow-hidden">
                  {(item.file_type === 'photo' || item.media_type === 'photo') ? (
                    <img 
                      src={item.file_url} 
                      alt="Inspection" 
                      className="w-full h-32 object-cover"
                    />
                  ) : (
                    <div className="w-full h-32 bg-gray-100 flex items-center justify-center">
                      <Video className="w-8 h-8 text-gray-400" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity flex items-center justify-center">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteMedia(item.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      disabled={deleteMediaMutation.isLoading}
                    >
                      {deleteMediaMutation.isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                  <div className="p-2 bg-gray-50 text-xs text-gray-600">
                    {item.section || 'General'}
                  </div>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}