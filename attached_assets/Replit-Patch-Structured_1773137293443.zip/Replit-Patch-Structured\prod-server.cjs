const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');
const prodDb = require('./db/prod-db.cjs');
const prodAuth = require('./db/prod-auth.cjs');
const prodIntegrations = require('./db/prod-integrations.cjs');
const localAuth = require('./db/local-auth.cjs');
const nodemailer = require('nodemailer');

async function sendEmail({ to, subject, html, from }) {
  const fromAddr = from || process.env.EMAIL_FROM || 'CompanySync <noreply@resend.dev>';
  const toArr = Array.isArray(to) ? to : [to];

  const smtpHost = process.env.SMTP_HOST;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const smtpPort = parseInt(process.env.SMTP_PORT || '587');

  if (smtpHost && smtpUser && smtpPass) {
    const transporter = nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: smtpPort === 465,
      auth: { user: smtpUser, pass: smtpPass }
    });
    const info = await transporter.sendMail({
      from: fromAddr,
      to: toArr.join(', '),
      subject: subject || 'No Subject',
      html: html || ''
    });
    console.log('[Email] Sent via SMTP:', info.messageId, '→', toArr.join(', '));
    return { success: true, id: info.messageId };
  }

  const resendKey = process.env.RESEND_API_KEY;
  if (!resendKey) throw new Error('No email provider configured — set SMTP_HOST/SMTP_USER/SMTP_PASS or RESEND_API_KEY');

  const resp = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: fromAddr, to: toArr, subject: subject || 'No Subject', html: html || '' })
  });
  const data = await resp.json();
  if (data.id) return { success: true, id: data.id };
  throw new Error(data.message || 'Email send failed');
}

let stripeClient = null;
async function getStripeClientProd() {
  if (stripeClient) return stripeClient;
  try {
    const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
    const xReplitToken = process.env.WEB_REPL_RENEWAL ? 'depl ' + process.env.WEB_REPL_RENEWAL : (process.env.REPL_IDENTITY ? 'repl ' + process.env.REPL_IDENTITY : null);
    if (!xReplitToken || !hostname) return null;
    const url = new URL(`https://${hostname}/api/v2/connection`);
    url.searchParams.set('include_secrets', 'true');
    url.searchParams.set('connector_names', 'stripe');
    url.searchParams.set('environment', process.env.REPLIT_DEPLOYMENT === '1' ? 'production' : 'development');
    const resp = await fetch(url.toString(), { headers: { 'Accept': 'application/json', 'X-Replit-Token': xReplitToken } });
    const data = await resp.json();
    const cs = data.items?.[0];
    if (!cs?.settings?.secret) return null;
    const Stripe = require('stripe');
    stripeClient = new Stripe(cs.settings.secret);
    return stripeClient;
  } catch (e) { console.error('[Stripe] Init error:', e.message); return null; }
}

async function billAIUsage(companyId, units = 1) {
  if (!companyId || companyId === 'companysync_master_001') return;
  try {
    const stripe = await getStripeClientProd();
    if (!stripe) return;
    const pool = prodDb.getPool();
    const { rows } = await pool.query(
      `SELECT data FROM generic_entities WHERE entity_type = 'CompanySubscription' AND company_id = $1 ORDER BY updated_date DESC NULLS LAST LIMIT 1`,
      [companyId]
    );
    const sub = rows[0]?.data;
    if (!sub?.stripe_subscription_id || !sub?.ai_usage_item_id) return;
    if (sub.plan === 'trial') return;
    await stripe.subscriptionItems.createUsageRecord(sub.ai_usage_item_id, { quantity: units, timestamp: Math.floor(Date.now() / 1000), action: 'increment' });
  } catch (e) { console.error('[Billing] AI usage billing failed (non-blocking):', e.message); }
}

const USAGE_UNIT_COSTS_PROD = { lexi: 0.05, sarah: 0.10, sms_ai: 0.02, ai_estimator: 0.08, marcus: 0.06, crew_cam: 0.12 };
async function logUsageEvent(companyId, feature, units = 1) {
  if (!companyId || companyId === 'companysync_master_001') return;
  try {
    const pool = prodDb.getPool();
    const unitCost = USAGE_UNIT_COSTS_PROD[feature] || 0.05;
    const totalCost = unitCost * units;
    const usageMonth = new Date().toISOString().slice(0, 7);
    const id = `usage_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const data = { company_id: companyId, feature, units, unit_cost: unitCost, total_cost: totalCost, usage_month: usageMonth, logged_at: new Date().toISOString() };
    await pool.query(
      `INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date) VALUES ($1, 'SubscriptionUsage', $2, $3, NOW(), NOW())`,
      [id, companyId, JSON.stringify(data)]
    );
  } catch (e) { console.error('[Usage] Failed to log usage event:', e.message); }
}

process.on('uncaughtException', (err) => {
  console.error('[Server] Uncaught exception (kept alive):', err.message, err.stack);
});
process.on('unhandledRejection', (reason) => {
  console.error('[Server] Unhandled rejection (kept alive):', reason?.message || reason);
});

const PORT = parseInt(process.env.PORT || '5000', 10);
const DIST_DIR = path.resolve(__dirname);
const SETTINGS_FILE = path.resolve('.sarah-voice-settings.json');

// Cache index.html in memory at startup for instant health-check responses
let INDEX_HTML_CACHE = null;
try {
  INDEX_HTML_CACHE = fs.readFileSync(path.join(DIST_DIR, 'index.html'), 'utf8');
  console.log('[Server] index.html cached in memory (' + INDEX_HTML_CACHE.length + ' bytes)');
} catch (e) {
  console.warn('[Server] Could not cache index.html:', e.message);
}

const BASE44_API_URL = process.env.BASE44_SARAH_API_URL || '';
const BRIDGE_SECRET = process.env.SARAH_BRIDGE_SECRET || '';
const DEFAULT_COMPANY_ID = '695944e3c1fb00b7ab716c6f';

const LEXI_BRIDGE_API_URL = process.env.BASE44_LEXI_BRIDGE_API_URL || '';
const LEXI_BRIDGE_SECRET = process.env.LEXI_NATIVE_BRIDGE_SECRET || '';

// ============================================================
// IN-MEMORY SUBSCRIBER CACHE
// Maps Twilio phone numbers -> subscriber routing config
// Refreshed when subscribers save settings, or periodically
// ============================================================
const subscriberCache = new Map(); // key: normalized phone number, value: { companyId, companyName, assistantName, routingMode, cellPhone, repName, repEmail, twilioSid, twilioToken, twilioPhone }
let cacheLastRefreshed = 0;
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

function normalizePhone(phone) {
  if (!phone) return '';
  let clean = phone.replace(/[^\d+]/g, '');
  if (clean.length === 10) clean = '+1' + clean;
  else if (clean.length === 11 && clean.startsWith('1')) clean = '+' + clean;
  else if (!clean.startsWith('+')) clean = '+' + clean;
  return clean;
}

function getCachedSubscriber(phoneNumber) {
  const normalized = normalizePhone(phoneNumber);
  return subscriberCache.get(normalized) || null;
}

function setCachedSubscriber(phoneNumber, data) {
  const normalized = normalizePhone(phoneNumber);
  if (normalized) {
    subscriberCache.set(normalized, { ...data, cachedAt: Date.now() });
    console.log(`[Cache] Set: ${normalized} -> company=${data.companyId}, rep=${data.repName || 'none'}, routing=${data.routingMode || 'sarah_answers'}`);
  }
}

function removeCachedSubscriber(phoneNumber) {
  const normalized = normalizePhone(phoneNumber);
  subscriberCache.delete(normalized);
}

function generateTwilioToken(accountSid, apiKeySid, apiKeySecret, identity, twimlAppSid, ttl = 3600) {
  const twilio = require('twilio');
  const AccessToken = twilio.jwt.AccessToken;
  const VoiceGrant = AccessToken.VoiceGrant;
  const voiceGrant = new VoiceGrant({
    outgoingApplicationSid: twimlAppSid,
    incomingAllow: true,
  });
  const token = new AccessToken(accountSid, apiKeySid, apiKeySecret, { identity, ttl });
  token.addGrant(voiceGrant);
  return token.toJwt();
}

async function refreshCacheFromAPI() {
  if (!BASE44_API_URL || !BRIDGE_SECRET) return;
  try {
    const result = await callBase44API('getAllSubscriberRouting', null);
    if (result?.subscribers && Array.isArray(result.subscribers)) {
      for (const sub of result.subscribers) {
        if (sub.phone_number) {
          setCachedSubscriber(sub.phone_number, {
            companyId: sub.company_id,
            companyName: sub.company_name || '',
            assistantName: sub.assistant_name || 'Sarah',
            routingMode: sub.routing_mode || 'sarah_answers',
            cellPhone: sub.cell_phone || '',
            repName: sub.rep_name || '',
            repEmail: sub.rep_email || '',
            twilioSid: sub.twilio_sid || '',
            twilioToken: sub.twilio_token || '',
            twilioPhone: sub.twilio_phone || '',
            availabilityStatus: sub.availability_status || 'available',
          });
        }
      }
      cacheLastRefreshed = Date.now();
      console.log(`[Cache] Refreshed: ${result.subscribers.length} subscriber numbers cached`);
    }
  } catch (err) {
    console.warn('[Cache] Full refresh failed:', err.message);
  }
}

// Refresh cache periodically
setInterval(async () => {
  if (Date.now() - cacheLastRefreshed > CACHE_TTL_MS) {
    await refreshCacheFromAPI();
  }
}, 60000);

// Process workflow queue every 60 seconds
setInterval(async () => {
  try {
    const prodDb = require('./db/prod-db.cjs');
    const pool = prodDb.getPool();
    const prodIntegrations = require('./db/prod-integrations.cjs');
    const now = new Date();

    const activeResult = await pool.query(
      `SELECT * FROM generic_entities WHERE entity_type = 'WorkflowExecution'
       AND (data->>'status' = 'active' OR data->>'status' = 'waiting_for_trigger')
       LIMIT 100`
    );

    const executions = activeResult.rows;
    if (executions.length === 0) return;
    console.log(`[Cron:processWorkflowQueue] Found ${executions.length} active executions`);
    let processed = 0;

    for (const execRow of executions) {
      try {
        const exec = typeof execRow.data === 'string' ? JSON.parse(execRow.data) : (execRow.data || {});
        if (exec.status === 'active' && exec.next_run_at && new Date(exec.next_run_at) > now) continue;

        const workflowResult = await pool.query(
          `SELECT * FROM generic_entities WHERE entity_type = 'Workflow' AND id = $1`,
          [exec.workflow_id]
        );
        if (workflowResult.rows.length === 0) {
          await pool.query(`UPDATE generic_entities SET data = jsonb_set(data::jsonb, '{status}', '"error"'), updated_date = NOW() WHERE id = $1`, [execRow.id]);
          continue;
        }

        const workflow = typeof workflowResult.rows[0].data === 'string' ? JSON.parse(workflowResult.rows[0].data) : (workflowResult.rows[0].data || {});
        const steps = workflow.actions || workflow.steps || [];
        const currentStep = exec.current_step || 0;

        if (currentStep >= steps.length) {
          await pool.query(`UPDATE generic_entities SET data = jsonb_set(data::jsonb, '{status}', '"completed"'), updated_date = NOW() WHERE id = $1`, [execRow.id]);
          processed++;
          continue;
        }

        const step = steps[currentStep];
        const actionType = step.action_type || step.action || step.type;

        if (actionType === 'delay' || actionType === 'wait') {
          const delayMs = (step.config?.minutes || step.minutes || step.delay_minutes || 5) * 60000;
          const nextRunAt = new Date(now.getTime() + delayMs);
          await pool.query(`UPDATE generic_entities SET data = jsonb_set(jsonb_set(data::jsonb, '{current_step}', $2::jsonb), '{next_run_at}', $3::jsonb), updated_date = NOW() WHERE id = $1`,
            [execRow.id, JSON.stringify(currentStep + 1), JSON.stringify(nextRunAt.toISOString())]);
          processed++;
          continue;
        }

        const entityData = exec.entity_data || {};
        await prodIntegrations.executeProdWorkflowAction(pool, step, entityData, exec.company_id || execRow.company_id, exec.entity_type, exec.entity_id);

        const nextStep = currentStep + 1;
        const newStatus = nextStep >= steps.length ? 'completed' : 'active';
        await pool.query(`UPDATE generic_entities SET data = jsonb_set(jsonb_set(data::jsonb, '{current_step}', $2::jsonb), '{status}', $3::jsonb), updated_date = NOW() WHERE id = $1`,
          [execRow.id, JSON.stringify(nextStep >= steps.length ? 0 : nextStep), JSON.stringify(newStatus)]);
        processed++;
      } catch (execErr) {
        console.error(`[Cron:processWorkflowQueue] Execution ${execRow.id} error:`, execErr.message);
      }
    }
    console.log(`[Cron:processWorkflowQueue] Complete: ${processed}/${executions.length} processed`);
  } catch (err) {
    if (err.message && !err.message.includes('Cannot find module')) {
      console.error('[Cron:processWorkflowQueue] Error:', err.message);
    }
  }
}, 60000);

// Send timezone-aware morning (5am) and EOD (8pm) reports every 15 minutes
setInterval(async () => {
  try {
    const resp = await fetch('http://localhost:5000/api/functions/invoke', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ functionName: 'sendScheduledDailyReports', params: {} }),
    });
    const result = await resp.json();
    if (result.success) {
      const r = result.results || {};
      const triggered = [...(r.morning_triggered || []), ...(r.eod_triggered || [])];
      if (triggered.length > 0) {
        console.log(`[Cron:sendScheduledDailyReports] Triggered reports for: ${triggered.join(', ')}`);
      } else {
        console.log('[Cron:sendScheduledDailyReports] No reports due at this time');
      }
    } else if (result.error) {
      console.error('[Cron:sendScheduledDailyReports] Error:', result.error);
    }
  } catch (err) {
    console.error('[Cron:sendScheduledDailyReports] Failed:', err.message);
  }
}, 15 * 60 * 1000);

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.webp': 'image/webp',
  '.map': 'application/json',
  '.txt': 'text/plain',
  '.xml': 'application/xml',
  '.webmanifest': 'application/manifest+json',
};

const BASE44_MARKETING_DOMAIN = process.env.BASE44_MARKETING_DOMAIN || '';

function getAllowedOrigins() {
  const origins = [
    'https://getcompanysync.com',
    'https://company-sync-crm-bf62df1e.base44.app',
    'https://companysync.io',
    'https://www.companysync.io',
  ];
  if (BASE44_MARKETING_DOMAIN) {
    const domain = BASE44_MARKETING_DOMAIN.replace(/\/+$/, '');
    if (!domain.startsWith('http')) {
      origins.push(`https://${domain}`);
      origins.push(`http://${domain}`);
    } else {
      origins.push(domain);
    }
  }
  const appUrl = process.env.VITE_REPLIT_APP_URL || '';
  if (appUrl) origins.push(appUrl.replace(/\/+$/, ''));
  return origins;
}

function setCorsHeaders(res, req) {
  const origin = req?.headers?.origin || '';
  const allowed = getAllowedOrigins();
  const isAllowed = origin && (
    allowed.some(a => origin === a || origin.startsWith(a)) ||
    origin.endsWith('.replit.app') ||
    origin.endsWith('.replit.dev')
  );
  if (isAllowed) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
  } else {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    }
  } catch (e) {}
  return {
    voice: 'Kore',
    response_speed: 'normal',
    background_audio: 'none',
    interim_audio: 'typing',
    personality_assertiveness: 50,
    personality_humor: 20
  };
}

function saveSettings(settings) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
}

function getPublicHost(reqHeaders) {
  const envUrl = process.env.VITE_REPLIT_APP_URL || '';
  if (envUrl) {
    try { return new URL(envUrl).host; } catch (e) {}
  }
  return reqHeaders?.host || 'localhost:5000';
}

async function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

async function localGetSettings(companyId) {
  const pool = prodDb.getPool();
  try {
    const { rows: settingsRows } = await pool.query(
      `SELECT data FROM generic_entities WHERE entity_type = 'AssistantSettings' AND company_id = $1 ORDER BY updated_date DESC NULLS LAST LIMIT 1`,
      [companyId]
    );
    const settings = settingsRows[0]?.data || {};

    const { rows: companyRows } = await pool.query(`SELECT name, data, preferred_language FROM companies WHERE id = $1 LIMIT 1`, [companyId]);
    const company = companyRows[0] || {};
    const companyName = settings.brand_short_name || company.name || company.data?.company_name || 'our company';
    const companyTimezone = company.data?.timezone || 'America/New_York';
    const preferredLanguage = company.preferred_language || 'en';

    const rawName = (settings.assistant_name || 'Sarah').trim();
    const assistantDisplayName = rawName.charAt(0).toUpperCase() + rawName.slice(1);

    let knowledgeParts = [];

    try {
      const { rows: memories } = await pool.query(
        `SELECT data FROM generic_entities WHERE entity_type = 'AIMemory' AND company_id = $1 AND (data->>'is_active')::boolean = true ORDER BY (data->>'importance')::int DESC NULLS LAST LIMIT 50`,
        [companyId]
      );
      if (memories.length > 0) {
        knowledgeParts.push(memories.map(m => `- ${m.data?.title || ''}: ${m.data?.content || ''}`).join('\n'));
      }
    } catch (e) { console.log(`[localGetSettings] AIMemory error: ${e.message}`); }

    try {
      const { rows: articles } = await pool.query(
        `SELECT data FROM generic_entities WHERE entity_type = 'KnowledgeBaseArticle' AND company_id = $1 AND data->>'status' = 'published' LIMIT 30`,
        [companyId]
      );
      if (articles.length > 0) {
        knowledgeParts.push(articles.map(a => `- ${a.data?.title || ''}: ${(a.data?.content || a.data?.summary || '').substring(0, 500)}`).join('\n'));
      }
    } catch (e) { console.log(`[localGetSettings] KnowledgeArticle error: ${e.message}`); }

    try {
      const { rows: training } = await pool.query(
        `SELECT data FROM generic_entities WHERE entity_type = 'AITrainingData' AND company_id = $1 AND data->>'status' = 'active' LIMIT 50`,
        [companyId]
      );
      if (training.length > 0) {
        knowledgeParts.push(training.map(t => `- ${t.data?.category || 'General'}: ${t.data?.content || ''}`).join('\n'));
      }
    } catch (e) { console.log(`[localGetSettings] AITrainingData error: ${e.message}`); }

    if (settings.knowledge_base) {
      knowledgeParts.push(settings.knowledge_base);
    }

    if (settings.website_urls && Array.isArray(settings.website_urls) && settings.website_urls.length > 0) {
      knowledgeParts.push('Company websites: ' + settings.website_urls.join(', '));
    }

    const fullKnowledge = knowledgeParts.filter(Boolean).join('\n');

    console.log(`[localGetSettings] company=${companyName}, assistant=${assistantDisplayName}, timezone=${companyTimezone}, settings_keys=${Object.keys(settings).length}, knowledge_parts=${knowledgeParts.length}, knowledge_length=${fullKnowledge.length}`);

    return {
      settings,
      companyName,
      assistantName: assistantDisplayName,
      timezone: companyTimezone,
      customSystemPrompt: settings.system_prompt || '',
      knowledgeBase: fullKnowledge,
      companyDescription: company.data?.description || '',
      companyServices: company.data?.services || '',
      preferredLanguage,
    };
  } catch (err) {
    console.error('[localGetSettings] Error:', err.message);
    return { error: err.message };
  }
}

async function localGetMessagingSettings(companyId) {
  const pool = prodDb.getPool();
  try {
    const { rows } = await pool.query(
      `SELECT data FROM generic_entities WHERE entity_type = 'MessagingSettings' AND company_id = $1 ORDER BY updated_date DESC NULLS LAST LIMIT 1`,
      [companyId]
    );
    const settings = rows[0]?.data || {};
    return {
      whatsapp_enabled: settings.whatsapp_enabled || false,
      sms_auto_reply: settings.sms_auto_reply !== false,
      missed_call_followup_enabled: settings.missed_call_followup_enabled || false,
      missed_call_channel: settings.missed_call_channel || 'sms',
      missed_call_template: settings.missed_call_template || '',
      ...settings,
    };
  } catch (e) {
    console.error('[localGetMessagingSettings] Error:', e.message);
    return null;
  }
}

const smsConversationHistory = new Map();

async function localHandleIncomingMessage(companyId, msgData) {
  const pool = prodDb.getPool();
  const { from, to, body, channel, message_sid } = msgData;
  console.log(`[LocalSMS] Handling ${channel} from ${from} for company ${companyId}`);
  try {
    const settingsResult = await localGetSettings(companyId);
    if (settingsResult.error) {
      console.error('[LocalSMS] Failed to get settings:', settingsResult.error);
      return { reply: null };
    }
    const { settings, companyName, assistantName, knowledgeBase, customSystemPrompt } = settingsResult;

    const convKey = `${companyId}:${from}`;
    if (!smsConversationHistory.has(convKey)) {
      smsConversationHistory.set(convKey, []);
    }
    const history = smsConversationHistory.get(convKey);
    history.push({ role: 'user', parts: [{ text: body }] });
    if (history.length > 20) history.splice(0, history.length - 20);

    let systemPrompt = customSystemPrompt || '';
    if (!systemPrompt) {
      systemPrompt = `You are ${assistantName}, the office manager for ${companyName}. You're responding to a ${channel === 'whatsapp' ? 'WhatsApp' : 'text'} message.

Personality: Conversational, helpful, and human. Use contractions (you're, we're, it's). Sound like a real person texting — not a script. Never mention being AI.

RULES:
- Keep responses SHORT — 1-3 sentences max for texts.
- Be helpful and specific. Reference actual services if you know them.
- If they're a new lead asking about services, get their name and address, one question at a time.
- Don't ask "How can I assist you further?" — just help naturally.
- If you can't help, let them know someone will follow up.`;
    }
    systemPrompt = systemPrompt.replace(/\{brand\}/gi, companyName).replace(/\{agent\}/gi, assistantName);
    if (knowledgeBase) systemPrompt += `\n\nKNOWLEDGE BASE:\n${knowledgeBase}`;
    systemPrompt += `\n\nIMPORTANT: You are responding via ${channel === 'whatsapp' ? 'WhatsApp' : 'SMS text message'}. Keep your responses short, conversational, and text-appropriate (1-3 sentences). Do not use long paragraphs.`;

    let apiKey = process.env.GOOGLE_GEMINI_API_KEY;
    try {
      const companyKey = await prodDb.getCompanyGeminiKey(companyId);
      if (companyKey) apiKey = companyKey;
    } catch (e) { console.error('[LocalSMS] BYOK key lookup failed:', e.message); }
    if (!apiKey) {
      console.error('[LocalSMS] GOOGLE_GEMINI_API_KEY not set');
      return { reply: null };
    }

    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemPrompt }] },
          contents: history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: h.parts })),
          generationConfig: { maxOutputTokens: 200, temperature: 0.7 },
        }),
      }
    );

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      console.error('[LocalSMS] Gemini error:', geminiRes.status, errText.substring(0, 300));
      return { reply: null };
    }

    const geminiData = await geminiRes.json();
    const reply = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text || '';

    if (reply) {
      history.push({ role: 'model', parts: [{ text: reply }] });
      console.log(`[LocalSMS] AI reply (${reply.length} chars): "${reply.substring(0, 100)}..."`);
      billAIUsage(companyId, 1);
      logUsageEvent(companyId, 'sms_ai', 1).catch(() => {});
    }

    try {
      await pool.query(
        `INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date)
         VALUES ($1, 'Communication', $2, $3, NOW(), NOW())`,
        [
          `local_comm_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          companyId,
          JSON.stringify({
            type: channel === 'whatsapp' ? 'whatsapp' : 'sms',
            direction: 'inbound',
            contact_phone: from,
            company_phone: to,
            message_body: body,
            ai_reply: reply,
            message_sid: message_sid,
            status: 'completed',
            created_at: new Date().toISOString(),
          }),
        ]
      );
    } catch (logErr) { console.warn('[LocalSMS] Failed to log communication:', logErr.message); }

    return { reply, success: true };
  } catch (err) {
    console.error('[LocalSMS] Error:', err.message);
    return { reply: null };
  }
}

async function localSendMissedCallFollowup(companyId, callData) {
  const pool = prodDb.getPool();
  const { caller_phone, called_number, channel } = callData;
  console.log(`[LocalMissedCall] Sending follow-up to ${caller_phone} for company ${companyId}`);
  try {
    const settingsResult = await localGetSettings(companyId);
    const { companyName, assistantName } = settingsResult;

    let twilioSid, twilioToken, twilioPhone;
    const { rows } = await pool.query(
      `SELECT data FROM generic_entities WHERE entity_type = 'TwilioSettings' AND company_id = $1 LIMIT 1`,
      [companyId]
    );
    const tw = rows[0]?.data || {};
    twilioSid = tw.account_sid || process.env.TWILIO_ACCOUNT_SID;
    twilioToken = tw.auth_token || process.env.TWILIO_AUTH_TOKEN;
    twilioPhone = tw.main_phone_number || called_number;

    if (!twilioSid || !twilioToken) {
      console.error('[LocalMissedCall] No Twilio credentials found');
      return { success: false };
    }

    const msgSettings = await localGetMessagingSettings(companyId);
    let template = msgSettings?.missed_call_template || '';
    if (!template) {
      template = `Hi! This is ${assistantName} from ${companyName}. We noticed we missed your call. How can we help you? Feel free to reply to this text or call us back anytime!`;
    }
    template = template.replace(/\{brand\}/gi, companyName).replace(/\{agent\}/gi, assistantName);

    const authHeader = Buffer.from(`${twilioSid}:${twilioToken}`).toString('base64');
    const smsParams = new URLSearchParams({ To: caller_phone, From: twilioPhone, Body: template });
    const twilioRes = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Messages.json`,
      {
        method: 'POST',
        headers: { 'Authorization': `Basic ${authHeader}`, 'Content-Type': 'application/x-www-form-urlencoded' },
        body: smsParams.toString(),
      }
    );

    if (twilioRes.ok) {
      console.log(`[LocalMissedCall] Follow-up SMS sent to ${caller_phone}`);
      return { success: true };
    } else {
      const errText = await twilioRes.text();
      console.error('[LocalMissedCall] Twilio SMS failed:', twilioRes.status, errText.substring(0, 200));
      return { success: false };
    }
  } catch (err) {
    console.error('[LocalMissedCall] Error:', err.message);
    return { success: false };
  }
}

async function callBase44API(action, companyId, data = null) {
  if (action === 'getSettings' && companyId) {
    try {
      const localResult = await localGetSettings(companyId);
      if (!localResult.error && localResult.settings && Object.keys(localResult.settings).length > 0) {
        console.log(`[Sarah CRM] getSettings served LOCALLY: assistant="${localResult.assistantName}", company="${localResult.companyName}"`);
        return localResult;
      }
    } catch (e) {
      console.warn('[Sarah CRM] Local getSettings failed, falling back to Base44:', e.message);
    }
  }

  if (action === 'handleIncomingMessage' && companyId) {
    try {
      const localResult = await localHandleIncomingMessage(companyId, data);
      if (localResult && (localResult.reply || localResult.success)) {
        console.log(`[Sarah CRM] handleIncomingMessage served LOCALLY for company ${companyId}`);
        return localResult;
      }
    } catch (e) {
      console.warn('[Sarah CRM] Local handleIncomingMessage failed, falling back to Base44:', e.message);
    }
  }

  if (action === 'getMessagingSettings' && companyId) {
    try {
      const localResult = await localGetMessagingSettings(companyId);
      if (localResult) {
        console.log(`[Sarah CRM] getMessagingSettings served LOCALLY for company ${companyId}`);
        return localResult;
      }
    } catch (e) {
      console.warn('[Sarah CRM] Local getMessagingSettings failed, falling back to Base44:', e.message);
    }
  }

  if (action === 'sendMissedCallFollowup' && companyId) {
    try {
      const localResult = await localSendMissedCallFollowup(companyId, data);
      if (localResult) {
        console.log(`[Sarah CRM] sendMissedCallFollowup served LOCALLY for company ${companyId}`);
        return localResult;
      }
    } catch (e) {
      console.warn('[Sarah CRM] Local sendMissedCallFollowup failed, falling back to Base44:', e.message);
    }
  }

  if (action === 'scheduleInspection' && companyId && data) {
    try {
      const pool = prodDb.getPool();
      const apptId = `appt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const apptData = {
        id: apptId,
        company_id: companyId,
        type: 'inspection',
        title: `Roof Inspection - ${data.customer_name || 'Customer'}`,
        customer_name: data.customer_name || '',
        customer_phone: data.customer_phone || '',
        address: data.address || '',
        date_time: data.date_time || '',
        notes: data.notes || '',
        assigned_to: data.assigned_to || '',
        status: 'scheduled',
        source: 'ai_voice',
        created_at: new Date().toISOString()
      };
      await pool.query(
        `INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date) VALUES ($1, 'Appointment', $2, $3, NOW(), NOW()) ON CONFLICT DO NOTHING`,
        [apptId, companyId, JSON.stringify(apptData)]
      );
      const notifData = {
        id: notifId,
        company_id: companyId,
        type: 'new_appointment',
        title: 'New Inspection Scheduled by AI',
        message: `${data.customer_name || 'A customer'} scheduled a roof inspection at ${data.address || 'their address'} for ${data.date_time || 'a requested time'}. Assigned to: ${data.assigned_to || 'unassigned'}.`,
        is_read: false,
        priority: 'high',
        appointment_id: apptId,
        created_at: new Date().toISOString()
      };
      await pool.query(
        `INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date) VALUES ($1, 'Notification', $2, $3, NOW(), NOW()) ON CONFLICT DO NOTHING`,
        [notifId, companyId, JSON.stringify(notifData)]
      );
      console.log(`[Sarah CRM] scheduleInspection saved LOCALLY: ${apptId} for ${data.customer_name}`);
      return { success: true, appointment_id: apptId, message: `Inspection scheduled for ${data.date_time} at ${data.address}` };
    } catch (e) {
      console.warn('[Sarah CRM] Local scheduleInspection failed, falling back to Base44:', e.message);
    }
  }

  if (action === 'sendAlert' && companyId && data) {
    try {
      const pool = prodDb.getPool();
      const notifId = `notif_alert_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const urgency = data.urgency || 'medium';
      const notifData = {
        id: notifId,
        company_id: companyId,
        type: 'ai_alert',
        title: `${data.category ? '[' + data.category + '] ' : ''}Alert from AI${data.caller_name ? ': ' + data.caller_name : ''}`,
        message: data.message || '',
        caller_name: data.caller_name || '',
        caller_phone: data.caller_phone || '',
        urgency,
        is_read: false,
        priority: urgency === 'urgent' || urgency === 'high' ? 'high' : 'medium',
        created_at: new Date().toISOString()
      };
      await pool.query(
        `INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date) VALUES ($1, 'Notification', $2, $3, NOW(), NOW()) ON CONFLICT DO NOTHING`,
        [notifId, companyId, JSON.stringify(notifData)]
      );
      console.log(`[Sarah CRM] sendAlert saved LOCALLY as Notification: ${notifId}`);
    } catch (e) {
      console.warn('[Sarah CRM] Local sendAlert notification failed:', e.message);
    }
  }

  if (action === 'saveCallLog' && companyId && data) {
    try {
      const pool = prodDb.getPool();
      const commId = `comm_ai_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const commData = {
        id: commId,
        company_id: companyId,
        communication_type: 'call',
        direction: data.direction || 'inbound',
        status: 'completed',
        caller_phone: data.caller_phone || 'Unknown',
        contact_name: data.caller_name || 'Voice Caller',
        transcript: data.transcript || '',
        duration_seconds: data.duration_seconds || 0,
        call_sid: data.call_sid || '',
        assistant_name: data.assistant_name || 'AI Assistant',
        tool_calls_made: data.tool_calls_made || 0,
        source: 'ai_voice',
        created_at: new Date().toISOString()
      };
      await pool.query(
        `INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date) VALUES ($1, 'Communication', $2, $3, NOW(), NOW()) ON CONFLICT DO NOTHING`,
        [commId, companyId, JSON.stringify(commData)]
      );
      console.log(`[Sarah CRM] saveCallLog saved LOCALLY: ${commId} (${data.duration_seconds}s, ${(data.transcript||'').length} chars)`);
    } catch (e) {
      console.warn('[Sarah CRM] Local saveCallLog failed, falling back to Base44:', e.message);
    }
  }

  if (!BASE44_API_URL || !BRIDGE_SECRET) {
    console.warn('[Sarah CRM] API not configured');
    return { error: 'CRM not configured' };
  }
  try {
    const body = { action, companyId };
    if (data) body.data = data;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    const resp = await fetch(BASE44_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${BRIDGE_SECRET}` },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    clearTimeout(timeout);
    const text = await resp.text();
    try { return JSON.parse(text); } catch (e) { return { error: `Non-JSON response (${resp.status})` }; }
  } catch (err) {
    console.error(`[Sarah CRM] ${action} failed:`, err.message);
    return { error: err.message };
  }
}

async function callLexiBridgeAPI(action, companyId, userEmail, data = null) {
  if (!LEXI_BRIDGE_API_URL || !LEXI_BRIDGE_SECRET) return { error: 'Not configured' };
  try {
    const body = { action, companyId, userEmail };
    if (data) body.data = data;
    const resp = await fetch(LEXI_BRIDGE_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${LEXI_BRIDGE_SECRET}` },
      body: JSON.stringify(body)
    });
    const text = await resp.text();
    try { return JSON.parse(text); } catch (e) { return { error: `Non-JSON (${resp.status})` }; }
  } catch (err) { return { error: err.message }; }
}

function getBase44FunctionUrl(functionName) {
  if (!BASE44_API_URL) return null;
  return BASE44_API_URL.replace(/\/functions\/[^/]+$/, '/functions/') + functionName;
}

function serveStaticFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mime = MIME_TYPES[ext] || 'application/octet-stream';
  try {
    const stat = fs.statSync(filePath);
    res.writeHead(200, {
      'Content-Type': mime,
      'Content-Length': stat.size,
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=31536000, immutable'
    });
    const stream = fs.createReadStream(filePath);
    stream.on('error', (err) => {
      console.error('[Static] Stream error:', err.message);
      if (!res.headersSent) {
        res.writeHead(500);
        res.end('Internal Server Error');
      } else {
        res.end();
      }
    });
    stream.pipe(res);
    return true;
  } catch (e) {
    console.error('[Static] File serve error:', e.message, filePath);
    if (!res.headersSent) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
    }
    return false;
  }
}

const CRM_TOOLS = [
  { name: "save_lead_details", description: "Save caller's contact information as a lead.", parameters: { type: "object", properties: { name: { type: "string" }, phone: { type: "string" }, email: { type: "string" }, service_needed: { type: "string" }, address: { type: "string" }, assigned_to: { type: "string", description: "Email of rep to assign the lead to" } }, required: ["name"] } },
  { name: "check_availability", description: "Check available appointment slots.", parameters: { type: "object", properties: {}, required: [] } },
  { name: "book_appointment", description: "Book an appointment for the caller.", parameters: { type: "object", properties: { slot_time: { type: "string" }, name: { type: "string" }, email: { type: "string" }, description: { type: "string" } }, required: ["slot_time", "name"] } },
  { name: "send_alert", description: "Send an urgent alert to the business team.", parameters: { type: "object", properties: { message: { type: "string" }, caller_name: { type: "string" }, caller_phone: { type: "string" }, urgency: { type: "string" }, category: { type: "string" } }, required: ["message"] } },
  { name: "schedule_inspection", description: "Schedule a roof inspection appointment. Creates a calendar event and assigns it to the appropriate rep.", parameters: { type: "object", properties: { date_time: { type: "string", description: "Date and time for the inspection in ISO format or natural language" }, customer_name: { type: "string", description: "Name of the customer" }, customer_phone: { type: "string", description: "Phone number of the customer" }, address: { type: "string", description: "Property address for the inspection" }, notes: { type: "string", description: "Special notes about the inspection" }, assigned_to: { type: "string", description: "Staff member name or email to assign this inspection to" } }, required: ["date_time", "customer_name", "address"] } },
  { name: "notify_rep", description: "Send an SMS or WhatsApp notification to a specific sales rep about a new lead, appointment, or update.", parameters: { type: "object", properties: { rep_name: { type: "string", description: "Name of the rep to notify" }, rep_phone: { type: "string", description: "Phone number of the rep" }, message: { type: "string", description: "The notification message to send" }, notification_type: { type: "string", description: "Type: new_lead, inspection_scheduled, callback_request, general" } }, required: ["message"] } },
  { name: "transfer_call", description: "Transfer the current call to a staff member's cell phone. Use this when: 1) The caller asks to speak to a specific person by name, or 2) The call routing mode is sarah_then_transfer and you have gathered the caller's info. Always gather the caller's name and reason before transferring. If a caller asks for someone by name, use target_person with their name.", parameters: { type: "object", properties: { reason: { type: "string", description: "Why the call is being transferred" }, target_person: { type: "string", description: "Name of the specific staff member the caller wants to speak to (e.g. 'Vicky', 'Kevin'). Leave empty to transfer to the default rep." } }, required: [] } }
];

const VALID_GEMINI_VOICES = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Aoede', 'Leda', 'Orus', 'Zephyr'];

const BIAS = 0x84;
const CLIP = 32635;
const EXP_LUT = new Uint8Array([0,0,1,1,2,2,2,2,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7]);

function mulawEncode(sample) {
  let sign = (sample >> 8) & 0x80;
  if (sign) sample = -sample;
  if (sample > CLIP) sample = CLIP;
  sample += BIAS;
  const exponent = EXP_LUT[(sample >> 7) & 0xFF];
  const mantissa = (sample >> (exponent + 3)) & 0x0F;
  return ~(sign | (exponent << 4) | mantissa) & 0xFF;
}

const MULAW_DECODE_TABLE = new Int16Array(256);
(function() {
  for (let i = 0; i < 256; i++) {
    const val = ~i & 0xFF;
    const sign = val & 0x80;
    const exponent = (val >> 4) & 0x07;
    const mantissa = val & 0x0F;
    let magnitude = ((mantissa << 3) + BIAS) << exponent;
    magnitude -= BIAS;
    MULAW_DECODE_TABLE[i] = sign ? -magnitude : magnitude;
  }
})();

function twilioToGemini(mulawB64) {
  const buf = Buffer.from(mulawB64, 'base64');
  const nSrc = buf.length;
  const pcm8k = new Int16Array(nSrc);
  for (let i = 0; i < nSrc; i++) pcm8k[i] = MULAW_DECODE_TABLE[buf[i]];
  const nDst = nSrc * 2;
  const pcm16 = new Int16Array(nDst);
  for (let i = 0; i < nSrc - 1; i++) {
    pcm16[i * 2] = pcm8k[i];
    pcm16[i * 2 + 1] = (pcm8k[i] + pcm8k[i + 1]) >> 1;
  }
  pcm16[nDst - 2] = pcm8k[nSrc - 1];
  pcm16[nDst - 1] = pcm8k[nSrc - 1];
  return Buffer.from(pcm16.buffer).toString('base64');
}

const LP_COEFFS = new Float64Array([0.0595, 0.0990, 0.1571, 0.2030, 0.2218, 0.2030, 0.1571, 0.0990, 0.0595]);
const LP_LEN = LP_COEFFS.length;
const LP_HALF = (LP_LEN - 1) >> 1;

function geminiToTwilio(pcmB64) {
  const buf = Buffer.from(pcmB64, 'base64');
  const nSrc = buf.length >> 1;
  const pcm = new Float64Array(nSrc);
  for (let i = 0; i < nSrc; i++) pcm[i] = buf.readInt16LE(i * 2);
  let prev = pcm[0];
  for (let i = 1; i < nSrc; i++) { const orig = pcm[i]; pcm[i] = orig - 0.4 * prev; prev = orig; }
  const ratio = 3;
  const nDst = Math.floor(nSrc / ratio);
  const out = Buffer.alloc(nDst);
  for (let i = 0; i < nDst; i++) {
    const center = i * ratio;
    let acc = 0;
    for (let k = 0; k < LP_LEN; k++) {
      const idx = center - LP_HALF + k;
      if (idx >= 0 && idx < nSrc) acc += pcm[idx] * LP_COEFFS[k];
    }
    out[i] = mulawEncode(Math.max(-32768, Math.min(32767, Math.round(acc))));
  }
  return out.toString('base64');
}

async function handleToolCall(functionCall, companyId) {
  const { name, args } = functionCall;
  let parsedArgs = {};
  try { parsedArgs = typeof args === 'string' ? JSON.parse(args) : (args || {}); } catch (e) { parsedArgs = {}; }
  console.log(`[Sarah CRM] Tool: ${name}`, JSON.stringify(parsedArgs));
  switch (name) {
    case 'save_lead_details': return callBase44API('saveLead', companyId, parsedArgs);
    case 'check_availability': return callBase44API('checkAvailability', companyId);
    case 'book_appointment': return callBase44API('bookAppointment', companyId, parsedArgs);
    case 'send_alert': return callBase44API('sendAlert', companyId, parsedArgs);
    case 'schedule_inspection': return callBase44API('scheduleInspection', companyId, parsedArgs);
    case 'notify_rep': return callBase44API('notifyRep', companyId, parsedArgs);
    case 'transfer_call': return { success: true, message: 'Transfer initiated' };
    default: return { error: `Unknown tool: ${name}` };
  }
}

const COMPANYSYNC_DEFAULT_KNOWLEDGE = `

KNOWLEDGE BASE — You MUST use this information when answering questions about CompanySync. Do NOT guess or invent details:

WHAT IS COMPANYSYNC:
CompanySync is an all-in-one roofing business management platform. It replaces spreadsheets, disconnected tools, and manual processes with a single system designed specifically for roofing contractors.

CORE FEATURES:
- CRM & Lead Management: Track every lead from first contact to signed contract. Storm-based lead generation, automated follow-ups, lead scoring, pipeline management.
- Estimates & Invoicing: Create professional estimates with material calculators, convert to invoices with one click, accept online payments via Stripe.
- Crew Management: Assign crews to jobs, track schedules, manage staff profiles and roles.
- CrewCam AI Inspection: Take photos of roof damage and get instant AI-powered analysis. Identifies materials, detects hail/wind damage with bounding boxes, measures damage severity. Uses Google Gemini Vision.
- Calendar & Scheduling: Built-in calendar with Google Calendar sync. Schedule inspections, appointments, and jobs. Automated reminders.
- Storm Tracking: Real-time NOAA severe weather monitoring. Track hail, wind, tornado events. Generate leads from storm-affected areas. Nationwide coverage.
- Contract Signing: Digital contract creation and e-signature. Send contracts for signing, track status, store signed documents.
- Communications: Track all calls, texts, and emails in one place. Integrated with Twilio for voice and SMS.

AI ASSISTANTS:
- Sarah (AI Voice): Answers phone calls, qualifies leads, books inspections, handles customer inquiries 24/7. Uses Google Gemini speech-to-speech. Can make outbound follow-up calls. Customizable personality and knowledge base per company.
- Lexi (AI Chat): In-app AI chat assistant for CRM operations. Can look up customers, create tasks, check calendar, send emails — all through natural conversation.
- Marcus (AI Marketing): AI-powered marketing assistant. Generates social media content, email campaigns, and marketing strategies tailored to the roofing industry.

SUBSCRIPTION PLANS:
- Basic Plan: $49/month — CRM, estimates, invoicing, calendar, 1 user.
- Business Plan: $99/month — Everything in Basic plus AI assistants (Sarah, Lexi, Marcus), crew management, storm tracking, unlimited users.
- Enterprise Plan: $199/month — Everything in Business plus priority support, custom integrations, advanced reporting, white-label options.
- All plans include a free trial period. No long-term contracts required.

INTEGRATIONS:
- Stripe for payment processing
- Twilio for voice calls and SMS
- Google Calendar for scheduling
- Google Maps for address geocoding
- NOAA for storm data
- Resend for transactional emails

WEBSITE: https://getcompanysync.com
SUPPORT: Available through the platform or by calling our main line.`;

function buildSystemPrompt(cName, aName, isOutbound, outboundLeadName, outboundLeadService, subscriberPrompt, companyDescription, companyKnowledge, forwardedInfo) {
  let prompt = '';

  if (forwardedInfo && forwardedInfo.isForwarded && !subscriberPrompt) {
    const rName = forwardedInfo.repName || 'the team';
    const rEmail = forwardedInfo.repEmail || '';
    prompt = `You are ${aName}, the lead qualifier and office manager for ${cName}. You're picking up a call forwarded from ${rName}'s line.

Personality: Conversational, warm, and real. You sound like a person — not a script. Use contractions (you're, we're, it's, I'll). Vary your phrasing. Never say the same thing twice. Never mention being AI.

GREETING (vary each time — pick ONE, don't repeat):
- "Hey! You've reached ${cName}, I'm ${aName} picking up for ${rName}. What's going on?"
- "Hi there! This is ${aName} at ${cName} — ${rName}'s line. How can I help?"
- "Thanks for calling ${cName}! ${rName} stepped away so I've got you. What do you need?"

CALL FLOW:
1. Answer naturally — acknowledge what they say before asking anything.
2. If new lead: get their name first, then address, then what they need. One question at a time.
3. Save with save_lead_details (assigned_to="${rEmail || rName}") as soon as you have a name.
4. If they want scheduling: use schedule_inspection (assigned_to="${rEmail || rName}").
5. After booking or capturing info: use notify_rep to text ${rName} about the new lead/appointment.
6. Let them know: "${rName} will follow up with you shortly."

TRIAGE (answer first, then ask ONE follow-up):
- Leak? "Got it — is water coming in right now or is it an older issue?"
- Storm damage? "When did the storm hit? We can get someone out to take a look."
- Pricing? "We do free inspections — takes about 15 minutes. Want to schedule one?"
- Wants a meeting/demo (not inspection)? Use check_availability then book_appointment.
- General? Respond to what they said, then: "What's the best address for service?"

RULES:
- Assign EVERY lead to ${rName} (${rEmail || 'their account'}). Always use assigned_to.
- ONE question at a time. Never stack questions.
- Don't say "How can I assist you further today?" — just help them naturally.
- If they give you info unprompted, save it immediately. Don't wait.
- When using notify_rep, include a clear message like: "New lead from [caller name] at [phone] — needs [service]. Appointment booked for [date/time]." so ${rName} has full context.

YOUR FIRST RESPONSE must be one of the greetings above — short, warm, under 20 words.`;

  } else if (isOutbound && !subscriberPrompt) {
    prompt = `You are ${aName}, the lead qualifier for ${cName}. You're making an OUTBOUND follow-up call.

Personality: Friendly, confident, not pushy. You're calling because they reached out — you're helping, not selling. Use contractions. Sound like a real person. Never mention being AI.

OPENING (vary — pick ONE):
- "Hi, this is ${aName} from ${cName}. Am I speaking with ${outboundLeadName || 'the homeowner'}?"
- "Hey ${outboundLeadName || 'there'}, it's ${aName} with ${cName} — just following up on your request."

CALL FLOW:
1. Confirm you're speaking to the right person.
2. Reference their inquiry: "I see you reached out about ${outboundLeadService || 'your roof'}. What's going on with it?"
3. Qualify: ask about the issue — storm damage, leak, age of roof, insurance claim. ONE question at a time.
4. Offer the inspection: "We do a free inspection — about 15 minutes, you get a full report. Want to set one up?"
5. If yes: use check_availability, then book_appointment. Confirm the address, date, and time.
6. If bad time: "No problem! I can call back or text you a link to book whenever works. What's easier?"

RULES:
- Never be pushy. If they're not interested, thank them and wrap up.
- Save or update their info with save_lead_details as you learn details.
- ONE question at a time. Acknowledge their answers before moving on.

YOUR FIRST RESPONSE must be one of the openings above — short, confident, under 20 words.`;

  } else if (subscriberPrompt) {
    prompt = subscriberPrompt;
  } else {
    prompt = `You are ${aName}, the lead qualifier and office manager for ${cName}.

Personality: Conversational, helpful, and human. You actually know things and share them naturally. Use contractions (you're, we're, it's). Vary your responses — don't repeat the same phrases. Never mention being AI.

GREETING (vary each time — pick ONE):
- "Hi, this is ${aName} with ${cName}. What can I do for you?"
- "Hey! You've reached ${cName}. I'm ${aName} — how can I help?"
- "Thanks for calling ${cName}! What's going on?"

CONVERSATION STYLE:
- Acknowledge what they say FIRST, then respond. Don't jump straight to questions.
- Ask ONE clarifying question max per turn. Never stack questions.
- Give specific answers — not generic "we can help with that" filler.
- If they tell you something, reference it back: "So you've got a leak near the chimney — that's pretty common after storms."

TRIAGE (answer first, then ask ONE follow-up):
- Leak: "Got it. Is water actively coming in, or is it more of a stain situation?"
- Storm/hail/wind damage: "When did the storm come through? We can get someone out to look."
- Missing shingles: "How many are we talking — a few or a larger section?"
- Pricing/estimate: "We do free inspections that take about 15 minutes. Want to schedule one?"
- General/other: Respond naturally, then: "What's the address for the property?"

EMERGENCY KEYWORDS: emergency, urgent, asap, flood, fire, 911
- If detected: use send_alert with urgency="urgent" IMMEDIATELY, then reassure the caller help is on the way.

SCHEDULING NOTE: For roof inspections, use schedule_inspection. For general meetings or demos, use check_availability then book_appointment.

YOUR FIRST RESPONSE must be one of the greetings above — short, warm, under 20 words.`;
  }

  prompt = prompt.replace(/\{agent\}/gi, aName).replace(/\{brand\}/gi, cName);
  if (aName.toLowerCase() !== 'sarah') prompt = prompt.replace(/\bSarah\b/gi, aName);
  if (cName.toLowerCase() !== 'companysync') prompt = prompt.replace(/\bCompanySync\b/gi, cName);

  prompt += `

VOICE RULES (non-negotiable):
- No internal thinking, reasoning, or markdown. Only say words you'd say out loud on a phone call.
- Keep responses under 25 words. Short and natural.
- Never say "I am an AI" or "I'm an artificial intelligence" or reference being a bot.
- Never say "How can I assist you further today?" or similar robotic closers.
- Vary your responses. Don't repeat greetings, phrases, or patterns.

CRM TOOLS — use these automatically as info comes in:
- save_lead_details: Save as soon as caller shares name, phone, or what they need. Don't wait. Include service_needed describing their issue. Every caller should be tracked.
- check_availability → book_appointment: For scheduling. Always confirm with caller before booking.
- schedule_inspection: For roof inspection bookings. Include address and assigned_to if this is a forwarded call.
- notify_rep: Text a rep about new leads or appointments. Use after saving a lead or booking.
- send_alert: For complaints, emergencies, or messages for someone specific. Set urgency appropriately (urgent/high/medium). After sending, confirm to the caller.
- After ANY tool call, respond to the caller immediately. Never go silent.
- NEVER make up pricing, service details, warranties, timelines, or company facts. Use your knowledge base below. If you don't know something, say "Let me have someone get back to you on that" or "I'll make sure the right person follows up with those details."
- When a caller asks about services, pricing, or how things work, reference your knowledge base — don't guess.`;

  if (companyDescription) prompt += `\n\nAbout ${cName}:\n${companyDescription}`;
  if (companyKnowledge) {
    prompt += `\n\nKNOWLEDGE BASE — You MUST use this information when answering questions about ${cName}. Do NOT guess or invent details. If a caller asks about services, pricing, warranties, process, or anything covered below, use these facts exactly. If the answer isn't here, say you'll have someone follow up:\n${companyKnowledge}`;
  } else if (cName.toLowerCase().includes('companysync') || cName.toLowerCase().includes('company sync')) {
    prompt += COMPANYSYNC_DEFAULT_KNOWLEDGE;
  }
  return prompt;
}

const LEXI_CRM_TOOLS = [
  { name: "get_crm_data", description: "Get CRM data counts/details.", parameters: { type: "object", properties: { data_type: { type: "string", enum: ["customers","leads","estimates","invoices","tasks","projects","payments","staff","calendar_events"] } }, required: ["data_type"] } },
  { name: "get_calendar_events", description: "Get calendar events for date range.", parameters: { type: "object", properties: { start_date: { type: "string" }, end_date: { type: "string" } }, required: ["start_date"] } },
  { name: "create_calendar_event", description: "Create a calendar event.", parameters: { type: "object", properties: { title: { type: "string" }, start_time: { type: "string" }, end_time: { type: "string" }, location: { type: "string" }, description: { type: "string" }, event_type: { type: "string" }, attendees: { type: "string" } }, required: ["title","start_time"] } },
  { name: "create_task", description: "Create a CRM task.", parameters: { type: "object", properties: { name: { type: "string" }, description: { type: "string" }, assigned_to: { type: "string" }, due_date: { type: "string" }, priority: { type: "string" } }, required: ["name"] } },
  { name: "create_lead", description: "Create a CRM lead.", parameters: { type: "object", properties: { name: { type: "string" }, email: { type: "string" }, phone: { type: "string" }, street: { type: "string" }, city: { type: "string" }, state: { type: "string" }, zip: { type: "string" }, notes: { type: "string" }, source: { type: "string" } }, required: ["name"] } },
  { name: "create_customer", description: "Create a CRM customer.", parameters: { type: "object", properties: { name: { type: "string" }, email: { type: "string" }, phone: { type: "string" }, street: { type: "string" }, city: { type: "string" }, state: { type: "string" }, zip: { type: "string" }, notes: { type: "string" } }, required: ["name"] } },
  { name: "send_email", description: "Compose email to customer/lead.", parameters: { type: "object", properties: { to: { type: "string" }, subject: { type: "string" }, message: { type: "string" }, contact_name: { type: "string" } }, required: ["to","subject","message"] } },
  { name: "send_sms", description: "Compose text message.", parameters: { type: "object", properties: { to: { type: "string" }, message: { type: "string" }, contact_name: { type: "string" } }, required: ["to","message"] } },
  { name: "manage_entity", description: "CRUD any CRM entity.", parameters: { type: "object", properties: { entity_action: { type: "string", enum: ["create","update","delete","list"] }, entity_name: { type: "string" }, entity_data: { type: "object" }, entity_id: { type: "string" } }, required: ["entity_action","entity_name"] } },
  { name: "assign_inspection", description: "Create/assign a CrewCam inspection.", parameters: { type: "object", properties: { client_name: { type: "string" }, client_phone: { type: "string" }, client_email: { type: "string" }, property_address: { type: "string" }, assigned_to_email: { type: "string" }, inspection_date: { type: "string" }, inspection_time: { type: "string" }, damage_type: { type: "string" }, special_instructions: { type: "string" }, create_calendar_event: { type: "boolean" }, create_lead: { type: "boolean" } }, required: ["client_name","property_address","assigned_to_email"] } }
];

async function handleLexiToolCall(functionCall, companyId, userEmail) {
  const { name, args } = functionCall;
  let parsedArgs = {};
  try { parsedArgs = typeof args === 'string' ? JSON.parse(args) : (args || {}); } catch (e) { parsedArgs = {}; }
  const result = await callLexiBridgeAPI('executeTool', companyId, userEmail, { toolName: name, args: parsedArgs });
  return result?.result || result;
}

function buildLexiSystemPrompt(companyName, userName, timezone, knowledgeBase, customerList, staffList, preferredLanguage) {
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: timezone });
  const timeStr = now.toLocaleString('en-US', { timeZone: timezone });
  const todayISO = now.toISOString().split('T')[0];
  let staffCtx = '';
  if (staffList?.length) staffCtx = `\nStaff: ${staffList.map(s => `${s.name} (${s.email}${s.role?', '+s.role:''})`).join(', ')}`;
  const isSpanish = preferredLanguage === 'es';
  const languageInstruction = isSpanish
    ? `\nLANGUAGE: You MUST respond exclusively in Spanish (Español) at all times. Greet in Spanish. All responses must be in Spanish unless the user explicitly switches to English.`
    : '';
  return `You are Lexi, a powerful AI assistant for ${companyName}. You can do almost ANYTHING within the CRM. Speaking with ${userName}.${languageInstruction}

CRITICAL: No internal thinking text. No markdown. Speak naturally. Keep under 30 words.

Context: Company=${companyName}, User=${userName}${staffCtx}
${customerList ? `Customers: ${customerList}` : ''}
${knowledgeBase ? `Knowledge Base:\n${knowledgeBase}` : ''}

YOUR CAPABILITIES (use tools for ALL of these):
- Calendar: Create events, look up upcoming events, set reminders, schedule inspections/appointments/meetings/calls
- Tasks: Create tasks with due dates and priorities
- Leads & Customers: Create, update, look up contacts
- Inspections: Schedule roof inspections with crew assignments
- Email & SMS: Compose and send messages
- CRM Data: Look up customers, leads, estimates, invoices, tasks, projects, payments, staff, calendar events
- Generic CRUD: Create, update, delete, or list ANY entity type

Date: ${dateStr}, Time: ${timeStr}, TZ: ${timezone}, Today: ${todayISO}

TOOL RULES:
- When asked to schedule/create/remind, just do it immediately using tools. Don't ask permission.
- When asked about calendar/data, use your tools to look it up. Never guess.
- NEVER say "I can't do that" — you have full CRM access.

Greet ${userName} warmly.`;
}

const server = http.createServer(async (req, res) => {
  try {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  if (req.method === 'OPTIONS') {
    setCorsHeaders(res, req);
    res.writeHead(204);
    res.end();
    return;
  }

  if (pathname === '/health' || pathname === '/_health' || pathname === '/ping') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
    return;
  }

  // Serve root path instantly from memory cache — must pass Replit health check fast
  if (pathname === '/' && (req.method === 'GET' || req.method === 'HEAD')) {
    if (INDEX_HTML_CACHE) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
      res.end(req.method === 'HEAD' ? '' : INDEX_HTML_CACHE);
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'ok' }));
    }
    return;
  }

  if (pathname.startsWith('/api/local/')) {
    return prodDb.handleLocalDbRoute(req, res, pathname, url);
  }

  if (pathname === '/twiml/forward-fallback') {
    setCorsHeaders(res);
    const host = getPublicHost(req.headers);
    const companyId = url.searchParams.get('companyId') || '';
    const callerPhone = url.searchParams.get('callerPhone') || '';
    const repName = url.searchParams.get('repName') || '';
    const repEmail = url.searchParams.get('repEmail') || '';
    const maxDuration = url.searchParams.get('maxDuration') || '1800';

    const body = await readBody(req);
    const params = new URLSearchParams(body);
    const dialStatus = params.get('DialCallStatus') || '';

    if (dialStatus === 'completed') {
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end(`<?xml version="1.0" encoding="UTF-8"?><Response><Hangup/></Response>`);
      return;
    }

    const wsUrl = `wss://${host}/ws/twilio`;
    const fallbackTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">${repName ? repName + ' is unavailable right now.' : 'The person you are trying to reach is unavailable.'} Let me connect you with our AI assistant who can help.</Say>
    <Connect>
        <Stream url="${wsUrl}">
            <Parameter name="companyId" value="${companyId}" />
            <Parameter name="callerPhone" value="${callerPhone}" />
            <Parameter name="maxCallDuration" value="${maxDuration}" />
            <Parameter name="isForwardedCall" value="true" />
            <Parameter name="forwardedRepName" value="${repName}" />
            <Parameter name="forwardedRepEmail" value="${repEmail}" />
            <Parameter name="callRoutingMode" value="sarah_answers" />
        </Stream>
    </Connect>
</Response>`;
    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(fallbackTwiml);
    return;
  }

  if (pathname === '/twiml/transfer') {
    setCorsHeaders(res);
    const cellPhone = url.searchParams.get('cellPhone') || '';
    const callerIdNumber = url.searchParams.get('callerId') || '';
    const repName = url.searchParams.get('repName') || '';

    if (!cellPhone) {
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end(`<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="alice">I'm sorry, I don't have a phone number to transfer to.</Say></Response>`);
      return;
    }

    const transferTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Let me transfer you to ${repName || 'your representative'} now. One moment please.</Say>
    <Dial callerId="${callerIdNumber || ''}" timeout="30">
        <Number>${cellPhone}</Number>
    </Dial>
    <Say voice="alice">I'm sorry, ${repName || 'the representative'} is not available right now.</Say>
</Response>`;
    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(transferTwiml);
    return;
  }

  if (pathname === '/api/sarah-voice') {
    setCorsHeaders(res);
    if (req.method === 'GET') {
      const settings = loadSettings();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(settings));
    } else if (req.method === 'POST') {
      const body = JSON.parse(await readBody(req));
      const settings = loadSettings();
      if (body.voice) settings.voice = body.voice;
      saveSettings(settings);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, ...settings }));
    } else {
      res.writeHead(405); res.end();
    }
    return;
  }

  // ============================================================
  // CACHE UPDATE ENDPOINT - called by frontend when subscriber saves settings
  // Requires BRIDGE_SECRET or valid Referer from same origin
  // ============================================================
  if (pathname === '/api/twilio/update-cache') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    if (req.method === 'POST') {
      const referer = req.headers.referer || req.headers.origin || '';
      const host = req.headers.host || '';
      const authHeader = req.headers['x-bridge-secret'] || '';
      const isSameOrigin = referer && (referer.includes(host) || referer.includes('replit'));
      if (!isSameOrigin && authHeader !== BRIDGE_SECRET) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Unauthorized' }));
        return;
      }
      try {
        const body = JSON.parse(await readBody(req));
        const { phone_number, company_id, company_name, rep_name, rep_email, cell_phone, routing_mode, twilio_sid, twilio_token, availability_status } = body;
        if (phone_number && company_id) {
          setCachedSubscriber(phone_number, {
            companyId: company_id,
            companyName: company_name || '',
            repName: rep_name || '',
            repEmail: rep_email || '',
            cellPhone: cell_phone || '',
            routingMode: routing_mode || 'sarah_answers',
            twilioSid: twilio_sid || '',
            twilioToken: twilio_token || '',
            twilioPhone: phone_number,
            availabilityStatus: availability_status || 'available',
          });
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, cached: normalizePhone(phone_number) }));
        } else {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'phone_number and company_id required' }));
        }
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    } else {
      res.writeHead(405); res.end();
    }
    return;
  }

  // ============================================================
  // AUTO-PROVISIONING - configures Twilio webhooks automatically
  // Requires same-origin or BRIDGE_SECRET
  // ============================================================
  if (pathname === '/api/twilio/auto-provision') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    if (req.method === 'POST') {
      const referer = req.headers.referer || req.headers.origin || '';
      const host = req.headers.host || '';
      const authHeader = req.headers['x-bridge-secret'] || '';
      const isSameOrigin = referer && (referer.includes(host) || referer.includes('replit'));
      if (!isSameOrigin && authHeader !== BRIDGE_SECRET) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Unauthorized' }));
        return;
      }
      try {
        const body = JSON.parse(await readBody(req));
        const { account_sid, auth_token, phone_number, company_id, company_name, rep_name, rep_email, cell_phone, routing_mode } = body;
        if (!account_sid || !auth_token || !phone_number) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'account_sid, auth_token, and phone_number required' }));
          return;
        }
        const host = getPublicHost(req.headers);
        const voiceWebhookUrl = `https://${host}/api/twilio/voice`;
        const smsWebhookUrl = `https://${host}/api/whatsapp-webhook`;
        const statusCallbackUrl = `https://${host}/api/sarah-missed-call`;
        const normalizedPhone = normalizePhone(phone_number);

        const authStr = Buffer.from(`${account_sid}:${auth_token}`).toString('base64');

        // Step 1: Find the phone number SID in the subscriber's Twilio account
        const listResp = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${account_sid}/IncomingPhoneNumbers.json?PhoneNumber=${encodeURIComponent(normalizedPhone)}`,
          { headers: { 'Authorization': `Basic ${authStr}` } }
        );
        const listData = await listResp.json();

        if (!listData.incoming_phone_numbers?.length) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: `Phone number ${normalizedPhone} not found in your Twilio account. Make sure you own this number.` }));
          return;
        }

        const phoneSid = listData.incoming_phone_numbers[0].sid;

        // Step 2: Set the webhooks on the phone number
        const updateBody = new URLSearchParams({
          VoiceUrl: voiceWebhookUrl,
          VoiceMethod: 'POST',
          SmsUrl: smsWebhookUrl,
          SmsMethod: 'POST',
          StatusCallback: statusCallbackUrl,
          StatusCallbackMethod: 'POST',
        });

        const updateResp = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${account_sid}/IncomingPhoneNumbers/${phoneSid}.json`,
          {
            method: 'POST',
            headers: { 'Authorization': `Basic ${authStr}`, 'Content-Type': 'application/x-www-form-urlencoded' },
            body: updateBody.toString()
          }
        );
        const updateData = await updateResp.json();

        if (!updateResp.ok) {
          res.writeHead(updateResp.status, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: updateData.message || 'Failed to update Twilio webhooks', details: updateData }));
          return;
        }

        // Step 3: Create API Key for WebRTC token generation
        let apiKeySid = '', apiKeySecret = '';
        try {
          const keyResp = await fetch(
            `https://api.twilio.com/2010-04-01/Accounts/${account_sid}/Keys.json`,
            { method: 'POST', headers: { 'Authorization': `Basic ${authStr}`, 'Content-Type': 'application/x-www-form-urlencoded' },
              body: new URLSearchParams({ FriendlyName: 'CompanySync Browser Dialer' }).toString() }
          );
          const keyData = await keyResp.json();
          if (keyResp.ok && keyData.sid) {
            apiKeySid = keyData.sid;
            apiKeySecret = keyData.secret;
            console.log(`[AutoProvision] API Key created: ${apiKeySid}`);
          } else {
            console.warn('[AutoProvision] API Key creation failed:', JSON.stringify(keyData));
          }
        } catch (keyErr) {
          console.warn('[AutoProvision] API Key error:', keyErr.message);
        }

        // Step 4: Create TwiML App for browser-to-PSTN dialing
        const browserCallTwimlUrl = `https://${host}/api/twilio/browser-call-twiml`;
        let twimlAppSid = '';
        try {
          const appResp = await fetch(
            `https://api.twilio.com/2010-04-01/Accounts/${account_sid}/Applications.json`,
            { method: 'POST', headers: { 'Authorization': `Basic ${authStr}`, 'Content-Type': 'application/x-www-form-urlencoded' },
              body: new URLSearchParams({ FriendlyName: 'CompanySync Browser Dialer', VoiceUrl: browserCallTwimlUrl, VoiceMethod: 'POST' }).toString() }
          );
          const appData = await appResp.json();
          if (appResp.ok && appData.sid) {
            twimlAppSid = appData.sid;
            console.log(`[AutoProvision] TwiML App created: ${twimlAppSid}`);
          } else {
            console.warn('[AutoProvision] TwiML App creation failed:', JSON.stringify(appData));
          }
        } catch (appErr) {
          console.warn('[AutoProvision] TwiML App error:', appErr.message);
        }

        // Step 5: Cache this subscriber's routing
        setCachedSubscriber(normalizedPhone, {
          companyId: company_id || '',
          companyName: company_name || '',
          repName: rep_name || '',
          repEmail: rep_email || '',
          cellPhone: cell_phone || '',
          routingMode: routing_mode || 'sarah_answers',
          twilioSid: account_sid,
          twilioToken: auth_token,
          twilioPhone: normalizedPhone,
          availabilityStatus: 'available',
        });

        console.log(`[AutoProvision] Successfully provisioned ${normalizedPhone}: voice=${voiceWebhookUrl}, sms=${smsWebhookUrl}`);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: true,
          phone_sid: phoneSid,
          voice_webhook: voiceWebhookUrl,
          sms_webhook: smsWebhookUrl,
          status_callback: statusCallbackUrl,
          browser_call_twiml_url: browserCallTwimlUrl,
          api_key_sid: apiKeySid, api_key_secret: apiKeySecret, twiml_app_sid: twimlAppSid,
          webrtc_ready: !!(apiKeySid && twimlAppSid),
          message: 'Webhooks configured. Sarah is ready to answer calls. Browser dialer is' + (apiKeySid && twimlAppSid ? ' active.' : ' not configured (API key creation failed).')
        }));
      } catch (err) {
        console.error('[AutoProvision] Error:', err.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    } else {
      res.writeHead(405); res.end();
    }
    return;
  }

  // ==========================================
  // WEBRTC TOKEN ENDPOINT
  // ==========================================
  if (pathname === '/api/twilio/webrtc-token' && req.method === 'GET') {
    setCorsHeaders(res);
    try {
      const companyId = url.searchParams.get('companyId') || DEFAULT_COMPANY_ID;
      const identity = url.searchParams.get('identity') || 'agent';
      const pool = prodDb.getPool();
      const settings = await pool.query(
        "SELECT data FROM generic_entities WHERE entity_type = 'TwilioSettings' AND company_id = $1 LIMIT 1",
        [companyId]
      ).then(r => r.rows[0]?.data || {}).catch(() => ({}));
      const accountSid = settings.account_sid || process.env.TWILIO_ACCOUNT_SID;
      const apiKeySid = settings.api_key_sid;
      const apiKeySecret = settings.api_key_secret;
      const twimlAppSid = settings.twiml_app_sid;
      if (!accountSid || !apiKeySid || !apiKeySecret || !twimlAppSid) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'WebRTC not configured. Please re-run "Connect Sarah to This Number" in Twilio Setup.' }));
        return;
      }
      const token = generateTwilioToken(accountSid, apiKeySid, apiKeySecret, identity, twimlAppSid);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ token, identity }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // ==========================================
  // BROWSER CALL TWIML
  // ==========================================
  if (pathname === '/api/twilio/browser-call-twiml') {
    setCorsHeaders(res);
    try {
      const body = await readBody(req);
      const params = new URLSearchParams(body);
      const to = params.get('To') || url.searchParams.get('To') || '';
      const companyId = params.get('CompanyId') || url.searchParams.get('companyId') || DEFAULT_COMPANY_ID;
      const contactName = params.get('ContactName') || url.searchParams.get('contactName') || '';
      const host = getPublicHost(req.headers);
      const transcriptionCallbackUrl = `https://${host}/api/twilio/transcription-done?companyId=${encodeURIComponent(companyId)}&contactName=${encodeURIComponent(contactName)}`;
      const pool = prodDb.getPool();
      const settings = await pool.query(
        "SELECT data FROM generic_entities WHERE entity_type = 'TwilioSettings' AND company_id = $1 LIMIT 1",
        [companyId]
      ).then(r => r.rows[0]?.data || {}).catch(() => ({}));
      const callerId = settings.main_phone_number || process.env.TWILIO_PHONE_NUMBER || '';
      const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice">This call may be monitored or recorded for quality assurance.</Say>
  <Dial callerId="${callerId}" record="record-from-ringing" timeout="30">
    <Number>${to}</Number>
  </Dial>
</Response>`;
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end(twiml);
      console.log(`[Dialer] Browser call TwiML: to=${to}, from=${callerId}, company=${companyId}`);
    } catch (err) {
      const errTwiml = `<?xml version="1.0" encoding="UTF-8"?><Response><Say>We're sorry, the call could not be connected. Please try again.</Say></Response>`;
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end(errTwiml);
    }
    return;
  }

  // ==========================================
  // TRANSCRIPTION WEBHOOK
  // ==========================================
  if (pathname === '/api/twilio/transcription-done') {
    setCorsHeaders(res);
    try {
      const body = await readBody(req);
      const params = new URLSearchParams(body);
      const transcriptionText = params.get('TranscriptionText') || '';
      const callSid = params.get('CallSid') || '';
      const companyId = url.searchParams.get('companyId') || DEFAULT_COMPANY_ID;
      const contactName = url.searchParams.get('contactName') || '';
      if (transcriptionText && companyId) {
        const pool = prodDb.getPool();
        const existing = await pool.query(
          "SELECT id FROM generic_entities WHERE entity_type='Communication' AND company_id=$1 AND data->>'call_sid'=$2 LIMIT 1",
          [companyId, callSid]
        ).catch(() => ({ rows: [] }));
        if (existing.rows[0]) {
          await pool.query(
            "UPDATE generic_entities SET data = data || $1::jsonb WHERE id=$2",
            [JSON.stringify({ transcript: transcriptionText, transcription_status: 'completed' }), existing.rows[0].id]
          );
        } else {
          const newId = `comm_trans_${Date.now()}`;
          await pool.query(
            "INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date) VALUES ($1,'Communication',$2,$3,NOW(),NOW()) ON CONFLICT DO NOTHING",
            [newId, companyId, JSON.stringify({ id: newId, company_id: companyId, call_sid: callSid, contact_name: contactName, transcript: transcriptionText, transcription_status: 'completed', communication_type: 'call', direction: 'outbound', status: 'completed' })]
          );
        }
        console.log(`[Dialer] Transcription saved for call ${callSid} (${transcriptionText.length} chars)`);
      }
      res.writeHead(204);
      res.end();
    } catch (err) {
      console.error('[Dialer] Transcription webhook error:', err.message);
      res.writeHead(200);
      res.end('ok');
    }
    return;
  }

  if (pathname === '/api/twilio/voice') {
    setCorsHeaders(res);
    const host = getPublicHost(req.headers);
    const body = await readBody(req);
    const params = new URLSearchParams(body);
    const from = params.get('From') || params.get('Caller') || '';
    const callSid = params.get('CallSid') || '';
    const calledNumber = params.get('To') || '';
    const pool = prodDb.getPool();

    // Check for custom inbound phone in Sarah settings
    let sarahInboundPhone = '';
    try {
      const { rows } = await pool.query(
        "SELECT data, company_id FROM generic_entities WHERE entity_type = 'AssistantSettings' AND (data->>'sarah_inbound_phone' = $1) LIMIT 1",
        [calledNumber]
      );
      if (rows[0]) {
        sarahInboundPhone = rows[0].data.sarah_inbound_phone;
        resolvedCompanyId = rows[0].company_id;
        console.log(`[Sarah] Custom inbound phone match: ${calledNumber} -> company ${resolvedCompanyId}`);
      }
    } catch (e) {}

    // === FAST PATH: Check in-memory cache first (no DB calls) ===
    let cached = getCachedSubscriber(calledNumber);
    let resolvedCompanyId = url.searchParams.get('companyId') || cached?.companyId || null;
    let forwardedRepName = url.searchParams.get('repName') || cached?.repName || '';
    let forwardedRepEmail = url.searchParams.get('repEmail') || cached?.repEmail || '';
    let forwardedRepPhone = cached?.cellPhone || '';
    let isForwarded = !!(forwardedRepName || url.searchParams.get('forwarded') === 'true');
    let effectiveRoutingMode = cached?.routingMode || 'sarah_answers';
    let cellPhone = cached?.cellPhone || '';

    // If cached subscriber is unavailable, override to sarah_answers
    if (cached && cached.availabilityStatus === 'unavailable') {
      effectiveRoutingMode = 'sarah_answers';
    }

    // If no cache hit, try local PostgreSQL first, then Base44 API
    if (!cached && calledNumber) {
      console.log(`[Sarah] Cache miss for ${calledNumber}, trying local DB...`);
      try {
        const normalizedNum = calledNumber.replace(/[^\d+]/g, '');
        const e164 = normalizedNum.startsWith('+') ? normalizedNum : `+1${normalizedNum}`;
        const digits = normalizedNum.replace(/^\+/, '');
        const localLookup = await pool.query(
          `SELECT company_id FROM call_routing_cache WHERE phone_number = $1 OR phone_number = $2 OR phone_number = $3 LIMIT 1`,
          [calledNumber, e164, digits]
        );
        if (localLookup.rows[0]) {
          resolvedCompanyId = localLookup.rows[0].company_id;
          console.log(`[Sarah] Local routing cache hit: ${calledNumber} -> company ${resolvedCompanyId}`);
        }
        if (!resolvedCompanyId) {
          const twilioLookup = await pool.query(
            `SELECT company_id FROM generic_entities WHERE entity_type = 'TwilioSettings' AND (data->>'main_phone_number' = $1 OR data->>'main_phone_number' = $2 OR data->>'main_phone_number' = $3) LIMIT 1`,
            [calledNumber, e164, digits]
          );
          if (twilioLookup.rows[0]) {
            resolvedCompanyId = twilioLookup.rows[0].company_id;
            console.log(`[Sarah] Local TwilioSettings hit: ${calledNumber} -> company ${resolvedCompanyId}`);
          }
        }
      } catch (e) { console.warn(`[Sarah] Local DB lookup failed:`, e.message); }

      if (!resolvedCompanyId && BASE44_API_URL) {
        console.log(`[Sarah] Local DB miss, falling back to Base44 API for ${calledNumber}...`);
        try {
          const lookup = await callBase44API('lookupByPhone', null, { phone_number: calledNumber });
          if (lookup?.success && lookup.company_id) {
            resolvedCompanyId = lookup.company_id;
            console.log(`[Sarah] Base44 lookup: ${calledNumber} -> company ${resolvedCompanyId}`);
          }
        } catch (e) { console.warn(`[Sarah] Base44 company lookup failed:`, e.message); }
      }

      // Also restore staff routing from DB on cache miss
      if (resolvedCompanyId) {
        try {
          const staffLookup = await callBase44API('lookupStaffByTwilioNumber', resolvedCompanyId, { twilio_number: calledNumber });
          if (staffLookup?.success && staffLookup.staff) {
            const staff = staffLookup.staff;
            isForwarded = true;
            forwardedRepName = staff.full_name || '';
            forwardedRepEmail = staff.email || '';
            forwardedRepPhone = staff.cell_phone || staff.phone || '';
            cellPhone = staff.cell_phone || staff.phone || '';
            effectiveRoutingMode = staff.availability_status === 'unavailable' ? 'sarah_answers' : (staff.call_routing_mode || 'sarah_answers');

            // After-hours check
            const staffData = staff.data || {};
            if (effectiveRoutingMode !== 'sarah_answers' && staffData.after_hours_enabled && staffData.after_hours_start && staffData.after_hours_end) {
              const now = new Date();
              const currentMins = now.getHours() * 60 + now.getMinutes();
              const [sH, sM] = staffData.after_hours_start.split(':').map(Number);
              const [eH, eM] = staffData.after_hours_end.split(':').map(Number);
              const startMins = sH * 60 + (sM || 0);
              const endMins = eH * 60 + (eM || 0);
              if (currentMins < startMins || currentMins >= endMins) {
                effectiveRoutingMode = 'sarah_answers';
                console.log(`[Sarah] After-hours override for ${forwardedRepName}: routing to sarah_answers (outside ${staffData.after_hours_start}-${staffData.after_hours_end})`);
              }
            }

            console.log(`[Sarah] DB staff routing: rep=${forwardedRepName}, mode=${effectiveRoutingMode}, cell=${cellPhone}`);

            // Populate cache for next time
            try {
              const twilioSettings = await callBase44API('getTwilioSettings', resolvedCompanyId);
              setCachedSubscriber(calledNumber, {
                companyId: resolvedCompanyId,
                companyName: '',
                repName: forwardedRepName,
                repEmail: forwardedRepEmail,
                cellPhone: cellPhone,
                routingMode: staff.call_routing_mode || 'sarah_answers',
                twilioSid: twilioSettings?.account_sid || '',
                twilioToken: twilioSettings?.auth_token || '',
                twilioPhone: calledNumber,
                availabilityStatus: staff.availability_status || 'available',
                data: staffData,
              });
            } catch (e) { /* cache population is best effort */ }
          }
        } catch (e) { console.log(`[Sarah] DB staff lookup: not a staff number`); }
      }
    }
    if (!resolvedCompanyId) resolvedCompanyId = DEFAULT_COMPANY_ID;

    if (cached) {
      isForwarded = true;
      console.log(`[Sarah] CACHE HIT: ${calledNumber} -> company=${resolvedCompanyId}, rep=${forwardedRepName}, routing=${effectiveRoutingMode}, cell=${cellPhone}`);
    }

    let maxCallDuration = 1800;
    if (BASE44_API_URL) {
      try {
        const accessCheck = await callBase44API('checkVoiceAccess', resolvedCompanyId);
        if (accessCheck && accessCheck.allowed === false) {
          console.warn(`[Sarah] BLOCKED: Company ${resolvedCompanyId} denied: ${accessCheck.reason}`);
          const blockedTwiml = `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="alice">We're sorry, voice service is currently unavailable. ${accessCheck.reason || 'Please contact your administrator.'}</Say><Hangup/></Response>`;
          res.writeHead(200, { 'Content-Type': 'text/xml' }); res.end(blockedTwiml); return;
        }
        if (accessCheck?.max_call_duration_seconds) maxCallDuration = accessCheck.max_call_duration_seconds;
      } catch (e) { console.warn(`[Sarah] Access check failed, allowing:`, e.message); }
    }

    if (effectiveRoutingMode === 'forward_to_cell' && cellPhone) {
      const forwardTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">This call may be monitored or recorded for quality assurance.</Say>
    <Dial callerId="${calledNumber}" timeout="30" action="https://${host}/api/twilio/forward-fallback?companyId=${resolvedCompanyId}&callerPhone=${encodeURIComponent(from)}&repName=${encodeURIComponent(forwardedRepName)}&repEmail=${encodeURIComponent(forwardedRepEmail)}&maxDuration=${maxCallDuration}">
        <Number>${cellPhone}</Number>
    </Dial>
</Response>`;
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end(forwardTwiml);
      console.log(`[Sarah] FORWARD TO CELL: caller=${from}, forwarding to ${cellPhone} for rep ${forwardedRepName}`);
      return;
    }

    console.log(`[Sarah] Inbound call from ${from}, SID: ${callSid}, company=${resolvedCompanyId}, forwarded=${isForwarded}${isForwarded ? ` rep=${forwardedRepName}` : ''}, routing=${effectiveRoutingMode}, maxDuration=${maxCallDuration}s`);
    const wsUrl = `wss://${host}/ws/twilio`;
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">This call may be monitored or recorded for quality assurance.</Say>
    <Connect>
        <Stream url="${wsUrl}">
            <Parameter name="companyId" value="${resolvedCompanyId}" />
            <Parameter name="from" value="${from}" />
            <Parameter name="callSid" value="${callSid}" />
            <Parameter name="maxCallDuration" value="${maxCallDuration}" />
            <Parameter name="isForwardedCall" value="${isForwarded ? 'true' : 'false'}" />
            <Parameter name="forwardedRepName" value="${forwardedRepName}" />
            <Parameter name="forwardedRepEmail" value="${forwardedRepEmail}" />
            <Parameter name="forwardedRepPhone" value="${forwardedRepPhone}" />
            <Parameter name="callRoutingMode" value="${effectiveRoutingMode}" />
            <Parameter name="staffCellPhone" value="${cellPhone}" />
            <Parameter name="calledNumber" value="${calledNumber}" />
        </Stream>
    </Connect>
</Response>`;
    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(twiml);
    return;
  }

  if (pathname === '/api/twilio/forward-fallback') {
    setCorsHeaders(res);
    const host = getPublicHost(req.headers);
    const companyId = url.searchParams.get('companyId') || '';
    const callerPhone = url.searchParams.get('callerPhone') || '';
    const repName = url.searchParams.get('repName') || '';
    const repEmail = url.searchParams.get('repEmail') || '';
    const maxDuration = url.searchParams.get('maxDuration') || '1800';

    const body = await readBody(req);
    const params = new URLSearchParams(body);
    const dialStatus = params.get('DialCallStatus') || '';

    console.log(`[Sarah] Forward fallback: dialStatus=${dialStatus}, company=${companyId}, rep=${repName}`);

    if (dialStatus === 'completed') {
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end(`<?xml version="1.0" encoding="UTF-8"?><Response><Hangup/></Response>`);
      return;
    }

    const wsUrl = `wss://${host}/ws/twilio`;
    const fallbackTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">${repName ? repName + ' is unavailable right now.' : 'The person you are trying to reach is unavailable.'} Let me connect you with our AI assistant who can help.</Say>
    <Connect>
        <Stream url="${wsUrl}">
            <Parameter name="companyId" value="${companyId}" />
            <Parameter name="callerPhone" value="${callerPhone}" />
            <Parameter name="maxCallDuration" value="${maxDuration}" />
            <Parameter name="isForwardedCall" value="true" />
            <Parameter name="forwardedRepName" value="${repName}" />
            <Parameter name="forwardedRepEmail" value="${repEmail}" />
            <Parameter name="forwardedRepPhone" value="" />
            <Parameter name="callRoutingMode" value="sarah_answers" />
            <Parameter name="staffCellPhone" value="" />
        </Stream>
    </Connect>
</Response>`;
    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(fallbackTwiml);
    return;
  }

  if (pathname === '/api/twilio/transfer') {
    setCorsHeaders(res);
    const cellPhone = url.searchParams.get('cellPhone') || '';
    const callerIdNumber = url.searchParams.get('callerId') || '';
    const repName = url.searchParams.get('repName') || '';

    if (!cellPhone) {
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end(`<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="alice">I'm sorry, I don't have a phone number to transfer to.</Say></Response>`);
      return;
    }

    const transferTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Let me transfer you to ${repName || 'your representative'} now. One moment please.</Say>
    <Dial callerId="${callerIdNumber || ''}" timeout="30">
        <Number>${cellPhone}</Number>
    </Dial>
    <Say voice="alice">I'm sorry, ${repName || 'the representative'} is not available right now. Please try again later.</Say>
</Response>`;
    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(transferTwiml);
    console.log(`[Sarah] TRANSFER: connecting to ${cellPhone} for rep ${repName}`);
    return;
  }

  if (pathname === '/api/twilio/outbound-voice') {
    setCorsHeaders(res);
    const host = getPublicHost(req.headers);
    const body = await readBody(req);
    const params = new URLSearchParams(body);
    const from = params.get('From') || params.get('Caller') || '';
    const callSid = params.get('CallSid') || '';
    const companyId = url.searchParams.get('companyId') || DEFAULT_COMPANY_ID;
    const leadPhone = url.searchParams.get('leadPhone') || '';
    const leadName = url.searchParams.get('leadName') || '';
    const leadService = url.searchParams.get('leadService') || '';
    const leadAddress = url.searchParams.get('leadAddress') || '';
    const maxDuration = url.searchParams.get('maxDuration') || '600';
    const campaignRaw = url.searchParams.get('campaign') || '';
    const escapedCampaign = campaignRaw.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const wsUrl = `wss://${host}/ws/twilio`;
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">This call may be monitored or recorded for quality assurance.</Say>
    <Connect>
        <Stream url="${wsUrl}">
            <Parameter name="companyId" value="${companyId}" />
            <Parameter name="callerPhone" value="${leadPhone}" />
            <Parameter name="callSid" value="${callSid}" />
            <Parameter name="outbound" value="true" />
            <Parameter name="leadName" value="${leadName}" />
            <Parameter name="leadService" value="${leadService}" />
            <Parameter name="leadAddress" value="${leadAddress}" />
            <Parameter name="maxCallDuration" value="${maxDuration}" />
            <Parameter name="campaign" value="${escapedCampaign}" />
        </Stream>
    </Connect>
</Response>`;
    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(twiml);
    console.log(`[Sarah] Served outbound TwiML: lead=${leadName}, phone=${leadPhone}, company=${companyId}, campaign=${campaignRaw ? 'yes' : 'none'}`);
    return;
  }

  if (pathname === '/api/twilio/outbound-call') {
    setCorsHeaders(res);
    if (req.method === 'POST') {
      try {
        const body = JSON.parse(await readBody(req));
        const { to, companyId: cId, leadName: ln, leadService: ls } = body;
        const accountSid = process.env.TWILIO_ACCOUNT_SID;
        const authToken = process.env.TWILIO_AUTH_TOKEN;
        const twilioPhone = process.env.TWILIO_PHONE_NUMBER;
        if (!accountSid || !authToken || !twilioPhone) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Twilio not configured' }));
          return;
        }
        const host = getPublicHost(req.headers);
        const twimlUrl = `https://${host}/api/twilio/outbound-voice?companyId=${cId || DEFAULT_COMPANY_ID}&leadName=${encodeURIComponent(ln || '')}&leadService=${encodeURIComponent(ls || '')}`;
        const params = new URLSearchParams({ To: to, From: twilioPhone, Url: twimlUrl });
        const twilioResp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Calls.json`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64') },
          body: params.toString()
        });
        const data = await twilioResp.json();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, callSid: data.sid }));
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    } else {
      res.writeHead(405); res.end();
    }
    return;
  }

  // ==========================================
  // STRIPE OVERVIEW ENDPOINT
  // ==========================================
  if (pathname === '/api/stripe/overview' && req.method === 'GET') {
    try {
      const schemaCheck = await pool.query(
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='stripe' AND table_name='subscriptions'"
      );
      if (schemaCheck.rows[0].count === '0') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ subscriptions: [], invoices: [], customers: [], summary: { totalRevenue: 0, activeSubscriptions: 0, totalCustomers: 0, paidInvoices: 0 } }));
        return;
      }
      const [subsRes, invRes, custRes, piRes] = await Promise.all([
        pool.query(`SELECT id, status, customer, items, metadata, current_period_start, current_period_end, cancel_at_period_end, created, trial_end FROM stripe.subscriptions ORDER BY created DESC NULLS LAST LIMIT 100`),
        pool.query(`SELECT id, total, amount_paid, status, customer, customer_email, customer_name, number, created, hosted_invoice_url, invoice_pdf, currency, subscription FROM stripe.invoices ORDER BY created DESC NULLS LAST LIMIT 50`),
        pool.query(`SELECT id, email, name, created, balance, currency FROM stripe.customers ORDER BY created DESC NULLS LAST LIMIT 100`),
        pool.query(`SELECT SUM(amount_received) as total_received, COUNT(*) as count FROM stripe.payment_intents WHERE status='succeeded'`),
      ]);
      const totalRevenue = Number(piRes.rows[0]?.total_received || 0) / 100;
      const activeSubscriptions = subsRes.rows.filter(s => s.status === 'active' || s.status === 'trialing').length;
      const paidInvoicesTotal = invRes.rows.filter(i => i.status === 'paid').reduce((sum, i) => sum + Number(i.amount_paid || 0), 0) / 100;
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        subscriptions: subsRes.rows,
        invoices: invRes.rows,
        customers: custRes.rows,
        summary: { totalRevenue, paidInvoicesTotal, activeSubscriptions, totalCustomers: custRes.rows.length, paidInvoices: invRes.rows.filter(i => i.status === 'paid').length },
      }));
    } catch (err) {
      console.error('[Stripe Overview]', err.message);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message, subscriptions: [], invoices: [], customers: [], summary: { totalRevenue: 0, activeSubscriptions: 0, totalCustomers: 0, paidInvoices: 0 } }));
    }
    return;
  }

  // ==========================================
  // ADMIN HEALTH ENDPOINT
  // ==========================================
  if (pathname === '/admin/health' && req.method === 'GET') {
    try {
      const sessionUser = req.session?.passport?.user || req.session?.user;
      const userEmail = sessionUser?.claims?.email || sessionUser?.email;
      if (!userEmail) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Not authenticated' }));
        return;
      }
      const userCheck = await pool.query('SELECT platform_role FROM users WHERE email = $1', [userEmail]);
      const role = userCheck.rows[0]?.platform_role;
      if (role !== 'super_admin' && role !== 'admin') {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Not authorized' }));
        return;
      }
      const dbCheck = await pool.query('SELECT COUNT(*) as count FROM users').catch(() => ({ rows: [{ count: -1 }] }));
      const companyCount = await pool.query('SELECT COUNT(*) as count FROM generic_entities WHERE entity_type = $1', ['Company']).catch(() => ({ rows: [{ count: -1 }] }));
      const leadCount = await pool.query('SELECT COUNT(*) as count FROM generic_entities WHERE entity_type = $1', ['Lead']).catch(() => ({ rows: [{ count: -1 }] }));
      const sessionCount = await pool.query('SELECT COUNT(*) as count FROM sessions').catch(() => ({ rows: [{ count: -1 }] }));

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        database: { connected: true, users: parseInt(dbCheck.rows[0].count), companies: parseInt(companyCount.rows[0].count), leads: parseInt(leadCount.rows[0].count), active_sessions: parseInt(sessionCount.rows[0].count) },
        memory: { rss: Math.round(process.memoryUsage().rss / 1024 / 1024), heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024), heapTotal: Math.round(process.memoryUsage().heapTotal / 1024 / 1024) },
        environment: process.env.NODE_ENV || 'production',
        services: {
          twilio: !!process.env.TWILIO_ACCOUNT_SID,
          gemini: !!process.env.GOOGLE_GEMINI_API_KEY,
          resend: !!process.env.RESEND_API_KEY,
          google_maps: !!process.env.GOOGLE_MAPS_API_KEY,
        }
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'error', error: err.message }));
    }
    return;
  }

  // ==========================================
  // AUTH ENDPOINTS
  // ==========================================
  if (req.method === 'OPTIONS' && (pathname === '/api/signup' || pathname === '/api/login-local' || pathname === '/api/change-password' || pathname === '/api/forgot-password' || pathname === '/api/reset-password' || pathname === '/api/auth/google' || pathname === '/api/auth/google/callback')) {
    setCorsHeaders(res, req);
    res.writeHead(200);
    res.end();
    return;
  }

  if (pathname === '/api/auth/google') {
    setCorsHeaders(res, req);
    const host = req.headers.host;
    const callbackUrl = `https://${host}/api/auth/google/callback`;
    const params = new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID,
      redirect_uri: callbackUrl,
      response_type: 'code',
      scope: 'profile email',
      access_type: 'offline',
      prompt: 'consent'
    });
    res.writeHead(302, { Location: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}` });
    res.end();
    return;
  }

  if (pathname === '/api/auth/google/callback') {
    setCorsHeaders(res, req);
    try {
      const code = url.searchParams.get('code');
      const host = req.headers.host;
      const callbackUrl = `https://${host}/api/auth/google/callback`;

      const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: process.env.GOOGLE_CLIENT_ID,
          client_secret: process.env.GOOGLE_CLIENT_SECRET,
          redirect_uri: callbackUrl,
          grant_type: 'authorization_code'
        })
      });

      const tokens = await tokenResp.json();
      if (!tokens.access_token) throw new Error('Failed to get access token');

      const userinfoResp = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { 'Authorization': `Bearer ${tokens.access_token}` }
      });
      const profile = await userinfoResp.json();

      const claims = {
        sub: profile.sub,
        email: profile.email,
        first_name: profile.given_name,
        last_name: profile.family_name,
        profile_image_url: profile.picture
      };

      const pool = prodDb.getPool();
      await pool.query(
        `INSERT INTO users (id, email, first_name, last_name, profile_image_url, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
         ON CONFLICT (id) DO UPDATE SET
           email = COALESCE($2, users.email),
           first_name = COALESCE($3, users.first_name),
           last_name = COALESCE($4, users.last_name),
           profile_image_url = COALESCE($5, users.profile_image_url),
           updated_at = NOW()`,
        [claims.sub, claims.email, claims.first_name, claims.last_name, claims.profile_image_url]
      );

      const sessionData = {
        cookie: { originalMaxAge: 7 * 24 * 60 * 60 * 1000, expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), httpOnly: true, secure: true, sameSite: 'lax', path: '/' },
        passport: { user: { claims } }
      };

      const sid = await prodAuth.createSession(pool, sessionData);
      const signedSid = require('crypto').createHmac('sha256', process.env.SESSION_SECRET).update(sid).digest('base64').replace(/=+$/, '');
      const cookieValue = `connect.sid=${encodeURIComponent('s:' + sid + '.' + signedSid)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${7 * 24 * 60 * 60}`;

      res.writeHead(302, { Location: '/', 'Set-Cookie': cookieValue });
      res.end();
    } catch (err) {
      console.error('[GoogleAuth] Callback error:', err.message);
      res.writeHead(302, { Location: '/login?error=google_auth_failed' });
      res.end();
    }
    return;
  }

  if (pathname === '/api/login-local' && req.method === 'POST') {
    setCorsHeaders(res, req);
    const pool = prodDb.getPool();
    await localAuth.handleLoginLocal(req, res, pool);
    return;
  }

  if (pathname === '/api/signup' && req.method === 'POST') {
    setCorsHeaders(res, req);
    const pool = prodDb.getPool();
    await localAuth.handleSignup(req, res, pool);
    return;
  }

  if (pathname === '/api/confirm-email') {
    setCorsHeaders(res, req);
    const pool = prodDb.getPool();
    await localAuth.handleConfirmEmail(req, res, pool);
    return;
  }

  if (pathname === '/api/change-password' && req.method === 'POST') {
    setCorsHeaders(res, req);
    const pool = prodDb.getPool();
    await localAuth.handleChangePassword(req, res, pool);
    return;
  }

  if (pathname === '/api/forgot-password' && req.method === 'POST') {
    setCorsHeaders(res, req);
    const pool = prodDb.getPool();
    await localAuth.handleForgotPassword(req, res, pool);
    return;
  }

  if (pathname === '/api/reset-password' && req.method === 'POST') {
    setCorsHeaders(res, req);
    const pool = prodDb.getPool();
    await localAuth.handleResetPassword(req, res, pool);
    return;
  }

  if (pathname === '/api/admin/set-staff-password' && req.method === 'POST') {
    const pool = prodDb.getPool();
    await localAuth.handleAdminSetStaffPassword(req, res, pool);
    return;
  }

  if (pathname === '/api/auth/user') {
    setCorsHeaders(res, req);
    const pool = prodDb.getPool();
    await prodAuth.handleGetUser(req, res, pool);
    return;
  }

  if (pathname === '/api/login') {
    setCorsHeaders(res);
    const pool = prodDb.getPool();
    await prodAuth.handleLogin(req, res, pool);
    return;
  }

  if (pathname === '/api/callback') {
    setCorsHeaders(res);
    const pool = prodDb.getPool();
    await prodAuth.handleCallback(req, res, pool);
    return;
  }

  if (pathname === '/api/logout') {
    setCorsHeaders(res);
    const pool = prodDb.getPool();
    await prodAuth.handleLogout(req, res, pool);
    return;
  }

  // ==========================================
  // SIGNING ENDPOINTS - All use local PostgreSQL
  // ==========================================
  if (pathname === '/api/public/get-signing-session') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    if (req.method !== 'POST') { res.writeHead(405); res.end(); return; }
    try {
      const body = JSON.parse(await readBody(req));
      const token = body.token || body?.body?.token || body?.data?.token;
      console.log('[Signing] getSigningSession - token:', token);
      if (!token) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Token required' }));
        return;
      }
      const pool = prodDb.getPool();
      const result = await pool.query('SELECT * FROM signing_sessions WHERE signing_token = $1', [token]);
      if (result.rows.length === 0) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid or expired signing link' }));
        return;
      }
      const s = result.rows[0];
      if (s.expires_at && new Date(s.expires_at) < new Date()) {
        res.writeHead(410, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'This signing link has expired' }));
        return;
      }
      const responseSession = {
        id: s.id, base44_session_id: s.base44_session_id, company_id: s.company_id,
        template_id: s.template_id, template_name: s.template_name, contract_name: s.contract_name,
        customer_name: s.customer_name, customer_email: s.customer_email,
        delivery_method: s.delivery_method, rep_name: s.rep_name, rep_email: s.rep_email,
        rep_fields: s.rep_fields || {}, rep_signature_url: s.rep_signature_url,
        status: s.status, current_signer: s.current_signer, final_pdf_url: null,
      };
      const template = {
        id: s.template_id, template_name: s.template_name,
        fillable_fields: s.fillable_fields || [], original_file_url: s.original_file_url,
      };
      res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ success: true, session: responseSession, template }));
    } catch (err) {
      console.error('[Signing] getSigningSession error:', err.message);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: 'Server error: ' + err.message }));
    }
    return;
  }

  if (pathname === '/api/public/sign-contract') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    if (req.method !== 'POST') { res.writeHead(405); res.end(); return; }
    try {
      const body = JSON.parse(await readBody(req));
      const token = body.token || body?.body?.token || body?.data?.token;
      const fields = body.fields || body?.body?.fields || body?.data?.fields || {};
      const signature = body.signature || body?.body?.signature || body?.data?.signature;
      console.log('[Signing] signContract - token:', token, 'hasSignature:', !!signature);
      if (!token || !signature) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Token and signature required' }));
        return;
      }
      const pool = prodDb.getPool();
      const result = await pool.query('SELECT * FROM signing_sessions WHERE signing_token = $1', [token]);
      if (result.rows.length === 0) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Invalid signing link' }));
        return;
      }
      const session = result.rows[0];
      if (session.status === 'completed') {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Contract already signed' }));
        return;
      }
      if (session.expires_at && new Date(session.expires_at) < new Date()) {
        res.writeHead(410, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'This signing link has expired' }));
        return;
      }
      await pool.query(
        `UPDATE signing_sessions SET customer_fields=$1, customer_signature_data=$2, customer_signed_at=$3, status='completed', completed_at=$4, updated_at=$5 WHERE id=$6`,
        [JSON.stringify(fields), signature, new Date(), new Date(), new Date(), session.id]
      );
      console.log('[Signing] Session completed, id:', session.id);
      if (session.rep_email) {
        try {
          let fieldRows = '';
          if (fields && Object.keys(fields).length > 0) {
            for (const [key, value] of Object.entries(fields)) {
              fieldRows += `<tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:600;">${key}</td><td style="padding:8px;border-bottom:1px solid #eee;">${value}</td></tr>`;
            }
          } else {
            fieldRows = '<tr><td colspan="2" style="padding:8px;color:#999;">No additional fields filled.</td></tr>';
          }
          const notifHtml = `<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;"><div style="background:linear-gradient(135deg,#22c55e 0%,#16a34a 100%);padding:20px;text-align:center;border-radius:10px 10px 0 0;"><h1 style="color:white;margin:0;font-size:22px;">Contract Signed!</h1></div><div style="background:#f9fafb;padding:25px;border-radius:0 0 10px 10px;"><p><strong>Contract:</strong> ${session.contract_name || session.template_name || 'N/A'}</p><p><strong>Customer:</strong> ${session.customer_name}</p><p><strong>Signed at:</strong> ${new Date().toLocaleString()}</p><h3 style="margin-top:20px;border-bottom:2px solid #22c55e;padding-bottom:5px;">Customer Filled Information</h3><table style="width:100%;border-collapse:collapse;">${fieldRows}</table><p style="margin-top:20px;font-size:14px;color:#666;">The signed contract is available in your CRM under Contracts.</p></div></body></html>`;
          await sendEmail({
            to: session.rep_email,
            subject: `Contract Signed: ${session.contract_name || session.template_name} - ${session.customer_name}`,
            html: notifHtml
          });
          console.log('[Signing] Rep notification sent to:', session.rep_email);
        } catch (emailErr) {
          console.error('[Signing] Rep notification error:', emailErr.message);
        }
      }
      res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ success: true, message: 'Contract signed successfully' }));
    } catch (err) {
      console.error('[Signing] signContract error:', err.message, err.stack);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: 'Server error: ' + err.message }));
    }
    return;
  }

  if (pathname === '/api/contracts/send-signing-link') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    if (req.method !== 'POST') { res.writeHead(405); res.end(); return; }
    try {
      const body = JSON.parse(await readBody(req));
      const reqHost = req.headers?.host || '';
      const reqProto = req.headers?.['x-forwarded-proto'] || 'https';
      const replitBaseUrl = (reqHost ? `${reqProto}://${reqHost}` : (process.env.VITE_REPLIT_APP_URL || `https://${getPublicHost(req.headers)}`)).replace(/\/$/, '');
      const sessionId = body.sessionId || body.session_id;
      const sessionData = body.sessionData;

      console.log('[Signing] send-signing-link, sessionId:', sessionId, 'hasSessionData:', !!sessionData);

      if (!sessionId && !sessionData) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'sessionId or sessionData required' }));
        return;
      }

      const pool = prodDb.getPool();
      const { randomUUID } = require('crypto');
      const signingToken = randomUUID();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

      let session;

      if (sessionData) {
        console.log('[Signing] Inserting new local signing session...');
        const insertResult = await pool.query(
          `INSERT INTO signing_sessions 
            (base44_session_id, company_id, template_id, template_name, contract_name,
             customer_name, customer_email, customer_phone, delivery_method,
             rep_name, rep_email, rep_fields, rep_signature_url, rep_signed_at,
             fillable_fields, original_file_url, signing_token, status, current_signer, expires_at, sent_to_customer_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)
           RETURNING *`,
          [
            sessionData.base44_session_id || sessionId,
            sessionData.company_id,
            sessionData.template_id,
            sessionData.template_name,
            sessionData.contract_name,
            sessionData.customer_name,
            sessionData.customer_email,
            sessionData.customer_phone,
            sessionData.delivery_method || 'email',
            sessionData.rep_name,
            sessionData.rep_email,
            JSON.stringify(sessionData.rep_fields || {}),
            sessionData.rep_signature_url,
            sessionData.rep_signed_at ? new Date(sessionData.rep_signed_at) : null,
            JSON.stringify(sessionData.fillable_fields || []),
            sessionData.original_file_url,
            signingToken,
            'awaiting_customer',
            'customer',
            expiresAt,
            new Date(),
          ]
        );
        session = insertResult.rows[0];
        console.log('[Signing] Local session created, id:', session.id);
      } else {
        const existing = await pool.query('SELECT * FROM signing_sessions WHERE base44_session_id = $1', [sessionId]);
        if (existing.rows.length > 0) {
          await pool.query(
            'UPDATE signing_sessions SET signing_token=$1, status=$2, current_signer=$3, expires_at=$4, sent_to_customer_at=$5, updated_at=$6 WHERE base44_session_id=$7',
            [signingToken, 'awaiting_customer', 'customer', expiresAt, new Date(), new Date(), sessionId]
          );
          session = (await pool.query('SELECT * FROM signing_sessions WHERE base44_session_id = $1', [sessionId])).rows[0];
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: 'Session not found. Please provide sessionData.' }));
          return;
        }
      }

      const signingLink = `${replitBaseUrl}/sign-contract-customer?token=${signingToken}`;
      console.log('[Signing] Signing link:', signingLink);

      const customerEmail = session.customer_email || '';
      const customerName = session.customer_name || 'Customer';
      const contractName = session.contract_name || '';
      const templateName = session.template_name || '';
      const repName = session.rep_name || '';
      const deliveryMethod = session.delivery_method || 'email';
      const expiresDate = expiresAt.toLocaleDateString();

      let emailSent = false;
      let emailError = null;

      if (deliveryMethod === 'email' && customerEmail && customerEmail.includes('@')) {
        console.log('[Signing] Sending signing link email to:', customerEmail);
        const emailHtml = `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head><body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;"><div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;"><h2 style="color: white; margin: 0 0 5px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 2px;">Contract Signing</h2><h1 style="color: white; margin: 0; font-size: 24px;">Contract Ready for Your Signature</h1></div><div style="background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px;"><p style="font-size: 16px;">Hello <strong>${customerName}</strong>,</p><p style="font-size: 16px;">${repName ? repName + ' has' : 'You have been'} sent you a contract for electronic signature.</p>${templateName || contractName ? `<div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea;">${templateName ? `<p style="margin: 5px 0;"><strong>Contract:</strong> ${templateName}</p>` : ''}${contractName ? `<p style="margin: 5px 0;"><strong>Job:</strong> ${contractName}</p>` : ''}<p style="margin: 5px 0;"><strong>Expires:</strong> ${expiresDate}</p></div>` : ''}<p style="text-align: center; margin: 30px 0;"><a href="${signingLink}" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; font-size: 18px; font-weight: bold;">Review & Sign Contract</a></p><p style="font-size: 14px; color: #666;">This link expires on <strong>${expiresDate}</strong>.</p></div></body></html>`;
        try {
          await sendEmail({
            to: customerEmail,
            subject: `Contract Ready: ${templateName || contractName || 'Review & Sign'}`,
            html: emailHtml
          });
          console.log('[Signing] Signing link email sent to:', customerEmail);
          emailSent = true;
        } catch (emailErr) {
          console.error('[Signing] Email error:', emailErr.message);
          emailError = emailErr.message;
        }
      }

      const result = {
        success: true,
        signing_link: signingLink,
        local_session_id: session.id,
        expires_at: expiresAt.toISOString(),
        delivery_method: deliveryMethod,
        email_sent: emailSent,
        message: deliveryMethod === 'sms'
          ? `SMS signing link ready for ${session.customer_phone}`
          : emailSent ? `Email sent to ${customerEmail}` : `Email not sent: ${emailError || 'unknown'}`,
      };
      if (emailError) result.email_warning = emailError;

      res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify(result));
    } catch (err) {
      console.error('[Signing] sendSigningLink error:', err.message, err.stack);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: err.message }));
    }
    return;
  }

  if (pathname === '/api/whatsapp-webhook') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    try {
      const body = await readBody(req);
      const params = new URLSearchParams(body);
      const from = params.get('From') || '';
      const to = params.get('To') || '';
      const messageBody = params.get('Body') || '';
      const messageSid = params.get('MessageSid') || '';
      const numMedia = parseInt(params.get('NumMedia') || '0');
      const isWhatsApp = from.startsWith('whatsapp:') || to.startsWith('whatsapp:');
      const cleanFrom = from.replace('whatsapp:', '');
      const cleanTo = to.replace('whatsapp:', '');
      console.log(`[Sarah] ${isWhatsApp ? 'WhatsApp' : 'SMS'} webhook: from=${cleanFrom}, body="${messageBody.substring(0, 100)}"`);
      const normalizedTo = cleanTo.replace(/[^\d]/g, '').replace(/^(\d{10})$/, '+1$1').replace(/^1(\d{10})$/, '+1$1').replace(/^(\d{11})$/, '+$1');
      const e164To = normalizedTo.startsWith('+') ? normalizedTo : `+${normalizedTo}`;

      const pool = prodDb.getPool();
      let resolvedCompanyId = null;
      try {
        const localLookup = await pool.query(
          `SELECT company_id FROM call_routing_cache WHERE phone_number = $1 LIMIT 1`, [e164To]
        );
        if (localLookup.rows[0]) {
          resolvedCompanyId = localLookup.rows[0].company_id;
          console.log(`[Sarah] SMS local routing hit: ${e164To} -> ${resolvedCompanyId}`);
        }
        if (!resolvedCompanyId) {
          const twilioLookup = await pool.query(
            `SELECT company_id FROM generic_entities WHERE entity_type = 'TwilioSettings' AND (data->>'main_phone_number' = $1) LIMIT 1`, [e164To]
          );
          if (twilioLookup.rows[0]) {
            resolvedCompanyId = twilioLookup.rows[0].company_id;
            console.log(`[Sarah] SMS TwilioSettings hit: ${e164To} -> ${resolvedCompanyId}`);
          }
        }
      } catch (e) {}
      if (!resolvedCompanyId && BASE44_API_URL) {
        try {
          const lookup = await callBase44API('lookupByPhone', null, { phone_number: e164To });
          if (lookup?.success && lookup.company_id) resolvedCompanyId = lookup.company_id;
        } catch (e) {}
      }
      if (!resolvedCompanyId) { res.writeHead(200, { 'Content-Type': 'text/xml' }); res.end('<?xml version="1.0" encoding="UTF-8"?><Response></Response>'); return; }
      try {
        const msgSettings = await callBase44API('getMessagingSettings', resolvedCompanyId);
        if (isWhatsApp && msgSettings?.whatsapp_enabled !== true) { res.writeHead(200, { 'Content-Type': 'text/xml' }); res.end('<?xml version="1.0" encoding="UTF-8"?><Response></Response>'); return; }
        const aiResponse = await callBase44API('handleIncomingMessage', resolvedCompanyId, { from: cleanFrom, to: cleanTo, body: messageBody, message_sid: messageSid, channel: isWhatsApp ? 'whatsapp' : 'sms', num_media: numMedia });
        if (aiResponse?.reply) { res.writeHead(200, { 'Content-Type': 'text/xml' }); res.end(`<?xml version="1.0" encoding="UTF-8"?><Response><Message>${aiResponse.reply}</Message></Response>`); }
        else { res.writeHead(200, { 'Content-Type': 'text/xml' }); res.end('<?xml version="1.0" encoding="UTF-8"?><Response></Response>'); }
      } catch (e) { console.error('[Sarah] WhatsApp/SMS error:', e.message); res.writeHead(200, { 'Content-Type': 'text/xml' }); res.end('<?xml version="1.0" encoding="UTF-8"?><Response></Response>'); }
    } catch (e) { res.writeHead(200, { 'Content-Type': 'text/xml' }); res.end('<?xml version="1.0" encoding="UTF-8"?><Response></Response>'); }
    return;
  }

  if (pathname === '/api/sarah-missed-call') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    try {
      const body = await readBody(req);
      const params = new URLSearchParams(body);
      const callStatus = params.get('CallStatus') || '';
      const callerPhone = params.get('From') || params.get('Caller') || '';
      const calledNumber = params.get('To') || params.get('Called') || '';
      const callSid = params.get('CallSid') || '';
      if (callStatus !== 'no-answer' && callStatus !== 'busy' && callStatus !== 'failed') { res.writeHead(200); res.end('OK'); return; }
      console.log(`[Sarah] Missed call: from=${callerPhone}, status=${callStatus}`);
      const pool = prodDb.getPool();
      let resolvedCompanyId = null;
      try {
        const localLookup = await pool.query(
          `SELECT company_id FROM call_routing_cache WHERE phone_number = $1 LIMIT 1`,
          [calledNumber]
        );
        if (localLookup.rows[0]) resolvedCompanyId = localLookup.rows[0].company_id;
        if (!resolvedCompanyId) {
          const twilioLookup = await pool.query(
            `SELECT company_id FROM generic_entities WHERE entity_type = 'TwilioSettings' AND (data->>'main_phone_number' = $1) LIMIT 1`,
            [calledNumber]
          );
          if (twilioLookup.rows[0]) resolvedCompanyId = twilioLookup.rows[0].company_id;
        }
      } catch (e) {}
      if (!resolvedCompanyId && BASE44_API_URL) {
        try { const lookup = await callBase44API('lookupByPhone', null, { phone_number: calledNumber }); if (lookup?.success && lookup.company_id) resolvedCompanyId = lookup.company_id; } catch (e) {}
      }
      if (!resolvedCompanyId) { res.writeHead(200); res.end('OK'); return; }
      try {
        const msgSettings = await callBase44API('getMessagingSettings', resolvedCompanyId);
        if (msgSettings?.missed_call_followup_enabled !== true) { console.log(`[Sarah] Missed call follow-up disabled`); res.writeHead(200); res.end('OK'); return; }
        await callBase44API('sendMissedCallFollowup', resolvedCompanyId, { caller_phone: callerPhone, called_number: calledNumber, call_sid: callSid, call_status: callStatus, channel: msgSettings.missed_call_channel || 'sms' });
        console.log(`[Sarah] Missed call follow-up sent to ${callerPhone}`);
      } catch (e) { console.error('[Sarah] Missed call follow-up error:', e.message); }
      res.writeHead(200); res.end('OK');
    } catch (e) { res.writeHead(200); res.end('OK'); }
    return;
  }

  if (pathname === '/api/messaging-settings') {
    setCorsHeaders(res);
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    const defaults = { whatsapp_enabled: false, missed_call_followup_enabled: false, appointment_reminders_enabled: false, missed_call_channel: 'sms', missed_call_template: '', appointment_reminder_template: '', dedup_window_hours: 24 };
    if (req.method === 'GET') {
      const companyId = url.searchParams.get('companyId') || '';
      if (!companyId) { res.writeHead(400, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: 'Missing companyId' })); return; }
      if (!BASE44_API_URL) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(defaults)); return; }
      try {
        const settings = await callBase44API('getMessagingSettings', companyId);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(settings || defaults));
      } catch (e) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(defaults)); }
    } else if (req.method === 'POST') {
      try {
        const body = JSON.parse(await readBody(req));
        const { companyId, ...settings } = body;
        if (!companyId) { res.writeHead(400, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: 'companyId required' })); return; }
        if (!BASE44_API_URL) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ success: true, ...settings })); return; }
        const result = await callBase44API('saveMessagingSettings', companyId, settings);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, ...result }));
      } catch (e) { res.writeHead(500, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: e.message })); }
    } else { res.writeHead(405); res.end(); }
    return;
  }

  if (pathname === '/api/integrations/upload' && req.method === 'POST') {
    await prodIntegrations.handleUpload(req, res);
    return;
  }

  if (pathname === '/api/integrations/invoke-llm' && req.method === 'POST') {
    await prodIntegrations.handleInvokeLLM(req, res);
    return;
  }

  if (pathname === '/api/integrations/send-email' && req.method === 'POST') {
    await prodIntegrations.handleSendEmail(req, res);
    return;
  }

  if (pathname === '/api/functions/invoke' && req.method === 'POST') {
    await prodIntegrations.handleFunctionInvoke(req, res);
    return;
  }

  // Google Calendar OAuth callback — must match redirect_uri in connectUserGoogleCalendar
  if (pathname === '/api/google-calendar-callback' && req.method === 'GET') {
    try {
      const code = url.searchParams.get('code');
      const state = url.searchParams.get('state');
      const error = url.searchParams.get('error');
      const host = getPublicHost(req.headers);
      const appUrl = (process.env.VITE_REPLIT_APP_URL || `https://${host}`).replace(/\/+$/, '');

      if (error) {
        const errorDesc = url.searchParams.get('error_description') || error;
        console.error('[Calendar] Google OAuth error:', error, '-', errorDesc);
        res.writeHead(302, { Location: `${appUrl}/settings/general?google_error=${encodeURIComponent(errorDesc)}` });
        res.end();
        return;
      }
      if (!code) {
        res.writeHead(400, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>Missing authorization code</h1></body></html>');
        return;
      }

      let stateData, userEmail, redirectTo;
      try {
        stateData = JSON.parse(Buffer.from(state, 'base64').toString());
        userEmail = stateData.user_email;
        redirectTo = stateData.redirect_to || '/calendar';
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>Invalid state parameter</h1></body></html>');
        return;
      }

      if (!userEmail) {
        res.writeHead(400, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>Invalid state: missing user email</h1></body></html>');
        return;
      }

      const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || process.env.Google_Client_Id;
      const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || process.env.Google_Secret_Key;
      if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET) {
        res.writeHead(500, { 'Content-Type': 'text/html' });
        res.end('<html><body><h1>Google OAuth not configured</h1></body></html>');
        return;
      }

      const REDIRECT_URI = `${appUrl}/api/google-calendar-callback`;
      const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: GOOGLE_CLIENT_ID,
          client_secret: GOOGLE_CLIENT_SECRET,
          redirect_uri: REDIRECT_URI,
          grant_type: 'authorization_code'
        })
      });
      const tokens = await tokenResp.json();

      if (tokens.error || !tokens.access_token) {
        console.error('[Calendar] Token exchange error:', JSON.stringify(tokens));
        console.error('[Calendar] Ensure redirect URI is in Google Cloud Console:', REDIRECT_URI);
        const errMsg = tokens.error_description || tokens.error || 'Token exchange failed';
        res.writeHead(302, { Location: `${appUrl}/settings/general?google_error=${encodeURIComponent(errMsg)}` });
        res.end();
        return;
      }

      const pool = prodDb.getPool();
      const expiresAt = new Date(Date.now() + (tokens.expires_in * 1000)).toISOString();
      await pool.query(
        `UPDATE users SET google_calendar_connected = true, google_access_token = $1, google_refresh_token = COALESCE($2, google_refresh_token), google_token_expires_at = $3, google_sync_enabled = true, last_google_sync = NOW(), updated_at = NOW() WHERE email = $4`,
        [tokens.access_token, tokens.refresh_token || null, expiresAt, userEmail]
      );
      console.log('[Calendar] Google Calendar connected for', userEmail);

      try {
        const handlers = await prodIntegrations.getFunctionHandlers();
        if (handlers.syncUserGoogleCalendar) {
          await handlers.syncUserGoogleCalendar({ targetUserEmail: userEmail });
          console.log('[Calendar] Initial sync completed for', userEmail);
        }
      } catch (syncErr) {
        console.error('[Calendar] Initial sync failed:', syncErr.message);
      }

      const successHtml = `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Google Calendar Connected</title><meta http-equiv="refresh" content="2;url=${appUrl}${redirectTo}?google_connected=true"><style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%)}.container{background:white;border-radius:16px;padding:40px;max-width:500px;box-shadow:0 20px 60px rgba(0,0,0,0.3);text-align:center}.icon{font-size:64px;margin-bottom:20px}h1{color:#10b981;margin:0 0 20px 0}p{color:#666;line-height:1.6}.btn{display:inline-block;background:#667eea;color:white;padding:12px 32px;border-radius:8px;text-decoration:none;font-weight:600}</style></head><body><div class="container"><div class="icon">✅</div><h1>Success!</h1><p>Google Calendar connected successfully!</p><a href="${appUrl}${redirectTo}?google_connected=true" class="btn">Return to Calendar</a><p style="color:#999;font-size:14px;margin-top:20px">Redirecting automatically...</p></div></body></html>`;
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(successHtml);
    } catch (err) {
      console.error('[Calendar] Callback error:', err);
      res.writeHead(500, { 'Content-Type': 'text/html' });
      res.end(`<html><body><h1>Error</h1><p>${err.message}</p></body></html>`);
    }
    return;
  }

  if (req.method === 'OPTIONS' && pathname.startsWith('/api/integrations/')) {
    setCorsHeaders(res);
    res.writeHead(200);
    res.end();
    return;
  }

  if (pathname.startsWith('/uploads/')) {
    if (prodIntegrations.serveUploadedFile(req, res, pathname)) return;
  }

  if (pathname.startsWith('/api/')) {
    console.warn(`[Server] 404 API route not found: ${req.method} ${pathname}`);
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found' }));
    return;
  }

  let filePath = path.join(DIST_DIR, pathname === '/' ? 'index.html' : pathname);
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    serveStaticFile(res, filePath);
    return;
  }

  const indexPath = path.join(DIST_DIR, 'index.html');
  if (fs.existsSync(indexPath)) {
    serveStaticFile(res, indexPath);
  } else {
    res.writeHead(404);
    res.end('Not Found');
  }
  } catch (err) {
    console.error('[Server] Request handler error:', err.message, req.url);
    if (!res.headersSent) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
    }
  }
});

const twilioWss = new WebSocketServer({ noServer: true });
const lexiWss = new WebSocketServer({ noServer: true });

server.on('upgrade', (req, socket, head) => {
  if (req.url?.startsWith('/ws/twilio')) {
    twilioWss.handleUpgrade(req, socket, head, ws => twilioWss.emit('connection', ws, req));
  } else if (req.url?.startsWith('/ws/lexi-native')) {
    lexiWss.handleUpgrade(req, socket, head, ws => lexiWss.emit('connection', ws, req));
  } else {
    socket.destroy();
  }
});

twilioWss.on('connection', async (twilioWs, req) => {
  console.log('[Sarah] Twilio media stream connected');
  let geminiWs = null;
  let currentStreamSid = null;
  let setupComplete = false;
  let waitingForOutboundGreeting = false;
  let outboundGreetingGateTimer = null;
  let callCompanyId = null;
  let callerPhone = null;
  let callSid = null;
  let callStartTime = Date.now();
  let conversationLog = [];
  let toolCallsMade = [];
  let collectedCallerName = null;
  let callLogSaved = false;
  let companyName = 'CompanySync';
  let assistantName = 'Sarah';
  let isOutboundCall = false;
  let outboundLeadName = '';
  let outboundLeadService = '';
  let outboundCampaign = null;
  let subscriberSystemPrompt = '';
  let companyDescription = '';
  let companyKnowledge = '';
  let geminiKeepaliveInterval = null;
  let isForwardedCall = false;
  let forwardedRepName = '';
  let forwardedRepEmail = '';
  let forwardedRepPhone = '';
  let callRoutingMode = 'sarah_answers';
  let staffCellPhone = '';
  let calledTwilioNumber = '';

  let geminiApiKey = process.env.GOOGLE_GEMINI_API_KEY;

  async function saveCallToBase44() {
    if (callLogSaved) return;
    callLogSaved = true;
    const dur = Math.round((Date.now() - callStartTime) / 1000);
    const transcript = conversationLog.map(e => `${e.role}: ${e.text}`).join('\n');
    try {
      await callBase44API('saveCallLog', callCompanyId, { caller_phone: callerPhone || 'Unknown', caller_name: collectedCallerName || outboundLeadName || 'Voice Caller', duration_seconds: dur, transcript, call_sid: callSid || '', tool_calls_made: toolCallsMade, assistant_name: assistantName, direction: isForwardedCall ? 'forwarded' : (isOutboundCall ? 'outbound' : 'inbound') });
      await callBase44API('trackCallMinutes', callCompanyId, { duration_seconds: dur });
      billAIUsage(callCompanyId, Math.max(1, Math.ceil(dur / 60)));
      logUsageEvent(callCompanyId, 'sarah', Math.max(1, Math.ceil(dur / 60))).catch(() => {});
    } catch (err) { console.error('[Sarah] Save failed:', err.message); }
  }

  try {
    const companyKey = await prodDb.getCompanyGeminiKey(callCompanyId);
    if (companyKey) geminiApiKey = companyKey;
  } catch (e) { console.error('[Sarah] BYOK key lookup failed:', e.message); }
  if (!geminiApiKey) { console.error('[Sarah] No API key'); twilioWs.close(); return; }

  const geminiUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${geminiApiKey}`;

  async function connectGemini() {
    const currentSettings = loadSettings();
    let voiceName = currentSettings.voice || 'Kore';

    let inboundGreeting = '';
    if (callCompanyId) {
      try {
        const crm = await callBase44API('getSettings', callCompanyId);
        const rawDisplay = (crm.settings?.intent_templates?._assistant_display_name || '').trim();
        const rawAssistant = (crm.settings?.assistant_name || '').trim();
        const rawBrand = (crm.settings?.brand_short_name || '').trim();
        if (rawBrand) companyName = rawBrand; else if (crm.companyName) companyName = crm.companyName;
        if (rawDisplay) assistantName = rawDisplay.charAt(0).toUpperCase() + rawDisplay.slice(1);
        else if (rawAssistant) assistantName = rawAssistant.charAt(0).toUpperCase() + rawAssistant.slice(1);
        if (crm.settings?.voice_id) voiceName = crm.settings.voice_id;
        else if (crm.settings?.voice) voiceName = crm.settings.voice;
        if (crm.customSystemPrompt) subscriberSystemPrompt = crm.customSystemPrompt;
        if (crm.knowledgeBase) companyKnowledge = crm.knowledgeBase;
        if (crm.companyDescription) companyDescription = crm.companyDescription;
        if (crm.companyServices) companyDescription += '\nServices: ' + crm.companyServices;
        if (crm.settings?.inbound_greeting) inboundGreeting = crm.settings.inbound_greeting;
      } catch (e) { console.warn('[Sarah] CRM load failed:', e.message); }
    }

    if (!VALID_GEMINI_VOICES.includes(voiceName)) { console.warn(`[Sarah] Invalid voice "${voiceName}", using Kore`); voiceName = 'Kore'; }
    console.log(`[Sarah] Connecting Gemini: voice=${voiceName}, company=${companyName}, assistant=${assistantName}`);

    geminiWs = new WebSocket(geminiUrl);

    geminiWs.on('open', () => {
      const forwardedInfo = isForwardedCall ? { isForwarded: true, repName: forwardedRepName, repEmail: forwardedRepEmail, repPhone: forwardedRepPhone } : null;
      const prompt = buildSystemPrompt(companyName, assistantName, isOutboundCall, outboundLeadName, outboundLeadService, subscriberSystemPrompt, companyDescription, companyKnowledge, forwardedInfo);
      geminiWs.send(JSON.stringify({
        setup: {
          model: "models/gemini-2.5-flash-native-audio-latest",
          generation_config: { response_modalities: ["AUDIO"], speech_config: { voice_config: { prebuilt_voice_config: { voice_name: voiceName } } } },
          system_instruction: { parts: [{ text: prompt }] },
          tools: [{ function_declarations: CRM_TOOLS }]
        }
      }));
    });

    geminiWs.on('message', async (raw) => {
      try {
        const data = JSON.parse(raw.toString());

        if (data.setupComplete) {
          setupComplete = true;
          console.log(`[${assistantName}] Gemini setup complete, sending greeting (outbound: ${isOutboundCall}, forwarded: ${isForwardedCall})...`);
          geminiKeepaliveInterval = setInterval(() => {
            if (geminiWs?.readyState === WebSocket.OPEN) {
              geminiWs.send(JSON.stringify({ realtime_input: { media_chunks: [{ data: Buffer.alloc(320).toString('base64'), mime_type: "audio/pcm;rate=16000" }] } }));
            } else {
              clearInterval(geminiKeepaliveInterval);
            }
          }, 5000);
          let returningLeadContext = '';
          if (callerPhone && callCompanyId) {
            try {
              const cleanPhone = callerPhone.replace(/[^\d+]/g, '');
              const phoneVariants = [cleanPhone, cleanPhone.replace(/^\+1/, ''), '+1' + cleanPhone.replace(/^\+1/, '')];
              const leadResult = await pool.query(
                `SELECT data FROM generic_entities WHERE entity_type = 'Lead' AND company_id = $1 AND (data->>'phone' = ANY($2) OR data->>'mobile_phone' = ANY($2)) ORDER BY updated_date DESC LIMIT 1`,
                [callCompanyId, phoneVariants]
              );
              if (leadResult.rows.length > 0) {
                const lead = leadResult.rows[0].data;
                const commResult = await pool.query(
                  `SELECT data FROM generic_entities WHERE entity_type = 'Communication' AND company_id = $1 AND data->>'lead_id' = $2 ORDER BY updated_date DESC LIMIT 3`,
                  [callCompanyId, lead.id || '']
                );
                const lastComm = commResult.rows[0]?.data;
                if (lead.full_name || lead.name) {
                  returningLeadContext = `\n\nRETURNING CALLER CONTEXT: This caller (${callerPhone}) is ${lead.full_name || lead.name}. `;
                  if (lastComm) returningLeadContext += `Last interaction: ${lastComm.type || 'contact'} on ${lastComm.date || lastComm.created_date || 'unknown date'}. `;
                  if (lead.service_needed || lead.service_type) returningLeadContext += `They previously inquired about: ${lead.service_needed || lead.service_type}. `;
                  if (lead.notes) returningLeadContext += `Notes: ${lead.notes}. `;
                  returningLeadContext += `Greet them by name and reference your prior conversation. Don't ask for info you already have.`;
                  console.log(`[${assistantName}] Returning lead detected: ${lead.full_name || lead.name}`);
                }
              }
            } catch (e) {
              console.log(`[${assistantName}] No prior history found for ${callerPhone}`);
            }
          }

          let greetingText;
          if (isForwardedCall && callRoutingMode === 'sarah_then_transfer') {
            greetingText = `A customer just called ${forwardedRepName}'s line. Greet them warmly as ${assistantName} with ${companyName}, answering for ${forwardedRepName}. Your goal is to: 1) Get their name, phone number, and what they need help with. 2) Save their info using save_lead_details (assign to ${forwardedRepName}). 3) Once you have their info, tell them you'll connect them with ${forwardedRepName} now and call transfer_call. Keep the conversation brief and focused on gathering info before transferring. Remember your name is ${assistantName}.${returningLeadContext}`;
          } else if (isForwardedCall) {
            greetingText = `A customer just called ${forwardedRepName}'s line and it was forwarded to you. Greet them warmly as ${assistantName} with ${companyName}, answering for ${forwardedRepName}. Remember your name is ${assistantName}. Any leads from this call should be assigned to ${forwardedRepName}.${returningLeadContext}`;
          } else if (isOutboundCall) {
            if (outboundCampaign && outboundCampaign.intro) {
              const replaceVars = (t) => (t || '').replace(/\{agent\}/g, assistantName).replace(/\{brand\}/g, companyName).replace(/\{lead_name\}/g, outboundLeadName || 'the homeowner').replace(/\{lead_service\}/g, outboundLeadService || 'their inquiry');
              const campaignIntro = replaceVars(outboundCampaign.intro);
              const campaignPoints = outboundCampaign.points ? `\n\nTALKING POINTS:\n${replaceVars(outboundCampaign.points)}` : '';
              const campaignGoals = outboundCampaign.goals ? `\n\nGOALS: ${outboundCampaign.goals}` : '';

              let campaignTraining = '';
              if (outboundCampaign.campaign_system_prompt) campaignTraining += `\n\nCAMPAIGN SYSTEM PROMPT:\n${outboundCampaign.campaign_system_prompt}`;
              if (outboundCampaign.knowledge_base) campaignTraining += `\n\nCAMPAIGN KNOWLEDGE BASE:\n${outboundCampaign.knowledge_base}`;
              if (outboundCampaign.tone_style) {
                const toneMap = { warm_empathetic: 'Be warm, caring, and empathetic. Show genuine concern.', professional: 'Be polished and professional.', casual_friendly: 'Be casual and friendly, like talking to a neighbor.', direct_confident: 'Be direct and confident without being pushy.' };
                campaignTraining += `\n\nTONE: ${toneMap[outboundCampaign.tone_style] || ''}`;
              }
              if (outboundCampaign.humor_level !== undefined) campaignTraining += ` Humor level: ${outboundCampaign.humor_level}% (${outboundCampaign.humor_level < 20 ? 'very serious' : outboundCampaign.humor_level < 50 ? 'light' : 'witty'}).`;
              if (outboundCampaign.example_conversations?.length > 0) {
                campaignTraining += '\n\nEXAMPLE CONVERSATIONS:';
                outboundCampaign.example_conversations.forEach((ex, i) => { campaignTraining += `\n--- Example ${i+1} ---\nCustomer: "${ex.customer}"\nYou: "${ex.sarah}"`; });
              }
              if (outboundCampaign.objection_handling?.length > 0) {
                campaignTraining += '\n\nOBJECTION HANDLING:';
                outboundCampaign.objection_handling.forEach(oh => { campaignTraining += `\nIf they say: "${oh.objection}" → Respond: "${oh.response}"`; });
              }
              if (outboundCampaign.dos?.length > 0) campaignTraining += '\n\nDO: ' + outboundCampaign.dos.join('; ');
              if (outboundCampaign.donts?.length > 0) campaignTraining += '\nDO NOT: ' + outboundCampaign.donts.join('; ');
              if (outboundCampaign.bailout_message) campaignTraining += `\n\nBAILOUT SCRIPT: If the conversation stalls or the lead becomes unresponsive, say: "${outboundCampaign.bailout_message}"`;


              let aiIdLine = '';
              if (outboundCampaign.ai_identification) aiIdLine = `\n\nAI DISCLOSURE: ${outboundCampaign.ai_identification_text || 'If asked, honestly tell them you are an AI assistant.'}`;

              let customGreetingLine = '';
              if (outboundCampaign.custom_greeting) customGreetingLine = `\n\nCUSTOM OPENING LINE: Use this greeting: "${replaceVars(outboundCampaign.custom_greeting)}"`;

              greetingText = `You are making an outbound call to ${outboundLeadName || 'a potential customer'}. ${campaignIntro}${aiIdLine}${customGreetingLine}${campaignPoints}${campaignGoals}${campaignTraining}\n\nRemember your name is ${assistantName}. Start the conversation now.`;
            } else {
              greetingText = `You are making an outbound call to ${outboundLeadName || 'a potential customer'}${outboundLeadService ? ' who inquired about ' + outboundLeadService : ''}. Introduce yourself as ${assistantName}, an AI assistant from ${companyName}, and ask if you're speaking with ${outboundLeadName || 'the homeowner'}. You MUST mention you are an AI assistant in your opening line. Then continue the conversation naturally. Remember your name is ${assistantName}.`;
            }
          } else {
            const inboundReplaceVars = (t) => (t || '').replace(/\{agent\}/g, assistantName).replace(/\{brand\}/g, companyName);
            if (inboundGreeting) {
              greetingText = `A customer just called. Use this custom opening: "${inboundReplaceVars(inboundGreeting)}". You MUST identify yourself as an AI assistant. Remember your name is ${assistantName}.${returningLeadContext}`;
            } else {
              greetingText = `A customer just called. Greet them warmly as ${assistantName}, the AI assistant for ${companyName}. In your opening line, mention that you are an AI assistant. Remember, your name is ${assistantName}, not Sarah or any other name.${returningLeadContext}`;
            }
          }
          if (isOutboundCall) {
            waitingForOutboundGreeting = true;
            if (outboundGreetingGateTimer) clearTimeout(outboundGreetingGateTimer);
            outboundGreetingGateTimer = setTimeout(() => {
              if (waitingForOutboundGreeting) {
                console.log(`[${assistantName}] Outbound greeting gate timed out — opening mic to caller`);
                waitingForOutboundGreeting = false;
              }
            }, 10000);
            console.log(`[${assistantName}] Outbound gate: blocking caller mic until Gemini starts speaking`);
          }
          geminiWs.send(JSON.stringify({ client_content: { turns: [{ role: "user", parts: [{ text: greetingText }] }], turn_complete: true } }));
        }

        if (data.toolCall) {
          const fcs = data.toolCall.functionCalls || [];
          const responses = [];
          if (geminiWs.readyState === WebSocket.OPEN) {
            geminiWs.send(JSON.stringify({
              client_content: {
                turns: [{ role: "user", parts: [{ text: "[System: Tool call in progress. Say a brief filler like 'One sec, let me check on that' or 'Sure, pulling that up now' while waiting. Keep it under 8 words.]" }] }],
                turn_complete: true
              }
            }));
          }

          for (const fc of fcs) {
            let result;
            try {
              const toolPromise = handleToolCall(fc, callCompanyId);
              const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Tool call timed out after 4s')), 4000));
              result = await Promise.race([toolPromise, timeoutPromise]);
            } catch (err) {
              console.error(`[Sarah] Tool call ${fc.name} failed:`, err.message);
              result = { error: err.message, status: 'failed' };
            }
            toolCallsMade.push(fc.name);
            if (fc.name === 'save_lead_details' && fc.args?.name) collectedCallerName = fc.args.name;
            if (fc.name === 'transfer_call' && result?.success && callSid) {
              const parsedTransferArgs = typeof fc.args === 'string' ? JSON.parse(fc.args) : (fc.args || {});
              const targetPerson = parsedTransferArgs.target_person || '';
              let transferCellPhone = staffCellPhone;
              let transferRepName = forwardedRepName;

              if (targetPerson && callCompanyId) {
                const targetLower = targetPerson.toLowerCase();
                for (const [phone, entry] of subscriberCache.entries()) {
                  if (entry.companyId === callCompanyId && entry.repName) {
                    const nameLower = entry.repName.toLowerCase();
                    if (nameLower.includes(targetLower) || nameLower.split(' ').some(part => part === targetLower)) {
                      transferCellPhone = entry.cellPhone || '';
                      transferRepName = entry.repName;
                      console.log(`[Sarah] Name-based transfer (cache): found ${transferRepName}, cell=${transferCellPhone}`);
                      break;
                    }
                  }
                }
                if (!transferCellPhone) {
                  try {
                    const allRouting = await callBase44API('getAllSubscriberRouting', null);
                    if (allRouting?.subscribers && Array.isArray(allRouting.subscribers)) {
                      const matched = allRouting.subscribers.find(s =>
                        s.company_id === callCompanyId && s.rep_name && (
                          s.rep_name.toLowerCase().includes(targetLower) ||
                          s.rep_name.toLowerCase().split(' ').some(part => part === targetLower)
                        )
                      );
                      if (matched) {
                        transferCellPhone = matched.cell_phone || '';
                        transferRepName = matched.rep_name;
                        console.log(`[Sarah] Name-based transfer (DB): found ${transferRepName}, cell=${transferCellPhone}`);
                      }
                    }
                  } catch (e) { console.warn(`[Sarah] Routing lookup failed:`, e.message); }
                }
              }

              if (!transferCellPhone) {
                const cachedForTransfer = calledTwilioNumber ? getCachedSubscriber(calledTwilioNumber) : null;
                transferCellPhone = cachedForTransfer?.cellPhone || '';
                if (!transferCellPhone && calledTwilioNumber && callCompanyId) {
                  try {
                    const staffLookup = await callBase44API('lookupStaffByTwilioNumber', callCompanyId, { twilio_number: calledTwilioNumber });
                    transferCellPhone = staffLookup?.staff?.phone || staffLookup?.staff?.cell_phone || '';
                    if (transferCellPhone) {
                      transferRepName = transferRepName || staffLookup?.staff?.full_name || '';
                      console.log('[Sarah] Got cell from staff lookup:', transferCellPhone);
                    }
                  } catch (e) {}
                }
              }
              if (!transferCellPhone) {
                console.error(`[Sarah] Cannot transfer: no cell phone found for ${targetPerson || transferRepName || 'any staff'}`);
                responses.push({ id: fc.id, name: fc.name, response: { error: 'No cell phone number configured for transfer. Please set your cell phone in Twilio Setup.' } });
                continue;
              }
              console.log(`[Sarah] TRANSFER requested: callSid=${callSid}, cell=${transferCellPhone}, rep=${transferRepName}, target=${targetPerson || '(default)'}, calledNumber=${calledTwilioNumber}`);
              setTimeout(async () => {
                try {
                  let tSid, tToken, callerIdNum;
                  // Use exact called number for cache lookup (not company search)
                  const cachedData = calledTwilioNumber ? getCachedSubscriber(calledTwilioNumber) : null;
                  if (cachedData?.twilioSid && cachedData?.twilioToken) {
                    tSid = cachedData.twilioSid;
                    tToken = cachedData.twilioToken;
                    callerIdNum = cachedData.twilioPhone || calledTwilioNumber || '';
                    console.log('[Sarah] Using cached Twilio credentials for transfer');
                  } else {
                    const twilioSettings = await callBase44API('getTwilioSettings', callCompanyId);
                    tSid = twilioSettings?.account_sid;
                    tToken = twilioSettings?.auth_token;
                    callerIdNum = twilioSettings?.main_phone_number || '';
                  }
                  if (tSid && tToken) {
                    const authStr = Buffer.from(`${tSid}:${tToken}`).toString('base64');
                    const transferHost = getPublicHost(null);
                    const transferUrl = `https://${transferHost}/twiml/transfer?cellPhone=${encodeURIComponent(transferCellPhone)}&callerId=${encodeURIComponent(callerIdNum)}&repName=${encodeURIComponent(transferRepName || forwardedRepName)}`;
                    const updateResp = await fetch(
                      `https://api.twilio.com/2010-04-01/Accounts/${tSid}/Calls/${callSid}.json`,
                      { method: 'POST', headers: { 'Authorization': `Basic ${authStr}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: `Url=${encodeURIComponent(transferUrl)}&Method=POST` }
                    );
                    console.log(`[Sarah] Transfer API response: ${updateResp.status}`);
                    saveCallToBase44();
                  } else {
                    console.error('[Sarah] Cannot transfer: Twilio credentials not found in cache or DB');
                  }
                } catch (err) {
                  console.error('[Sarah] Transfer failed:', err.message);
                }
              }, 2000);
            }
            responses.push({ id: fc.id, name: fc.name, response: typeof result === 'object' ? result : { output: String(result) } });
          }
          if (geminiWs.readyState === WebSocket.OPEN) {
            geminiWs.send(JSON.stringify({ tool_response: { function_responses: responses } }));

            const toolNames = fcs.map(fc => fc.name).join(', ');
            geminiWs.send(JSON.stringify({
              client_content: {
                turns: [{
                  role: "user",
                  parts: [{ text: `[System: ${toolNames} completed. Now respond to the caller naturally with the result. Keep it brief and conversational.]` }]
                }],
                turn_complete: true
              }
            }));
          }
        }

        if (data.serverContent?.modelTurn?.parts) {
          for (const part of data.serverContent.modelTurn.parts) {
            if (part.text) {
              const isThinking = /\*\*/.test(part.text) || part.text.includes("I'm starting") || part.text.includes("I've formulated");
              if (!isThinking) conversationLog.push({ role: assistantName, text: part.text });
            }
            if (part.inlineData?.mimeType?.startsWith("audio/")) {
              if (waitingForOutboundGreeting) {
                waitingForOutboundGreeting = false;
                if (outboundGreetingGateTimer) { clearTimeout(outboundGreetingGateTimer); outboundGreetingGateTimer = null; }
                console.log(`[${assistantName}] Outbound gate: Gemini started speaking — opening caller mic`);
              }
            }
            if (part.inlineData?.mimeType?.startsWith("audio/") && currentStreamSid && twilioWs.readyState === WebSocket.OPEN) {
              const mulawB64 = geminiToTwilio(part.inlineData.data);
              const CHUNK = 160;
              for (let off = 0; off < mulawB64.length; off += CHUNK) {
                twilioWs.send(JSON.stringify({ event: 'media', streamSid: currentStreamSid, media: { payload: mulawB64.slice(off, off + CHUNK) } }));
              }
            }
          }
        }

        if (data.serverContent?.inputTranscript) {
          conversationLog.push({ role: 'Caller', text: data.serverContent.inputTranscript });
        }
      } catch (err) { console.error('[Sarah] Gemini msg error:', err.message); }
    });

    geminiWs.on('close', () => {
      if (geminiKeepaliveInterval) clearInterval(geminiKeepaliveInterval);
      if (twilioWs.readyState === WebSocket.OPEN && callSid) {
        console.log('[Sarah] Gemini disconnected while call active - triggering bailout');
        try {
          const twilioSid = process.env.TWILIO_ACCOUNT_SID;
          const twilioToken = process.env.TWILIO_AUTH_TOKEN;
          if (twilioSid && twilioToken) {
            const bailoutMsg = "I'm having a technical glitch. I'll have a human manager call you right back. Thank you for your patience!";
            const twiml = `<Response><Say voice="Polly.Joanna">${bailoutMsg}</Say><Hangup/></Response>`;
            const updateUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Calls/${callSid}.json`;
            const authB64 = Buffer.from(`${twilioSid}:${twilioToken}`).toString('base64');
            fetch(updateUrl, {
              method: 'POST',
              headers: { 'Authorization': `Basic ${authB64}`, 'Content-Type': 'application/x-www-form-urlencoded' },
              body: `Twiml=${encodeURIComponent(twiml)}`
            }).catch(e => console.error('[Sarah] Bailout TwiML update failed:', e.message));
            if (callCompanyId) {
              const notifId = `notif_bailout_${Date.now()}`;
              const pool = prodDb.getPool();
              pool.query(
                `INSERT INTO generic_entities (id, entity_type, company_id, data, created_date, updated_date) VALUES ($1, 'Notification', $2, $3, NOW(), NOW()) ON CONFLICT DO NOTHING`,
                [notifId, callCompanyId, JSON.stringify({
                  id: notifId,
                  company_id: callCompanyId,
                  type: 'ai_bailout',
                  title: 'Sarah AI Disconnected During Call',
                  message: `Sarah lost connection during a call${collectedCallerName ? ' with ' + collectedCallerName : ''}${callerPhone ? ' (' + callerPhone + ')' : ''}. The caller was told a manager would call back.`,
                  is_read: false,
                  priority: 'high',
                  created_at: new Date().toISOString()
                })]
              ).catch(e => console.error('[Sarah] Bailout notification DB save failed:', e.message));
            }
          }
        } catch (bailoutErr) {
          console.error('[Sarah] Bailout handler error:', bailoutErr.message);
        }
      }
      saveCallToBase44();
    });
    geminiWs.on('error', (err) => console.error('[Sarah] Gemini error:', err.message));
  }

  twilioWs.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.event === 'start') {
        currentStreamSid = msg.start?.streamSid;
        const customParams = msg.start?.customParameters || {};
        callerPhone = customParams.callerPhone || customParams.from || '';
        callCompanyId = customParams.companyId || DEFAULT_COMPANY_ID;
        callSid = customParams.callSid || '';
        isOutboundCall = customParams.outbound === 'true';
        outboundLeadName = customParams.leadName || '';
        outboundLeadService = customParams.leadService || '';
        if (customParams.campaign) {
          try { outboundCampaign = JSON.parse(customParams.campaign); } catch(e) { outboundCampaign = null; }
        }
        callRoutingMode = customParams.callRoutingMode || 'sarah_answers';
        staffCellPhone = customParams.staffCellPhone || '';
        calledTwilioNumber = customParams.calledNumber || '';
        forwardedRepName = customParams.forwardedRepName || customParams.repName || '';
        forwardedRepEmail = customParams.forwardedRepEmail || customParams.repEmail || '';
        forwardedRepPhone = customParams.forwardedRepPhone || customParams.repPhone || '';
        isForwardedCall = customParams.isForwardedCall === 'true' || customParams.forwarded === 'true' || callRoutingMode === 'sarah_then_transfer' || callRoutingMode === 'forward_to_cell';
        if (isForwardedCall) console.log(`[Sarah] ROUTED call: rep=${forwardedRepName}, routing=${callRoutingMode}, cell=${staffCellPhone}`);
        connectGemini();
      }
      if (msg.event === 'media' && setupComplete && !waitingForOutboundGreeting && geminiWs?.readyState === WebSocket.OPEN) {
        const pcmB64 = twilioToGemini(msg.media.payload);
        geminiWs.send(JSON.stringify({ realtime_input: { media_chunks: [{ data: pcmB64, mime_type: "audio/pcm;rate=16000" }] } }));
      }
      if (msg.event === 'stop') {
        if (geminiWs?.readyState === WebSocket.OPEN) geminiWs.close();
        if (geminiKeepaliveInterval) clearInterval(geminiKeepaliveInterval);
        saveCallToBase44();
      }
    } catch (e) {}
  });

  twilioWs.on('close', () => {
    if (geminiWs?.readyState === WebSocket.OPEN) geminiWs.close();
    if (geminiKeepaliveInterval) clearInterval(geminiKeepaliveInterval);
    saveCallToBase44();
  });
});

lexiWss.on('connection', async (clientWs, req) => {
  console.log('[Lexi] Browser client connected');
  const url = new URL(req.url, `http://${req.headers.host}`);
  const companyId = url.searchParams.get('companyId') || '';
  const userEmail = url.searchParams.get('userEmail') || '';
  const userName = url.searchParams.get('userName') || 'User';
  const requestedVoice = url.searchParams.get('voice') || 'Kore';

  let geminiWs = null;
  let setupComplete = false;
  let conversationLog = [];
  let toolCallsMade = [];
  let sessionStartTime = Date.now();

  let geminiApiKey = process.env.GOOGLE_GEMINI_API_KEY;
  try {
    const companyKey = await prodDb.getCompanyGeminiKey(companyId);
    if (companyKey) geminiApiKey = companyKey;
  } catch (e) { console.error('[Lexi Native] BYOK key lookup failed:', e.message); }
  if (!geminiApiKey) { clientWs.send(JSON.stringify({ type: 'error', message: 'API key missing' })); clientWs.close(); return; }
  const geminiUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${geminiApiKey}`;

  async function saveSession() {
    if (!companyId) return;
    const dur = Math.round((Date.now() - sessionStartTime) / 1000);
    try {
      await callLexiBridgeAPI('saveVoiceSession', companyId, userEmail, { duration_seconds: dur, transcript: conversationLog.map(e => `${e.role}: ${e.text}`).join('\n'), tool_calls_made: toolCallsMade, user_email: userEmail });
      billAIUsage(companyId, Math.max(1, Math.ceil(dur / 60)));
      logUsageEvent(companyId, 'lexi', Math.max(1, Math.ceil(dur / 60))).catch(() => {});
    } catch (e) {}
  }

  async function connectGemini() {
    let voiceName = requestedVoice;
    let companyName = 'CompanySync';
    let timezone = 'America/New_York';
    let knowledgeBase = '';
    let customerList = '';
    let staffList = [];
    let preferredLanguage = 'en';
    if (companyId) {
      try {
        let s = null;
        if (LEXI_BRIDGE_API_URL) {
          s = await callLexiBridgeAPI('getSettings', companyId, userEmail);
        }
        if (!s || s.error) {
          s = await localGetSettings(companyId);
        }
        if (s && !s.error) {
          if (s.companyName) companyName = s.companyName;
          if (s.timezone) timezone = s.timezone;
          if (s.knowledgeBase) knowledgeBase = s.knowledgeBase;
          if (s.customerList) customerList = s.customerList;
          if (s.staffList) staffList = s.staffList;
          if (s.preferredLanguage) preferredLanguage = s.preferredLanguage;
          if (s.settings?.voice_id) voiceName = s.settings.voice_id;
          else if (s.settings?.voice) voiceName = s.settings.voice;
        }
      } catch (e) { console.warn('[Lexi Native] Could not load settings:', e.message); }
    }
    if (!VALID_GEMINI_VOICES.includes(voiceName)) voiceName = 'Kore';

    geminiWs = new WebSocket(geminiUrl);
    geminiWs.on('open', () => {
      geminiWs.send(JSON.stringify({
        setup: {
          model: "models/gemini-2.5-flash-native-audio-latest",
          generation_config: { response_modalities: ["AUDIO"], speech_config: { voice_config: { prebuilt_voice_config: { voice_name: voiceName } } } },
          system_instruction: { parts: [{ text: buildLexiSystemPrompt(companyName, userName, timezone, knowledgeBase, customerList, staffList, preferredLanguage) }] },
          tools: [{ function_declarations: LEXI_CRM_TOOLS }]
        }
      }));
    });

    geminiWs.on('message', async (raw) => {
      try {
        const data = JSON.parse(raw.toString());
        if (data.setupComplete) {
          setupComplete = true;
          clientWs.send(JSON.stringify({ type: 'status', status: 'ready' }));
          geminiWs.send(JSON.stringify({ client_content: { turns: [{ role: "user", parts: [{ text: `Greet ${userName} warmly. Under 15 words.` }] }], turn_complete: true } }));
        }
        if (data.toolCall) {
          const fcs = data.toolCall.functionCalls || [];
          const responses = [];
          if (geminiWs.readyState === WebSocket.OPEN) {
            geminiWs.send(JSON.stringify({
              client_content: {
                turns: [{ role: "user", parts: [{ text: "[System: Tool call in progress. Say a brief filler like 'One sec, let me pull that up' or 'Sure, checking now' while waiting. Keep it under 8 words.]" }] }],
                turn_complete: true
              }
            }));
          }
          for (const fc of fcs) {
            let result;
            try {
              const toolPromise = handleLexiToolCall(fc, companyId, userEmail);
              const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Tool call timed out after 4s')), 4000));
              result = await Promise.race([toolPromise, timeoutPromise]);
            } catch (err) {
              console.error(`[Lexi] Tool call ${fc.name} failed:`, err.message);
              result = { error: err.message, status: 'failed' };
            }
            toolCallsMade.push(fc.name);
            responses.push({ id: fc.id, name: fc.name, response: typeof result === 'object' ? result : { output: String(result) } });
          }
          if (geminiWs.readyState === WebSocket.OPEN) {
            geminiWs.send(JSON.stringify({ tool_response: { function_responses: responses } }));
            const toolNames = fcs.map(fc => fc.name).join(', ');
            geminiWs.send(JSON.stringify({
              client_content: {
                turns: [{
                  role: "user",
                  parts: [{ text: `[System: ${toolNames} completed. Now respond to the user naturally with the result. Keep it brief.]` }]
                }],
                turn_complete: true
              }
            }));
          }
        }
        if (data.serverContent?.inputTranscript) {
          conversationLog.push({ role: 'User', text: data.serverContent.inputTranscript });
          clientWs.send(JSON.stringify({ type: 'transcript', role: 'user', text: data.serverContent.inputTranscript }));
        }
        if (data.serverContent?.modelTurn?.parts) {
          for (const part of data.serverContent.modelTurn.parts) {
            if (part.text && !/\*\*/.test(part.text)) {
              conversationLog.push({ role: 'Lexi', text: part.text });
              clientWs.send(JSON.stringify({ type: 'transcript', role: 'assistant', text: part.text }));
            }
            if (part.inlineData?.mimeType?.startsWith("audio/") && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'audio', data: part.inlineData.data, mimeType: part.inlineData.mimeType }));
            }
          }
        }
        if (data.serverContent?.interrupted) clientWs.send(JSON.stringify({ type: 'interrupted' }));
        if (data.serverContent?.turnComplete) clientWs.send(JSON.stringify({ type: 'turn_complete' }));
      } catch (err) {}
    });

    geminiWs.on('close', () => saveSession());
    geminiWs.on('error', (err) => clientWs.send(JSON.stringify({ type: 'error', message: err.message })));
  }

  connectGemini();

  clientWs.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'audio' && geminiWs?.readyState === WebSocket.OPEN && setupComplete) {
        geminiWs.send(JSON.stringify({ realtime_input: { media_chunks: [{ data: msg.data, mime_type: "audio/pcm;rate=16000" }] } }));
      }
      if (msg.type === 'text' && geminiWs?.readyState === WebSocket.OPEN && setupComplete) {
        geminiWs.send(JSON.stringify({ client_content: { turns: [{ role: "user", parts: [{ text: msg.text }] }], turn_complete: true } }));
        conversationLog.push({ role: 'User', text: msg.text });
      }
    } catch (e) {}
  });

  clientWs.on('close', () => {
    saveSession();
    if (geminiWs?.readyState === WebSocket.OPEN) geminiWs.close();
  });
});

prodDb.initDatabase().then(() => {
  console.log('[Production] Local database ready');
}).catch(err => {
  console.warn('[Production] Database init failed (will retry):', err.message);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[Production] Server running on port ${PORT}`);
  console.log(`[Production] Auth: /api/login, /api/callback, /api/auth/user, /api/logout, /api/auth/google, /api/auth/google/callback, /api/login-local, /api/signup, /api/confirm-email, /api/change-password`);
  console.log(`[Production] Integrations: /api/integrations/* (invoke-llm, upload, send-email)`);
  console.log(`[Production] Functions: /api/functions/invoke`);
  console.log(`[Production] Auto-provisioning: /api/twilio/auto-provision`);
  console.log(`[Production] Local DB API: /api/local/*`);
  console.log(`[Production] Lexi native bridge: /ws/lexi-native`);
  console.log(`[Production] Sarah voice bridge: /ws/twilio`);
  refreshCacheFromAPI().then(() => {
    console.log(`[Production] Subscriber cache loaded: ${subscriberCache.size} entries`);
  }).catch(err => {
    console.warn(`[Production] Initial cache load failed (will retry):`, err.message);
  });
});
