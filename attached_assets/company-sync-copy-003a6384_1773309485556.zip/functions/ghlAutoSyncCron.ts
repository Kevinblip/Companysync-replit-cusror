import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

// 🔄 AUTOMATIC GHL SYNC - Runs every 30 minutes via Deno.cron
// This ensures GHL contacts are automatically synced to CRM without manual intervention

Deno.cron("GHL Auto Sync", "*/5 * * * *", async () => {
    console.log('🔄 [CRON] Starting automatic GHL sync...');
    
    try {
        // Create a minimal request object for SDK initialization
        const req = new Request('http://localhost');
        const base44 = createClientFromRequest(req);
        
        // Get all companies with GHL integration enabled
        const allIntegrations = await base44.asServiceRole.entities.IntegrationSetting.filter({
            integration_name: 'gohighlevel',
            is_enabled: true
        });
        
        console.log(`✅ Found ${allIntegrations.length} companies with GHL enabled`);
        
        if (allIntegrations.length === 0) {
            console.log('ℹ️ No active GHL integrations, skipping sync');
            return;
        }
        
        const ghlApiKey = Deno.env.get('GHL_API_KEY');
        if (!ghlApiKey) {
            console.error('❌ GHL_API_KEY not configured - cannot sync');
            return;
        }
        
        const results = [];
        
        for (const integration of allIntegrations) {
            try {
                const companyId = integration.company_id;
                const locationId = integration.config?.location_id;
                
                console.log(`🔄 Syncing for company: ${companyId}`);
                
                // Fetch the 10 newest contacts from GHL
                let ghlUrl = 'https://rest.gohighlevel.com/v1/contacts/?limit=10';
                if (locationId) {
                    ghlUrl += `&locationId=${locationId}`;
                }
                
                const ghlResponse = await fetch(ghlUrl, {
                    headers: {
                        'Authorization': `Bearer ${ghlApiKey}`,
                        'Content-Type': 'application/json',
                        'Version': '2021-07-28'
                    }
                });
                
                if (!ghlResponse.ok) {
                    console.error(`❌ Failed to fetch GHL contacts for company ${companyId}: ${ghlResponse.status}`);
                    results.push({
                        company_id: companyId,
                        success: false,
                        error: `GHL API returned ${ghlResponse.status}`
                    });
                    continue;
                }
                
                const ghlData = await ghlResponse.json();
                const contacts = ghlData.contacts || [];
                
                console.log(`✅ Found ${contacts.length} contacts for company ${companyId}`);
                
                if (contacts.length === 0) {
                    console.log('ℹ️ No contacts to sync');
                    results.push({
                        company_id: companyId,
                        success: true,
                        created: 0,
                        skipped: 0,
                        message: 'No contacts to sync'
                    });
                    continue;
                }
                
                // Get existing leads (large limit to avoid missing older records)
                const existingLeads = await base44.asServiceRole.entities.Lead.filter({ company_id: companyId }, '-created_date', 5000);
                
                let created = 0;
                let skipped = 0;
                
                for (const contact of contacts) {
                    try {
                        const email = contact.email?.toLowerCase();
                        const phone = contact.phone?.replace(/\D/g, '');
                        
                        // Check if already exists (by GHL ID, email, or last 10 digits of phone)
                        const cleanPhone = phone ? phone.slice(-10) : null;
                        const isDuplicate = existingLeads.some(lead => {
                            const leadPhoneClean = (lead.phone || '').replace(/\D/g, '');
                            const leadPhoneLast10 = leadPhoneClean ? leadPhoneClean.slice(-10) : null;
                            return (contact.id && (lead.ghl_contact_id === contact.id || (lead.notes || '').includes(`GHL ID: ${contact.id}`))) ||
                                   (email && lead.email?.toLowerCase() === email) ||
                                   (cleanPhone && leadPhoneLast10 === cleanPhone);
                        });
                        
                        if (isDuplicate) {
                            skipped++;
                            continue;
                        }
                        
                        // Auto-detect tags
                        const autoTags = [];
                        const formData = contact.customFields || [];
                        const ghlTags = contact.tags || [];
                        
                        autoTags.push(...ghlTags);
                        
                        for (const field of formData) {
                            const fieldName = (field.name || field.key || '').toLowerCase();
                            const fieldValue = (field.value || '').toLowerCase();
                            
                            if (fieldName.includes('inspection') || fieldName.includes('roof inspector')) {
                                autoTags.push('lead inspections');
                            }
                            if (fieldName.includes('ladder') || fieldValue.includes('ladder')) {
                                autoTags.push('ladder assistants');
                            }
                            if (fieldName.includes('sales') || fieldName.includes('representative') || 
                                fieldValue.includes('sales') || fieldValue.includes('rep')) {
                                autoTags.push('sales reps');
                            }
                        }
                        
                        // Build notes
                        let notesText = `Auto-imported from GHL (Cron Sync). GHL ID: ${contact.id || 'unknown'}\n\n`;
                        
                        if (contact.notes) {
                            notesText += `GHL Notes:\n${contact.notes}\n\n`;
                        }
                        
                        // Get company owner
                        const companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
                        const ownerEmail = companies[0]?.created_by;
                        
                        // Create new lead
                        const newLead = await base44.asServiceRole.entities.Lead.create({
                            company_id: companyId,
                            ghl_contact_id: contact.id,
                            name: contact.firstName && contact.lastName 
                                ? `${contact.firstName} ${contact.lastName}` 
                                : contact.firstName || contact.lastName || 'Unknown',
                            email: contact.email,
                            phone: contact.phone,
                            company: contact.companyName,
                            street: contact.address1,
                            city: contact.city,
                            state: contact.state,
                            zip: contact.postalCode,
                            status: 'new',
                            source: 'gohighlevel',
                            lead_source: contact.source || 'GHL Auto-Sync',
                            tags: [...new Set(autoTags)],
                            notes: notesText,
                            is_active: true,
                            created_by: ownerEmail || 'system'
                        });
                        
                        created++;
                        existingLeads.push(newLead);
                        console.log(`✅ Created lead: ${contact.email || contact.phone}`);
                        
                        // Notify company owner
                        if (ownerEmail) {
                            await base44.asServiceRole.entities.Notification.create({
                                company_id: companyId,
                                user_email: ownerEmail,
                                title: '🎯 New Lead from GoHighLevel',
                                message: `${contact.firstName || ''} ${contact.lastName || ''} has been automatically imported from GHL`,
                                type: 'lead_created',
                                icon: 'user-plus',
                                link_url: `/lead-profile?id=${newLead.id}`
                            });
                        }
                    } catch (contactError) {
                        console.error(`❌ Failed to process contact ${contact.email || contact.phone}:`, contactError.message);
                    }
                }
                
                results.push({
                    company_id: companyId,
                    success: true,
                    created,
                    skipped
                });
                
                console.log(`✅ Company ${companyId}: Created ${created}, Skipped ${skipped}`);
                
            } catch (companyError) {
                console.error(`❌ Error syncing company ${integration.company_id}:`, companyError);
                results.push({
                    company_id: integration.company_id,
                    success: false,
                    error: companyError.message
                });
            }
        }
        
        console.log('✅ Auto-sync completed');
        
        return Response.json({
            success: true,
            message: 'Manual sync completed',
            results
        });
        
    } catch (error) {
        console.error('❌ Auto-sync error:', error);
        return Response.json({
            success: false,
            error: error.message
        }, { status: 500 });
    }
});