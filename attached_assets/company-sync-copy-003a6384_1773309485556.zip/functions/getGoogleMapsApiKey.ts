Deno.serve((req) => {
    const apiKey = Deno.env.get("GOOGLE_MAPS_API_KEY");

    if (!apiKey) {
        return new Response(
            JSON.stringify({ error: "GOOGLE_MAPS_API_KEY not configured" }), 
            { 
                status: 500,
                headers: { "Content-Type": "application/json" }
            }
        );
    }
    
    return new Response(
        JSON.stringify({ apiKey }), 
        { 
            status: 200,
            headers: { "Content-Type": "application/json" }
        }
    );
});