import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized - Admin only' }, { status: 403 });
    }

    const { email } = await req.json();

    if (!email) {
      return Response.json({ error: 'Email is required' }, { status: 400 });
    }

    console.log(`🗑️ Attempting to delete user account: ${email}`);

    // Use service role to delete from User entity
    try {
      const users = await base44.asServiceRole.entities.User.filter({ email });
      if (users && users.length > 0) {
        for (const u of users) {
          await base44.asServiceRole.entities.User.delete(u.id);
          console.log(`✅ Deleted user record: ${u.id}`);
        }
      } else {
        console.log(`⚠️ No user found with email: ${email}`);
      }

      // Also delete StaffProfile records to remove them from the dashboard
      const staffProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ user_email: email });
      if (staffProfiles && staffProfiles.length > 0) {
        for (const profile of staffProfiles) {
          await base44.asServiceRole.entities.StaffProfile.delete(profile.id);
          console.log(`✅ Deleted StaffProfile record: ${profile.id}`);
        }
      }
    } catch (error) {
      console.error(`Error deleting user/staff entity:`, error);
    }

    console.log(`✅ User account processing complete for: ${email}`);

    return Response.json({ 
      success: true, 
      message: `User account ${email} deleted successfully. Email can now be reused for testing.` 
    });

  } catch (error) {
    console.error('❌ Delete user error:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack 
    }, { status: 500 });
  }
});