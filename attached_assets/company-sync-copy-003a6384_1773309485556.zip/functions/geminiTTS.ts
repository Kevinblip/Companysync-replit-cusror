import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { text, assistantName, voice } = await req.json();

    if (!text || typeof text !== 'string') {
      return Response.json({ error: 'Missing text' }, { status: 400 });
    }

    const apiKey = Deno.env.get('GOOGLE_GEMINI_API_KEY');
    if (!apiKey) {
      console.error('❌ GOOGLE_GEMINI_API_KEY not configured');
      return Response.json({ error: 'Gemini API key not configured', fallback: true }, { status: 500 });
    }

    // Determine voice profile - prioritize explicit voice parameter
    let voiceName = voice || 'Kore'; // Use provided voice or default
    
    // If assistantName provided but no explicit voice, use assistant defaults
    if (!voice && assistantName) {
      const ownedCompanies = await base44.asServiceRole.entities.Company.filter({ created_by: user.email });
      const staffProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ user_email: user.email });
      const companyId = ownedCompanies[0]?.id || staffProfiles[0]?.company_id;

      if (companyId) {
        const settings = await base44.asServiceRole.entities.AssistantSettings.filter({
          company_id: companyId,
          assistant_name: assistantName.toLowerCase()
        });

        if (settings[0]?.google_voice_name) {
          voiceName = settings[0].google_voice_name;
        } else if (assistantName.toLowerCase() === 'sarah') {
          voiceName = 'Puck';
        } else if (assistantName.toLowerCase() === 'lexi') {
          voiceName = 'Kore';
        }
      }
    }

    console.log('🔊 Gemini TTS Request:');
    console.log('   Voice:', voiceName);
    console.log('   Text length:', text.length);

    // Use Google's Text-to-Speech API with specified voice
    const response = await fetch(`https://texttospeech.googleapis.com/v1/text:synthesize?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        input: { text },
        voice: {
          name: `en-US-${voiceName}`,
          languageCode: 'en-US'
        },
        audioConfig: {
          audioEncoding: 'MP3',
          speakingRate: 1.0,
          pitch: 0
        }
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('❌ Gemini API error:', response.status, errText);
      return Response.json({ 
        error: `Gemini TTS error: ${response.status}`,
        details: errText,
        fallback: true 
      }, { status: 500 });
    }

    const data = await response.json();
    
    // Check if we got audio data
    if (data.audioContent) {
      // Convert base64 to blob
      const audioBytes = Uint8Array.from(atob(data.audioContent), (c) => c.charCodeAt(0));
      const audioBlob = new Blob([audioBytes], { type: 'audio/mpeg' });
      const audioFile = new File([audioBlob], `tts_${Date.now()}.mp3`, { type: 'audio/mpeg' });

      // Upload to storage for stable URL
      const upload = await base44.integrations.Core.UploadFile({ file: audioFile });

      console.log('✅ TTS succeeded with', voiceName, 'voice');

      return Response.json({ audio_url: upload.file_url });
    }

    console.error('❌ No audio data in response');
    return Response.json({ error: 'No audio generated', fallback: true }, { status: 500 });

  } catch (error) {
    console.error('❌ Gemini TTS error:', error);
    return Response.json({ error: error.message, fallback: true }, { status: 500 });
  }
});