import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    console.log('🔄 Auto Calendar Sync - Starting...');
    
    const base44 = createClientFromRequest(req);
    
    // Get all users with Google Calendar connected
    const allUsers = await base44.asServiceRole.entities.User.list();
    const connectedUsers = allUsers.filter(u => u.google_calendar_connected === true);
    
    console.log(`📅 Found ${connectedUsers.length} users with Google Calendar connected`);
    
    const results = [];
    
    for (const user of connectedUsers) {
      try {
        console.log(`🔄 Syncing calendar for ${user.email}...`);
        
        // Invoke sync function for each user
        const syncResult = await base44.asServiceRole.functions.invoke('syncUserGoogleCalendar', {
          userEmail: user.email
        });
        
        results.push({
          email: user.email,
          status: 'success',
          events_synced: syncResult.data?.events_synced || 0
        });
        
        console.log(`✅ Synced ${syncResult.data?.events_synced || 0} events for ${user.email}`);
      } catch (error) {
        console.error(`❌ Failed to sync ${user.email}:`, error.message);
        results.push({
          email: user.email,
          status: 'error',
          error: error.message
        });
      }
    }
    
    const successCount = results.filter(r => r.status === 'success').length;
    const errorCount = results.filter(r => r.status === 'error').length;
    
    console.log(`✅ Auto Sync Complete: ${successCount} success, ${errorCount} errors`);
    
    return Response.json({
      success: true,
      total_users: connectedUsers.length,
      synced: successCount,
      errors: errorCount,
      results
    });
    
  } catch (error) {
    console.error('❌ Auto Sync Error:', error);
    return Response.json({ 
      error: error.message 
    }, { status: 500 });
  }
});