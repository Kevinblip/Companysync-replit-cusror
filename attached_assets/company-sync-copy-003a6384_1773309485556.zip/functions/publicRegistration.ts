import { createClient } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const { email, full_name, selected_plan = {} } = await req.json();

        if (!email) {
            return Response.json({ error: 'Email is required' }, { status: 400 });
        }

        console.log('🔄 Public registration request for:', email);

        // Create service role client using environment variables
        const appId = Deno.env.get('BASE44_APP_ID');
        const serviceKey = Deno.env.get('BASE44_SERVICE_ROLE_KEY');
        
        if (!appId || !serviceKey) {
            throw new Error('BASE44_APP_ID or BASE44_SERVICE_ROLE_KEY not configured');
        }

        const base44 = createClient(appId, serviceKey);

        // Check for existing active account first
        // 1. Check if they own an active company
        const existingCompanies = await base44.asServiceRole.entities.Company.filter({ 
            email, 
            is_deleted: { $ne: true } 
        });

        // 2. Check if they are staff on an active company
        const existingStaff = await base44.asServiceRole.entities.StaffProfile.filter({ user_email: email });
        let hasActiveStaffProfile = false;
        
        if (existingStaff.length > 0) {
            const companyIds = existingStaff.map(s => s.company_id);
            // Fetch companies that are NOT deleted
            const activeCompanies = await base44.asServiceRole.entities.Company.filter({
                id: { $in: companyIds },
                is_deleted: { $ne: true }
            });
            if (activeCompanies.length > 0) {
                hasActiveStaffProfile = true;
            }
        }

        if (existingCompanies.length > 0 || hasActiveStaffProfile) {
             return Response.json({ 
                error: 'An active account with this email already exists. Please log in.',
                redirect: '/login'
            }, { status: 400 });
        }

        // Calculate trial end date (14 days from now)
        const trialEndDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);

        // Create company for new user with selected plan
        const company = await base44.asServiceRole.entities.Company.create({
            company_name: full_name || email.split('@')[0],
            email: email,
            subscription_status: 'trial',
            subscription_plan: (selected_plan?.name || 'professional').toLowerCase(),
            trial_ends_at: trialEndDate.toISOString().split('T')[0],
            max_users: selected_plan?.name === 'enterprise' ? 25 : selected_plan?.name === 'professional' ? 10 : 5,
            max_customers: selected_plan?.name === 'starter' ? 100 : 1000,
            setup_completed: false
        });

        console.log('✅ Company created:', company.id);

        // Use Base44's invite system which will send the proper magic link
        const appUrl = Deno.env.get('APP_URL') || 'https://company-sync-copy-003a6384.base44.app';
        await base44.asServiceRole.users.inviteUser(email, 'admin', {
            redirectUrl: `${appUrl}/quick-setup`
        });

        console.log('✅ User invited:', email);

        return Response.json({ 
            success: true,
            message: 'Registration email sent! Check your inbox to complete signup.',
            email
        });

    } catch (error) {
        console.error('❌ Registration error:', error);
        
        if (error.message?.includes('already exists') || error.message?.includes('duplicate')) {
            return Response.json({ 
                error: 'An account with this email already exists. Please log in instead.',
                redirect: '/login'
            }, { status: 400 });
        }
        
        return Response.json({ 
            error: error.message || 'Registration failed. Please try again.' 
        }, { status: 500 });
    }
});