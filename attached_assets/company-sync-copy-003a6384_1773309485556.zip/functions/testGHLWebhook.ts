import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        let user;
        try {
            user = await base44.auth.me();
        } catch (authError) {
            return Response.json({ 
                success: false,
                error: 'Authentication failed. Please refresh the page and try again.',
                details: authError.message 
            }, { status: 401 });
        }

        if (!user) {
            return Response.json({ 
                success: false,
                error: 'User not authenticated' 
            }, { status: 401 });
        }

        // Get company
        const companies = await base44.entities.Company.filter({ created_by: user.email });
        const company = companies[0];

        if (!company) {
            return Response.json({ 
                success: false,
                error: 'No company found for this user',
                message: 'Please complete company setup first'
            }, { status: 400 });
        }

        // Get GHL settings
        const settings = await base44.entities.IntegrationSetting.filter({
            company_id: company.id,
            integration_name: 'gohighlevel'
        });

        if (settings.length === 0) {
            return Response.json({ 
                success: false,
                error: 'GoHighLevel not configured',
                message: 'Please save your Location ID settings first, then try testing again'
            }, { status: 200 });
        }

        const ghlApiKey = Deno.env.get('GHL_API_KEY');
        if (!ghlApiKey) {
            return Response.json({ 
                success: false,
                error: 'GHL_API_KEY not configured',
                message: 'Contact support - GHL_API_KEY environment variable is missing'
            }, { status: 200 });
        }

        // Test 1: Fetch recent contacts from GHL
        console.log('🧪 Testing GHL API connection...');
        const locationId = settings[0].config?.location_id;
        
        let url = 'https://rest.gohighlevel.com/v1/contacts/?limit=5';
        if (locationId) {
            url += `&locationId=${locationId}`;
        }

        const response = await fetch(url, {
            headers: {
                'Authorization': `Bearer ${ghlApiKey}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            const errorText = await response.text();
            return Response.json({
                success: false,
                error: 'GHL API connection failed',
                status: response.status,
                message: errorText || 'Check that your GHL API key is valid',
                troubleshooting: [
                    'Verify GHL_API_KEY is correct in Settings',
                    'Check that API key has proper permissions',
                    'Try generating a new API key in GoHighLevel'
                ]
            }, { status: 200 });
        }

        const data = await response.json();
        
        // Test 2: Check webhook URL format
        const webhookUrl = `${new URL(req.url).origin}/api/functions/ghlWebhook`;

        // Test 3: Simulate webhook payload
        const testPayload = {
            type: 'ContactCreate',
            contact: data.contacts?.[0] || {
                id: 'test-123',
                email: 'test@example.com',
                firstName: 'Test',
                lastName: 'Contact',
                phone: '5555555555'
            }
        };

        return Response.json({
            success: true,
            message: 'GHL API connection successful',
            tests: {
                apiConnection: {
                    status: 'PASS',
                    contacts: data.contacts?.length || 0,
                    sampleContact: data.contacts?.[0]?.firstName || 'N/A'
                },
                webhookUrl: {
                    status: 'INFO',
                    url: webhookUrl,
                    instructions: `
1. Go to GHL → Settings → Integrations → Webhooks
2. Create a new webhook pointing to: ${webhookUrl}
3. Enable these events:
   - Contact Created
   - Contact Updated
   - Opportunity Created
   - Note Created
   - Inbound Message
   - Outbound Message
                    `.trim()
                },
                locationId: {
                    status: locationId ? 'CONFIGURED' : 'MISSING',
                    value: locationId || 'Not set'
                },
                testPayload: {
                    status: 'SAMPLE',
                    payload: testPayload,
                    message: 'This is what a webhook should send'
                }
            },
            nextSteps: [
                'Verify webhook is created in GHL',
                'Test webhook by creating a new contact in GHL',
                'Check function logs for incoming webhook events'
            ]
        });

    } catch (error) {
        console.error('❌ Test GHL Webhook Error:', error);
        return Response.json({ 
            success: false,
            error: error.message,
            stack: error.stack
        }, { status: 500 });
    }
});