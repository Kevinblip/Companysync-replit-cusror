import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    console.log(`🗑️ User ${user.email} deleting all PriceListItem entities.`);

    // Fetch all items
    const allItems = await base44.asServiceRole.entities.PriceListItem.list();
    
    if (allItems.length === 0) {
      console.log(`ℹ️ No items to delete.`);
      return Response.json({
        success: true,
        deletedCount: 0,
        message: 'No price list items found to delete.'
      });
    }

    // Use bulk delete for efficiency
    const itemIds = allItems.map(item => item.id);
    const deletedCount = await base44.asServiceRole.entities.PriceListItem.bulkDelete(itemIds);
    
    console.log(`✅ Deleted ${deletedCount} PriceListItem entities.`);

    return Response.json({
      success: true,
      deletedCount: deletedCount,
      message: `Successfully deleted ${deletedCount} price list items.`
    });

  } catch (error) {
    console.error('❌ Error deleting price list items:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
});