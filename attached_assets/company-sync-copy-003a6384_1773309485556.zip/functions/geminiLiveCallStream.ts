import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    console.log('🎙️ Gemini Live Call Stream - WebSocket handler');

    const { socket, response } = Deno.upgradeWebSocket(req);
    
    const url = new URL(req.url);
    const companyId = url.searchParams.get('companyId');
    const from = url.searchParams.get('from');
    const callSid = url.searchParams.get('callSid');

    console.log('📞 Call info:', { companyId, from, callSid });

    let geminiWs = null;
    const base44 = createClientFromRequest(req);

    socket.onopen = async () => {
        console.log('✅ Twilio Media Stream connected');

        try {
            // Load Sarah's settings
            const settingsRows = await base44.asServiceRole.entities.AssistantSettings.filter({ 
                company_id: companyId, 
                assistant_name: 'sarah' 
            });
            const settings = settingsRows[0] || {};

            const companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
            const company = companies[0];
            const companyName = settings.brand_short_name || company?.company_name || 'our company';

            let agentName = 'Sarah';
            if (settings.system_prompt) {
                const nameMatch = settings.system_prompt.match(/(?:You are|Your name is|I am|Role:)[:\s]*(?:You are\s+)?([A-Z][a-z]+)/i);
                if (nameMatch && nameMatch[1] && nameMatch[1].toLowerCase() !== 'you') {
                    agentName = nameMatch[1];
                }
            }

            const systemPrompt = settings.system_prompt || `You are ${agentName}, a friendly receptionist for ${companyName}. Keep responses under 20 words.`;
            const selectedVoice = settings.gemini_voice || 'Aoede';

            // Connect to Gemini
            const geminiApiKey = Deno.env.get('GEMINI_API_KEY');
            if (!geminiApiKey) {
                throw new Error('GEMINI_API_KEY not configured');
            }

            const geminiUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=${geminiApiKey}`;
            
            console.log('🔌 Connecting to Gemini...');
            geminiWs = new WebSocket(geminiUrl);

            geminiWs.onopen = () => {
                console.log('✅ Connected to Gemini');
                
                // Send setup configuration
                geminiWs.send(JSON.stringify({
                    setup: {
                        model: "models/gemini-2.0-flash-exp",
                        generation_config: {
                            response_modalities: ["AUDIO"],
                            speech_config: {
                                voice_config: { 
                                    prebuilt_voice_config: { voice_name: selectedVoice } 
                                }
                            }
                        },
                        system_instruction: {
                            parts: [{ text: systemPrompt }]
                        }
                    }
                }));
            };

            geminiWs.onmessage = async (event) => {
                try {
                    const data = JSON.parse(event.data);
                    
                    if (data.serverContent?.modelTurn?.parts) {
                        for (const part of data.serverContent.modelTurn.parts) {
                            // Send audio back to Twilio
                            if (part.inlineData && part.inlineData.mimeType.startsWith("audio/")) {
                                const audioBase64 = part.inlineData.data;
                                
                                // Send audio to Twilio stream
                                socket.send(JSON.stringify({
                                    event: 'media',
                                    streamSid: streamSid,
                                    media: {
                                        payload: audioBase64
                                    }
                                }));
                            }
                        }
                    }
                } catch (err) {
                    console.error('❌ Gemini message error:', err);
                }
            };

            geminiWs.onclose = () => {
                console.log('❌ Gemini disconnected');
            };

            geminiWs.onerror = (err) => {
                console.error('❌ Gemini error:', err);
            };

        } catch (error) {
            console.error('❌ Setup error:', error);
            socket.close();
        }
    };

    socket.onmessage = async (event) => {
        try {
            const msg = JSON.parse(event.data);
            
            // Handle Twilio stream events
            if (msg.event === 'media' && geminiWs?.readyState === WebSocket.OPEN) {
                // Forward audio to Gemini
                const audioPayload = msg.media.payload;
                
                geminiWs.send(JSON.stringify({
                    realtime_input: {
                        media_chunks: [{
                            mime_type: "audio/pcm;rate=8000",
                            data: audioPayload
                        }]
                    }
                }));
            }

            if (msg.event === 'start') {
                console.log('🎬 Stream started:', msg.start.streamSid);
            }

            if (msg.event === 'stop') {
                console.log('🛑 Stream stopped');
                geminiWs?.close();
            }
        } catch (err) {
            console.error('❌ Message handling error:', err);
        }
    };

    socket.onclose = () => {
        console.log('❌ Twilio stream closed');
        geminiWs?.close();
    };

    socket.onerror = (err) => {
        console.error('❌ Twilio stream error:', err);
    };

    return response;
});