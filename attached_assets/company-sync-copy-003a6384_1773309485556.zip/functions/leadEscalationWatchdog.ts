import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Define time threshold
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);

        // Fetch leads: 'new', active, and created recently (limit 50 to avoid timeout)
        // We'll filter for !tags.includes('Escalated') in memory if needed, 
        // but let's try to grab a batch and process efficiently.
        const leads = await base44.asServiceRole.entities.Lead.filter(
            { status: 'new', is_active: true }, 
            '-created_date', 
            50
        );

        if (!leads.length) return Response.json({ success: true, count: 0 });

        // Group leads by company_id to fetch admins efficiently
        const leadsByCompany = {};
        for (const lead of leads) {
            // Check if created > 5 mins ago
            if (new Date(lead.created_date) >= fiveMinutesAgo) continue;
            
            // Check if already escalated
            if (lead.tags && lead.tags.includes('Escalated')) continue;
            
            // Check if contacted
            if (lead.last_contact_date) continue;

            if (!leadsByCompany[lead.company_id]) {
                leadsByCompany[lead.company_id] = [];
            }
            leadsByCompany[lead.company_id].push(lead);
        }

        // Process each company
        const companyIds = Object.keys(leadsByCompany);
        
        await Promise.all(companyIds.map(async (companyId) => {
            const companyLeads = leadsByCompany[companyId];
            if (!companyLeads.length) return;

            // Fetch admins for this company ONCE
            const admins = await base44.asServiceRole.entities.StaffProfile.filter({
                company_id: companyId,
                is_administrator: true
            });
            const adminEmails = admins.map(a => a.user_email);

            // Process leads for this company in parallel
            await Promise.all(companyLeads.map(async (lead) => {
                console.log(`Escalating lead ${lead.id}`);

                try {
                    // 1. Create Task
                    await base44.asServiceRole.entities.Task.create({
                        company_id: lead.company_id,
                        name: "Escalation - lead not contacted",
                        description: `Lead ${lead.name} has been new for >5 minutes without contact.`,
                        priority: "high",
                        status: "not_started",
                        assigned_to: lead.assigned_to,
                        assignees: lead.assigned_to ? [{email: lead.assigned_to}] : []
                    });

                    // 2. Notify Admins
                    // Use Promise.all for multiple admins
                    if (adminEmails.length > 0) {
                        await Promise.all(adminEmails.map(email => 
                            base44.integrations.Core.SendEmail({
                                to: email,
                                subject: `ESCALATION: Lead ${lead.name} ignored`,
                                body: `Lead ${lead.name} has been sitting in 'New' status for over 5 minutes.`
                            }).catch(err => console.error(`Failed to email admin ${email}`, err))
                        ));
                    }

                    // 3. Mark as Escalated
                    const currentTags = lead.tags || [];
                    await base44.asServiceRole.entities.Lead.update(lead.id, {
                        tags: [...currentTags, 'Escalated']
                    });
                } catch (err) {
                    console.error(`Error processing lead ${lead.id}:`, err);
                }
            }));
        }));

        return Response.json({ success: true });

    } catch (error) {
        console.error("Error in Escalation Watchdog:", error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});