import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Get first company (webhooks don't have user auth)
        const companies = await base44.asServiceRole.entities.Company.list('-created_date', 1);
        
        if (!companies || companies.length === 0) {
            return Response.json({ error: 'No company found' }, { status: 404 });
        }
        
        const companyId = companies[0].id;
        const companyOwner = companies[0].created_by;

        // Parse GHL webhook payload
        const payload = await req.json();
        console.log('📥 GHL Webhook received:', JSON.stringify(payload, null, 2));

        // Detect event type - if call data fields are present, treat as call event
        let eventType = payload.type || payload.event;
        if (!eventType && (payload.call_from || payload.call_to || payload.call_duration)) {
            eventType = 'CallStatus';
        }
        if (!eventType) {
            eventType = 'unknown';
        }
        
        // Handle different GHL event types
        switch (eventType) {
            case 'ContactCreate':
            case 'contact.created':
                await handleContactCreated(base44, companyId, payload, companyOwner);
                break;
            
            case 'ContactUpdate':
            case 'contact.updated':
                await handleContactUpdated(base44, companyId, payload, companyOwner);
                break;
            
            case 'OpportunityCreate':
            case 'opportunity.created':
                await handleOpportunityCreated(base44, companyId, payload, companyOwner);
                break;
            
            case 'NoteCreate':
            case 'note.created':
                await handleNoteCreated(base44, companyId, payload, companyOwner);
                break;
            
            case 'InboundMessage':
            case 'message.inbound':
                await handleInboundMessage(base44, companyId, payload, companyOwner);
                break;
            
            case 'OutboundMessage':
            case 'message.outbound':
                await handleOutboundMessage(base44, companyId, payload, companyOwner);
                break;

            case 'CallStatus':
            case 'call.status':
            case 'call.completed':
                await handleCallStatus(base44, companyId, payload, companyOwner);
                break;

            default:
                console.log('⚠️ Unhandled GHL event type:', eventType);
                // Don't clutter Communication Hub with raw JSON dumps
                logGenericEvent(base44, companyId, payload, eventType);
            }

        return Response.json({ 
            success: true, 
            message: `GHL event ${eventType} processed successfully` 
        });

    } catch (error) {
        console.error('❌ GHL Webhook Error:', error);
        return Response.json({ 
            error: error.message,
            details: error.stack 
        }, { status: 500 });
    }
});

// Handle contact created in GHL
async function handleContactCreated(base44, companyId, payload, ownerEmail) {
    const contact = payload.contact || payload.data || payload;
    
    // Auto-detect tags from GHL data
    const autoTags = [];
    const formData = contact.customFields || [];
    const ghlTags = contact.tags || [];
    
    // Add GHL tags to our tags array
    autoTags.push(...ghlTags);
    
    // Auto-tag based on custom fields or form data
    for (const field of formData) {
        const fieldName = (field.name || field.key || '').toLowerCase();
        const fieldValue = (field.value || '').toLowerCase();
        
        // Detect inspection-related leads
        if (fieldName.includes('inspection') || fieldName.includes('roof inspector')) {
            autoTags.push('lead inspections');
        }
        
        // Detect ladder assistant applications
        if (fieldName.includes('ladder') || fieldValue.includes('ladder')) {
            autoTags.push('ladder assistants');
        }
        
        // Detect sales rep applications
        if (fieldName.includes('sales') || fieldName.includes('representative') || 
            fieldValue.includes('sales') || fieldValue.includes('rep')) {
            autoTags.push('sales reps');
        }
    }
    
    // Check campaign source for additional tagging
    const source = (contact.source || '').toLowerCase();
    if (source.includes('sales rep') || source.includes('hiring')) {
        autoTags.push('sales reps');
    }
    if (source.includes('inspection')) {
        autoTags.push('lead inspections');
    }
    
    // Extract notes from GHL
    let notesText = `Imported from GHL. GHL ID: ${contact.id || 'unknown'}\n\n`;
    
    // Capture GHL notes
    if (contact.notes) {
        notesText += `GHL Notes:\n${contact.notes}\n\n`;
    }
    
    // Capture custom fields (only if they have readable names)
    const allCustomFields = contact.customFields || contact.customField || [];
    const readableFields = allCustomFields.filter(field => {
        const name = field.name || '';
        // Only include if name exists and doesn't look like an ID (no random chars)
        return name && name.length > 2 && !/^[a-zA-Z0-9]{15,}$/.test(name);
    });
    
    if (readableFields.length > 0) {
        notesText += '=== Contact Information ===\n';
        readableFields.forEach(field => {
            const fieldValue = field.value || '';
            if (fieldValue) {
                notesText += `${field.name}: ${fieldValue}\n`;
            }
        });
        notesText += '\n';
    }
    
    // Capture additional contact details
    if (contact.website) notesText += `Website: ${contact.website}\n`;
    if (contact.companyName) notesText += `Company: ${contact.companyName}\n`;
    if (contact.dateOfBirth) notesText += `DOB: ${contact.dateOfBirth}\n`;
    if (contact.businessId) notesText += `Business ID: ${contact.businessId}\n`;
    
    // Capture source and attribution
    if (contact.attributionSource) {
        notesText += `\n=== Source Information ===\n`;
        notesText += `Source: ${contact.attributionSource.medium || 'Unknown'}\n`;
        if (contact.attributionSource.campaign) notesText += `Campaign: ${contact.attributionSource.campaign}\n`;
        if (contact.attributionSource.source) notesText += `Channel: ${contact.attributionSource.source}\n`;
        if (contact.attributionSource.referrer) notesText += `Referrer: ${contact.attributionSource.referrer}\n`;
    }
    
    // 🎯 AUTO-ASSIGNMENT: Assign to Kevin or Victoria based on tags
    const allStaffProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ company_id: companyId });
    
    let assignedUsers = [ownerEmail]; // Default to owner
    
    // Find Kevin and Victoria
    const kevin = allStaffProfiles.find(s => s.full_name?.toLowerCase().includes('kevin'));
    const victoria = allStaffProfiles.find(s => s.full_name?.toLowerCase().includes('victoria') || s.full_name?.toLowerCase().includes('vicktoria'));
    
    // Auto-assign based on tags
    if (autoTags.includes('sales reps') && kevin) {
        assignedUsers = [kevin.user_email];
    } else if (autoTags.includes('ladder assistants') && victoria) {
        assignedUsers = [victoria.user_email];
    } else if (autoTags.includes('lead inspections') && victoria) {
        assignedUsers = [victoria.user_email];
    } else if (kevin && victoria) {
        // If no specific tag, assign to both
        assignedUsers = [kevin.user_email, victoria.user_email];
    }

    // Map GHL contact to CRM Lead
    const leadData = {
        company_id: companyId,
        ghl_contact_id: contact.id, // Store GHL ID
        name: contact.name || `${contact.firstName || ''} ${contact.lastName || ''}`.trim(),
        email: contact.email,
        phone: contact.phone || contact.phoneNumber,
        status: 'new',
        source: 'gohighlevel',
        lead_source: contact.source || 'GoHighLevel Integration',
        notes: notesText,
        tags: [...new Set(autoTags)], // Remove duplicates
        assigned_to: assignedUsers[0],
        assigned_to_users: assignedUsers,
        street: contact.address1 || contact.address,
        city: contact.city,
        state: contact.state,
        zip: contact.postalCode || contact.zip,
    };

    // 🔥 IMPROVED: Check for duplicates by GHL ID first, then email/phone
    const existingLeads = await base44.asServiceRole.entities.Lead.filter({ company_id: companyId }, '-created_date', 5000);
    const existingCustomers = await base44.asServiceRole.entities.Customer.filter({ company_id: companyId }, '-created_date', 5000);
    
    const cleanPhone = (contact.phone || '').replace(/\D/g, '');
    const cleanEmail = (contact.email || '').toLowerCase();
    
    // Check Leads - STRICT GHL ID MATCH FIRST
    let existingLead = null;
    
    // Priority 1: Exact GHL contact ID match
    if (contact.id) {
        existingLead = existingLeads.find(l => l.ghl_contact_id === contact.id);
        if (existingLead) {
            console.log('✅ Found existing lead by GHL ID:', existingLead.id);
        }
    }
    
    // Priority 2: GHL ID in notes (legacy)
    if (!existingLead && contact.id) {
        existingLead = existingLeads.find(l => l.notes?.includes(`GHL ID: ${contact.id}`));
        if (existingLead) {
            console.log('✅ Found existing lead by GHL ID in notes:', existingLead.id);
        }
    }
    
    // Priority 3: Email match (only if email exists and isn't generic)
    if (!existingLead && cleanEmail && !cleanEmail.includes('noemail') && !cleanEmail.includes('test')) {
        existingLead = existingLeads.find(l => {
            const leadEmail = (l.email || '').toLowerCase();
            return leadEmail === cleanEmail;
        });
        if (existingLead) {
            console.log('✅ Found existing lead by email:', existingLead.id);
        }
    }
    
    // Priority 4: Phone match (last resort, only if phone has 10+ digits)
    if (!existingLead && cleanPhone.length >= 10) {
        existingLead = existingLeads.find(l => {
            const leadPhone = (l.phone || '').replace(/\D/g, '');
            return leadPhone.includes(cleanPhone.slice(-10));
        });
        if (existingLead) {
            console.log('✅ Found existing lead by phone:', existingLead.id);
        }
    }

    // Check Customers
    let existingCustomer = existingCustomers.find(c => c.ghl_contact_id === contact.id);
    if (!existingCustomer) {
        existingCustomer = existingCustomers.find(cust => {
            const custPhone = (cust.phone || '').replace(/\D/g, '');
            const custEmail = (cust.email || '').toLowerCase();
            
            return (cleanEmail && custEmail === cleanEmail) || 
                   (cleanPhone.length >= 10 && custPhone.includes(cleanPhone.slice(-10)));
        });
    }

    // If it's a customer, update the customer and STOP (don't create a lead)
    if (existingCustomer) {
        console.log('🔄 Contact exists as Customer, updating GHL ID:', existingCustomer.id);
        await base44.asServiceRole.entities.Customer.update(existingCustomer.id, {
            ghl_contact_id: contact.id, // Link GHL ID
            notes: (existingCustomer.notes || '') + `\n\n[GHL Sync - Found via Webhook]`
        });
        return; // Stop here to prevent duplicate Lead creation
    }

    if (!existingLead) {
        console.log('🆕 Creating NEW lead - no duplicates found:', leadData.name);
        const newLead = await base44.asServiceRole.entities.Lead.create(leadData);
        console.log('✅ New lead created from GHL webhook:', newLead.id, 'GHL ID:', contact.id, 'Tags:', autoTags);
        
        // Log conversation history as Communication records
        if (contact.conversations && contact.conversations.length > 0) {
            for (const msg of contact.conversations) {
                await base44.asServiceRole.entities.Communication.create({
                    company_id: companyId,
                    contact_name: leadData.name,
                    contact_email: leadData.email,
                    contact_phone: leadData.phone,
                    communication_type: msg.type === 'SMS' ? 'sms' : 'note',
                    direction: msg.direction || 'inbound',
                    subject: 'GHL Message History',
                    message: msg.body || msg.message,
                    status: 'completed'
                });
            }
        }

        // Log recent notes/activities from GHL
        if (contact.activities && contact.activities.length > 0) {
            for (const activity of contact.activities.slice(0, 10)) {
                await base44.asServiceRole.entities.Communication.create({
                    company_id: companyId,
                    contact_name: leadData.name,
                    contact_email: leadData.email,
                    contact_phone: leadData.phone,
                    communication_type: 'note',
                    direction: 'inbound',
                    subject: `GHL Activity: ${activity.type || 'Note'}`,
                    message: activity.description || activity.note || activity.message || 'Activity logged',
                    status: 'completed'
                });
            }
        }
        
        // 🔥 IMPROVED: Send ONE notification to admins/assignees (no duplicates)
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
        const companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
        const companyOwner = companies[0]?.created_by;
        
        // Get all recent notifications for this lead to prevent duplicates
        const recentNotifications = await base44.asServiceRole.entities.Notification.filter({
            company_id: companyId,
            type: 'lead_created'
        });
        
        const hasDuplicateNotification = recentNotifications.some(n => 
            n.created_date >= fiveMinutesAgo && 
            (n.message?.includes(leadData.name) || n.related_entity_id === newLead.id)
        );
        
        if (!hasDuplicateNotification) {
            // Send ONE notification to each assigned user + owner
            const notifyUsers = new Set([companyOwner, ...assignedUsers]);
            
            for (const userEmail of notifyUsers) {
                if (userEmail) {
                    await base44.asServiceRole.entities.Notification.create({
                        company_id: companyId,
                        user_email: userEmail,
                        title: '🎯 New Lead from GoHighLevel',
                        message: `${leadData.name} has been automatically imported from GHL`,
                        type: 'lead_created',
                        related_entity_type: 'Lead',
                        related_entity_id: newLead.id,
                        link_url: `/LeadProfile?id=${newLead.id}`,
                        icon: 'user-plus'
                    });
                }
            }
            console.log(`✅ Notifications sent to ${notifyUsers.size} users`);
        } else {
            console.log('⏭️ Duplicate notification prevented for', leadData.name);
        }
    } else {
        // Update existing lead with GHL ID if missing and update other fields
        console.log('🔄 Lead already exists, updating:', existingLead.id);
        
        await base44.asServiceRole.entities.Lead.update(existingLead.id, {
            ghl_contact_id: contact.id,
            // Only update fields if they are missing or if we want GHL to be the source of truth
            // For now, we update basic contact info
            email: contact.email || existingLead.email,
            phone: contact.phone || contact.phoneNumber || existingLead.phone,
            street: contact.address1 || contact.address || existingLead.street,
            city: contact.city || existingLead.city,
            state: contact.state || existingLead.state,
            zip: contact.postalCode || contact.zip || existingLead.zip,
        });
    }
}

// Handle contact updated in GHL
async function handleContactUpdated(base44, companyId, payload, ownerEmail) {
    const contact = payload.contact || payload.data || payload;
    
    // Find existing lead by GHL ID or email/phone
    const existingLeads = await base44.asServiceRole.entities.Lead.filter({ company_id: companyId }, '-created_date', 5000);
    
    let lead = existingLeads.find(l => l.ghl_contact_id === contact.id);
    
    if (!lead) {
        const cleanPhone = (contact.phone || '').replace(/\D/g, '');
        const cleanEmail = (contact.email || '').toLowerCase();
        
        lead = existingLeads.find(l => {
            const leadPhone = (l.phone || '').replace(/\D/g, '');
            const leadEmail = (l.email || '').toLowerCase();
            return (cleanEmail && leadEmail === cleanEmail) || 
                   (cleanPhone.length >= 10 && leadPhone.includes(cleanPhone.slice(-10)));
        });
    }

    if (lead) {
        
        // Auto-detect tags from GHL data (same logic as create)
        const autoTags = [];
        const formData = contact.customFields || [];
        const ghlTags = contact.tags || [];
        
        autoTags.push(...ghlTags);
        
        for (const field of formData) {
            const fieldName = (field.name || field.key || '').toLowerCase();
            const fieldValue = (field.value || '').toLowerCase();
            
            if (fieldName.includes('inspection') || fieldName.includes('roof inspector')) {
                autoTags.push('lead inspections');
            }
            if (fieldName.includes('ladder') || fieldValue.includes('ladder')) {
                autoTags.push('ladder assistants');
            }
            if (fieldName.includes('sales') || fieldName.includes('representative') || 
                fieldValue.includes('sales') || fieldValue.includes('rep')) {
                autoTags.push('sales reps');
            }
        }
        
        const source = (contact.source || '').toLowerCase();
        if (source.includes('sales rep') || source.includes('hiring')) {
            autoTags.push('sales reps');
        }
        if (source.includes('inspection')) {
            autoTags.push('lead inspections');
        }
        
        // Merge existing tags with new auto-tags
        const existingTags = lead.tags || [];
        const mergedTags = [...new Set([...existingTags, ...autoTags])];
        
        // Extract notes from GHL
        let updatedNotes = lead.notes || '';
        if (contact.notes && !updatedNotes.includes(contact.notes)) {
            updatedNotes += `\n\n[GHL Update - ${new Date().toLocaleDateString()}]\n${contact.notes}`;
        }
        
        // Add custom field data to notes
        if (formData.length > 0) {
            updatedNotes += `\n\nUpdated Application Details:\n`;
            formData.forEach(field => {
                updatedNotes += `${field.name || field.key}: ${field.value}\n`;
            });
        }
        
        await base44.asServiceRole.entities.Lead.update(lead.id, {
            ghl_contact_id: contact.id, // Ensure ID is linked
            phone: contact.phone || contact.phoneNumber || lead.phone,
            street: contact.address1 || contact.address || lead.street,
            city: contact.city || lead.city,
            state: contact.state || lead.state,
            zip: contact.postalCode || contact.zip || lead.zip,
            source: 'gohighlevel',
            tags: mergedTags,
            notes: updatedNotes,
            lead_source: contact.source || lead.lead_source
        });
        console.log('✅ Lead updated from GHL:', lead.id, 'New tags:', autoTags);
    }
}

async function handleOpportunityCreated(base44, companyId, payload, ownerEmail) {

    const opportunity = payload.opportunity || payload.data || payload;
    
    // Create a task for the opportunity
    const taskData = {
        company_id: companyId,
        name: opportunity.name || 'GHL Opportunity',
        description: `Pipeline: ${opportunity.pipelineStage || 'Unknown'}\nValue: $${opportunity.monetaryValue || 0}\nGHL ID: ${opportunity.id}`,
        status: 'not_started',
        priority: 'high',
        source: 'other',
        assigned_to: ownerEmail,
        related_to: opportunity.contactName || opportunity.contact?.name || 'GHL Contact'
    };

    const newTask = await base44.asServiceRole.entities.Task.create(taskData);
    console.log('✅ Task created from GHL opportunity:', newTask.id);
    
    // Internal notification
    await base44.asServiceRole.entities.Notification.create({
        company_id: companyId,
        user_email: ownerEmail,
        title: '💼 New Opportunity from GHL',
        message: `${opportunity.name} - $${opportunity.monetaryValue || 0}`,
        type: 'general',
        related_entity_type: 'Task',
        related_entity_id: newTask.id,
        icon: 'briefcase'
    });
}

async function handleNoteCreated(base44, companyId, payload, ownerEmail) {
    const note = payload.note || payload.data || payload;
    
    // Find the related lead by email or phone
    const contactEmail = note.contactEmail || note.email;
    const contactPhone = note.contactPhone || note.phone;
    
    let relatedLead = null;
    if (contactEmail) {
        const leads = await base44.entities.Lead.filter({ 
            company_id: companyId,
            email: contactEmail 
        });
        relatedLead = leads[0];
    }
    
    // Log as communication
    await base44.asServiceRole.entities.Communication.create({
        company_id: companyId,
        contact_name: note.contactName || relatedLead?.name || 'GHL Contact',
        contact_email: contactEmail,
        contact_phone: contactPhone,
        communication_type: 'note',
        direction: 'inbound',
        subject: 'Note from GHL',
        message: note.body || note.content || note.text,
        status: 'completed'
    });
    
    // Append note to lead's notes field
    if (relatedLead) {
        const updatedNotes = `${relatedLead.notes || ''}\n\n[GHL Note - ${new Date().toLocaleDateString()}]\n${note.body || note.content || note.text}`;
        await base44.asServiceRole.entities.Lead.update(relatedLead.id, {
            notes: updatedNotes
        });
    }
    
    console.log('✅ Note logged from GHL and added to lead');
}

async function handleInboundMessage(base44, companyId, payload, ownerEmail) {
    const message = payload.message || payload.data || payload;
    
    // Log communication (but DON'T send a reply from CRM)
    await base44.asServiceRole.entities.Communication.create({
        company_id: companyId,
        contact_name: message.contactName || 'GHL Contact',
        contact_email: message.email,
        contact_phone: message.phone,
        communication_type: message.type === 'SMS' ? 'sms' : 'email',
        direction: 'inbound',
        subject: message.subject || 'Message from GHL',
        message: message.body || message.content,
        status: 'completed'
    });
    
    console.log('✅ Inbound message logged from GHL (no auto-reply)');
}

async function handleOutboundMessage(base44, companyId, payload, ownerEmail) {
    const message = payload.message || payload.data || payload;
    
    // Log that GHL sent a message (tracking only)
    await base44.asServiceRole.entities.Communication.create({
        company_id: companyId,
        contact_name: message.contactName || 'GHL Contact',
        contact_email: message.email,
        contact_phone: message.phone,
        communication_type: message.type === 'SMS' ? 'sms' : 'email',
        direction: 'outbound',
        subject: message.subject || 'GHL Automated Message',
        message: message.body || message.content,
        status: 'completed'
    });
    
    console.log('✅ Outbound message from GHL logged (sent by GHL, not CRM)');
}

async function handleCallStatus(base44, companyId, payload, ownerEmail) {
    // Extract call data - GHL sends them as top-level fields in payload
    const contactId = payload.contact_id;
    const callFrom = payload.call_from;
    const callTo = payload.call_to;
    const callDirection = payload.call_direction || 'unknown';
    const callDuration = payload.call_duration || 0;
    const callStatus = payload.call_status || 'completed';
    const callTranscription = payload.call_transcription || '';
    
    console.log('📞 Processing call status:', { contactId, callFrom, callTo, callDirection, callDuration, callStatus });
    
    // Find related lead by contact ID or phone
    let relatedLead = null;
    let contactName = 'GHL Contact';
    let contactEmail = null;
    let contactPhone = callDirection === 'inbound' ? callFrom : callTo;
    
    // Try to find lead by GHL contact ID in notes
    if (contactId) {
        const allLeads = await base44.entities.Lead.filter({ company_id: companyId });
        relatedLead = allLeads.find(lead => lead.notes?.includes(`GHL ID: ${contactId}`));
    }
    
    // If not found by ID, try to find by phone
    if (!relatedLead && contactPhone) {
        const cleanPhone = contactPhone.replace(/\D/g, '');
        const leads = await base44.entities.Lead.filter({ company_id: companyId });
        relatedLead = leads.find(lead => {
            const leadPhone = (lead.phone || '').replace(/\D/g, '');
            return leadPhone && leadPhone.includes(cleanPhone.slice(-10));
        });
    }
    
    if (relatedLead) {
        contactName = relatedLead.name;
        contactEmail = relatedLead.email;
        contactPhone = relatedLead.phone || contactPhone;
    }
    
    // Convert duration to minutes (assuming it comes as seconds)
    const durationMinutes = Math.ceil(parseInt(callDuration) / 60) || 0;
    
    // Create Communication record
    await base44.asServiceRole.entities.Communication.create({
        company_id: companyId,
        contact_name: contactName,
        contact_email: contactEmail,
        contact_phone: contactPhone,
        communication_type: 'call',
        direction: callDirection,
        subject: `${callDirection === 'inbound' ? 'Incoming' : 'Outgoing'} call - ${callStatus}`,
        message: callTranscription || `Call ${callStatus}. Duration: ${durationMinutes} minutes.`,
        duration_minutes: durationMinutes,
        transcription: callTranscription || null,
        status: 'completed',
        outcome: callStatus === 'completed' ? 'successful' : callStatus
    });
    
    console.log(`✅ Call logged from GHL: ${callDirection} call, ${durationMinutes} min`);
    
    // If lead found, append call info to notes
    if (relatedLead) {
        const callNote = `\n\n[GHL Call - ${new Date().toLocaleString()}]\nDirection: ${callDirection}\nDuration: ${durationMinutes} minutes\nStatus: ${callStatus}${callTranscription ? `\n\nTranscription:\n${callTranscription}` : ''}`;
        
        await base44.asServiceRole.entities.Lead.update(relatedLead.id, {
            notes: (relatedLead.notes || '') + callNote,
            last_contact_date: new Date().toISOString()
        });
        
        console.log(`✅ Updated lead ${relatedLead.id} with call details`);
    }
}

function logGenericEvent(base44, companyId, payload, eventType) {
    // Don't log unknown events to Communication - they clutter the UI with raw JSON
    // Just log to console for debugging
    console.log(`ℹ️ Unhandled GHL event type "${eventType}" received (not logged to Communication)`);
    console.log('Event payload:', JSON.stringify(payload, null, 2));
}