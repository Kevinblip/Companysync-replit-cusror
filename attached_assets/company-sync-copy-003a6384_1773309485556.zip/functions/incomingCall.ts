import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function normalizePhone(phone) {
    if (!phone) return '';
    return phone.replace(/\D/g, '').slice(-10);
}

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        const contentType = req.headers.get('content-type') || '';
        let from, to;
        
        // Parse Twilio request
        if (contentType.includes('application/x-www-form-urlencoded')) {
            const formData = await req.formData();
            from = formData.get('From');
            to = formData.get('To');
        } else if (contentType.includes('application/json')) {
            const json = await req.json();
            from = json.From || json.from;
            to = json.To || json.to;
        } else {
            // Fallback for query params
            const url = new URL(req.url);
            to = url.searchParams.get('To');
            from = url.searchParams.get('From');
        }
        
        console.log('📞 Incoming call from:', from, 'to:', to);

        // 1. Find Settings for this number
        const normalizedTo = normalizePhone(to);
        console.log('🔍 Looking for normalized number:', normalizedTo);
        
        const allTwilioSettings = await base44.asServiceRole.entities.TwilioSettings.list('-created_date', 100);
        console.log(`📋 Found ${allTwilioSettings.length} total Twilio settings`);
        
        // Match either main number or thoughtly number
        const matches = allTwilioSettings.filter(s => 
            normalizePhone(s.main_phone_number) === normalizedTo || 
            normalizePhone(s.thoughtly_phone) === normalizedTo
        );
        console.log(`✅ Matched ${matches.length} settings for this number`);

        // Prioritize settings that have Thoughtly configured
        const settings = matches.find(s => s.use_thoughtly_ai && s.thoughtly_phone) || matches[0];

        if (settings) {
            console.log('⚙️ Using settings for company:', settings.company_id);
            // 2. Check for Thoughtly AI Forwarding
            if (settings.use_thoughtly_ai) {
                // Priority: Explicit thoughtly_phone setting -> AssistantSettings -> Hardcoded Fallback
                let forwardTo = settings.thoughtly_phone;
                
                if (!forwardTo) {
                    const assistantSettings = await base44.asServiceRole.entities.AssistantSettings.filter({ 
                        company_id: settings.company_id, 
                        assistant_name: 'sarah' 
                    });
                    forwardTo = assistantSettings[0]?.thoughtly_phone;
                }

                if (forwardTo) {
                    // Prevent infinite loop if forwarding to same number
                    if (normalizePhone(forwardTo) === normalizedTo) {
                        console.error('❌ CONFIG ERROR: Infinite loop detected. Thoughtly Phone is same as Twilio Phone.');
                        const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say>Configuration error. The AI forwarding number cannot be the same as this phone number.</Say>
    <Record />
</Response>`;
                        return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });
                    }

                    console.log('✅ Forwarding to Thoughtly AI:', forwardTo);
                    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Dial>${forwardTo}</Dial>
    <Say>Sarah is currently unavailable. Please leave a message.</Say>
    <Record />
</Response>`;
                    return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });
                }
            }

            // 3. Check for Internal Sarah AI (ElevenLabs + Gemini)
            // If Thoughtly is OFF, check if Sarah is enabled for voice
            const sarahSettings = await base44.asServiceRole.entities.AssistantSettings.filter({ 
                company_id: settings.company_id, 
                assistant_name: 'sarah' 
            });
            
            const sarah = sarahSettings[0];
            console.log('🤖 Sarah settings:', sarah ? `voice_enabled=${sarah.voice_enabled}` : 'NOT FOUND');
            
            if (sarah && sarah.voice_enabled) {
                console.log('✅ Forwarding to Internal Sarah AI with Gemini');
                const appUrl = (Deno.env.get('APP_URL') || `https://${Deno.env.get('BASE44_APP_ID')}.base44.app`).replace(/\/$/, '');
                const handlerUrl = `${appUrl}/api/functions/sarahVoiceCallHandler?companyId=${settings.company_id}`;
                console.log('📍 Redirect URL:', handlerUrl);
                
                const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Redirect method="POST">${handlerUrl}</Redirect>
</Response>`;
                return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });
            } else {
                console.log('⚠️ Sarah not enabled for voice, using fallback');
            }
        } else {
            console.log('❌ No Twilio settings found for this number');
        }

        // 4. Fallback: Default Greeting if no AI configured or Settings not found
        console.log('ℹ️ No AI forwarding configured, playing default message');
        const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">Thank you for calling. We are currently unavailable. Please leave a message or try again later.</Say>
    <Hangup/>
</Response>`;

        return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });

    } catch (error) {
        console.error('Error in incomingCall:', error);
        const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say>We are experiencing technical difficulties.</Say>
    <Hangup/>
</Response>`;
        return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });
    }
});