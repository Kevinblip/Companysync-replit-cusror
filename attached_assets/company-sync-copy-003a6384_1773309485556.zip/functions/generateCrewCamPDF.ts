import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import { jsPDF } from 'npm:jspdf@2.5.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { jobId, imagesData, sectionNotes, inspectorSignature } = await req.json();

    console.log(`📄 Generating PDF for job ${jobId} with ${imagesData?.length || 0} images`);

    // Fetch job details
    const jobs = await base44.entities.InspectionJob.filter({ id: jobId });
    const job = jobs[0];

    if (!job) {
      return Response.json({ error: 'Job not found' }, { status: 404 });
    }

    // Fetch company details
    const companies = await base44.entities.Company.filter({ id: job.company_id });
    const company = companies[0];

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15;
    const contentWidth = pageWidth - (margin * 2);

    // Cover page
    if (company?.logo_url) {
      try {
        doc.addImage(company.logo_url, 'PNG', margin, margin, 40, 40);
      } catch (error) {
        console.log('⚠️ Could not add company logo');
      }
    }

    doc.setFontSize(24);
    doc.text('Inspection Report', margin, 70);
    
    doc.setFontSize(12);
    doc.text(`Property: ${job.property_address || 'N/A'}`, margin, 85);
    doc.text(`Client: ${job.client_name || 'N/A'}`, margin, 92);
    doc.text(`Date: ${new Date(job.inspection_date || job.created_date).toLocaleDateString()}`, margin, 99);
    
    let yPos = 106;
    if (job.insurance_claim_number) {
      doc.text(`Claim #: ${job.insurance_claim_number}`, margin, yPos);
      yPos += 7;
    }

    // Add storm event information if available
    if (job.storm_event_id) {
      try {
        const stormEvents = await base44.entities.StormEvent.filter({ id: job.storm_event_id });
        if (stormEvents && stormEvents[0]) {
          const storm = stormEvents[0];
          doc.setFontSize(14);
          doc.setFillColor(255, 243, 205);
          doc.rect(margin, yPos, contentWidth, 30, 'F');
          doc.setTextColor(0);
          doc.text('⚡ Related Storm Event', margin + 2, yPos + 7);
          doc.setFontSize(10);
          doc.text(`Event: ${storm.title || 'Unknown'}`, margin + 2, yPos + 13);
          doc.text(`Date: ${new Date(storm.start_time).toLocaleDateString()}`, margin + 2, yPos + 19);
          if (storm.event_type) {
            doc.text(`Type: ${storm.event_type.toUpperCase()}`, margin + 2, yPos + 25);
          }
          doc.setTextColor(0);
          yPos += 35; // Move position down after storm box
          console.log('✅ Added storm event to PDF');
        }
      } catch (error) {
        console.log('⚠️ Could not fetch storm event:', error);
      }
    }

    // Group images by section
    const imagesBySection = {};
    if (imagesData && Array.isArray(imagesData)) {
      imagesData.forEach(item => {
        const section = item.section || 'Other';
        if (!imagesBySection[section]) {
          imagesBySection[section] = [];
        }
        imagesBySection[section].push(item);
      });
    }

    console.log(`📸 Grouped into ${Object.keys(imagesBySection).length} sections`);

    // Add sections with photos
    for (const [section, images] of Object.entries(imagesBySection)) {
      doc.addPage();
      
      doc.setFontSize(18);
      doc.text(section, margin, margin + 10);
      
      if (sectionNotes && sectionNotes[section]) {
        doc.setFontSize(10);
        const lines = doc.splitTextToSize(sectionNotes[section], contentWidth);
        doc.text(lines, margin, margin + 20);
      }

      let yPos = margin + 40;
      
      // Process images 2 per page
      for (let i = 0; i < images.length; i += 2) {
        // Check if we need a new page
        if (i > 0) {
          doc.addPage();
          doc.setFontSize(18);
          doc.text(`${section} (continued)`, margin, margin + 10);
          yPos = margin + 25;
        }

        // First image (top half of page)
        const firstItem = images[i];
        if (firstItem) {
          try {
            const imageData = firstItem.imageBase64;
            
            if (imageData) {
              const imgWidth = contentWidth;
              const imgHeight = 80;
              
              doc.addImage(imageData, 'JPEG', margin, yPos, imgWidth, imgHeight);
              yPos += imgHeight + 3;

              if (firstItem.caption) {
                doc.setFontSize(9);
                doc.setTextColor(100);
                doc.text(firstItem.caption, margin, yPos);
                yPos += 6;
                doc.setTextColor(0);
              }
              
              console.log(`✅ Added image ${i + 1} to ${section}`);
            }
          } catch (error) {
            console.error(`❌ Error adding image ${i + 1}:`, error);
          }
        }

        yPos += 5; // Space between images

        // Second image (bottom half of page)
        const secondItem = images[i + 1];
        if (secondItem) {
          try {
            const imageData = secondItem.imageBase64;
            
            if (imageData) {
              const imgWidth = contentWidth;
              const imgHeight = 80;
              
              doc.addImage(imageData, 'JPEG', margin, yPos, imgWidth, imgHeight);
              yPos += imgHeight + 3;

              if (secondItem.caption) {
                doc.setFontSize(9);
                doc.setTextColor(100);
                doc.text(secondItem.caption, margin, yPos);
                doc.setTextColor(0);
              }
              
              console.log(`✅ Added image ${i + 2} to ${section}`);
            }
          } catch (error) {
            console.error(`❌ Error adding image ${i + 2}:`, error);
          }
        }
      }
    }

    // Inspector signature
    if (inspectorSignature) {
      doc.addPage();
      doc.setFontSize(16);
      doc.text('Inspector Signature', margin, margin + 10);
      
      try {
        doc.addImage(inspectorSignature, 'PNG', margin, margin + 20, 80, 30);
        console.log('✅ Added inspector signature');
      } catch (error) {
        console.error('❌ Error adding signature:', error);
      }
    }

    console.log('✅ PDF generation complete');

    const pdfBytes = doc.output('arraybuffer');

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=inspection-${jobId}.pdf`
      }
    });

  } catch (error) {
    console.error('❌ PDF Generation Error:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack 
    }, { status: 500 });
  }
});