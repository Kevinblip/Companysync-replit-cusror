import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Check keys
        const voiceKey = Deno.env.get('GEMINI_API_KEY_COMPANYSYNC_VOICE');
        const generalKey = Deno.env.get('GOOGLE_GEMINI_API_KEY');
        const apiKey = (generalKey || voiceKey || "").trim();
        
        if (!apiKey) {
            return Response.json({ error: "No API Key found" });
        }

        const maskedKey = apiKey.substring(0, 4) + "..." + apiKey.substring(apiKey.length - 4);
        const results = {};

        // Test 1: v1alpha (Gemini 2.0)
        try {
            const url = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=${apiKey}`;
            const ws = new WebSocket(url);
            
            const result = await new Promise((resolve) => {
                const timer = setTimeout(() => {
                    ws.close();
                    resolve({ status: "timeout", message: "Connection timed out after 5s" });
                }, 5000);

                ws.onopen = () => {
                    clearTimeout(timer);
                    ws.close();
                    resolve({ status: "success", message: "Connected successfully" });
                };

                ws.onerror = (e) => {
                    clearTimeout(timer);
                    resolve({ status: "error", message: "WebSocket Error event fired (likely 404 or Auth)" });
                };
                
                ws.onclose = (e) => {
                     // If it closes immediately without open, it failed
                     if (!ws.readyState === WebSocket.OPEN) {
                        clearTimeout(timer);
                        resolve({ status: "closed", code: e.code, reason: e.reason });
                     }
                };
            });
            results.v1alpha = result;
        } catch (e) {
            results.v1alpha = { status: "exception", message: e.message };
        }

        // Test 2: v1beta (Gemini 1.5)
        try {
            const url = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${apiKey}`;
            const ws = new WebSocket(url);
            
            const result = await new Promise((resolve) => {
                const timer = setTimeout(() => {
                    ws.close();
                    resolve({ status: "timeout", message: "Connection timed out after 5s" });
                }, 5000);

                ws.onopen = () => {
                    clearTimeout(timer);
                    ws.close();
                    resolve({ status: "success", message: "Connected successfully" });
                };

                ws.onerror = (e) => {
                    clearTimeout(timer);
                    resolve({ status: "error", message: "WebSocket Error event fired" });
                };
            });
            results.v1beta = result;
        } catch (e) {
            results.v1beta = { status: "exception", message: e.message };
        }

        return Response.json({ 
            keys_found: { 
                voice_key: !!voiceKey, 
                general_key: !!generalKey,
                active_key_masked: maskedKey
            },
            connectivity_test: results 
        });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});