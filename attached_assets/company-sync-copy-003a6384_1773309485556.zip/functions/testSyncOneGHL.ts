import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { locationId } = await req.json();

    // Get company ID
    const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: user.email });
    let companyId;
    
    if (staffProfiles && staffProfiles.length > 0) {
      companyId = staffProfiles[0].company_id;
    } else {
      const companies = await base44.entities.Company.filter({ created_by: user.email });
      companyId = companies[0]?.id;
    }

    if (!companyId) {
      return Response.json({ error: 'Company not found' }, { status: 400 });
    }

    const ghlApiKey = Deno.env.get('GHL_API_KEY');
    if (!ghlApiKey) {
      return Response.json({ error: 'GHL_API_KEY not configured' }, { status: 400 });
    }

    // Fetch only 1 contact from GHL
    let ghlUrl = 'https://rest.gohighlevel.com/v1/contacts/?limit=1';
    if (locationId) {
      ghlUrl += `&locationId=${locationId}`;
    }

    const ghlResponse = await fetch(ghlUrl, {
      headers: {
        'Authorization': `Bearer ${ghlApiKey}`,
        'Content-Type': 'application/json',
        'Version': '2021-07-28'
      }
    });

    if (!ghlResponse.ok) {
      return Response.json({ error: 'Failed to fetch GHL contact' }, { status: 400 });
    }

    const ghlData = await ghlResponse.json();
    const contacts = ghlData.contacts || [];
    
    if (contacts.length === 0) {
      return Response.json({ error: 'No contacts found in GHL' }, { status: 404 });
    }

    const contact = contacts[0];
    console.log('📋 Testing with contact:', contact.email || contact.phone);
    console.log('🔍 RAW GHL DATA:', JSON.stringify(contact, null, 2));

    // Fetch conversations for this contact
    let conversations = [];
    try {
      const convResponse = await fetch(`https://services.leadconnectorhq.com/conversations/search?contactId=${contact.id}`, {
        headers: {
          'Authorization': `Bearer ${ghlApiKey}`,
          'Version': '2021-04-15'
        }
      });
      if (convResponse.ok) {
        const convData = await convResponse.json();
        conversations = convData.conversations || [];
        console.log(`📨 Fetched ${conversations.length} conversations`);
      }
    } catch (err) {
      console.log('⚠️ Could not fetch conversations:', err.message);
    }

    // Get existing leads
    const existingLeads = await base44.asServiceRole.entities.Lead.filter({ company_id: companyId });

    const email = contact.email?.toLowerCase();
    const phone = contact.phone?.replace(/\D/g, '');
    
    // Check for duplicates
    const existingLead = existingLeads.find(lead => 
      (email && lead.email?.toLowerCase() === email) || 
      (phone && lead.phone?.replace(/\D/g, '') === phone)
    );

    // Auto-detect tags
    const autoTags = [];
    const formData = contact.customFields || [];
    const ghlTags = contact.tags || [];

    autoTags.push(...ghlTags);

    for (const field of formData) {
      const fieldName = (field.name || field.key || '').toLowerCase();
      const fieldValue = (field.value || '').toLowerCase();

      if (fieldName.includes('inspection') || fieldName.includes('roof inspector')) {
        autoTags.push('lead inspections');
      }
      if (fieldName.includes('ladder') || fieldValue.includes('ladder')) {
        autoTags.push('ladder assistants');
      }
      if (fieldName.includes('sales') || fieldName.includes('representative') || 
          fieldValue.includes('sales') || fieldValue.includes('rep')) {
        autoTags.push('sales reps');
      }
    }

    // Build comprehensive notes
    let notesText = `Imported from GHL. GHL ID: ${contact.id || 'unknown'}\n\n`;
    
    // Capture GHL notes
    if (contact.notes) {
      notesText += `GHL Notes:\n${contact.notes}\n\n`;
    }

    // Capture conversation history
    if (conversations.length > 0) {
      notesText += '=== Conversation History ===\n';
      for (const conv of conversations.slice(0, 5)) {
        // Fetch messages for each conversation
        try {
          const msgResponse = await fetch(`https://services.leadconnectorhq.com/conversations/messages?conversationId=${conv.id}`, {
            headers: {
              'Authorization': `Bearer ${ghlApiKey}`,
              'Version': '2021-04-15'
            }
          });
          if (msgResponse.ok) {
            const msgData = await msgResponse.json();
            const messages = msgData.messages || [];
            for (const msg of messages.slice(0, 10)) {
              const msgDate = msg.dateAdded ? new Date(msg.dateAdded).toLocaleString() : 'Unknown date';
              notesText += `[${msgDate}] ${msg.direction === 'outbound' ? 'To' : 'From'} Contact: ${msg.body || msg.messageBody || ''}\n`;
            }
          }
        } catch (err) {
          console.log('⚠️ Could not fetch messages for conversation:', err.message);
        }
      }
      notesText += '\n';
    }
    
    // Capture custom fields (only readable ones)
    const allCustomFields = contact.customFields || contact.customField || [];
    const readableFields = allCustomFields.filter(field => {
      const name = field.name || '';
      // Only include if name exists and doesn't look like an ID
      return name && name.length > 2 && !/^[a-zA-Z0-9]{15,}$/.test(name);
    });
    
    if (readableFields.length > 0) {
      notesText += '=== Contact Information ===\n';
      readableFields.forEach(field => {
        const fieldValue = field.value || '';
        if (fieldValue) {
          notesText += `${field.name}: ${fieldValue}\n`;
        }
      });
      notesText += '\n';
    }
    
    // Capture additional contact details
    if (contact.website) notesText += `Website: ${contact.website}\n`;
    if (contact.companyName) notesText += `Company: ${contact.companyName}\n`;
    if (contact.dateOfBirth) notesText += `DOB: ${contact.dateOfBirth}\n`;
    if (contact.businessId) notesText += `Business ID: ${contact.businessId}\n`;
    
    // Capture source and attribution
    if (contact.attributionSource) {
      notesText += `\n=== Source Information ===\n`;
      notesText += `Source: ${contact.attributionSource.medium || 'Unknown'}\n`;
      if (contact.attributionSource.campaign) notesText += `Campaign: ${contact.attributionSource.campaign}\n`;
      if (contact.attributionSource.source) notesText += `Channel: ${contact.attributionSource.source}\n`;
      if (contact.attributionSource.referrer) notesText += `Referrer: ${contact.attributionSource.referrer}\n`;
    }

    const leadData = {
      company_id: companyId,
      name: contact.firstName && contact.lastName 
        ? `${contact.firstName} ${contact.lastName}` 
        : contact.firstName || contact.lastName || 'Unknown',
      email: contact.email,
      phone: contact.phone,
      company: contact.companyName,
      street: contact.address1,
      city: contact.city,
      state: contact.state,
      zip: contact.postalCode,
      status: 'new',
      source: 'gohighlevel',
      lead_source: contact.source || 'GHL Test Import',
      tags: [...new Set(autoTags)],
      notes: notesText,
      is_active: true,
      created_by: user.email
    };

    let result;
    if (existingLead) {
      // Update existing
      const mergedTags = [...new Set([...(existingLead.tags || []), ...autoTags])];
      await base44.asServiceRole.entities.Lead.update(existingLead.id, {
        ...leadData,
        tags: mergedTags,
        notes: existingLead.notes + '\n\n' + notesText
      });
      result = { action: 'updated', lead: existingLead.id };
    } else {
      // Create new
      const newLead = await base44.asServiceRole.entities.Lead.create(leadData);
      result = { action: 'created', lead: newLead.id };
    }

    return Response.json({
      success: true,
      result,
      preview: {
        name: leadData.name,
        email: leadData.email,
        phone: leadData.phone,
        tags: leadData.tags,
        notesPreview: notesText.substring(0, 500) + (notesText.length > 500 ? '...' : ''),
        customFieldsFound: readableFields.length,
        customFieldNames: readableFields.map(f => f.name),
        rawFieldCount: allCustomFields.length,
        rawFields: allCustomFields.map(f => ({ name: f.name, key: f.key, id: f.id })),
        hasNotes: !!contact.notes,
        hasConversations: conversations.length > 0,
        conversationCount: conversations.length,
        hasAttribution: !!contact.attributionSource
      }
    });

  } catch (error) {
    console.error('Test sync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});