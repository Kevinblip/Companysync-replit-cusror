import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const formData = await req.formData();
        const callSid = formData.get('CallSid');
        const callStatus = formData.get('CallStatus');
        const callDuration = formData.get('CallDuration');

        const base44 = createClientFromRequest(req);

        // Find the communication record
        const comms = await base44.asServiceRole.entities.Communication.filter({ 
            twilio_sid: callSid 
        });

        if (comms && comms.length > 0) {
            const comm = comms[0];
            
            // Update the call status
            await base44.asServiceRole.entities.Communication.update(comm.id, {
                status: callStatus === 'completed' ? 'completed' : callStatus,
                duration_minutes: callDuration ? Math.ceil(parseInt(callDuration) / 60) : 0,
                cost: callDuration ? (parseInt(callDuration) / 60) * 0.013 : 0 // Approximate $0.013/min
            });
        }

        return new Response('OK');

    } catch (error) {
        console.error('Call Status Webhook Error:', error);
        return new Response('ERROR');
    }
});