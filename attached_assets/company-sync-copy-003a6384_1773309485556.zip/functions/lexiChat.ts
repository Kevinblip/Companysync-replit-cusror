import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  console.log('🚀 Lexi Chat - Unified Identity Gate (Voice + Text)');
  
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Please log in to use Lexi' }, { status: 401 });
    }
    
    console.log('✅ Authenticated:', user.email);

    const body = await req.json();
    const { message, conversationHistory, companyId, userEmail, userName, userIdentity, mode } = body;

    // 🔒 PLATFORM OWNER CHECK
    const isPlatformOwner = user.email === 'yicnteam@gmail.com';
    let isSuperAdmin = isPlatformOwner;

    // Check if user is super admin via staff profile
    if (!isSuperAdmin) {
      const allStaffProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ user_email: user.email });
      isSuperAdmin = allStaffProfiles.some(sp => sp.is_super_admin);
    }

    // 🎯 UNIFIED IDENTITY GATE
    // Priority 1: Use the passed userIdentity from the voice stream
    // Priority 2: Use the passed userEmail (legacy)
    // Priority 3: Use the standard auth session (for text chat)
    // This ensures Lexi Voice + Lexi Text use identical CRM access rules.
    const effectiveUserEmail = userIdentity || userEmail || user.email;
    const effectiveUserName = userName || user.full_name;
    const inputMode = mode || 'text'; // Track if this came from voice or text

    console.log('🧠 lexiChat - User:', effectiveUserEmail, '|', effectiveUserName, '| Platform Owner:', isPlatformOwner);

    // 🏢 Company Detection & Security Verification - PARALLEL
    const [ownedCompanies, staffProfiles] = await Promise.all([
      base44.asServiceRole.entities.Company.filter({ created_by: effectiveUserEmail }),
      base44.asServiceRole.entities.StaffProfile.filter({ user_email: effectiveUserEmail })
    ]);
    
    // Build set of allowed company IDs
    const allowedCompanyIds = new Set([
      ...ownedCompanies.map(c => c.id),
      ...staffProfiles.map(sp => sp.company_id)
    ].filter(Boolean));

    let actualCompanyId = null;

    if (companyId) {
      // Platform owners can access ANY company (for impersonation/support)
      if (isSuperAdmin) {
        console.log('🔓 Platform owner access granted to company:', companyId);
        actualCompanyId = companyId;
      } else if (allowedCompanyIds.has(companyId)) {
        actualCompanyId = companyId;
      } else {
        console.warn(`🚨 SECURITY ALERT: User ${user.email} attempted to access unauthorized company ${companyId}`);
        return Response.json({ error: 'Unauthorized: You do not have access to this company.' }, { status: 403 });
      }
    } else {
      actualCompanyId = ownedCompanies[0]?.id || staffProfiles[0]?.company_id;
    }
    
    if (!actualCompanyId) {
      return Response.json({
        response: "I couldn't identify your company. Please set up your company profile first.",
        error: 'No company found'
      });
    }

    const companies = await base44.asServiceRole.entities.Company.filter({ id: actualCompanyId });
    const company = companies?.[0];
    
    if (!company) {
      console.error('❌ CRITICAL: Company not found for ID:', actualCompanyId);
      return Response.json({ error: 'Company not found' }, { status: 404 });
    }
    
    console.log('🏢 VERIFIED Company:', company.company_name, '| ID:', actualCompanyId, '| Owner:', company.created_by);
    
    // SECURITY: Verify this company ID is allowed for this user
    if (!allowedCompanyIds.has(actualCompanyId)) {
      console.error('🚨 SECURITY BREACH ATTEMPT: User tried to access unauthorized company');
      return Response.json({ error: 'Unauthorized company access' }, { status: 403 });
    }

    // 👤 DETERMINE USER ROLE & ACCESS LEVEL
    const isCompanyOwner = company.created_by === effectiveUserEmail;
    let userStaffProfile = null;
    let isAdmin = isCompanyOwner; // Company owners are always admins

    if (!isCompanyOwner) {
      // Check if user has a staff profile for this company
      const userProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ 
        user_email: effectiveUserEmail, 
        company_id: actualCompanyId 
      });
      userStaffProfile = userProfiles?.[0];
      if (userStaffProfile) {
        isAdmin = userStaffProfile.is_administrator || userStaffProfile.is_super_admin;
        console.log(`📋 Staff Role: ${userStaffProfile.role_name || 'N/A'}, Admin: ${isAdmin}`);
      }
    }

    // Helper function to apply role-based filters
    // ⚠️ CRITICAL: All CRM tool calls pass through this filter
    // Whether voice or text, effectiveUserEmail is enforced here
    const applyRoleFilter = (baseFilter) => {
      if (isAdmin) {
        return baseFilter; // Admins see all data
      }
      // Non-admins only see their assigned records
      return { ...baseFilter, assigned_to_users: { "$in": [effectiveUserEmail] } };
    };
    
    // Get customer context for Lexi - LAZY LOADED (fetched only when needed)
    let customerList = '(Customer list loaded on demand)';
    const getCustomerListForPrompt = async () => {
      const companyCustomers = await base44.asServiceRole.entities.Customer.filter({ company_id: actualCompanyId }, '-created_date', 50);
      return companyCustomers.length > 0 
        ? companyCustomers.map(c => `${c.name} (${c.email || c.phone || 'no contact'})`).join(', ')
        : '(No customers yet)';
    };

    const openaiKey = Deno.env.get('Open_AI_Api_Key');
    if (!openaiKey) {
      return Response.json({ error: 'OpenAI API key not configured' }, { status: 500 });
    }

    // 🔍 CHECK LIMITS
    try {
      // Dynamic import to avoid static import errors if file doesn't exist
      const checkLimitModule = await import('./utils/checkSubscriptionLimit.js').catch(() => null);
      if (checkLimitModule) {
        const limitCheck = await checkLimitModule.checkSubscriptionLimit(base44, actualCompanyId, 'lexi');
        if (!limitCheck.allowed) {
          return Response.json({
            response: `You've reached your monthly limit for Lexi messages on the ${limitCheck.plan} plan (${limitCheck.current_usage}/${limitCheck.limit}). Please upgrade to continue chatting.`,
            error: 'Limit reached'
          });
        }
      }
    } catch (e) {
      console.error('Limit check error:', e);
    }

    // 📊 TRACK USAGE
    try {
      const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
      const feature = 'lexi';
      const costPerUnit = 0.01; // Estimated cost per chat

      const existingUsage = await base44.asServiceRole.entities.SubscriptionUsage.filter({
        company_id: actualCompanyId,
        feature: feature,
        usage_month: currentMonth
      });

      if (existingUsage && existingUsage.length > 0) {
        const record = existingUsage[0];
        await base44.asServiceRole.entities.SubscriptionUsage.update(record.id, {
          credits_used: (record.credits_used || 0) + 1,
          total_cost: (record.total_cost || 0) + costPerUnit,
          last_used: new Date().toISOString()
        });
      } else {
        await base44.asServiceRole.entities.SubscriptionUsage.create({
          company_id: actualCompanyId,
          feature: feature,
          usage_month: currentMonth,
          credits_used: 1,
          credits_limit: 1000, 
          cost_per_unit: costPerUnit,
          total_cost: costPerUnit,
          last_used: new Date().toISOString()
        });
      }
    } catch (err) {
      console.error('Failed to track usage:', err.message);
    }

    // 📚 TOOLS
    const tools = [
      {
        type: 'function',
        function: {
          name: 'get_crm_data',
          description: 'Get counts and details from CRM - customers, leads, estimates, invoices, tasks, projects, payments, etc.',
          parameters: {
            type: 'object',
            properties: {
              data_type: { 
                type: 'string', 
                enum: ['customers', 'leads', 'estimates', 'invoices', 'tasks', 'projects', 'payments', 'staff', 'calendar_events'],
                description: 'What type of data to retrieve'
              },
              filters: {
                type: 'object',
                description: 'Optional filters like status, date range, etc.'
              }
            },
            required: ['data_type']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'get_calendar_events',
          description: 'Get calendar events for a specific date range. ALWAYS use this to check schedule availability.',
          parameters: {
            type: 'object',
            properties: {
              start_date: { type: 'string', description: 'Start date (YYYY-MM-DD)' },
              end_date: { type: 'string', description: 'End date (YYYY-MM-DD)' }
            },
            required: ['start_date']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'create_calendar_event',
          description: 'Create a calendar event. ALWAYS use full ISO format with timezone for dates.',
          parameters: {
            type: 'object',
            properties: {
              title: { type: 'string', description: 'Event title' },
              start_time: { type: 'string', description: 'ISO datetime (e.g., "2026-01-07T16:00:00-05:00")' },
              end_time: { type: 'string', description: 'ISO datetime (optional, defaults to 1 hour after start)' },
              location: { type: 'string' },
              description: { type: 'string' },
              event_type: { type: 'string', enum: ['meeting', 'appointment', 'call', 'inspection', 'other'], description: 'Type of event' }
            },
            required: ['title', 'start_time']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'create_task',
          description: 'Create a new task',
          parameters: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              description: { type: 'string' },
              assigned_to: { type: 'string' },
              due_date: { type: 'string' },
              priority: { type: 'string', enum: ['low', 'medium', 'high'] }
            },
            required: ['name']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'create_lead',
          description: 'Create a new lead. Extract name, phone, email, and address details.',
          parameters: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              email: { type: 'string' },
              phone: { type: 'string' },
              street: { type: 'string' },
              city: { type: 'string' },
              state: { type: 'string' },
              zip: { type: 'string' },
              notes: { type: 'string' },
              source: { type: 'string', description: 'Source of the lead (e.g., "manual", "referral")' }
            },
            required: ['name']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'create_customer',
          description: 'Create a new customer. Extract name, phone, email, and address details.',
          parameters: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              email: { type: 'string' },
              phone: { type: 'string' },
              street: { type: 'string' },
              city: { type: 'string' },
              state: { type: 'string' },
              zip: { type: 'string' },
              notes: { type: 'string' }
            },
            required: ['name']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'send_email',
          description: 'Send an email to a customer or lead',
          parameters: {
            type: 'object',
            properties: {
              to: { type: 'string' },
              subject: { type: 'string' },
              message: { type: 'string' },
              contact_name: { type: 'string' }
            },
            required: ['to', 'subject', 'message']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'send_sms',
          description: 'Send a text message to a customer or lead',
          parameters: {
            type: 'object',
            properties: {
              to: { type: 'string' },
              message: { type: 'string' },
              contact_name: { type: 'string' }
            },
            required: ['to', 'message']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'manage_entity',
          description: 'General purpose tool to Create, Update, or Delete ANY entity in the CRM. Use this for Leads, Customers, Notes, Projects, etc.',
          parameters: {
            type: 'object',
            properties: {
              action: { type: 'string', enum: ['create', 'update', 'delete', 'list'], description: 'Action to perform' },
              entity_name: { type: 'string', description: 'Name of the entity (e.g., Lead, Customer, Project, Note, Task)' },
              data: { type: 'object', description: 'Data fields for create/update (e.g., { "name": "John", "status": "active" })' },
              id: { type: 'string', description: 'ID of the entity (required for update/delete)' }
            },
            required: ['action', 'entity_name']
          }
        }
      }
    ];

    // Dynamic Date Calculation
    const now = new Date();
    const userTimeZone = 'America/New_York';
    const currentDateString = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: userTimeZone });
    const todayISO = now.toISOString().split('T')[0];
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowISO = tomorrow.toISOString().split('T')[0];

    const systemPrompt = `You are Lexi, a friendly and professional AI assistant for ${company.company_name}.

👤 USER CONTEXT:
- Current User: ${effectiveUserName || effectiveUserEmail}
- Role: ${isAdmin ? 'Administrator' : userStaffProfile?.role_name || 'Staff Member'}
- Access Level: ${isAdmin ? 'Full company access' : 'Own assigned records only'}

📋 COMPANY CONTEXT:
- Company Name: ${company.company_name}
- Your CRM System: CompanySync
- Customers in ${company.company_name}: ${customerList}

🗣️ NATURAL COMMUNICATION STYLE:
- Speak conversationally and naturally, like a helpful colleague
- Summarize information instead of reading raw data verbatim
- Use common phrases: "10 AM Eastern" instead of "10:00 AM (EST)"
- Group similar items: "You have two meetings tomorrow" instead of listing every detail
- Avoid technical jargon - speak like a human, not a database
- Keep responses concise and friendly
- Only provide full details when specifically asked

🔒 CRITICAL SECURITY RULES:
1. You work EXCLUSIVELY for ${company.company_name}. This is your ONLY client.
2. You CANNOT access data from any other company (including YICN Roofing, Salesforce, HubSpot, or any external systems).
3. When asked "what is the name of this company" or "what company am I with", ALWAYS answer: "${company.company_name}".
4. Your CRM platform is called "CompanySync" - NEVER mention external CRM names like Salesforce or HubSpot.
5. If you don't have information, say you don't know - DO NOT make up information or reference other companies.

🎯 CAPABILITIES:
- You have full CRUD access to the CRM. You can create, update, delete, and list ANY entity.
- If a user asks to "add a note" or "change status", use the 'manage_entity' tool.
- Access CRM data, calendar, tasks, emails, and SMS.

🚨 CRITICAL RULES:
1. ALWAYS use tools. Never guess.
2. For "how many X", use get_crm_data.
3. For calendar, use get_calendar_events to check availability first.
4. If the user asks to modify data (e.g., "update customer phone"), use 'manage_entity'.

📅 DATE CONTEXT:
- Current Date: ${currentDateString}
- Timezone: ${userTimeZone}
- Today Example: "${todayISO}T16:00:00-05:00" (4 PM)
- Tomorrow Example: "${tomorrowISO}T09:00:00-05:00" (9 AM)
- ALWAYS use ISO format with the correct timezone offset for ${userTimeZone}.

Current Time: ${now.toLocaleString('en-US', { timeZone: userTimeZone })}`;
    
    const formattedHistory = (conversationHistory || [])
      .slice(-10)
      .filter(msg => msg?.role && msg?.content)
      .map(msg => ({
        role: msg.role === 'assistant' ? 'assistant' : 'user',
        content: msg.content
      }));

    // 🔄 EXECUTION LOOP
    let currentMessages = [
      { role: 'system', content: systemPrompt },
      ...formattedHistory,
      { role: 'user', content: message || 'Hello' }
    ];

    let finalResponse = "";
    const actionsExecuted = [];
    const MAX_TURNS = 10; // Increased for longer conversations
    let turnCount = 0;

    while (turnCount < MAX_TURNS) {
      turnCount++;
      console.log(`📞 Turn ${turnCount}: Calling OpenAI...`);
      
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${openaiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: currentMessages,
          tools,
          tool_choice: 'auto',
          temperature: 0.7,
          max_tokens: 2048
        })
      });

      const data = await response.json();
      if (data.error) {
        console.error('OpenAI Error:', data.error);
        throw new Error(`OpenAI Error: ${data.error.message}`);
      }

      const choice = data.choices[0];
      const responseMessage = choice.message;
      const toolCalls = responseMessage.tool_calls;

      currentMessages.push(responseMessage);
      finalResponse = responseMessage.content;

      if (!toolCalls || toolCalls.length === 0) {
        break;
      }

      console.log('🔧 Executing', toolCalls.length, 'tools');
      
      // Execute each tool call
      for (const toolCall of toolCalls) {
        const fname = toolCall.function.name;
        const args = JSON.parse(toolCall.function.arguments || '{}');
        console.log('🔨', fname, JSON.stringify(args));

        try {
          let toolResultContent = null;

          // Special case: tools that require confirmation and exit immediately
          if (fname === 'send_email') {
            return Response.json({
              response: `I'd like to send an email:\n\n**To:** ${args.to}\n**Subject:** ${args.subject}\n\n${args.message}\n\nShall I send this?`,
              requires_confirmation: true,
              proposed_action: { type: 'email', ...args }
            });
          }
          
          if (fname === 'send_sms') {
            return Response.json({
              response: `I'd like to send a text message:\n\n**To:** ${args.to}\n\n${args.message}\n\nShall I send this?`,
              requires_confirmation: true,
              proposed_action: { type: 'sms', ...args }
            });
          }

          // Regular tools
          if (fname === 'get_crm_data') {
            const dataType = args.data_type;
            let result = { count: 0, data: [] };

            if (dataType === 'customers') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              console.log('🔍 Customer query:', JSON.stringify(query));
              const allCustomers = await base44.asServiceRole.entities.Customer.filter(query, '-created_date', 200);
              console.log('👥 Found', allCustomers.length, 'customers');
              result = { count: allCustomers.length, sample: allCustomers.map(c => ({ name: c.name, email: c.email })) };
              actionsExecuted.push({ tool_name: 'get_customers', result: `Found ${allCustomers.length} customers` });
            } else if (dataType === 'leads') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              const filtered = await base44.asServiceRole.entities.Lead.filter(query, '-created_date', 200);
              result = { count: filtered.length };
              actionsExecuted.push({ tool_name: 'get_leads', result: `Found ${filtered.length} leads` });
            } else if (dataType === 'estimates') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              const filtered = await base44.asServiceRole.entities.Estimate.filter(query, '-created_date', 200);
              result = { count: filtered.length };
              actionsExecuted.push({ tool_name: 'get_estimates', result: `Found ${filtered.length} estimates` });
            } else if (dataType === 'invoices') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              const filtered = await base44.asServiceRole.entities.Invoice.filter(query, '-created_date', 200);
              const totalRevenue = filtered.reduce((sum, inv) => sum + (inv.amount || 0), 0);
              const totalPaid = filtered.reduce((sum, inv) => sum + (inv.amount_paid || 0), 0);
              result = { count: filtered.length, total_revenue: totalRevenue, total_paid: totalPaid };
              actionsExecuted.push({ tool_name: 'get_invoices', result: `Found ${filtered.length} invoices` });
            } else if (dataType === 'tasks') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              const filtered = await base44.asServiceRole.entities.Task.filter(query, '-created_date', 200);
              result = { count: filtered.length };
              actionsExecuted.push({ tool_name: 'get_tasks', result: `Found ${filtered.length} tasks` });
            } else if (dataType === 'projects') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              const filtered = await base44.asServiceRole.entities.Project.filter(query, '-created_date', 200);
              result = { count: filtered.length };
              actionsExecuted.push({ tool_name: 'get_projects', result: `Found ${filtered.length} projects` });
            } else if (dataType === 'payments') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              const filtered = await base44.asServiceRole.entities.Payment.filter(query, '-created_date', 200);
              const totalPayments = filtered.reduce((sum, pmt) => sum + (pmt.amount || 0), 0);
              result = { count: filtered.length, total_amount: totalPayments };
              actionsExecuted.push({ tool_name: 'get_payments', result: `Found ${filtered.length} payments` });
            } else if (dataType === 'staff') {
              // Staff list always shows all (admins need to see who's on the team)
               const filtered = await base44.asServiceRole.entities.StaffProfile.filter({ company_id: actualCompanyId }, '-created_date', 200);
               console.log('📋 Found', filtered.length, 'staff members');
               result = { count: filtered.length, staff: filtered.map(s => ({ name: s.full_name, email: s.user_email })) };
               actionsExecuted.push({ tool_name: 'get_staff', result: `Found ${filtered.length} staff` });
            } else if (dataType === 'calendar_events') {
              const query = applyRoleFilter({ company_id: actualCompanyId });
              const filtered = await base44.asServiceRole.entities.CalendarEvent.filter(query, '-created_date', 200);
              result = { count: filtered.length, events: filtered.slice(0, 50).map(e => ({ title: e.title, start: e.start_time })) };
              actionsExecuted.push({ tool_name: 'get_events', result: `Found ${filtered.length} events` });
            }
            toolResultContent = JSON.stringify(result);

          } else if (fname === 'get_calendar_events') {
          const startDate = args.start_date;
          const endDate = args.end_date || startDate;

          console.log('📅 Calendar query for user:', effectiveUserEmail);

          // Sync triggers - use service role but with the effective user context
          try {
             await base44.asServiceRole.functions.invoke('syncGoogleCalendar', { companyId: actualCompanyId, userEmail: effectiveUserEmail });
          } catch (e) { console.log('Sync error:', e.message); }

          // For non-admins, filter to their own events
          const calendarQuery = isAdmin 
            ? { company_id: actualCompanyId }
            : { company_id: actualCompanyId, assigned_to: effectiveUserEmail };
          const allEvents = await base44.asServiceRole.entities.CalendarEvent.filter(calendarQuery, '-start_time', 1000);
            const events = allEvents.filter(e => {
              if (!e.start_time) return false;
              try {
                // Approximate filtering
                const eventDate = new Date(e.start_time).toISOString().split('T')[0];
                return eventDate >= startDate && eventDate <= endDate;
              } catch (err) { return false; }
            }).map(e => ({
              title: e.title,
              start: e.start_time,
              end: e.end_time,
              status: e.status
            }));
            actionsExecuted.push({ tool_name: 'get_calendar', result: `Found ${events.length} events` });
            toolResultContent = JSON.stringify({ count: events.length, events, message: `Found ${events.length} events` });

          } else if (fname === 'create_calendar_event') {
            let startTime = args.start_time;
            let endTime = args.end_time;
            if (!endTime) {
              const d = new Date(startTime);
              d.setHours(d.getHours() + 1);
              endTime = d.toISOString();
            }
            const eventData = {
              title: args.title,
              start_time: startTime,
              end_time: endTime,
              location: args.location || '',
              description: args.description || '',
              event_type: args.event_type || 'meeting',
              status: 'scheduled',
              company_id: actualCompanyId,
              assigned_to: effectiveUserEmail
            };
            const event = await base44.asServiceRole.entities.CalendarEvent.create(eventData);

            console.log('📅 Created event assigned to:', effectiveUserEmail);

            // Sync
            try {
              await base44.asServiceRole.functions.invoke('syncCRMToGoogleCalendar', { eventId: event.id, userEmail: effectiveUserEmail });
            } catch (e) { console.error('Sync failed:', e.message); }

            actionsExecuted.push({ tool_name: 'create_event', result: `Created: "${args.title}"` });
            toolResultContent = JSON.stringify({ success: true, event_id: event.id, message: 'Event created' });

          } else if (fname === 'create_task') {
            const task = await base44.asServiceRole.entities.Task.create({ ...args, company_id: actualCompanyId, assigned_to: effectiveUserEmail, assigned_to_users: [effectiveUserEmail] });
            actionsExecuted.push({ tool_name: 'create_task', result: `Created task: ${args.name}` });
            toolResultContent = JSON.stringify({ success: true, task_id: task.id });

          } else if (fname === 'create_lead') {
            const lead = await base44.asServiceRole.entities.Lead.create({ 
              ...args, 
              company_id: actualCompanyId, 
              status: 'new', 
              lead_source: 'Lexi AI',
              assigned_to: effectiveUserEmail,
              assigned_to_users: [effectiveUserEmail]
            });
            actionsExecuted.push({ tool_name: 'create_lead', result: `Created lead: ${args.name}` });
            toolResultContent = JSON.stringify({ success: true, lead_id: lead.id, message: `Lead ${lead.name} created successfully and assigned to you.` });

          } else if (fname === 'create_customer') {
            const customer = await base44.asServiceRole.entities.Customer.create({ 
              ...args, 
              company_id: actualCompanyId,
              assigned_to: effectiveUserEmail,
              assigned_to_users: [effectiveUserEmail]
            });
            actionsExecuted.push({ tool_name: 'create_customer', result: `Created customer: ${args.name}` });
            toolResultContent = JSON.stringify({ success: true, customer_id: customer.id, message: `Customer ${customer.name} created successfully and assigned to you.` });

          } else if (fname === 'manage_entity') {
            const { action, entity_name, data, id } = args;
            const normalizedEntity = entity_name.charAt(0).toUpperCase() + entity_name.slice(1);
            
            if (!base44.asServiceRole.entities[normalizedEntity]) {
               throw new Error(`Entity type '${normalizedEntity}' not found.`);
            }

            let result;
            if (action === 'create') {
               const payload = { ...data, company_id: actualCompanyId };
               // Auto-assign to current user if not admin creating for someone else
               if (!isAdmin && !payload.assigned_to && !payload.assigned_to_users) {
                 payload.assigned_to = effectiveUserEmail;
                 payload.assigned_to_users = [effectiveUserEmail];
               }
               result = await base44.asServiceRole.entities[normalizedEntity].create(payload);
               actionsExecuted.push({ tool_name: 'manage_entity', result: `Created ${normalizedEntity}` });
            } else if (action === 'update') {
               // For non-admins, verify they own the record before updating
               if (!isAdmin) {
                 const existing = await base44.asServiceRole.entities[normalizedEntity].filter({ id });
                 if (existing?.[0] && !existing[0].assigned_to_users?.includes(effectiveUserEmail) && existing[0].assigned_to !== effectiveUserEmail) {
                   throw new Error(`You don't have permission to update this ${normalizedEntity}`);
                 }
               }
               result = await base44.asServiceRole.entities[normalizedEntity].update(id, data);
               actionsExecuted.push({ tool_name: 'manage_entity', result: `Updated ${normalizedEntity}` });
            } else if (action === 'delete') {
               // For non-admins, verify they own the record before deleting
               if (!isAdmin) {
                 const existing = await base44.asServiceRole.entities[normalizedEntity].filter({ id });
                 if (existing?.[0] && !existing[0].assigned_to_users?.includes(effectiveUserEmail) && existing[0].assigned_to !== effectiveUserEmail) {
                   throw new Error(`You don't have permission to delete this ${normalizedEntity}`);
                 }
               }
               await base44.asServiceRole.entities[normalizedEntity].delete(id);
               result = { success: true };
               actionsExecuted.push({ tool_name: 'manage_entity', result: `Deleted ${normalizedEntity}` });
            } else if (action === 'list') {
               const query = applyRoleFilter({ company_id: actualCompanyId });
               result = await base44.asServiceRole.entities[normalizedEntity].filter(query, '-created_date', 20);
               actionsExecuted.push({ tool_name: 'manage_entity', result: `Listed ${normalizedEntity}` });
            }
            toolResultContent = JSON.stringify({ success: true, data: result });
          }

          // Add tool result to conversation history
          currentMessages.push({
            role: 'tool',
            tool_call_id: toolCall.id,
            content: toolResultContent || JSON.stringify({ success: true })
          });

        } catch (toolError) {
          console.error('❌ Tool error:', fname, toolError.message);
          currentMessages.push({
            role: 'tool',
            tool_call_id: toolCall.id,
            content: JSON.stringify({ error: toolError.message })
          });
        }
      }
    }

    return Response.json({
      response: finalResponse || 'Hello! How can I help you?',
      actions_executed: actionsExecuted
    });

  } catch (error) {
    console.error('❌ Error:', error.message);
    return Response.json({ 
      response: "I encountered an error. Please try again.",
      error: error.message
    }, { status: 500 });
  }
});