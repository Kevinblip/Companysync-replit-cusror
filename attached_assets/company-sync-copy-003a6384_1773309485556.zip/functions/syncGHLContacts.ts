import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { skipDuplicates = true, locationId } = await req.json();

    // Get company ID
    const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: user.email });
    let companyId;
    
    if (staffProfiles && staffProfiles.length > 0) {
      companyId = staffProfiles[0].company_id;
    } else {
      const companies = await base44.entities.Company.filter({ created_by: user.email });
      companyId = companies[0]?.id;
    }

    if (!companyId) {
      return Response.json({ error: 'Company not found' }, { status: 400 });
    }

    const ghlApiKey = Deno.env.get('GHL_API_KEY');
    if (!ghlApiKey) {
      return Response.json({ error: 'GHL_API_KEY not configured' }, { status: 400 });
    }

    // Fetch ALL contacts from GHL (paginated)
    let ghlUrl = 'https://rest.gohighlevel.com/v1/contacts/?limit=100';
    if (locationId) {
      ghlUrl += `&locationId=${locationId}`;
    }

    const ghlResponse = await fetch(ghlUrl, {
      headers: {
        'Authorization': `Bearer ${ghlApiKey}`,
        'Content-Type': 'application/json',
        'Version': '2021-07-28'
      }
    });

    if (!ghlResponse.ok) {
      return Response.json({ error: 'Failed to fetch GHL contacts' }, { status: 400 });
    }

    const ghlData = await ghlResponse.json();
    let contacts = ghlData.contacts || [];

    console.log(`✅ Fetched ${contacts.length} contacts from GHL (page 1)`);

    // Fetch all pages if there are more
    let nextPageUrl = ghlData.meta?.nextPageUrl;
    let pageCount = 1;
    
    while (nextPageUrl && pageCount < 50) { // Safety limit of 50 pages (5000 contacts max)
      const nextResponse = await fetch(nextPageUrl, {
        headers: {
          'Authorization': `Bearer ${ghlApiKey}`,
          'Content-Type': 'application/json',
          'Version': '2021-07-28'
        }
      });
      
      if (nextResponse.ok) {
        const nextData = await nextResponse.json();
        const nextContacts = nextData.contacts || [];
        contacts = [...contacts, ...nextContacts];
        nextPageUrl = nextData.meta?.nextPageUrl;
        pageCount++;
        console.log(`✅ Fetched page ${pageCount}, total contacts: ${contacts.length}`);
      } else {
        break;
      }
    }

    console.log(`✅ Total contacts fetched: ${contacts.length}`);

    // Fetch conversations for each contact
    for (const contact of contacts) {
      try {
        const convResponse = await fetch(`https://services.leadconnectorhq.com/conversations/search?contactId=${contact.id}`, {
          headers: {
            'Authorization': `Bearer ${ghlApiKey}`,
            'Version': '2021-04-15'
          }
        });
        if (convResponse.ok) {
          const convData = await convResponse.json();
          contact._conversations = convData.conversations || [];
        }
      } catch (err) {
        console.log(`⚠️ Could not fetch conversations for ${contact.email}:`, err.message);
        contact._conversations = [];
      }
    }

    // Get existing leads and customers (Fetch up to 1000 to ensure we find duplicates)
    const existingLeads = await base44.asServiceRole.entities.Lead.filter({ company_id: companyId }, '-created_date', 5000);
    const existingCustomers = await base44.asServiceRole.entities.Customer.filter({ company_id: companyId }, '-created_date', 5000);

    let created = 0;
    let skipped = 0;
    let updated = 0;
    const errors = [];

    for (const contact of contacts) {
      try {
        const email = contact.email?.toLowerCase();
        const phone = contact.phone?.replace(/\D/g, '');
        
        // Check for duplicates by GHL ID first, then email/phone (last 10 digits)
        const cleanPhone = phone ? phone.slice(-10) : null;

        const isDuplicateLead = existingLeads.some(lead => {
            const leadPhone = lead.phone?.replace(/\D/g, '') || '';
            return (contact.id && lead.ghl_contact_id === contact.id) ||
                   (email && lead.email?.toLowerCase() === email) || 
                   (cleanPhone && leadPhone.length >= 10 && leadPhone.slice(-10) === cleanPhone);
        });

        const isDuplicateCustomer = existingCustomers.some(customer => {
            const custPhone = customer.phone?.replace(/\D/g, '') || '';
            return (contact.id && customer.ghl_contact_id === contact.id) ||
                   (email && customer.email?.toLowerCase() === email) || 
                   (cleanPhone && custPhone.length >= 10 && custPhone.slice(-10) === cleanPhone);
        });

        if (isDuplicateLead || isDuplicateCustomer) {
          // Always update existing lead with new data
          const existingLead = existingLeads.find(lead => {
            const leadPhone = lead.phone?.replace(/\D/g, '') || '';
            return (contact.id && lead.ghl_contact_id === contact.id) ||
                   (email && lead.email?.toLowerCase() === email) || 
                   (cleanPhone && leadPhone.length >= 10 && leadPhone.slice(-10) === cleanPhone);
          });
          
          if (existingLead) {
            // Auto-detect tags
            const autoTags = [];
            const formData = contact.customFields || [];
            const ghlTags = contact.tags || [];

            autoTags.push(...ghlTags);

            for (const field of formData) {
              const fieldName = (field.name || field.key || '').toLowerCase();
              const fieldValue = (field.value || '').toLowerCase();

              if (fieldName.includes('inspection') || fieldName.includes('roof inspector')) {
                autoTags.push('lead inspections');
              }
              if (fieldName.includes('ladder') || fieldValue.includes('ladder')) {
                autoTags.push('ladder assistants');
              }
              if (fieldName.includes('sales') || fieldName.includes('representative') || 
                  fieldValue.includes('sales') || fieldValue.includes('rep')) {
                autoTags.push('sales reps');
              }
            }

            // Merge existing tags with new auto-tags
            const existingTags = existingLead.tags || [];
            const mergedTags = [...new Set([...existingTags, ...autoTags])];

            // Build comprehensive updated notes
            let notesText = existingLead.notes || '';
            notesText += `\n\n[GHL Sync Update - ${new Date().toLocaleString()}]\n`;
            
            // Capture GHL notes
            if (contact.notes && !existingLead.notes?.includes(contact.notes)) {
              notesText += `GHL Notes:\n${contact.notes}\n\n`;
            }

            // Capture conversation history
            if (contact._conversations && contact._conversations.length > 0) {
              notesText += '=== Recent Conversation History ===\n';
              for (const conv of contact._conversations.slice(0, 3)) {
                try {
                  const msgResponse = await fetch(`https://services.leadconnectorhq.com/conversations/messages?conversationId=${conv.id}`, {
                    headers: {
                      'Authorization': `Bearer ${ghlApiKey}`,
                      'Version': '2021-04-15'
                    }
                  });
                  if (msgResponse.ok) {
                    const msgData = await msgResponse.json();
                    const messages = msgData.messages || [];
                    for (const msg of messages.slice(0, 10)) {
                      const msgDate = msg.dateAdded ? new Date(msg.dateAdded).toLocaleString() : 'Unknown date';
                      notesText += `[${msgDate}] ${msg.direction === 'outbound' ? 'To' : 'From'} Contact: ${msg.body || msg.messageBody || ''}\n`;
                    }
                  }
                } catch (err) {
                  console.log('⚠️ Could not fetch messages:', err.message);
                }
              }
              notesText += '\n';
            }
            
            // Capture custom fields (only if they have readable names)
            const allCustomFields = contact.customFields || contact.customField || [];
            const readableFields = allCustomFields.filter(field => {
              const name = field.name || '';
              return name && name.length > 2 && !/^[a-zA-Z0-9]{15,}$/.test(name);
            });
            
            if (readableFields.length > 0) {
              notesText += '=== Updated Contact Information ===\n';
              readableFields.forEach(field => {
                const fieldValue = field.value || '';
                if (fieldValue) {
                  notesText += `${field.name}: ${fieldValue}\n`;
                }
              });
              notesText += '\n';
            }
            
            // Capture source and attribution
            if (contact.attributionSource) {
              notesText += '=== Source Information ===\n';
              notesText += `Source: ${contact.attributionSource.medium || 'Unknown'}\n`;
              if (contact.attributionSource.campaign) notesText += `Campaign: ${contact.attributionSource.campaign}\n`;
              if (contact.attributionSource.source) notesText += `Channel: ${contact.attributionSource.source}\n`;
            }

            await base44.asServiceRole.entities.Lead.update(existingLead.id, {
              ghl_contact_id: contact.id, // Ensure ID is saved
              name: contact.firstName && contact.lastName 
                ? `${contact.firstName} ${contact.lastName}` 
                : contact.firstName || contact.lastName || 'Unknown',
              email: contact.email,
              phone: contact.phone,
              company: contact.companyName,
              street: contact.address1,
              city: contact.city,
              state: contact.state,
              zip: contact.postalCode,
              source: 'gohighlevel',
              lead_source: contact.source || 'GoHighLevel Integration',
              tags: mergedTags,
              notes: notesText,
            });
            updated++;
            } else if (isDuplicateCustomer) {
                // It matched a customer but not a lead. Update the customer's GHL ID if missing.
                const existingCustomer = existingCustomers.find(customer => {
                    const custPhone = customer.phone?.replace(/\D/g, '') || '';
                    return (contact.id && customer.ghl_contact_id === contact.id) ||
                           (email && customer.email?.toLowerCase() === email) || 
                           (cleanPhone && custPhone.length >= 10 && custPhone.slice(-10) === cleanPhone);
                });

                if (existingCustomer) {
                    console.log(`Matched existing customer: ${existingCustomer.name}. Updating GHL ID.`);
                    await base44.asServiceRole.entities.Customer.update(existingCustomer.id, {
                        ghl_contact_id: contact.id
                    });
                    updated++; // Count as updated
                }
            }

            // Skip creating duplicate if skipDuplicates is true
            if (skipDuplicates) {
            continue;
            }
        } else {
          // Auto-detect tags for new lead
          const autoTags = [];
          const formData = contact.customFields || [];
          const ghlTags = contact.tags || [];

          autoTags.push(...ghlTags);

          for (const field of formData) {
            const fieldName = (field.name || field.key || '').toLowerCase();
            const fieldValue = (field.value || '').toLowerCase();

            if (fieldName.includes('inspection') || fieldName.includes('roof inspector')) {
              autoTags.push('lead inspections');
            }
            if (fieldName.includes('ladder') || fieldValue.includes('ladder')) {
              autoTags.push('ladder assistants');
            }
            if (fieldName.includes('sales') || fieldName.includes('representative') || 
                fieldValue.includes('sales') || fieldValue.includes('rep')) {
              autoTags.push('sales reps');
            }
          }

          // Build comprehensive notes
          let notesText = `Imported from GHL. GHL ID: ${contact.id || 'unknown'}\n\n`;

          // Capture GHL notes
          if (contact.notes) {
            notesText += `GHL Notes:\n${contact.notes}\n\n`;
          }

          // Capture conversation history
          if (contact._conversations && contact._conversations.length > 0) {
            notesText += '=== Recent Conversation History ===\n';
            for (const conv of contact._conversations.slice(0, 3)) {
              try {
                const msgResponse = await fetch(`https://services.leadconnectorhq.com/conversations/messages?conversationId=${conv.id}`, {
                  headers: {
                    'Authorization': `Bearer ${ghlApiKey}`,
                    'Version': '2021-04-15'
                  }
                });
                if (msgResponse.ok) {
                  const msgData = await msgResponse.json();
                  const messages = msgData.messages || [];
                  for (const msg of messages.slice(0, 10)) {
                    const msgDate = msg.dateAdded ? new Date(msg.dateAdded).toLocaleString() : 'Unknown date';
                    notesText += `[${msgDate}] ${msg.direction === 'outbound' ? 'To' : 'From'} Contact: ${msg.body || msg.messageBody || ''}\n`;
                  }
                }
              } catch (err) {
                console.log('⚠️ Could not fetch messages:', err.message);
              }
            }
            notesText += '\n';
          }

          // Capture custom fields (only if they have readable names)
          const allCustomFields = contact.customFields || contact.customField || [];
          const readableFields = allCustomFields.filter(field => {
            const name = field.name || '';
            // Only include if name exists and doesn't look like an ID
            return name && name.length > 2 && !/^[a-zA-Z0-9]{15,}$/.test(name);
          });
          
          if (readableFields.length > 0) {
            notesText += '=== Contact Information ===\n';
            readableFields.forEach(field => {
              const fieldValue = field.value || '';
              if (fieldValue) {
                notesText += `${field.name}: ${fieldValue}\n`;
              }
            });
            notesText += '\n';
          }

          // Capture additional contact details
          if (contact.website) notesText += `Website: ${contact.website}\n`;
          if (contact.companyName) notesText += `Company: ${contact.companyName}\n`;
          if (contact.dateOfBirth) notesText += `DOB: ${contact.dateOfBirth}\n`;
          if (contact.businessId) notesText += `Business ID: ${contact.businessId}\n`;

          // Capture source and attribution
          if (contact.attributionSource) {
            notesText += `\n=== Source Information ===\n`;
            notesText += `Source: ${contact.attributionSource.medium || 'Unknown'}\n`;
            if (contact.attributionSource.campaign) notesText += `Campaign: ${contact.attributionSource.campaign}\n`;
            if (contact.attributionSource.source) notesText += `Channel: ${contact.attributionSource.source}\n`;
            if (contact.attributionSource.referrer) notesText += `Referrer: ${contact.attributionSource.referrer}\n`;
          }

          // Create new lead
          await base44.asServiceRole.entities.Lead.create({
            company_id: companyId,
            ghl_contact_id: contact.id, // Store GHL ID
            name: contact.firstName && contact.lastName 
              ? `${contact.firstName} ${contact.lastName}` 
              : contact.firstName || contact.lastName || 'Unknown',
            email: contact.email,
            phone: contact.phone,
            company: contact.companyName,
            street: contact.address1,
            city: contact.city,
            state: contact.state,
            zip: contact.postalCode,
            status: 'new',
            source: 'gohighlevel',
            lead_source: contact.source || 'GHL Import',
            tags: [...new Set(autoTags)],
            notes: notesText,
            is_active: true,
            created_by: user.email
          });
          created++;
        }
      } catch (error) {
        errors.push({
          contact: contact.email || contact.phone,
          error: error.message
        });
      }
    }

    return Response.json({
      success: true,
      total: contacts.length,
      created,
      updated,
      skipped,
      errors: errors.length > 0 ? errors : undefined
    });

  } catch (error) {
    console.error('Sync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});