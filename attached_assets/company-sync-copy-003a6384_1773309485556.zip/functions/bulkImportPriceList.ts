import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { items, source } = await req.json();

    if (!items || !Array.isArray(items) || items.length === 0) {
      return Response.json({ 
        success: false, 
        error: 'No items provided' 
      }, { status: 400 });
    }

    console.log(`🔄 Starting bulk import: ${items.length} items for source: ${source}`);

    // Clear existing items for this source using bulk delete
    console.log(`🗑️ Clearing existing items for source: ${source}...`);
    try {
      // Delete all existing items for this source at once
      const existingCount = await base44.asServiceRole.entities.PriceListItem.deleteMany({ source: source });
      console.log(`✅ Deleted ${existingCount} existing items`);
    } catch (deleteError) {
      console.log(`⚠️ Could not bulk delete (may be first import): ${deleteError.message}`);
    }

    // Import in batches with error handling
    const batchSize = 50; // Smaller batch size to avoid timeout
    let imported = 0;
    const failedBatches = [];

    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize);
      try {
        const result = await base44.asServiceRole.entities.PriceListItem.bulkCreate(batch);
        imported += batch.length;
      } catch (batchError) {
        console.error(`❌ Batch ${i / batchSize + 1} failed:`, batchError.message);
        failedBatches.push({ batchNumber: Math.floor(i / batchSize) + 1, error: batchError.message });
        // Continue with next batch instead of failing completely
      }
      
      const progress = Math.floor((imported / items.length) * 100);
      console.log(`Progress: ${imported}/${items.length} (${progress}%)`);
      
      // Delay to avoid overwhelming the system
      if (i + batchSize < items.length) {
        await new Promise(resolve => setTimeout(resolve, 300));
      }
    }

    if (failedBatches.length > 0) {
      console.warn(`⚠️ ${failedBatches.length} batches failed to import`);
    }

    console.log('✅ Bulk import complete!');

    return Response.json({
      success: true,
      imported: imported,
      total: items.length,
      failedBatches: failedBatches.length > 0 ? failedBatches : undefined
    });

  } catch (error) {
    console.error('❌ Bulk import error:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
});