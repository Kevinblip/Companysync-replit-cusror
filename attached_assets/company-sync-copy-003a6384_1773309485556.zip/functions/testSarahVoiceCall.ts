import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import twilio from 'npm:twilio@5.10.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { phone_number } = await req.json();
    if (!phone_number) {
      return Response.json({ error: 'phone_number required' }, { status: 400 });
    }

    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');
    const fromPhone = Deno.env.get('TWILIO_PHONE_NUMBER');
    const appUrl = Deno.env.get('APP_URL');

    if (!accountSid || !authToken || !fromPhone || !appUrl) {
      return Response.json({ error: 'Twilio credentials not configured' }, { status: 500 });
    }

    const client = twilio(accountSid, authToken);

    const call = await client.calls.create({
      to: phone_number,
      from: fromPhone,
      url: `${appUrl}/api/functions/sarahVoiceCallHandler`
    });

    return Response.json({ 
      success: true, 
      call_sid: call.sid,
      message: 'Call initiated with Sarah voice'
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});