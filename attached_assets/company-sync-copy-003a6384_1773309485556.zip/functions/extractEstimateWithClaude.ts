import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Anthropic from 'npm:@anthropic-ai/sdk@0.32.1';

Deno.serve(async (req) => {
  try {
    const apiKey = Deno.env.get("ANTHROPIC_API_KEY");
    
    if (!apiKey) {
      return Response.json({
        success: false,
        error: 'ANTHROPIC_API_KEY not configured. Please add it in Dashboard → Settings → Secrets'
      }, { status: 400 });
    }

    const anthropic = new Anthropic({ apiKey });
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({
        success: false,
        error: 'Unauthorized'
      }, { status: 401 });
    }

    const { fileUrl, description, pricingSource } = await req.json();

    if (!fileUrl) {
      return Response.json({
        success: false,
        error: 'fileUrl is required'
      }, { status: 400 });
    }

    console.log('📄 Processing file:', fileUrl);
    console.log('🎯 Pricing source:', pricingSource);

    // Fetch file as base64
    const fileResponse = await fetch(fileUrl);
    const fileBuffer = await fileResponse.arrayBuffer();
    const base64Data = btoa(String.fromCharCode(...new Uint8Array(fileBuffer)));
    
    const extension = fileUrl.split('.').pop().toLowerCase();
    const mediaType = extension === 'pdf' ? 'application/pdf' : `image/${extension}`;

    // Fetch price list for context (REDUCED to prevent stack overflow)
    let priceList = [];
    try {
      if (pricingSource === 'xactimate') {
        priceList = await base44.entities.PriceListItem.filter({ source: 'Xactimate' }, '-created_date', 50);
      } else if (pricingSource === 'symbility') {
        priceList = await base44.entities.PriceListItem.filter({ source: 'Symbility' }, '-created_date', 50);
      } else {
        priceList = await base44.entities.PriceListItem.filter({ source: 'Custom' }, '-created_date', 50);
      }
      console.log(`📋 Loaded ${priceList.length} items from ${pricingSource} price list`);
    } catch (err) {
      console.warn('⚠️ Could not load price list:', err.message);
    }

    // Build context (simplified to prevent stack overflow)
    let priceListContext = '';
    if (priceList.length > 0) {
      const contextItems = priceList.slice(0, 30).map(item => 
        `${item.code}: ${item.description.substring(0, 50)} - $${item.price}/${item.unit}`
      );
      priceListContext = contextItems.join('\n');
    }

    const systemPrompt = `You are an expert insurance estimator specializing in ${pricingSource === 'xactimate' ? 'Xactimate' : pricingSource === 'symbility' ? 'Symbility' : 'roofing'} estimates.

Your task: Extract line items from the estimate and MATCH them to actual ${pricingSource.toUpperCase()} codes.

${priceListContext ? `Sample codes for reference:\n${priceListContext}\n\n` : ''}

CRITICAL INSTRUCTIONS:
1. Extract ALL line items with actual ${pricingSource.toUpperCase()} codes
2. Common roofing codes:
   - Shingles: RFG SSSQ, RFG ARLM
   - Ridge: RFG RDG
   - Hip: RFG HP
   - Valley: RFG VLY
   - Eave: RFG EVE
   - Flashing: RFG FLS
   - Drip Edge: RFG DE
   - Ice & Water: RFG IWS
   - Underlayment: RFG UL
   - Tear-off: RFG R&R
   - Decking: FRM DK
3. Match quantities and units exactly
4. If unsure of code, use closest match

${description ? `Context: ${description}` : ''}

Return ONLY valid JSON:
{
  "line_items": [
    {
      "code": "RFG SSSQ",
      "description": "Shingles, standard 3-tab",
      "quantity": 24.39,
      "unit": "SQ"
    }
  ],
  "total_from_report": 0
}`;

    const response = await anthropic.messages.create({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 4096,
      temperature: 0,
      system: systemPrompt,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'document',
              source: {
                type: 'base64',
                media_type: mediaType,
                data: base64Data
              }
            },
            {
              type: 'text',
              text: 'Extract all line items with Xactimate codes, quantities, and units.'
            }
          ]
        }
      ]
    });

    const content = response.content[0].text.trim();
    console.log('🤖 Claude Response:', content.substring(0, 500));

    let parsed;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsed = JSON.parse(jsonMatch[0]);
      } else {
        parsed = JSON.parse(content);
      }
    } catch (parseError) {
      console.error('❌ JSON parse error:', parseError);
      return Response.json({
        success: false,
        error: 'Failed to parse AI response',
        details: content.substring(0, 500)
      }, { status: 500 });
    }

    return Response.json({
      success: true,
      line_items: parsed.line_items || [],
      total_from_report: parsed.total_from_report || 0
    });

  } catch (error) {
    console.error('💥 Error:', error);
    return Response.json({
      success: false,
      error: error.message,
      errorType: error.constructor.name,
      details: error.stack
    }, { status: 500 });
  }
});