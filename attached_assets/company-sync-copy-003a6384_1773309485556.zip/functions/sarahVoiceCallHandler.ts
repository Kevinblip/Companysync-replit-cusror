import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function escapeXml(unsafe) {
    if (!unsafe) return '';
    return String(unsafe).replace(/[<>&"']/g, (c) => {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '"': return '&quot;';
            case "'": return '&apos;';
        }
    });
}

function normalizePhone(phone) {
    if (!phone) return '';
    return phone.replace(/\D/g, '').slice(-10);
}

Deno.serve(async (req) => {
    console.log('📞 Sarah Voice Call Handler - START (Gemini Voice)');
    
    let safeVoiceId = 'Polly.Joanna';
    
    try {
        const contentType = req.headers.get('content-type') || '';
        let from, to, callSid, speechResult;
        
        if (contentType.includes('application/x-www-form-urlencoded')) {
            const formData = await req.formData();
            from = formData.get('From');
            to = formData.get('To');
            callSid = formData.get('CallSid');
            speechResult = formData.get('SpeechResult');
        } else if (contentType.includes('application/json')) {
            const json = await req.json();
            from = json.From || json.from;
            to = json.To || json.to;
            callSid = json.CallSid || json.callSid;
            speechResult = json.SpeechResult || json.speechResult;
        }

        console.log('📞 From:', from, '| To:', to, '| CallSid:', callSid);
        console.log('💬 Speech:', speechResult || 'INITIAL_GREETING');
        
        const base44 = createClientFromRequest(req);
        
        const url = new URL(req.url);
        let companyId = url.searchParams.get('companyId');
        
        if (!companyId) {
            console.log('🔍 Looking up company by phone:', to);
            const normalizedTo = normalizePhone(to);
            
            const allTwilioSettings = await base44.asServiceRole.entities.TwilioSettings.list('-created_date', 100);
            
            const twilioSettings = allTwilioSettings.find(s => 
                normalizePhone(s.main_phone_number) === normalizedTo || 
                (s.available_numbers?.some(num => normalizePhone(num.phone_number) === normalizedTo))
            );

            if (!twilioSettings) {
                console.error('❌ No company found for number:', to);
                return new Response(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>Sorry, this number is not configured.</Say><Hangup/></Response>`, 
                    { headers: { 'Content-Type': 'text/xml' } });
            }
            companyId = twilioSettings.company_id;
        }
        
        console.log('🏢 Found Company ID:', companyId);
        const companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
        const company = companies[0];
        
        if (!company) {
            console.error('❌ CRITICAL: Company not found for ID:', companyId);
            return new Response(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>Company configuration error.</Say><Hangup/></Response>`, 
                { headers: { 'Content-Type': 'text/xml' } });
        }
        
        console.log('✅ VERIFIED Company:', company.company_name, '| ID:', companyId);
        
        const settingsRows = await base44.asServiceRole.entities.AssistantSettings.filter({ 
            company_id: companyId, 
            assistant_name: 'sarah' 
        });
        const settings = settingsRows[0] || {};

        safeVoiceId = settings.voice_id || 'Polly.Joanna';
        if (!safeVoiceId.startsWith('Polly.') && !safeVoiceId.startsWith('Alice')) {
            console.log(`⚠️ Invalid Voice ID, using Polly.Joanna`);
            safeVoiceId = 'Polly.Joanna';
        }

        const companyName = settings.brand_short_name || company?.company_name || 'our company';

        let agentName = 'Sarah';
        if (settings?.system_prompt) {
            const nameMatch = settings.system_prompt.match(/(?:You are|Your name is|I am|Role:)[:\s]*(?:You are\s+)?([A-Z][a-z]+)/i);
            if (nameMatch && nameMatch[1] && nameMatch[1].toLowerCase() !== 'you') {
                agentName = nameMatch[1];
            }
        }

        const appUrl = (Deno.env.get('APP_URL') || `https://${Deno.env.get('BASE44_APP_ID')}.base44.app`).replace(/\/$/, '');
        const callbackUrl = `${appUrl}/api/functions/sarahVoiceCallHandler?companyId=${companyId}`;
        
        const recentComms = await base44.asServiceRole.entities.Communication.filter({
            company_id: companyId,
            contact_phone: from,
            twilio_sid: callSid
        }, '-created_date', 20);
        
        const conversationHistory = recentComms
            .reverse()
            .map(c => `${c.direction === 'inbound' ? 'Customer' : agentName}: ${c.message}`)
            .join('\n');

        // Initial greeting
        if (!speechResult) {
            console.log('🎤 Sending initial greeting');
            
            let greetingTemplate = settings.intent_templates?.greeting || "Hi! This is {agent} from {brand}. How can I help you today?";
            const greeting = greetingTemplate
                .replace(/{agent}/g, agentName)
                .replace(/{brand}/g, companyName);

            console.log(`🗣️ Greeting: "${greeting}"`);

            const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Gather input="speech" action="${escapeXml(callbackUrl)}" speechTimeout="auto" language="en-US" timeout="5" speechModel="phone_call">
        <Say voice="${safeVoiceId}">${escapeXml(greeting)}</Say>
    </Gather>
    <Say voice="${safeVoiceId}">I didn't catch that. Please call back anytime!</Say>
    <Hangup/>
</Response>`;
            
            return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });
        }
        
        
        // Process customer's message
        console.log('💬 Processing customer message...');
        
        // Emergency detection
        const emergencyKeywords = settings.escalation_keywords || [
            "emergency", "urgent", "asap", "fire", "flood", "leak", "cave", "collapse", "danger"
        ];
        
        const isEmergency = emergencyKeywords.some(keyword => 
            speechResult.toLowerCase().includes(keyword.toLowerCase())
        );
        
        // Transfer request detection
        const transferKeywords = ["talk to someone", "speak to", "real person", "human", "manager", "owner"];
        const requestsTransfer = transferKeywords.some(keyword => 
            speechResult.toLowerCase().includes(keyword.toLowerCase())
        );
        
        if (isEmergency || requestsTransfer) {
            console.log('🚨 Emergency or transfer - alerting staff');
            
            const staffProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ 
                company_id: companyId,
                is_administrator: true 
            });
            
            for (const staff of staffProfiles) {
                await base44.asServiceRole.entities.Notification.create({
                    company_id: companyId,
                    user_email: staff.user_email,
                    title: isEmergency ? '🚨 EMERGENCY CALL' : '📞 Transfer Request',
                    message: `Call from ${from}: "${speechResult}"`,
                    type: 'emergency',
                    link_url: '/LiveCallDashboard'
                });
            }
            
            if (recentComms[0]) {
                await base44.asServiceRole.entities.Communication.update(recentComms[0].id, {
                    outcome: isEmergency ? 'emergency' : 'transfer_requested',
                    intent: isEmergency ? 'emergency' : 'transfer'
                });
            }
            
            const transferMessage = isEmergency 
                ? "I understand this is urgent. I'm alerting our team right now and someone will call you back within 5 minutes."
                : "Let me connect you with someone from our team. They'll call you back shortly.";

            return new Response(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="${safeVoiceId}">${escapeXml(transferMessage)}</Say>
    <Hangup/>
</Response>`, { headers: { 'Content-Type': 'text/xml' } });
        }
        
        // Fetch Training Data (AI Memory)
        const trainingData = await base44.asServiceRole.entities.AITrainingData.filter({ 
            company_id: companyId,
            is_active: true 
        });

        let knowledgeBase = "";
        const responseSpeed = settings.response_speed || 'normal';
        
        if (trainingData.length > 0 && responseSpeed !== 'ultra_fast') {
            console.log(`🧠 Injecting ${trainingData.length} memory items`);
            knowledgeBase = "\n\n[COMPANY KNOWLEDGE BASE]\n" + trainingData
                .map(t => `SOURCE: ${t.title}\nCONTENT: ${t.content?.substring(0, 1500) || ''}`) 
                .join("\n\n");
        }

        let basePrompt = settings.system_prompt || `You are ${agentName}, a friendly AI receptionist for ${companyName}.
Keep responses SHORT - 15-20 words max for phone conversations.
Be warm, natural, and conversational.
Do not use special characters like * or #.

🔒 CRITICAL: You work for ${companyName} ONLY. Never mention external CRMs like Salesforce, HubSpot, etc. Your CRM system is called CompanySync.`;

        const assertiveness = settings.personality_assertiveness ?? 50;
        const humor = settings.personality_humor ?? 20;

        let personalityInstructions = "";
        if (assertiveness > 70) personalityInstructions += "\nBe direct, confident, and take charge of the conversation.";
        else if (assertiveness < 30) personalityInstructions += "\nBe gentle, soft-spoken, and very polite.";

        if (humor > 70) personalityInstructions += "\nBe witty and use humor where appropriate.";
        else if (humor < 30) personalityInstructions += "\nBe serious, professional, and minimize humor.";

        basePrompt += personalityInstructions;

        const fullSystemPrompt = `${basePrompt}\n${knowledgeBase}\n\nUse the Knowledge Base above to answer specific questions. If the answer isn't there, politely offer to have a human call them back.`;

        let finalHistory = conversationHistory;

        // Define CRM tools for Gemini
        const tools = [{
            functionDeclarations: [
                {
                    name: 'get_crm_data',
                    description: 'Get counts and details from CRM - customers, leads, estimates, invoices, tasks, projects, payments',
                    parameters: {
                        type: 'OBJECT',
                        properties: {
                            data_type: { 
                                type: 'STRING',
                                description: 'Type of data: customers, leads, estimates, invoices, tasks, projects, payments, staff'
                            }
                        },
                        required: ['data_type']
                    }
                },
                {
                    name: 'get_calendar_events',
                    description: 'Get calendar events for checking availability',
                    parameters: {
                        type: 'OBJECT',
                        properties: {
                            start_date: { type: 'STRING', description: 'Start date YYYY-MM-DD' },
                            end_date: { type: 'STRING', description: 'End date YYYY-MM-DD' }
                        },
                        required: ['start_date']
                    }
                },
                {
                    name: 'create_lead',
                    description: 'Create a new lead in the CRM',
                    parameters: {
                        type: 'OBJECT',
                        properties: {
                            name: { type: 'STRING' },
                            phone: { type: 'STRING' },
                            notes: { type: 'STRING' }
                        },
                        required: ['name']
                    }
                }
            ]
        }];

        // Use Gemini with tool calling
        let responseText = '';
        let toolResults = [];
        
        try {
            console.log('🤖 Calling Gemini API with CRM tools...');
            const geminiApiKey = Deno.env.get('GEMINI_API_KEY');
            
            const geminiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${geminiApiKey}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{
                        role: 'user',
                        parts: [{ text: `${fullSystemPrompt}\n\nPrevious conversation:\n${finalHistory || 'None'}\n\nCustomer said: "${speechResult}"\n\nYou can access CRM data using tools. Respond in 15-20 words max for phone conversation.` }]
                    }],
                    tools: tools,
                    generationConfig: {
                        maxOutputTokens: 60,
                        temperature: 0.7
                    }
                })
            });

            if (!geminiResponse.ok) {
                const errText = await geminiResponse.text();
                throw new Error(`Gemini API Error: ${geminiResponse.status} - ${errText}`);
            }

            const data = await geminiResponse.json();
            const firstPart = data.candidates?.[0]?.content?.parts?.[0];
            
            // Check if Gemini wants to use tools
            if (firstPart?.functionCall) {
                console.log('🔧 Gemini requested tool:', firstPart.functionCall.name);
                const toolName = firstPart.functionCall.name;
                const toolArgs = firstPart.functionCall.args || {};
                
                // Execute tool
                let toolResult = {};
                
                if (toolName === 'get_crm_data') {
                    const dataType = toolArgs.data_type;
                    if (dataType === 'customers') {
                        const customers = await base44.asServiceRole.entities.Customer.filter({ company_id: companyId }, '-created_date', 100);
                        toolResult = { count: customers.length, sample: customers.slice(0, 5).map(c => c.name) };
                    } else if (dataType === 'leads') {
                        const leads = await base44.asServiceRole.entities.Lead.filter({ company_id: companyId }, '-created_date', 100);
                        toolResult = { count: leads.length };
                    } else if (dataType === 'invoices') {
                        const invoices = await base44.asServiceRole.entities.Invoice.filter({ company_id: companyId }, '-created_date', 100);
                        toolResult = { count: invoices.length, total_revenue: invoices.reduce((sum, inv) => sum + (inv.amount || 0), 0) };
                    }
                    toolResults.push(`Retrieved ${dataType}: ${JSON.stringify(toolResult)}`);
                    
                } else if (toolName === 'get_calendar_events') {
                    const events = await base44.asServiceRole.entities.CalendarEvent.filter({ company_id: companyId }, '-start_time', 50);
                    const filtered = events.filter(e => {
                        if (!e.start_time) return false;
                        const eventDate = new Date(e.start_time).toISOString().split('T')[0];
                        return eventDate >= toolArgs.start_date && eventDate <= (toolArgs.end_date || toolArgs.start_date);
                    });
                    toolResult = { count: filtered.length, events: filtered.slice(0, 5).map(e => ({ title: e.title, start: e.start_time })) };
                    toolResults.push(`Calendar: ${filtered.length} events found`);
                    
                } else if (toolName === 'create_lead') {
                    const lead = await base44.asServiceRole.entities.Lead.create({
                        company_id: companyId,
                        name: toolArgs.name,
                        phone: toolArgs.phone || from,
                        notes: toolArgs.notes || `Lead created from call with ${agentName}`,
                        status: 'new',
                        source: 'ai',
                        lead_source: `${agentName} AI Call`
                    });
                    toolResult = { success: true, lead_id: lead.id };
                    toolResults.push(`Created lead: ${toolArgs.name}`);
                }
                
                // Call Gemini again with tool result
                const followUpResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${geminiApiKey}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [
                            {
                                role: 'user',
                                parts: [{ text: `${fullSystemPrompt}\n\nCustomer: "${speechResult}"` }]
                            },
                            {
                                role: 'model',
                                parts: [{ functionCall: firstPart.functionCall }]
                            },
                            {
                                role: 'user',
                                parts: [{ functionResponse: { name: toolName, response: toolResult } }]
                            }
                        ],
                        generationConfig: {
                            maxOutputTokens: 60,
                            temperature: 0.7
                        }
                    })
                });
                
                const followUpData = await followUpResponse.json();
                responseText = followUpData.candidates?.[0]?.content?.parts?.[0]?.text || "Got the information!";
                console.log('✅ Tool result response:', responseText);
                
            } else {
                // No tool call, just text response
                responseText = firstPart?.text || "I didn't hear you clearly, could you say that again?";
                console.log('✅ Direct response:', responseText);
            }

        } catch (aiError) {
            console.error('❌ AI error:', aiError);
            responseText = "I am having a little trouble hearing you. Could you please repeat that?";
        }
        
        // Check if scheduling is mentioned
        const calendlyUrl = settings.calendly_booking_url;
        if (calendlyUrl && /schedule|appointment|book|come out|inspect/i.test(speechResult)) {
            console.log('📅 Scheduling detected - sending SMS');
            try {
                await base44.asServiceRole.functions.invoke('sendSMS', { 
                    to: from, 
                    message: `Perfect! Book your appointment here: ${calendlyUrl}`, 
                    companyId,
                    calledFromService: true
                });
                responseText = "Just texted you the booking link! Pick any time that works for you.";
            } catch (smsErr) {
                console.error('❌ SMS failed:', smsErr);
            }
        }

        // Log conversation
        await base44.asServiceRole.entities.Communication.create({
            company_id: companyId,
            contact_phone: from,
            communication_type: 'call',
            direction: 'inbound',
            message: speechResult,
            twilio_sid: callSid,
            status: 'completed'
        });
        
        await base44.asServiceRole.entities.Communication.create({
            company_id: companyId,
            contact_phone: from,
            communication_type: 'call',
            direction: 'outbound',
            message: responseText,
            twilio_sid: callSid,
            status: 'completed'
        });

        // Detect goodbye
        const isGoodbye = /bye|goodbye|thanks|thank you|that's all|nothing else|no thanks/i.test(speechResult);
        const finalText = isGoodbye ? `${responseText} Have a great day!` : responseText;
        
        console.log('✅ Using Gemini TTS for voice response');

        // Use Gemini TTS to generate audio
        let audioUrl = null;
        try {
            const ttsResponse = await base44.asServiceRole.functions.invoke('geminiTTS', {
                text: finalText,
                assistant: 'sarah'
            });
            
            if (ttsResponse.data?.audio_url) {
                audioUrl = ttsResponse.data.audio_url;
                console.log('🔊 Gemini TTS audio generated:', audioUrl);
            }
        } catch (ttsError) {
            console.error('❌ Gemini TTS failed, falling back to Polly:', ttsError);
        }

        const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    ${isGoodbye ? `
    ${audioUrl ? `<Play>${escapeXml(audioUrl)}</Play>` : `<Say voice="${safeVoiceId}">${escapeXml(finalText)}</Say>`}
    <Hangup/>` : `
    <Gather input="speech" action="${escapeXml(callbackUrl)}" speechTimeout="auto" language="en-US" timeout="5" speechModel="phone_call">
        ${audioUrl ? `<Play>${escapeXml(audioUrl)}</Play>` : `<Say voice="${safeVoiceId}">${escapeXml(finalText)}</Say>`}
    </Gather>
    <Say voice="${safeVoiceId}">I'm sorry, I didn't hear anything. Thanks for calling ${escapeXml(companyName)}!</Say>
    <Hangup/>`}
</Response>`;

        return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });
        
    } catch (error) {
        console.error('❌ FATAL ERROR:', error.message, error.stack);
        console.error('📋 Full error:', JSON.stringify(error));
        
        // Ensure we always return valid TwiML, even on error
        const errorXml = `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="Polly.Joanna">I'm sorry, I'm having technical trouble. Please try again later.</Say><Hangup/></Response>`;
        return new Response(errorXml, { 
            status: 200,  // IMPORTANT: Return 200 so Twilio accepts the response
            headers: { 'Content-Type': 'text/xml' } 
        });
    }
});