import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import { jsPDF } from 'npm:jspdf@2.5.1';

async function fetchImageAsBase64(imageUrl) {
  try {
    console.log('📥 Fetching image:', imageUrl);
    
    const response = await fetch(imageUrl, {
      method: 'GET',
      headers: {
        'Accept': 'image/*'
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    
    if (arrayBuffer.byteLength === 0) {
      throw new Error('Image is empty (0 bytes)');
    }
    
    console.log('✅ Image fetched, size:', arrayBuffer.byteLength, 'bytes');
    
    // Convert to base64
    const bytes = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);
    
    // Detect format
    const contentType = response.headers.get('content-type') || '';
    let format = 'PNG';
    
    if (contentType.includes('jpeg') || contentType.includes('jpg') || 
        imageUrl.toLowerCase().endsWith('.jpg') || imageUrl.toLowerCase().endsWith('.jpeg')) {
      format = 'JPEG';
    }
    
    console.log('📄 Image format detected:', format, 'Content-Type:', contentType);
    
    return { base64, format };
    
  } catch (error) {
    console.error('❌ Image fetch failed:', error.message);
    return null;
  }
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { estimate, customerInfo, format, satelliteImageUrl, inspectionPhotos, returnBase64 } = await req.json();

    console.log('📋 PDF Generation Request:', {
      has_estimate: !!estimate,
      has_customerInfo: !!customerInfo,
      format_id: format?.id,
      returnBase64
    });

    if (!estimate || !estimate.line_items || estimate.line_items.length === 0) {
      return Response.json({ error: 'No estimate data provided' }, { status: 400 });
    }

    // Get user's company - check if they own it OR are a staff member
    let companies = await base44.asServiceRole.entities.Company.filter({ created_by: user.email });
    let company = companies[0];

    // If not owner, check staff profile for company
    if (!company) {
      const staffProfiles = await base44.asServiceRole.entities.StaffProfile.filter({ user_email: user.email });
      if (staffProfiles.length > 0) {
        const companyId = staffProfiles[0].company_id;
        if (companyId) {
          companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
          company = companies[0];
        }
      }
    }

    console.log('🏢 Company loaded:', {
      found: !!company,
      name: company?.company_name,
      has_logo_url: !!company?.logo_url,
      has_logo_base64: !!company?.logo_base64,
      logo_base64_length: company?.logo_base64?.length
    });

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 20;
    
    // Get color based on format color_scheme OR company branding
    const hexToRgb = (hex) => {
      const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } : { r: 30, g: 58, b: 138 };
    };
    
    // PRIORITY: Use format color_scheme, fallback to company brand color
    let headerColor;
    if (format?.color_scheme) {
      const colorMap = {
        red: { r: 220, g: 38, b: 38 },     // Red-600
        green: { r: 22, g: 163, b: 74 },   // Green-600
        blue: { r: 37, g: 99, b: 235 },    // Blue-600
        gray: { r: 75, g: 85, b: 99 }      // Gray-600
      };
      headerColor = colorMap[format.color_scheme] || colorMap.blue;
    } else {
      headerColor = company?.brand_primary_color 
        ? hexToRgb(company.brand_primary_color) 
        : { r: 30, g: 58, b: 138 };
    }
    
    const darkBlue = headerColor;
    
    let y = 20;

    // Company info starts at top
    let companyY = y;

    // Add company logo - maintaining aspect ratio
    if (company?.logo_url) {
      const logoData = await fetchImageAsBase64(company.logo_url);
      if (logoData && logoData.base64) {
        try {
          const maxLogoWidth = 35;
          const maxLogoHeight = 16;
          
          doc.addImage(
            `data:image/${logoData.format.toLowerCase()};base64,${logoData.base64}`,
            logoData.format,
            margin,
            companyY,
            maxLogoWidth,
            maxLogoHeight,
            undefined,
            'FAST'
          );
          companyY += maxLogoHeight + 4;
        } catch (error) {
          console.error('❌ Failed to add logo:', error.message);
          // Skip logo and continue
        }
      }
    }

    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.text(company?.company_name || 'Your Company', margin, companyY);
    
    companyY += 6;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 60, 60);
    
    if (company?.address) {
      doc.text(company.address, margin, companyY);
      companyY += 4.5;
    }
    if (company?.city && company?.state && company?.zip) {
      doc.text(`${company.city}, ${company.state} ${company.zip}`, margin, companyY);
      companyY += 4.5;
    }
    if (company?.phone) {
      doc.text(company.phone, margin, companyY);
      companyY += 4.5;
    }
    if (company?.email) {
      doc.text(company.email, margin, companyY);
    }

    // RIGHT SIDE: ESTIMATE Title
    y = 20;
    doc.setFontSize(32);
    doc.setTextColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.setFont('helvetica', 'bold');
    doc.text('ESTIMATE', pageWidth - margin, y, { align: 'right' });
    
    y += 8;
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.setFont('helvetica', 'normal');
    doc.text(`# ${estimate.estimate_number || 'DRAFT'}`, pageWidth - margin, y, { align: 'right' });
    
    y += 5;
    doc.setFontSize(9);
    doc.text(`DRAFT`, pageWidth - margin, y, { align: 'right' });

    // Customer Section (RIGHT SIDE)
    y = 60;
    doc.setFontSize(9);
    doc.setTextColor(80, 80, 80);
    doc.text('To', pageWidth - margin, y, { align: 'right' });
    
    y += 6;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text(customerInfo?.customer_name || 'Customer', pageWidth - margin, y, { align: 'right' });
    
    y += 6;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 60, 60);
    
    if (customerInfo?.customer_phone) {
      doc.text(customerInfo.customer_phone, pageWidth - margin, y, { align: 'right' });
      y += 4.5;
    }
    
    if (customerInfo?.customer_email) {
      doc.text(customerInfo.customer_email, pageWidth - margin, y, { align: 'right' });
      y += 4.5;
    }
    
    if (customerInfo?.property_address) {
      const addressLines = doc.splitTextToSize(customerInfo.property_address, 80);
      addressLines.forEach(line => {
        doc.text(line, pageWidth - margin, y, { align: 'right' });
        y += 4.5;
      });
    }
    
    y += 2;
    doc.text(`Estimate Date: ${new Date().toLocaleDateString('en-US')}`, pageWidth - margin, y, { align: 'right' });
    
    if (customerInfo?.claim_number) {
      y += 4.5;
      doc.text(`Claim #: ${customerInfo.claim_number}`, pageWidth - margin, y, { align: 'right' });
    }

    // Horizontal separator line before estimate details (like in preview)
    y = 95;
    doc.setDrawColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.setLineWidth(1.5);
    doc.line(margin, y, pageWidth - margin, y);
    
    // LINE ITEMS TABLE - DARK BLUE HEADER
    y = 100;
    
    // Dark blue header background with border
    doc.setFillColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.setDrawColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.setLineWidth(0.5);
    doc.rect(margin, y, pageWidth - 2 * margin, 8, 'FD');
    
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    
    const showRcvAcv = format?.show_rcv_acv !== false;
    const showDepreciation = format?.show_depreciation === true;
    const showAgeLife = format?.show_age_life === true;
    
    // Column positions - matching the new 2-line layout with shifted left columns
    const sfQtyCol = 90;
    const sfUnitCol = 105;
    const sfRateCol = 122;
    const sfRcvCol = 140;
    const sfDepCol = 155;
    const sfAcvCol = 170;
    
    // Render headers aligned with data columns
    doc.text('#', margin + 2, y + 5.5);
    doc.text('Description', margin + 10, y + 5.5);
    doc.text('Qty', sfQtyCol, y + 5.5, { align: 'right' });
    doc.text('Unit', sfUnitCol, y + 5.5, { align: 'left' });
    doc.text('Rate', sfRateCol, y + 5.5, { align: 'right' });
    
    if (showRcvAcv) {
      doc.text(format?.rcv_label || 'RCV', sfRcvCol, y + 5.5, { align: 'right' });
      if (showDepreciation || showAgeLife) {
        doc.text('Dep %', sfDepCol, y + 5.5, { align: 'right' });
      }
      doc.text(format?.acv_label || 'ACV', sfAcvCol, y + 5.5, { align: 'right' });
    } else {
      doc.text('Amount', sfAcvCol, y + 5.5, { align: 'right' });
    }

    y += 10;
    doc.setFont('helvetica', 'normal');

    let subtotal = 0;
    
    // Check if this is a State Farm format
    const isStateFarmFormat = format?.format_name?.toLowerCase().includes('state farm') || 
                              format?.insurance_company?.toLowerCase().includes('state farm');
    
    estimate.line_items.forEach((item, index) => {
      if (y > pageHeight - 40) {
        doc.addPage();
        y = 20;
      }

      // Calculate values
      const qty = parseFloat(item.quantity) || 0;
      const rate = parseFloat(item.rate) || 0;
      const rcv = parseFloat(item.rcv) || 0;
      const acv = parseFloat(item.acv) || 0;
      const amount = parseFloat(item.amount) || 0;
      
      const qtyFormatted = qty % 1 === 0 ? qty.toFixed(0) : qty.toFixed(2);

      if (isStateFarmFormat) {
        // STATE FARM LAYOUT: Description on first line, numbers on second line
        
        // Alternating row colors with border - taller for 2-line layout
        const rowHeight = 15;
        if (index % 2 === 0) {
          doc.setFillColor(250, 250, 250);
        } else {
          doc.setFillColor(255, 255, 255);
        }
        doc.setDrawColor(200, 200, 200);
        doc.setLineWidth(0.3);
        doc.rect(margin, y - 2, pageWidth - 2 * margin, rowHeight, 'FD');

        doc.setTextColor(0, 0, 0);
        doc.setFontSize(9);
        
        // First line: Item # and Description (full width)
        doc.text(String(index + 1), margin + 2, y + 4);
        
        const desc = item.description || '';
        const maxDescWidth = 160;
        const descLines = doc.splitTextToSize(desc, maxDescWidth);
        doc.text(descLines[0] || '', margin + 10, y + 4);
        
        // Second line: Numerical data - State Farm column positions (shifted left)
        const numY = y + 10;
        const sfQtyCol = 90;
        const sfUnitCol = 105;
        const sfRateCol = 122;
        const sfRcvCol = 140;
        const sfDepCol = 155;
        const sfAcvCol = 170;
        
        if (showRcvAcv) {
          doc.text(qtyFormatted, sfQtyCol, numY, { align: 'right' });
          doc.text(item.unit || 'SQ', sfUnitCol, numY, { align: 'left' });
          doc.text(`$${rate.toFixed(2)}`, sfRateCol, numY, { align: 'right' });
          doc.text(`$${rcv.toFixed(2)}`, sfRcvCol, numY, { align: 'right' });
          
          if (showAgeLife || showDepreciation) {
            const depPercent = parseFloat(item.depreciation_percent) || 0;
            doc.text(depPercent > 0 ? `${depPercent.toFixed(0)}%` : '0%', sfDepCol, numY, { align: 'right' });
          }
          
          doc.text(`$${acv.toFixed(2)}`, sfAcvCol, numY, { align: 'right' });
          subtotal += acv;
        } else {
          doc.text(qtyFormatted, sfQtyCol, numY, { align: 'right' });
          doc.text(item.unit || 'SQ', sfUnitCol, numY, { align: 'left' });
          doc.text(`$${rate.toFixed(2)}`, sfRateCol, numY, { align: 'right' });
          doc.text(`$${amount.toFixed(2)}`, sfAcvCol, numY, { align: 'right' });
          subtotal += amount;
        }

        y += 15;
        
      } else {
        // STANDARD LAYOUT: Description on first line, numbers on second line (matching State Farm)

        // Alternating row colors with border - taller for 2-line layout
        const rowHeight = 15;
        if (index % 2 === 0) {
          doc.setFillColor(250, 250, 250);
        } else {
          doc.setFillColor(255, 255, 255);
        }
        doc.setDrawColor(200, 200, 200);
        doc.setLineWidth(0.3);
        doc.rect(margin, y - 2, pageWidth - 2 * margin, rowHeight, 'FD');

        doc.setTextColor(0, 0, 0);
        doc.setFontSize(9);

        // First line: Item # and Description (full width)
        doc.text(String(index + 1), margin + 2, y + 4);

        const desc = item.description || '';
        const maxDescWidth = 160;
        const descLines = doc.splitTextToSize(desc, maxDescWidth);
        doc.text(descLines[0] || '', margin + 10, y + 4);

        // Second line: Numerical data - shifted left columns
        const numY = y + 10;
        const sfQtyCol = 90;
        const sfUnitCol = 105;
        const sfRateCol = 122;
        const sfRcvCol = 140;
        const sfDepCol = 155;
        const sfAcvCol = 170;

        if (showRcvAcv) {
          doc.text(qtyFormatted, sfQtyCol, numY, { align: 'right' });
          doc.text(item.unit || 'EA', sfUnitCol, numY, { align: 'left' });
          doc.text(`$${rate.toFixed(2)}`, sfRateCol, numY, { align: 'right' });
          doc.text(`$${rcv.toFixed(2)}`, sfRcvCol, numY, { align: 'right' });

          if (showAgeLife || showDepreciation) {
            const depPercent = parseFloat(item.depreciation_percent) || 0;
            doc.text(depPercent > 0 ? `${depPercent.toFixed(0)}%` : '0%', sfDepCol, numY, { align: 'right' });
          }

          doc.text(`$${acv.toFixed(2)}`, sfAcvCol, numY, { align: 'right' });
          subtotal += acv;
        } else {
          doc.text(qtyFormatted, sfQtyCol, numY, { align: 'right' });
          doc.text(item.unit || 'EA', sfUnitCol, numY, { align: 'left' });
          doc.text(`$${rate.toFixed(2)}`, sfRateCol, numY, { align: 'right' });
          doc.text(`$${amount.toFixed(2)}`, sfAcvCol, numY, { align: 'right' });
          subtotal += amount;
        }

        y += 15;
      }
      
      // Add long_description (building code details) if present
      if (item.long_description && item.long_description.trim()) {
        if (y > pageHeight - 40) {
          doc.addPage();
          y = 20;
        }
        
        doc.setFontSize(7);
        doc.setFont('helvetica', 'italic');
        doc.setTextColor(80, 80, 80);
        
        const longDescLines = doc.splitTextToSize(item.long_description, pageWidth - 2 * margin - 24);
        longDescLines.forEach(line => {
          if (y > pageHeight - 25) {
            doc.addPage();
            y = 20;
          }
          doc.text(line, margin + 24, y);
          y += 3.5;
        });
        
        y += 2;
        doc.setFont('helvetica', 'normal');
      }
    });

    // Totals section - ensure we don't overflow page
    if (y > pageHeight - 60) {
      doc.addPage();
      y = 20;
    }
    
    y += 8;
    
    // SUBTOTAL ROW with colored background and border
    const totalsRowHeight = 8;
    doc.setFillColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.setDrawColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.setLineWidth(0.5);
    doc.rect(margin, y - 2, pageWidth - 2 * margin, totalsRowHeight, 'FD');
    
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('SUBTOTAL:', 100, y + 4);
    doc.text(`$${subtotal.toFixed(2)}`, 190, y + 4, { align: 'right' });
    
    y += totalsRowHeight + 6;
    
    // TOTAL ROW with colored background and border
    doc.setFillColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.setDrawColor(darkBlue.r, darkBlue.g, darkBlue.b);
    doc.rect(margin, y - 2, pageWidth - 2 * margin, totalsRowHeight, 'FD');
    
    doc.setFontSize(14);
    doc.setTextColor(255, 255, 255);
    doc.text('TOTAL:', 100, y + 4);
    doc.text(`$${subtotal.toFixed(2)}`, 190, y + 4, { align: 'right' });

    y += 15;

    // Notes/Terms section
    if (customerInfo?.notes || company?.pdf_terms_conditions) {
      if (y > pageHeight - 50) {
        doc.addPage();
        y = 20;
      }
      
      doc.setFontSize(11);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(0, 0, 0);
      doc.text('Note:', margin, y);
      
      y += 6;
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(60, 60, 60);
      
      const notesText = customerInfo?.notes || company?.pdf_terms_conditions || '';
      const notesLines = doc.splitTextToSize(notesText, pageWidth - 2 * margin);
      
      notesLines.forEach(line => {
        if (y > pageHeight - 25) {
          doc.addPage();
          y = 20;
        }
        doc.text(line, margin, y);
        y += 4.5;
      });
    }

    // DISCLAIMER PAGE
    doc.addPage();
    y = 20;
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text('NOTE:', margin, y);
    
    y += 6;
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(40, 40, 40);
    
    const disclaimerText = `This price is only valid for 30 days from estimate date, and is based on a deposit of half down upon acceptance of estimate and the remaining half due upon completion of work.

The estimate is hereby based on seen, disclosed, or otherwise obvious damage. The repair of the covered loss may be higher than these figures because of other circumstances not yet discovered. Included in this estimate are the items that the Contractor believes necessary to return the property to pre loss condition.

Unseen, undisclosed, or otherwise not obvious conditions, if discovered later or during the course of repairs, will be considered not included.

If discovered, any necessary additional repairs will be submitted for supplemental coverage, based on current market pricing.

Terms & Conditions:

The following estimate is only an approximation of the damages suffered, or expenses incurred, by the insured. No warranty or representation with regard to the accuracy of the estimate is expressed or implied and none should be inferred. The actual damages suffered, or expenses incurred, could be higher or lower than the estimate, even significantly, depending on variances in a number of factors affecting the estimate and the accuracy of the information and assumptions upon which the estimate is based. The estimate is based upon, among other things: information provided to us by the insured; our own observations; measurements taken by our own representatives, the insured and others engaged by the insured; as well as certain assumptions made by us.

Many factors may effect the amount of the estimate where compensation has already been received by the insured for the damage, and with regard to which payment we were not informed; the cost of one contractor varying from another contractor as a result of a number of factors, including, without limitation, the quality of the work, the quality of the materials, or warranties provided by such contractors; damages that were not observed at the time the estimate was rendered because of a lack of accessibility or weather; and all other factors beyond our reasonable control.

Due to rapidly changing material and labor costs, the Insured retains the right to supplement or amend any part of this estimate at a later date should new information comes to light.

This estimate has been calculated for informational purposes only, and is based upon our good faith belief as the damages suffered or expenses incurred as a result of the particular loss, and only represents one opinion as to the method of repair, restoration, or replacement.

Any reliance on the estimate is at your own risk and you agree to hold ${company?.company_name || 'Your Insurance Claims Network'}, its representatives, employees, agents, officers, and principals harmless in the event of such reliance.`;

    const disclaimerLines = doc.splitTextToSize(disclaimerText, pageWidth - 2 * margin);
    
    disclaimerLines.forEach(line => {
      if (y > pageHeight - 25) {
        doc.addPage();
        y = 20;
      }
      doc.text(line, margin, y);
      y += 4;
    });
    
    // Contact info at bottom
    y += 6;
    if (y > pageHeight - 40) {
      doc.addPage();
      y = 20;
    }
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(user?.full_name || 'Production Manager', margin, y);
    y += 5;
    
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    if (company?.address) {
      doc.text(company.address, margin, y);
      y += 4;
    }
    if (company?.city && company?.state && company?.zip) {
      doc.text(`${company.city}, ${company.state} ${company.zip}`, margin, y);
    }

    // Inspection photos section - SKIP to avoid timeout
    // Photos removed to ensure fast PDF generation

    // Footer on all pages
    const totalPages = doc.internal.pages.length - 1;
    
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(150, 150, 150);
      
      const footerText = company?.pdf_footer_text || 'Thank you for your business!';
      doc.text(footerText, pageWidth / 2, pageHeight - 15, { align: 'center' });
      
      doc.text(`${i}/${totalPages}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
    }

    if (returnBase64) {
      const pdfBase64 = doc.output('datauristring').split(',')[1];
      return Response.json({ base64: pdfBase64 });
    }

    const pdfBytes = doc.output('arraybuffer');

    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=estimate-${customerInfo?.customer_name || 'draft'}.pdf`
      }
    });

  } catch (error) {
    console.error('PDF generation error:', error);
    return Response.json({ 
      error: error.message,
      details: error.stack 
    }, { status: 500 });
  }
});