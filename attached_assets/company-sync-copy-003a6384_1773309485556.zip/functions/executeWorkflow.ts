import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import { Resend } from 'npm:resend@4.0.0';
import { sendSMSInternal } from './utils/smsSender.js';

// Helper function to calculate next recurrence
function calculateNextRecurrence(fromDate, pattern) {
  const next = new Date(fromDate);
  const timeOfDay = pattern.time_of_day || '09:00';
  const [hours, minutes] = timeOfDay.split(':').map(Number);

  switch (pattern.frequency) {
    case 'daily': {
      next.setDate(next.getDate() + (pattern.interval || 1));
      break;
    }

    case 'weekly': {
      const targetDays = pattern.days_of_week || [1];
      const currentDay = next.getDay();
      let daysToAdd = targetDays.find(d => d > currentDay) - currentDay;
      
      if (daysToAdd <= 0) {
        daysToAdd = (7 - currentDay) + targetDays[0];
      }
      
      next.setDate(next.getDate() + daysToAdd);
      break;
    }

    case 'monthly': {
      const targetDay = pattern.day_of_month || 1;
      next.setMonth(next.getMonth() + (pattern.interval || 1));
      next.setDate(Math.min(targetDay, new Date(next.getFullYear(), next.getMonth() + 1, 0).getDate()));
      break;
    }

    case 'yearly': {
      next.setFullYear(next.getFullYear() + (pattern.interval || 1));
      break;
    }
  }

  next.setHours(hours, minutes, 0, 0);
  return next;
}

function replaceVariables(text, data) {
  if (!text) return text;
  
  let result = text;
  
  // Normalize all field names from different entities
  const normalizedEmail = data?.customer_email || data?.contact_email || data?.email || data?.lead_email || '';
  const normalizedPhone = data?.customer_phone || data?.contact_phone || data?.phone || data?.lead_phone || '';
  const normalizedName = data?.customer_name || data?.contact_name || data?.lead_name || data?.name || 'Customer';
  const normalizedAddress = data?.address || data?.property_address || data?.street || '';
  
  const varMap = {
    '{contact_name}': normalizedName,
    '{customer_name}': normalizedName,
    '{lead_name}': normalizedName,
    '{name}': normalizedName,
    '{contact_email}': normalizedEmail,
    '{customer_email}': normalizedEmail,
    '{lead_email}': normalizedEmail,
    '{email}': normalizedEmail,
    '{contact_phone}': normalizedPhone,
    '{customer_phone}': normalizedPhone,
    '{lead_phone}': normalizedPhone,
    '{phone}': normalizedPhone,
    '{address}': normalizedAddress,
    '{property_address}': normalizedAddress,
    '{company_name}': data?.company_name || 'Our Company',
    '{estimate_number}': data?.estimate_number || '',
    '{invoice_number}': data?.invoice_number || '',
    '{project_name}': data?.project_name || '',
    '{proposal_number}': data?.proposal_number || '',
    '{task_name}': data?.task_name || data?.name || '',
    '{payment_amount}': data?.payment_amount || data?.amount || '',
    '{amount}': data?.amount || data?.payment_amount || '',
    '{status}': data?.status || '',
    '{source}': data?.source || data?.lead_source || '',
    '{assigned_to}': data?.assigned_to || '',
    '{assigned_to_name}': data?.assigned_to_name || '',
    '{created_by}': data?.created_by || '',
    '{app_url}': data?.app_url || 'https://ai-crm-pro.10afd77e.base44.app',
  };

  for (const [placeholder, value] of Object.entries(varMap)) {
    result = result.replace(new RegExp(placeholder.replace(/[{}]/g, '\\$&'), 'g'), value);
  }

  return result;
}

async function sendNotification(base44, action, entityData, workflowCompanyId) {
  try {
    const title = replaceVariables(action.notification_title || 'Notification', entityData);
    const message = replaceVariables(action.notification_message || '', entityData);
    
    let recipientEmail = action.recipient;
    
    if (recipientEmail === 'lead' || recipientEmail === 'customer') {
      recipientEmail = entityData.contact_email || entityData.customer_email || entityData.email;
    }
    
    if (!recipientEmail) {
      console.warn('⚠️ No recipient email for notification');
      return;
    }

    await base44.asServiceRole.entities.Notification.create({
      company_id: workflowCompanyId,
      user_email: recipientEmail,
      title: title,
      message: message,
      type: 'general',
      is_read: false
    });

    console.log('✅ Notification created for:', recipientEmail);
  } catch (error) {
    console.error('❌ Failed to create notification:', error);
    throw error;
  }
}

async function createTask(base44, action, entityData, workflowCompanyId) {
  try {
    const title = replaceVariables(action.task_title || 'Task', entityData);
    const description = replaceVariables(action.task_description || '', entityData);

    await base44.asServiceRole.entities.Task.create({
      company_id: workflowCompanyId,
      name: title,
      description: description,
      status: 'not_started',
      related_to: entityData.contact_name || entityData.customer_name || entityData.name
    });

    console.log('✅ Task created:', title);
  } catch (error) {
    console.error('❌ Failed to create task:', error);
    throw error;
  }
}

async function sendSMS(base44, action, entityData, workflowCompanyId) {
  try {
    let recipient = action.recipient;
    
    if (recipient === 'lead' || recipient === 'customer') {
      recipient = entityData.contact_phone || entityData.customer_phone || entityData.phone;
    }
    
    if (!recipient) {
      console.warn('⚠️ No phone number for SMS');
      return;
    }

    const message = replaceVariables(action.sms_message || '', entityData);

    const smsResult = await sendSMSInternal(base44, {
      to: recipient,
      body: message,
      contactName: entityData.contact_name || entityData.customer_name || entityData.name,
      companyId: workflowCompanyId,
      userEmail: 'workflow'
    });

    if (smsResult.success) {
      console.log('✅ SMS sent to:', recipient);
    }
  } catch (error) {
    console.error('❌ Failed to send SMS:', error);
    throw error;
  }
}

async function sendEmail(base44, action, entityData, workflowCompanyId) {
  try {
    console.log('📧 sendEmail started');
    console.log('   → Action recipient field:', action.recipient);
    console.log('   → Entity data keys:', Object.keys(entityData));
    console.log('   → customer_email:', entityData.customer_email);
    console.log('   → contact_email:', entityData.contact_email);
    console.log('   → email:', entityData.email);
    
    let recipients = [];
    
    // Support comma-separated recipients
    const recipientField = action.recipient || '';
    const recipientList = recipientField.split(',').map(r => r.trim()).filter(r => r);
    
    for (const recipient of recipientList) {
      // If recipient is 'customer' or 'lead', resolve the email from entity data
      if (recipient === 'lead' || recipient === 'customer') {
        const resolvedEmail = entityData.email || entityData.customer_email || entityData.contact_email || entityData.lead_email;
        console.log('   → Resolving customer/lead email:', resolvedEmail);
        if (resolvedEmail && resolvedEmail.includes('@')) {
          recipients.push(resolvedEmail);
        } else {
          console.warn(`   ⚠️ No email found for ${recipient} in entity data`);
        }
      } else if (recipient.includes('@')) {
        // Check notification preferences before adding staff/admin
        try {
          const prefs = await base44.asServiceRole.entities.NotificationPreference.filter({ 
            user_email: recipient,
            company_id: workflowCompanyId 
          });
          const userPref = prefs[0];
          
          if (userPref?.mute_all_notifications) {
            console.log(`⏭️ Skipping ${recipient} - notifications muted`);
            continue;
          }
          
          // Check if this is their own action
          const createdBy = entityData.created_by || entityData.assigned_to;
          const isOwnAction = createdBy === recipient;
          
          // Check specific preferences
          const triggerType = entityData.trigger_type || '';
          if (triggerType.includes('lead_created') && userPref?.notify_on_lead_created === false) {
            console.log(`⏭️ Skipping ${recipient} - lead notifications disabled`);
            continue;
          }
          if (triggerType.includes('lead_created') && isOwnAction && userPref?.notify_on_lead_created_by_others_only) {
            console.log(`⏭️ Skipping ${recipient} - own lead creation`);
            continue;
          }
          if (triggerType.includes('customer_created') && userPref?.notify_on_customer_created === false) {
            console.log(`⏭️ Skipping ${recipient} - customer notifications disabled`);
            continue;
          }
          if (triggerType.includes('customer_created') && isOwnAction && userPref?.notify_on_customer_created_by_others_only) {
            console.log(`⏭️ Skipping ${recipient} - own customer creation`);
            continue;
          }
        } catch (e) {
          console.log('⚠️ Could not check notification preferences:', e.message);
        }
        
        recipients.push(recipient);
      }
    }
    
    console.log('   → Resolved recipients after filtering:', recipients);
    
    // CRITICAL: If no valid recipients found, throw detailed error
    if (recipients.length === 0) {
      const errorMsg = `❌ NO EMAIL ADDRESSES FOUND!\n` +
        `   Recipient field: "${action.recipient}"\n` +
        `   Checked: customer_email, contact_email, email, lead_email\n` +
        `   Entity data: ${JSON.stringify(entityData, null, 2)}\n` +
        `   💡 TIP: Use actual emails (e.g., yicnteam@gmail.com, sis@example.com) or comma-separated list`;
      console.error(errorMsg);
      throw new Error(errorMsg);
    }

    const subject = replaceVariables(action.email_subject || 'Notification', entityData);
    const body = replaceVariables(action.email_body || '', entityData);
    
    console.log('✅ Email details ready');
    console.log('   → To:', recipients);
    console.log('   → Subject:', subject);

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    if (!RESEND_API_KEY) {
      console.error('❌ RESEND_API_KEY not configured in environment variables');
      throw new Error('RESEND_API_KEY not configured');
    }

    console.log('✅ RESEND_API_KEY found');
    const resend = new Resend(RESEND_API_KEY);

    let company = null;
    if (workflowCompanyId) {
      const companies = await base44.asServiceRole.entities.Company.filter({ id: workflowCompanyId });
      company = companies[0];
      console.log('   → Company found:', company?.company_name);
    }

    const fromName = company?.company_name || 'AI CRM Pro';
    const fromEmail = `noreply@mycrewcam.com`;

    console.log('📤 Attempting to send email via Resend...');
    console.log('   → From:', fromEmail);
    console.log('   → To:', recipients);
    console.log('   → Subject:', subject);

    const result = await resend.emails.send({
      from: fromEmail,
      to: recipients,
      subject: subject,
      html: body
    });

    if (result.error) {
      console.error('❌ Resend API returned error:', result.error);
      throw new Error(`Resend error: ${JSON.stringify(result.error)}`);
    }

    console.log('✅ Email sent successfully via Resend!');
    console.log('   → Resend ID:', result.data?.id);
    console.log('   → Recipients:', recipients);
    
    return {
      success: true,
      recipients: recipients,
      subject: subject,
      resendId: result.data?.id
    };

  } catch (error) {
    console.error('❌ Failed to send email:', error);
    console.error('   → Error details:', error.message);
    console.error('   → Stack:', error.stack);
    throw error;
  }
}

async function executeAction(base44, action, entityData, workflowCompanyId) {
  console.log(`📌 Executing action: ${action.action_type} (Step ${action.step})`);

  const actionType = action.action_type || action.type;
  switch (actionType) {
    case 'send_email': {
      const emailResult = await sendEmail(base44, action, entityData, workflowCompanyId);
      console.log('📧 Email result:', emailResult);
      return emailResult;
    }
    case 'send_sms':
      await sendSMS(base44, action, entityData, workflowCompanyId);
      break;
    case 'create_task':
      await createTask(base44, action, entityData, workflowCompanyId);
      break;
    case 'send_notification':
      await sendNotification(base44, action, entityData, workflowCompanyId);
      break;
    case 'wait':
      console.log('⏳ Wait action (handled by scheduling)');
      break;
    default:
      console.warn(`⚠️ Unknown action type: ${action.action_type}`);
  }
}

async function executeWorkflowInstance(base44, workflow, entityData) {
  console.log(`🚀 Starting workflow: ${workflow.workflow_name}`);
  console.log('📦 Entity data received:', JSON.stringify(entityData, null, 2));
  console.log('📋 Workflow actions:', JSON.stringify(workflow.actions, null, 2));

  const workflowCompanyId = workflow.company_id;

  // 🔥 FIX: Use "actions" field (new format) OR "steps" field (legacy format)
  const allActions = workflow.actions || workflow.steps || [];
  console.log(`📋 Total actions in workflow: ${allActions.length}`);

  // Execute immediate actions (delay_minutes = 0)
  const immediateActions = allActions.filter(a => (a.delay_minutes || a.config?.delay_minutes || 0) === 0);
  console.log(`⚡ Found ${immediateActions.length} immediate actions to execute`);
  const results = [];
  
  for (const action of immediateActions) {
    try {
      const result = await executeAction(base44, action, entityData, workflowCompanyId);
      results.push({ step: action.step, success: true, result });
      console.log(`✅ Step ${action.step} completed:`, result);
    } catch (error) {
      results.push({ step: action.step, success: false, error: error.message });
      console.error(`❌ Step ${action.step} FAILED:`, error.message);
    }
  }
  
  console.log('📊 Workflow execution summary:', results);

  // Schedule delayed/future actions
  const remainingActions = allActions.filter(a => !immediateActions.includes(a));
  if (remainingActions.length > 0) {
    const nextAction = remainingActions[0];
    let nextActionTime = null;
    let status = 'active';
    let waitingForEvent = null;
    let triggerTimeout = null;
    let recurringSchedule = null;

    // Calculate next action time based on schedule type
    switch (nextAction.schedule_type) {
      case 'specific_time': {
        if (nextAction.specific_datetime) {
          nextActionTime = new Date(nextAction.specific_datetime);
        }
        break;
      }

      case 'recurring': {
        if (nextAction.recurring_pattern) {
          const pattern = nextAction.recurring_pattern;
          const now = new Date();
          const nextOccurrence = calculateNextRecurrence(now, pattern);
          
          nextActionTime = nextOccurrence;
          recurringSchedule = {
            next_occurrence: nextOccurrence.toISOString(),
            occurrences_count: 0,
            last_occurrence: null
          };
        }
        break;
      }

      case 'trigger_based': {
        if (nextAction.trigger_condition) {
          status = 'waiting_for_trigger';
          waitingForEvent = nextAction.trigger_condition.wait_for_event;
          
          // Set timeout if specified
          if (nextAction.trigger_condition.timeout_minutes) {
            triggerTimeout = new Date(Date.now() + nextAction.trigger_condition.timeout_minutes * 60 * 1000);
          }
        }
        break;
      }

      case 'delay':
      default: {
        const delayMinutes = nextAction.delay_minutes || 0;
        nextActionTime = new Date(Date.now() + delayMinutes * 60 * 1000);
        break;
      }
    }

    await base44.asServiceRole.entities.WorkflowExecution.create({
      company_id: workflowCompanyId,
      workflow_id: workflow.id,
      workflow_name: workflow.workflow_name,
      entity_type: entityData.entity_type || 'Unknown',
      entity_id: entityData.entity_id || 'unknown',
      entity_name: entityData.contact_name || entityData.customer_name || entityData.name || 'Unknown',
      entity_data: entityData,
      current_step: immediateActions.length,
      status: status,
      next_action_time: nextActionTime ? nextActionTime.toISOString() : null,
      waiting_for_event: waitingForEvent,
      trigger_timeout: triggerTimeout ? triggerTimeout.toISOString() : null,
      recurring_schedule: recurringSchedule,
      completed_steps: immediateActions.map(a => a.step),
      execution_log: [
        {
          step: 0,
          action: 'workflow_started',
          timestamp: new Date().toISOString(),
          success: true,
          message: `Workflow execution started. Next action: ${nextAction.schedule_type || 'delay'}`
        }
      ]
    });

    console.log(`⏰ Scheduled next action (${nextAction.schedule_type || 'delay'}) at ${nextActionTime ? nextActionTime.toISOString() : 'awaiting trigger'}`);
  }

  // Update workflow execution count
  await base44.asServiceRole.entities.Workflow.update(workflow.id, {
    execution_count: (workflow.execution_count || 0) + 1,
    last_executed: new Date().toISOString()
  });

  // 📱 Send SMS notification to admins when workflow starts
  try {
    const companies = await base44.asServiceRole.entities.Company.filter({ id: workflowCompanyId });
    const company = companies[0];
    const allStaff = await base44.asServiceRole.entities.StaffProfile.filter({ company_id: workflowCompanyId });
    const admins = allStaff.filter(s => s.is_administrator && s.phone_number);

    for (const admin of admins) {
      try {
        await base44.asServiceRole.functions.invoke('sendSMS', {
          to: admin.phone_number,
          message: `🔄 Workflow Started: "${workflow.workflow_name}" for ${entityData.contact_name || entityData.customer_name || entityData.name || 'entity'}`,
          contactName: admin.full_name,
          companyId: workflowCompanyId,
          calledFromService: true
        });
        console.log(`📱 Workflow start SMS sent to admin: ${admin.user_email}`);
      } catch (smsError) {
        console.error(`Failed to send SMS to ${admin.user_email}:`, smsError);
      }
    }
  } catch (error) {
    console.error('Failed to send workflow start SMS:', error);
  }

  console.log('✅ Workflow execution completed');
}

Deno.serve(async (req) => {
  try {
    console.log('🔄 executeWorkflow function started');

    const base44 = createClientFromRequest(req);
    
    // Service role for workflow execution
    const body = await req.json();
    console.log('📦 Received body:', JSON.stringify(body, null, 2));
    
    const { workflow_id, workflowId, entity_data, entityData, entity_type, entity_id } = body;
    const finalWorkflowId = workflow_id || workflowId;
    
    // Merge top-level entity info if present
    const finalEntityData = {
      ...(entity_data || entityData || {}),
      entity_type: (entity_data?.entity_type || entityData?.entity_type || entity_type),
      entity_id: (entity_data?.entity_id || entityData?.entity_id || entity_id)
    };

    if (!finalWorkflowId) {
      console.error('❌ No workflow_id provided');
      return Response.json({ error: 'Workflow ID required' }, { status: 400 });
    }

    console.log('🔍 Looking up workflow:', finalWorkflowId);
    const workflows = await base44.asServiceRole.entities.Workflow.filter({ id: finalWorkflowId });
    
    if (!workflows || workflows.length === 0) {
      return Response.json({ error: 'Workflow not found' }, { status: 404 });
    }

    const workflow = workflows[0];

    if (!workflow.is_active) {
      return Response.json({ error: 'Workflow is not active' }, { status: 400 });
    }

    await executeWorkflowInstance(base44, workflow, finalEntityData);

    return Response.json({ 
      success: true, 
      message: 'Workflow executed successfully',
      workflowName: workflow.workflow_name,
      actionsExecuted: (workflow.actions || workflow.steps || []).length
    });

  } catch (error) {
    console.error('💥 ERROR in executeWorkflow:', error);
    return Response.json({ 
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});