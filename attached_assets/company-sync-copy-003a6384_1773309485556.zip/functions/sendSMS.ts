import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { sendSMSInternal } from './utils/smsSender.js';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        const payload = await req.json();
        let user = null;

        // Allow bypassing auth if trusted flag is present (for internal system calls)
        if (!payload.calledFromService) {
            user = await base44.auth.me();
            if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

            // 🔒 SECURITY CHECK: Ensure user has access to the requested companyId
            if (payload.companyId) {
                // Allow YICN Team (Super Admin) to impersonate anyone
                const isSuperAdmin = user.email === 'yicnteam@gmail.com'; 
                
                if (!isSuperAdmin) {
                    // Check if user owns the company
                    const company = await base44.asServiceRole.entities.Company.filter({ id: payload.companyId });
                    const isOwner = company.length > 0 && company[0].created_by === user.email;

                    // Check if user is staff of the company
                    const staff = await base44.asServiceRole.entities.StaffProfile.filter({ 
                        user_email: user.email, 
                        company_id: payload.companyId 
                    });
                    const isStaff = staff.length > 0;

                    if (!isOwner && !isStaff) {
                        console.error(`⛔ ACCESS DENIED: User ${user.email} tried to send SMS for company ${payload.companyId}`);
                        return Response.json({ error: 'Forbidden: You do not have access to this company.' }, { status: 403 });
                    }
                }
            }
        }

        const { to, companyId, contactName } = payload;
        const body = payload.body || payload.message;

        const result = await sendSMSInternal(base44, {
            to,
            body,
            companyId,
            contactName,
            userEmail: user?.email
        });

        return Response.json(result);

    } catch (error) {
        console.error('SMS Error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});