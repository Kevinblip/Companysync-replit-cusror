import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  const debugLogs = [];
  
  try {
    debugLogs.push('🛰️ Function started');
    
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    debugLogs.push(`✅ User authenticated: ${user.email}`);

    const { latitude, longitude, address } = await req.json();

    if (!latitude || !longitude) {
      return Response.json({ 
        success: false, 
        error: 'Latitude and longitude are required' 
      }, { status: 400 });
    }

    debugLogs.push(`📍 Analyzing EXACT coordinates: ${address} (${latitude}, ${longitude})`);

    const googleApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!googleApiKey) {
      return Response.json({ 
        success: false, 
        error: 'Google Maps API key not configured. Please add GOOGLE_MAPS_API_KEY in Settings → Secrets.',
        debug_logs: debugLogs
      }, { status: 500 });
    }

    debugLogs.push('✅ Google API key found');

    // Generate satellite image URL with marker at EXACT location
    const satelliteImageUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${latitude},${longitude}&zoom=20&size=800x600&maptype=satellite&markers=color:red%7C${latitude},${longitude}&key=${googleApiKey}`;
    debugLogs.push('📸 Generated satellite image URL for EXACT coordinates');

    // Call Google Solar API with EXACT coordinates (not findClosest)
    // Using requiredQuality=HIGH to force precise location
    const solarApiUrl = `https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=${latitude}&location.longitude=${longitude}&requiredQuality=HIGH&key=${googleApiKey}`;
    
    debugLogs.push(`🌐 Calling Google Solar API for EXACT building at (${latitude}, ${longitude})...`);
    
    const response = await fetch(solarApiUrl);
    
    debugLogs.push(`📡 Solar API Response Status: ${response.status}`);
    
    let effectiveResponse = response;
    if (!response.ok) {
      const errorText = await response.text();
      debugLogs.push(`❌ Solar API Error (HIGH): ${errorText}`);

      // Retry with MEDIUM quality
      const retryMediumUrl = `https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=${latitude}&location.longitude=${longitude}&requiredQuality=MEDIUM&key=${googleApiKey}`;
      debugLogs.push('🔁 Retrying Solar API with MEDIUM quality...');
      const mediumResp = await fetch(retryMediumUrl);
      debugLogs.push(`📡 Solar API Response Status (MEDIUM): ${mediumResp.status}`);

      if (mediumResp.ok) {
        effectiveResponse = mediumResp;
      } else {
        const mediumErr = await mediumResp.text();
        debugLogs.push(`❌ Solar API Error (MEDIUM): ${mediumErr}`);

        // Retry without requiredQuality
        const retryAnyUrl = `https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=${latitude}&location.longitude=${longitude}&key=${googleApiKey}`;
        debugLogs.push('🔁 Retrying Solar API without requiredQuality...');
        const anyResp = await fetch(retryAnyUrl);
        debugLogs.push(`📡 Solar API Response Status (ANY): ${anyResp.status}`);

        if (anyResp.ok) {
          effectiveResponse = anyResp;
        } else {
          const anyErr = await anyResp.text();
          debugLogs.push(`❌ Solar API Error (ANY): ${anyErr}`);

          // If Solar API fails in all retries, use estimated measurements as fallback
          debugLogs.push('⚠️ Solar API failed after retries - using small-building estimate');

          // Estimate based on typical garage/shed (500-800 sq ft)
          const estimatedAreaSqFt = 600;
          const roofAreaSquares = 6; // 6 squares

          const sqrtArea = Math.sqrt(estimatedAreaSqFt);
          const ridgeLf = Math.round(sqrtArea * 0.8);
          const valleyLf = Math.round(sqrtArea * 0.2);
          const rakeLf = Math.round(sqrtArea * 1.8);
          const eaveLf = Math.round(sqrtArea * 2.2);
          const stepFlashingLf = Math.round(sqrtArea * 0.4);

          return Response.json({
            success: true,
            roof_area_sq: roofAreaSquares,
            roof_area_sqft: estimatedAreaSqFt,
            ridge_lf: ridgeLf,
            hip_lf: 0,
            valley_lf: valleyLf,
            rake_lf: rakeLf,
            eave_lf: eaveLf,
            step_flashing_lf: stepFlashingLf,
            pitch: "6/12",
            satellite_image_url: satelliteImageUrl,
            overall_confidence: 40,
            ridge_confidence: 40,
            hip_confidence: 40,
            valley_confidence: 40,
            rake_confidence: 40,
            eave_confidence: 40,
            step_flashing_confidence: 40,
            analysis_notes: `⚠️ Google Solar API couldn't detect building near coordinates (${latitude}, ${longitude}). Using estimated ${roofAreaSquares} SQ for typical small structure. For accuracy, use Manual Drawing mode or upload inspection photos.`,
            debug_logs: debugLogs,
            fallback_used: true
          });
        }
      }
    }

    const solarData = await (effectiveResponse || response).json();
    debugLogs.push('✅ Parsed Solar API response');

    // Log which building was detected
    if (solarData.center) {
      debugLogs.push(`📍 Solar API detected building at: ${solarData.center.latitude}, ${solarData.center.longitude}`);
    }

    // Extract roof data
    const roofSegments = solarData.solarPotential?.roofSegmentStats || [];
    debugLogs.push(`📊 Found ${roofSegments.length} roof segments`);
    
    if (roofSegments.length === 0) {
      debugLogs.push('⚠️ No roof segments found in Solar API data');
      
      // Fallback to estimated measurements for garage/shed
      const estimatedAreaSqFt = 600;
      const roofAreaSquares = 6;
      
      const sqrtArea = Math.sqrt(estimatedAreaSqFt);
      const ridgeLf = Math.round(sqrtArea * 0.8);
      const valleyLf = Math.round(sqrtArea * 0.2);
      const rakeLf = Math.round(sqrtArea * 1.8);
      const eaveLf = Math.round(sqrtArea * 2.2);
      const stepFlashingLf = Math.round(sqrtArea * 0.4);
      
      return Response.json({
        success: true,
        roof_area_sq: roofAreaSquares,
        roof_area_sqft: estimatedAreaSqFt,
        ridge_lf: ridgeLf,
        hip_lf: 0,
        valley_lf: valleyLf,
        rake_lf: rakeLf,
        eave_lf: eaveLf,
        step_flashing_lf: stepFlashingLf,
        pitch: "6/12",
        satellite_image_url: satelliteImageUrl,
        overall_confidence: 40,
        ridge_confidence: 40,
        hip_confidence: 40,
        valley_confidence: 40,
        rake_confidence: 40,
        eave_confidence: 40,
        step_flashing_confidence: 40,
        analysis_notes: `⚠️ No detailed roof data available. Using estimated measurements. For accurate garage/shed measurements, use Manual Drawing mode.`,
        debug_logs: debugLogs,
        fallback_used: true
      });
    }
    
    // Calculate total roof area in square feet
    let totalAreaSqFt = 0;
    const wholeAreaM2 = solarData.solarPotential?.wholeRoofStats?.areaMeters2;
    const usedWhole = !!(wholeAreaM2 && wholeAreaM2 > 0);
    if (usedWhole) {
      totalAreaSqFt = wholeAreaM2 * 10.764;
      debugLogs.push(`📗 Total area (wholeRoofStats): ${totalAreaSqFt.toFixed(2)} sq ft`);
    }
    roofSegments.forEach(segment => {
      const areaMeters = segment.stats?.areaMeters2 || 0;
      if (!usedWhole) { totalAreaSqFt += areaMeters * 10.764; } // Convert m² to ft²
    });

    debugLogs.push(`📐 Total area: ${totalAreaSqFt.toFixed(2)} sq ft`);

    // Convert to roofing squares
    const roofAreaSquares = Math.round((totalAreaSqFt / 100) * 100) / 100;

    debugLogs.push(`📦 Roof squares: ${roofAreaSquares} SQ`);

    // Estimate linear measurements
    const sqrtArea = Math.sqrt(totalAreaSqFt);
    const ridgeLf = Math.round(sqrtArea * 0.8);
    const hipLf = 0;
    const valleyLf = Math.round(sqrtArea * 0.3);
    const rakeLf = Math.round(sqrtArea * 1.8);
    const eaveLf = Math.round(sqrtArea * 2.2);
    const stepFlashingLf = Math.round(sqrtArea * 0.6);
// Compute pitch from segment tilt degrees if available
const degs = (roofSegments || [])
  .map(s => (typeof s.pitchDegrees === 'number' ? s.pitchDegrees : (typeof s.tiltDegrees === 'number' ? s.tiltDegrees : null)))
  .filter(v => typeof v === 'number' && !isNaN(v) && v > 0);
const avgDeg = degs.length ? (degs.reduce((a,b)=>a+b,0) / degs.length) : null;
const degToX12 = (deg) => {
  const rise = Math.tan((deg * Math.PI) / 180) * 12;
  const clamped = Math.min(20, Math.max(1, Math.round(rise)));
  return `${clamped}/12`;
};
const pitchStr = avgDeg ? degToX12(avgDeg) : '6/12';

    debugLogs.push('✅ Measurements calculated successfully');

    // 🔍 CHECK LIMITS & TRACK USAGE
    try {
      // Find company ID
      let companyId = user.company_id;
      if (!companyId) {
        const staff = await base44.asServiceRole.entities.StaffProfile.filter({user_email: user.email});
        if (staff && staff.length > 0) companyId = staff[0].company_id;
      }
      
      if (companyId) {
        // Check Limit
        const { checkSubscriptionLimit } = await import('./utils/checkSubscriptionLimit.js');
        const limitCheck = await checkSubscriptionLimit(base44, companyId, 'ai_estimator');
        
        if (!limitCheck.allowed) {
          return Response.json({ 
            success: false, 
            error: `Monthly limit reached for AI Estimator on ${limitCheck.plan} plan (${limitCheck.current_usage}/${limitCheck.limit}). Purchase credits or upgrade to run more reports.` 
          }, { status: 403 });
        }

        // Track Usage / Deduct Credits
        if (limitCheck.source === 'extra') {
          // Deduct from extra credits
          const companies = await base44.asServiceRole.entities.Company.filter({ id: companyId });
          if (companies.length > 0) {
            const currentExtra = companies[0].extra_ai_credits || 0;
            if (currentExtra > 0) {
              await base44.asServiceRole.entities.Company.update(companyId, {
                extra_ai_credits: currentExtra - 1
              });
            }
          }
        } else {
          // Standard Plan Usage
          const currentMonth = new Date().toISOString().slice(0, 7);
          const feature = 'ai_estimator';
          const costPerUnit = 0.15;

          const existingUsage = await base44.asServiceRole.entities.SubscriptionUsage.filter({
            company_id: companyId,
            feature: feature,
            usage_month: currentMonth
          });

          if (existingUsage && existingUsage.length > 0) {
            const record = existingUsage[0];
            await base44.asServiceRole.entities.SubscriptionUsage.update(record.id, {
              credits_used: (record.credits_used || 0) + 1,
              total_cost: (record.total_cost || 0) + costPerUnit,
              last_used: new Date().toISOString()
            });
          } else {
            await base44.asServiceRole.entities.SubscriptionUsage.create({
              company_id: companyId,
              feature: feature,
              usage_month: currentMonth,
              credits_used: 1,
              credits_limit: limitCheck.limit || 100,
              cost_per_unit: costPerUnit,
              total_cost: costPerUnit,
              last_used: new Date().toISOString()
            });
          }
        }
      }
    } catch (err) {
      console.error('Usage/Limit Error:', err.message);
      if (err.message && err.message.includes('Monthly limit reached')) {
         return Response.json({ success: false, error: err.message }, { status: 403 });
      }
    }

    return Response.json({
      success: true,
      roof_area_sq: roofAreaSquares,
      roof_area_sqft: totalAreaSqFt,
      ridge_lf: ridgeLf,
      hip_lf: hipLf,
      valley_lf: valleyLf,
      rake_lf: rakeLf,
      eave_lf: eaveLf,
      step_flashing_lf: stepFlashingLf,
      pitch: pitchStr,
      satellite_image_url: satelliteImageUrl,
      overall_confidence: usedWhole ? 95 : 85,
      ridge_confidence: 80,
      hip_confidence: 100,
      valley_confidence: 75,
      rake_confidence: 80,
      eave_confidence: 80,
      step_flashing_confidence: 75,
      analysis_notes: usedWhole ? "Used Google Solar wholeRoofStats (full-roof area). LF estimated from area." : "Used sum of roofSegmentStats (solar-eligible area). LF estimated from area.",
      debug_logs: debugLogs
    });

  } catch (error) {
    console.error('💥 Error:', error);
    debugLogs.push(`💥 ERROR: ${error.message}`);
    
    return Response.json({ 
      success: false, 
      error: error.message,
      stack: error.stack,
      debug_logs: debugLogs
    }, { status: 500 });
  }
});