import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, Camera, Loader2, ArrowLeft, AlertCircle, Trash2, Mail, DollarSign, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"; // Added for Role Select

const ONBOARDING_CHECKLIST = {
  'Claims Specialist Onboarding': [
    '1099 Form', 'Independent contract agreement', '2 shirts 1 sweatshirt',
    'Business Cards', 'Tablet', 'Safety training acknowledgement', 'Waiver release form',
    'Copy of Drivers license and proof of insurance', 'Social security number/EIN',
    'ID badge', 'lanyard and clipboard', 'YICN CRM app training', 'SVGU TRaining',
    'Field Training', 'Ladder', 'Drone', 'Roof/Siding Picture App', 'Certification Award'
  ]
};

const DEPARTMENTS = [
  'Punch Out', 'Free Inspection (Insurance)', 'Free Inspection (Retail)', 'Interior',
  'Gutter', 'Roof Repair', 'Roof Replacement', 'Insurance Claims Specialist',
  'Siding', 'Sales', 'Roof Inspection(Accuserve)'
];

const PERMISSIONS_CONFIG = [
  { feature: "Estimates", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Invoices", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Proposals", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Payments", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Items", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Customers", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Leads", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Projects", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Tasks", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Contracts", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Staff", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Settings", capabilities: ["view", "edit"] },
  { feature: "Reports", capabilities: ["view"] },
];

export default function StaffProfilePage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const userEmail = urlParams.get("email");
  const isNewUser = userEmail === 'new';

  console.log('🔍 StaffProfilePage Debug:', { userEmail, isNewUser }); // Debug log

  const [currentUser, setCurrentUser] = useState(null);
  const [profile, setProfile] = useState({});
  const [isUploading, setIsUploading] = useState(false);
  const [emailDebugLog, setEmailDebugLog] = useState([]);
  const avatarFileRef = useRef(null);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['current-user-profile', currentUser?.email],
    queryFn: () => currentUser ? base44.entities.StaffProfile.filter({ user_email: currentUser.email }) : [],
    enabled: !!currentUser,
    initialData: [],
  });

  const myCompany = React.useMemo(() => {
    if (!currentUser) return null;
    const ownedCompany = companies.find(c => c.created_by === currentUser.email);
    if (ownedCompany) return ownedCompany;
    const staffProfile = staffProfiles[0];
    if (staffProfile?.company_id) {
      return companies.find(c => c.id === staffProfile.company_id);
    }
    return null;
  }, [currentUser, companies, staffProfiles]);

  const { data: staffRoles = [] } = useQuery({
    queryKey: ['staff-roles', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.StaffRole.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: profileData, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['staff-profile', userEmail],
    queryFn: async () => {
        if (isNewUser) {
          console.log('✅ New user mode - returning null');
          return null;
        }
        console.log('📊 Fetching profile for:', userEmail);
        const profiles = await base44.entities.StaffProfile.filter({ user_email: userEmail });
        return profiles[0];
    },
    enabled: !!userEmail && !isNewUser,
  });

  useEffect(() => {
    console.log('🔄 Profile useEffect triggered:', { isNewUser, profileData });
    if (isNewUser) {
      console.log('✅ Setting up NEW user profile');
      setProfile({
        full_name: '',
        email: '',
        role_id: '',
        role_name: '',
        is_administrator: false,
        can_process_commission_payments: false,
        position: '',
        phone: '',
        hourly_rate: 0,
        commission_rate: '',
        twilio_number: '',
        whatsapp_enabled: false,
        social_facebook: '',
        social_linkedin: '',
        social_skype: '',
        email_signature: '',
        departments: [],
        onboarding_checklist: {},
        avatar_url: '',
        permissions: {},
        invite_sent: false,
        invite_sent_at: null,
        requires_ladder_assist: false,
        default_ladder_assist_cost: 100,
      });
    } else if (profileData) {
      console.log('✅ Setting up EXISTING user profile');
      setProfile({
        profile_id: profileData.id,
        full_name: profileData.full_name || '',
        email: profileData.user_email || '',
        role_id: profileData.role_id || '',
        role_name: profileData.role_name || '',
        is_administrator: profileData.is_administrator || false,
        can_process_commission_payments: profileData.can_process_commission_payments || false,
        position: profileData.position || '',
        phone: profileData.phone || '',
        hourly_rate: profileData.hourly_rate || 0,
        commission_rate: profileData.commission_rate === null ? '' : (profileData.commission_rate || ''), // Explicitly handle null to empty string for display
        twilio_number: profileData.twilio_number || '',
        whatsapp_enabled: profileData.whatsapp_enabled || false,
        social_facebook: profileData.social_facebook || '',
        social_linkedin: profileData.social_linkedin || '',
        social_skype: profileData.social_skype || '',
        email_signature: profileData.email_signature || '',
        departments: profileData.departments || [],
        onboarding_checklist: profileData.onboarding_checklist || {},
        avatar_url: profileData.avatar_url || '',
        permissions: profileData.permissions || {},
        invite_sent: profileData.invite_sent || false,
        invite_sent_at: profileData.invite_sent_at,
        requires_ladder_assist: profileData.requires_ladder_assist || false,
        default_ladder_assist_cost: profileData.default_ladder_assist_cost || 100,
      });
    }
  }, [profileData, isNewUser]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (!myCompany?.id) {
        throw new Error("Company setup required");
      }

      const profilePayload = {
        user_email: data.email,
        company_id: myCompany.id,
        full_name: data.full_name,
        role_id: data.role_id,
        role_name: data.role_name,
        is_administrator: data.is_administrator,
        can_process_commission_payments: data.can_process_commission_payments,
        position: data.position,
        phone: data.phone,
        hourly_rate: data.hourly_rate,
        commission_rate: data.commission_rate === '' ? null : data.commission_rate,
        twilio_number: data.twilio_number,
        whatsapp_enabled: data.whatsapp_enabled,
        social_facebook: data.social_facebook,
        social_linkedin: data.social_linkedin,
        social_skype: data.social_skype,
        email_signature: data.email_signature,
        departments: data.departments,
        onboarding_checklist: data.onboarding_checklist,
        avatar_url: data.avatar_url,
        is_active: true,
        permissions: data.permissions,
        requires_ladder_assist: data.requires_ladder_assist,
        default_ladder_assist_cost: data.default_ladder_assist_cost,
      };

      let savedProfile;
      const isCreating = !data.profile_id;
      
      if (data.profile_id) {
        savedProfile = await base44.entities.StaffProfile.update(data.profile_id, profilePayload);
      } else {
        savedProfile = await base44.entities.StaffProfile.create(profilePayload);
      }
      
      // Trigger workflows for staff creation/update
      if (myCompany?.id) {
        try {
          const triggerType = isCreating ? 'staff_created' : 'staff_updated';
          await base44.functions.invoke('triggerWorkflow', {
            triggerType,
            companyId: myCompany.id,
            entityType: 'StaffProfile',
            entityId: savedProfile.id,
            entityData: {
              staff_name: savedProfile.full_name,
              staff_email: savedProfile.user_email,
              position: savedProfile.position,
              role_name: savedProfile.role_name,
              is_administrator: savedProfile.is_administrator,
              app_url: window.location.origin
            }
          });
        } catch (error) {
          console.error('Workflow trigger failed (non-critical):', error);
        }
      }
      
      return savedProfile;
    },
    onSuccess: (savedProfile) => {
      queryClient.invalidateQueries({ queryKey: ['company-staff-profiles'] });
      queryClient.invalidateQueries({ queryKey: ['staff-profile', userEmail] }); // Invalidate specific profile query

      const wasNewUserCreation = !profile.profile_id; // Check if it was a new creation before state update

      setProfile(prev => ({
        ...prev,
        profile_id: savedProfile.id,
        // Update invite status if it was changed during the save operation, or if it's new
        invite_sent: savedProfile.invite_sent || prev.invite_sent,
        invite_sent_at: savedProfile.invite_sent_at || prev.invite_sent_at,
        role_id: savedProfile.role_id || prev.role_id, // Ensure role_id is updated
        role_name: savedProfile.role_name || prev.role_name, // Ensure role_name is updated
        commission_rate: savedProfile.commission_rate === null ? '' : (savedProfile.commission_rate || ''), // Ensure commission rate is updated correctly, handle null from DB
      }));
      
      // If it's an existing profile, show a generic success message.
      // New user creation will be handled by specific alerts after saving.
      if (!wasNewUserCreation) {
        alert("✅ Profile saved successfully!");
      } else {
        alert("✅ Profile created successfully!");
        navigate(createPageUrl('StaffProfilePage', { email: savedProfile.user_email })); // Redirect to newly created profile
      }
    },
    onError: (error) => {
      alert(`❌ Failed to save profile: ${error.message}`);
    }
  });

  const sendInviteMutation = useMutation({
    mutationFn: async () => {
      if (!profile.email) {
        throw new Error('Email address is required');
      }

      if (!myCompany?.id) {
        throw new Error('Company not found');
      }

      if (!myCompany?.email) {
        throw new Error('Company email not configured. Please update your company settings.');
      }

      const inviteUrl = `${window.location.origin}`; 
      
      setEmailDebugLog(prev => [...prev, `📧 Attempting to send to: ${profile.email} via SendEmail function`]);
      
      try {
        // Get role name for the email
        const roleName = profile.role_name || 'Staff Member';
        
        // Use the CRM email function instead of Core.SendEmail
        const emailResult = await base44.functions.invoke('sendEmailFromCRM', {
          to: profile.email,
          subject: `You're invited to join ${myCompany?.company_name || 'our team'}!`,
          message: `Hi ${profile.full_name},

You've been added as a ${roleName} to ${myCompany?.company_name || 'our CRM system'}. We're excited to have you on the team!

Your Login Credentials:
- Email: ${profile.email}
- Password: Use "Forgot Password" on the login page to set your password

Login here: ${inviteUrl}

⚠️ IMPORTANT SETUP STEPS:
1. Click "Forgot Password" on the login page
2. Enter this email address: ${profile.email}
3. Check your email for a password reset link
4. Set your new password
5. Log in with your new credentials

Your Access Level: ${roleName}
${profile.is_administrator ? '✅ You have administrator access to all features.' : '📋 Your permissions are configured by your administrator.'}

If you have any questions, feel free to reach out to your team administrator.`,
          contactName: profile.full_name,
          companyId: myCompany.id
        });

        setEmailDebugLog(prev => [...prev, `✅ Email function returned: ${JSON.stringify(emailResult)}`]);

        if (profile.profile_id) {
          const updatedProfile = await base44.entities.StaffProfile.update(profile.profile_id, {
            invite_sent: true,
            invite_sent_at: new Date().toISOString()
          });
          
          setProfile(prev => ({
            ...prev,
            invite_sent: updatedProfile.invite_sent,
            invite_sent_at: updatedProfile.invite_sent_at,
          }));
        }

        return emailResult;
      } catch (emailError) {
        setEmailDebugLog(prev => [...prev, `❌ Error: ${emailError.message}`]);
        throw emailError;
      }
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['staff-profile', userEmail] });
      alert(`✅ Invite email sent to ${profile.email}!\n\nThey should use "Forgot Password" to set up their account.\n\nCheck spam/junk folder if not received.`);
    },
    onError: (error) => {
      alert(`❌ Failed to send invite: ${error.message}`);
    }
  });

  const deleteProfileMutation = useMutation({
    mutationFn: (id) => base44.entities.StaffProfile.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-staff-profiles'] });
      alert("✅ Staff member deleted");
      navigate(createPageUrl('StaffManagement'));
    },
  });

  const handleCopyInviteLink = () => {
    const inviteMessage = `Hi ${profile.full_name},

You've been invited to join ${myCompany?.company_name || 'our team'}!

Your login email: ${profile.email}

Login here: ${window.location.origin}

If you don't have a password yet, click "Forgot Password" on the login page to set one up.

Welcome to the team!`;

    navigator.clipboard.writeText(inviteMessage);
    alert('✅ Invite message copied to clipboard!\n\nYou can now paste and send it via text, WhatsApp, or another method.');
  };

  const handleFieldChange = (field, value) => {
    setProfile(p => ({ ...p, [field]: value }));
  };

  const handlePermissionChange = (feature, capability) => {
    setProfile(p => {
      const newPermissions = { ...(p.permissions || {}) };
      if (!newPermissions[feature]) newPermissions[feature] = {};
      newPermissions[feature][capability] = !newPermissions[feature][capability];
      return { ...p, permissions: newPermissions };
    });
  };

  const handleSave = () => {
    console.log('💾 Attempting to save profile:', profile);
    console.log('📧 Email value:', profile.email);
    console.log('👤 Name value:', profile.full_name);
    
    if (!profile.full_name || !profile.full_name.trim()) {
      alert("❌ Name is required");
      return;
    }
    
    if (!profile.email || !profile.email.trim()) {
      alert("❌ Email is required");
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(profile.email)) {
      alert("❌ Please enter a valid email address");
      return;
    }
    
    saveMutation.mutate(profile);
  };

  const handleAvatarUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setIsUploading(true);
    try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        handleFieldChange('avatar_url', file_url);
    } catch(err) {
        alert('Upload failed: ' + err.message);
    } finally {
        setIsUploading(false);
    }
  };

  const handleChecklistChange = (checklistName, item) => {
    setProfile(p => {
        const currentChecklist = { ...(p.onboarding_checklist?.[checklistName] || {}) };
        currentChecklist[item] = !currentChecklist[item];
        const newOnboarding = { ...(p.onboarding_checklist || {}), [checklistName]: currentChecklist };
        return { ...p, onboarding_checklist: newOnboarding };
    });
  };

  const handleDepartmentChange = (department) => {
      setProfile(p => {
          const currentDepartments = p.departments || [];
          const newDepartments = currentDepartments.includes(department)
              ? currentDepartments.filter(d => d !== department)
              : [...currentDepartments, department];
          return { ...p, departments: newDepartments };
      });
  };

  const handleRoleChange = (roleId) => {
    const selectedRole = staffRoles.find(r => r.id === roleId);
    setProfile(p => ({
      ...p,
      role_id: roleId,
      role_name: selectedRole?.name || '',
      permissions: selectedRole?.permissions || {}
    }));
  };

  const handleDelete = () => {
    if (window.confirm(`⚠️ Delete ${profile.full_name}?\n\nThis will remove their profile. Are you sure?`)) {
      deleteProfileMutation.mutate(profile.profile_id);
    }
  };

  if (isLoadingProfile) return <div className="p-6">Loading...</div>;

  const fullNameParts = profile.full_name?.split(' ') || [];
  const firstName = fullNameParts[0] || '';
  const lastName = fullNameParts.slice(1).join(' ') || '';

  console.log('🎨 Rendering form - isNewUser:', isNewUser, 'email:', profile.email);

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('StaffManagement'))}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{isNewUser ? 'Add New Staff Member' : profile.full_name}</h1>
            <p className="text-gray-500 mt-1">{isNewUser ? 'Set up their profile' : profile.email}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {profile.profile_id && (
            <>
              <Button 
                variant="outline"
                onClick={() => sendInviteMutation.mutate()}
                disabled={sendInviteMutation.isLoading}
                className="text-blue-600 hover:text-blue-700"
              >
                {sendInviteMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Mail className="w-4 h-4 mr-2" />}
                Send Invite
              </Button>
              <Button 
                variant="outline"
                onClick={handleCopyInviteLink}
                className="text-green-600 hover:text-green-700"
              >
                📋 Copy Invite Link
              </Button>
              <Button 
                variant="outline" 
                onClick={handleDelete}
                disabled={deleteProfileMutation.isLoading}
                className="text-red-600 hover:text-red-700"
              >
                {deleteProfileMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                Delete
              </Button>
            </>
          )}
        </div>
      </div>

      {isNewUser && (
        <Alert className="bg-blue-50 border-blue-200">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Creating New Staff Member:</strong> Fill in their details below. After saving, you can send them an invite email.
          </AlertDescription>
        </Alert>
      )}

      {profile.profile_id && !profile.invite_sent && (
        <Alert className="bg-yellow-50 border-yellow-200">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-900">
            <strong>⚠️ Invite Not Sent:</strong> This staff member hasn't received their login credentials yet.
            <div className="flex gap-2 mt-2">
              <Button size="sm" onClick={() => sendInviteMutation.mutate()} disabled={sendInviteMutation.isLoading}>
                {sendInviteMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Mail className="w-4 h-4 mr-2" />}
                Send Invite Email
              </Button>
              <Button size="sm" onClick={handleCopyInviteLink} variant="outline">
                📋 Copy Invite Message
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {profile.invite_sent && profile.invite_sent_at && (
        <Alert className="bg-green-50 border-green-200">
          <Mail className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-900">
            ✅ Invite email sent on {new Date(profile.invite_sent_at).toLocaleDateString()}
          </AlertDescription>
        </Alert>
      )}

      {emailDebugLog.length > 0 && (
        <Alert className="bg-gray-50 border-gray-200">
          <AlertCircle className="h-4 w-4 text-gray-600" />
          <AlertDescription>
            <strong className="text-gray-900">Email Debug Log:</strong>
            <pre className="text-xs mt-2 text-gray-700 whitespace-pre-wrap">
              {emailDebugLog.join('\n')}
            </pre>
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6 mt-6">
          <Card>
            <CardHeader><CardTitle>Profile Information</CardTitle></CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={profile.avatar_url} />
                  <AvatarFallback>{profile.full_name?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <input type="file" ref={avatarFileRef} onChange={handleAvatarUpload} className="hidden" accept="image/*" />
                <Button variant="outline" onClick={() => avatarFileRef.current?.click()} disabled={isUploading}>
                    {isUploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Camera className="w-4 h-4 mr-2" />}
                    Upload Photo
                </Button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <Checkbox 
                    id="is-admin"
                    checked={profile.is_administrator || false}
                    onCheckedChange={(checked) => handleFieldChange('is_administrator', checked)}
                  />
                  <Label htmlFor="is-admin" className="text-sm font-semibold cursor-pointer">
                    Administrator (Full Access - Bypasses Role Permissions)
                  </Label>
                </div>

                <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <Checkbox 
                    id="can-process-payments"
                    checked={profile.can_process_commission_payments || false}
                    onCheckedChange={(checked) => handleFieldChange('can_process_commission_payments', checked)}
                  />
                  <Label htmlFor="can-process-payments" className="text-sm font-semibold cursor-pointer">
                    🔒 Can Process Commission Payments (Required for direct deposit authorization)
                  </Label>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label>First Name *</Label>
                  <Input 
                    value={firstName} 
                    onChange={(e) => handleFieldChange('full_name', `${e.target.value} ${lastName}`.trim())} 
                    placeholder="Enter first name"
                  />
                </div>
                <div>
                  <Label>Last Name *</Label>
                  <Input 
                    value={lastName} 
                    onChange={(e) => handleFieldChange('full_name', `${firstName} ${e.target.value}`.trim())} 
                    placeholder="Enter last name"
                  />
                </div>
                <div>
                  <Label>Email *</Label>
                  <Input 
                    type="email"
                    value={profile.email || ''} 
                    onChange={(e) => handleFieldChange('email', e.target.value)} 
                    placeholder="Enter email address"
                  />
                  <p className="text-xs text-gray-500 mt-1">Staff member's email address</p>
                </div>
                <div>
                  <Label>Role</Label>
                  <Select
                    value={profile.role_id || 'none'}
                    onValueChange={(value) => {
                      if (value === 'none') {
                        handleFieldChange('role_id', '');
                        handleFieldChange('role_name', '');
                        handleFieldChange('permissions', {});
                      } else {
                        handleRoleChange(value);
                      }
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a role..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Role Assigned</SelectItem>
                      {staffRoles.map(role => (
                        <SelectItem key={role.id} value={role.id}>{role.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">
                    Assign a role to grant permissions
                  </p>
                </div>
                <div>
                  <Label>Position / Job Title</Label>
                  <Input 
                    value={profile.position || ''} 
                    onChange={(e) => handleFieldChange('position', e.target.value)}
                  />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input 
                    value={profile.phone || ''} 
                    onChange={(e) => handleFieldChange('phone', e.target.value)}
                  />
                </div>
                <div>
                  <Label>Hourly Rate</Label>
                  <Input 
                    type="number" 
                    value={profile.hourly_rate || 0} 
                    onChange={(e) => handleFieldChange('hourly_rate', parseFloat(e.target.value) || 0)} 
                  />
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  Commission Structure (Optional)
                </h3>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <Label className="text-base font-semibold">Commission Rate (%)</Label>
                  <Input 
                    type="number" 
                    step="0.01"
                    min="0"
                    max="100"
                    placeholder="e.g., 5 for 5%, 10 for 10%, 9.8 for 9.8%"
                    value={profile.commission_rate === '' || profile.commission_rate === null || profile.commission_rate === undefined ? '' : profile.commission_rate} 
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === '') {
                        handleFieldChange('commission_rate', '');
                      } else {
                        const parsed = parseFloat(value);
                        if (!isNaN(parsed) && parsed >= 0 && parsed <= 100) {
                          handleFieldChange('commission_rate', parsed);
                        } else if (value === '-' && parsed === 0) { // Allow negative sign for input, but not for final value
                          handleFieldChange('commission_rate', value);
                        }
                      }
                    }} 
                    className="mt-2 text-lg font-semibold"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    💡 This percentage will be used to calculate their commission from paid invoices
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Leave empty if this person is not on commission (e.g., 1099 contractors)
                  </p>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="font-semibold text-lg mb-4">Ladder Assistant Settings</h3>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-4">
                    <Checkbox
                      id="requires-ladder-assist"
                      checked={profile.requires_ladder_assist || false}
                      onCheckedChange={(checked) => handleFieldChange('requires_ladder_assist', checked)}
                    />
                    <Label htmlFor="requires-ladder-assist" className="cursor-pointer">
                      This rep typically requires ladder assistance for inspections
                    </Label>
                  </div>
                  {profile.requires_ladder_assist && (
                    <div className="ml-7">
                      <Label>Default Ladder Assist Cost</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={profile.default_ladder_assist_cost || 100}
                        onChange={(e) => handleFieldChange('default_ladder_assist_cost', parseFloat(e.target.value) || 0)}
                      />
                      <p className="text-xs text-gray-600 mt-1">
                        This will be the default cost when creating inspections for this rep
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="font-semibold text-lg mb-4">Twilio Phone Number</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Twilio Number</Label>
                    <Input
                      value={profile.twilio_number || ''}
                      onChange={(e) => handleFieldChange('twilio_number', e.target.value)}
                    />
                    <p className="text-xs text-gray-500 mt-1">This number will show as caller ID</p>
                  </div>
                  <div className="flex items-center gap-2 pt-6">
                    <Checkbox
                      id="whatsapp-enabled"
                      checked={profile.whatsapp_enabled || false}
                      onCheckedChange={(checked) => handleFieldChange('whatsapp_enabled', checked)}
                    />
                    <Label htmlFor="whatsapp-enabled">WhatsApp Enabled</Label>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Facebook</Label>
                  <Input value={profile.social_facebook || ''} onChange={(e) => handleFieldChange('social_facebook', e.target.value)} />
                </div>
                <div>
                  <Label>LinkedIn</Label>
                  <Input value={profile.social_linkedin || ''} onChange={(e) => handleFieldChange('social_linkedin', e.target.value)} />
                </div>
                <div>
                  <Label>Skype</Label>
                  <Input value={profile.social_skype || ''} onChange={(e) => handleFieldChange('social_skype', e.target.value)} />
                </div>
              </div>

              <div>
                <Label>Email Signature</Label>
                <Textarea value={profile.email_signature || ''} onChange={e => handleFieldChange('email_signature', e.target.value)} />
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-2">Member Departments</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {DEPARTMENTS.map(dept => (
                    <div key={dept} className="flex items-center gap-2">
                      <Checkbox
                        id={`dept-${dept}`}
                        checked={profile.departments?.includes(dept) || false}
                        onCheckedChange={() => handleDepartmentChange(dept)}
                      />
                      <Label htmlFor={`dept-${dept}`} className="font-normal">{dept}</Label>
                    </div>
                  ))}
                </div>
              </div>

              {Object.entries(ONBOARDING_CHECKLIST).map(([listName, items]) => (
                <div key={listName}>
                  <h3 className="font-semibold text-lg mb-2">{listName}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {items.map(item => (
                      <div key={item} className="flex items-center gap-2">
                        <Checkbox
                          id={`onboard-${listName}-${item}`}
                          checked={profile.onboarding_checklist?.[listName]?.[item] || false}
                          onCheckedChange={() => handleChecklistChange(listName, item)}
                        />
                        <Label htmlFor={`onboard-${listName}-${item}`} className="font-normal text-sm">{item}</Label>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Permissions</CardTitle>
              <p className="text-sm text-gray-500">Configure what this staff member can access (ignored if Administrator)</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {PERMISSIONS_CONFIG.map(({ feature, capabilities }) => (
                  <div key={feature} className="border-b pb-4 last:border-0">
                    <h4 className="font-semibold mb-3">{feature}</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {capabilities.map(capability => (
                        <div key={capability} className="flex items-center gap-2">
                          <Checkbox
                            id={`${feature}-${capability}`}
                            checked={profile.permissions?.[feature]?.[capability] || false}
                            onCheckedChange={() => handlePermissionChange(feature, capability)}
                            disabled={profile.is_administrator}
                          />
                          <Label 
                            htmlFor={`${feature}-${capability}`} 
                            className={`font-normal text-sm ${profile.is_administrator ? 'text-gray-400' : ''}`}
                          >
                            {capability.charAt(0).toUpperCase() + capability.slice(1)}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={saveMutation.isLoading}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {saveMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          {isNewUser ? 'Create Profile' : 'Save Profile'}
        </Button>
      </div>
    </div>
  );
}