import React from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

export default function ImpersonationBanner({ impersonationData, onStopImpersonation }) {
  const queryClient = useQueryClient();

  const stopImpersonationMutation = useMutation({
    mutationFn: async () => {
      // Clear impersonation from sessionStorage
      const impersonationSessionId = sessionStorage.getItem('impersonation_session_id');
      
      if (impersonationSessionId) {
        try {
          // Log end time
          const log = await base44.entities.ImpersonationLog.filter({ id: impersonationSessionId });
          if (log.length > 0) {
            const startedAt = new Date(log[0].started_at);
            const endedAt = new Date();
            const durationMinutes = Math.round((endedAt - startedAt) / 1000 / 60);
            
            await base44.entities.ImpersonationLog.update(impersonationSessionId, {
              ended_at: endedAt.toISOString(),
              duration_minutes: durationMinutes,
              is_active: false
            });
          }
        } catch (err) {
          console.error('Failed to update impersonation log:', err);
        }
      }
      
      sessionStorage.removeItem('impersonating_company_id');
      sessionStorage.removeItem('impersonating_company_name');
      sessionStorage.removeItem('impersonation_session_id');
    },
    onSuccess: () => {
      // Reload immediately to clear all state
      window.location.reload();
    },
  });

  if (!impersonationData) return null;

  return (
    <Alert className="fixed top-0 left-0 right-0 z-50 rounded-none border-0 bg-red-600 text-white shadow-lg animate-pulse">
      <AlertDescription className="flex items-center justify-between max-w-7xl mx-auto px-4">
        <div className="flex items-center gap-3">
          <Shield className="w-5 h-5" />
          <span className="font-bold text-lg">
            🔴 IMPERSONATING: {impersonationData.companyName}
          </span>
          <span className="text-sm opacity-90">
            (Platform Owner Mode - All actions are logged)
          </span>
        </div>
        <Button
          onClick={() => stopImpersonationMutation.mutate()}
          disabled={stopImpersonationMutation.isPending}
          variant="outline"
          size="sm"
          className="bg-white text-red-600 hover:bg-red-50 border-white"
        >
          <X className="w-4 h-4 mr-2" />
          Stop Impersonating
        </Button>
      </AlertDescription>
    </Alert>
  );
}