import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sparkles, ArrowLeft, Facebook, Instagram, Video, MapPin, Wrench, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ComingSoon({ 
  title = "Coming Soon", 
  description = "This feature is currently under development and will be available soon.",
  showBackButton = true 
}) {
  const navigate = useNavigate();

  const upcomingFeatures = [
    {
      name: "Facebook Lead Ads",
      icon: Facebook,
      color: "bg-blue-600",
      description: "Auto-capture leads from Facebook ads directly into CRM",
      category: "Marketing"
    },
    {
      name: "Facebook Pages",
      icon: Facebook,
      color: "bg-blue-500",
      description: "Manage messages and comments from Facebook Pages",
      category: "Marketing"
    },
    {
      name: "Instagram Business",
      icon: Instagram,
      color: "from-purple-500 to-pink-500",
      description: "Sync DMs and comments to your CRM automatically",
      category: "Marketing"
    },
    {
      name: "TikTok Lead Ads",
      icon: Video,
      color: "bg-black",
      description: "Capture TikTok ad leads in real-time",
      category: "Marketing"
    },
    {
      name: "Google My Business",
      icon: MapPin,
      color: "bg-green-600",
      description: "Review monitoring and automated responses",
      category: "Marketing"
    },
    {
      name: "Google Chat",
      icon: MessageSquare,
      color: "bg-blue-500",
      description: "Send notifications and updates to Google Chat spaces",
      category: "Communication"
    },
    {
      name: "ABC Supply",
      icon: Wrench,
      color: "bg-orange-600",
      description: "One-click material ordering from estimates",
      category: "Materials"
    },
    {
      name: "SRS Distribution",
      icon: Wrench,
      color: "bg-blue-600",
      description: "Direct ordering integration with SRS",
      category: "Materials"
    },
    {
      name: "Beacon Building Products",
      icon: Wrench,
      color: "bg-red-600",
      description: "Material ordering from Beacon",
      category: "Materials"
    },
    {
      name: "Symbility Integration",
      icon: Sparkles,
      color: "bg-purple-600",
      description: "Bi-directional claims and estimate sync",
      category: "Insurance"
    }
  ];

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-10 h-10 text-white" />
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{title}</h1>
          <p className="text-gray-600 mb-6">{description}</p>
          
          {showBackButton && (
            <Button 
              onClick={() => navigate(createPageUrl('Dashboard'))}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
          {upcomingFeatures.map((feature, idx) => {
            const Icon = feature.icon;
            const colorClass = feature.color.startsWith('from-') 
              ? `bg-gradient-to-r ${feature.color}` 
              : feature.color;

            return (
              <Card key={idx} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start gap-3">
                    <div className={`w-12 h-12 ${colorClass} rounded-lg flex items-center justify-center text-white flex-shrink-0`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-lg">{feature.name}</CardTitle>
                      <Badge className="mt-1 bg-purple-100 text-purple-700 text-xs">
                        {feature.category}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}