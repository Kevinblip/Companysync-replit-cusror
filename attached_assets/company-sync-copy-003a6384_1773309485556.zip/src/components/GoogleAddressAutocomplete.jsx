import React, { useRef, useEffect, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, MapPin } from 'lucide-react';

export function GoogleAddressAutocomplete({ onAddressSelect, placeholder = "Enter property address...", initialAddress = "" }) {
  const inputRef = useRef(null);
  const autocompleteRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [inputValue, setInputValue] = useState(initialAddress);
  const isSelectingFromAutocomplete = useRef(false); // Track when autocomplete is selecting
  
  // Use ref for callback to prevent re-initialization of autocomplete when parent re-renders
  const onAddressSelectRef = useRef(onAddressSelect);
  useEffect(() => {
    onAddressSelectRef.current = onAddressSelect;
  }, [onAddressSelect]);

  useEffect(() => {
    if (initialAddress !== inputValue) {
      setInputValue(initialAddress);
    }
  }, [initialAddress]);

  useEffect(() => {
    // Wait for Google Maps to load
    const initAutocomplete = () => {
      if (!window.google || !window.google.maps || !window.google.maps.places) {
        console.warn('Google Maps not loaded yet, retrying...');
        return false;
      }

      if (!inputRef.current) {
        console.warn('Input ref not ready');
        return false;
      }

      try {
        // Create autocomplete instance
        // We use the input ref directly
        autocompleteRef.current = new window.google.maps.places.Autocomplete(inputRef.current, {
          types: ['geocode', 'establishment'],
          componentRestrictions: { country: 'us' },
          fields: ['formatted_address', 'geometry', 'address_components', 'place_id']
        });

        // Listen for place selection
        autocompleteRef.current.addListener('place_changed', () => {
          const place = autocompleteRef.current.getPlace();

          console.log('🔍 Place changed event fired');
          
          if (!place || !place.place_id) {
            // User pressed enter without selecting
            // Don't show error immediately as they might still be typing
            isSelectingFromAutocomplete.current = false;
            return; 
          }

          if (!place.geometry || !place.geometry.location) {
            console.error('❌ No geometry in place object');
            setError('Could not get location for this address. Please try another address.');
            isSelectingFromAutocomplete.current = false;
            return;
          }

          // Set flag to prevent onChange interference
          isSelectingFromAutocomplete.current = true;

          setError(null);
          
          // Construct full address manually to ensure Zip/City/State are present
          let fullAddress = place.formatted_address;
          
          if (place.address_components) {
            const getComponent = (type) => place.address_components.find(c => c.types.includes(type));
            
            const streetNum = getComponent('street_number')?.long_name || '';
            const street = getComponent('route')?.long_name || '';
            const city = getComponent('locality')?.long_name || 
                         getComponent('sublocality')?.long_name || 
                         getComponent('neighborhood')?.long_name || '';
            const state = getComponent('administrative_area_level_1')?.short_name || '';
            const zip = getComponent('postal_code')?.long_name || '';
            
            // Only override if we have at least Street, City, and State
            if (street && city && state) {
              fullAddress = `${streetNum} ${street}`.trim();
              fullAddress += `, ${city}, ${state}`;
              if (zip) fullAddress += ` ${zip}`;
            }
          }

          console.log('✅ Setting full address:', fullAddress);
          
          // Update state and DOM immediately
          setInputValue(fullAddress);
          
          if (inputRef.current) {
            inputRef.current.value = fullAddress;
          }
          
          // Call the callback using ref
          if (onAddressSelectRef.current) {
            onAddressSelectRef.current(fullAddress, place);
          }

          // Reset flag after a short delay to allow React to process
          setTimeout(() => {
            isSelectingFromAutocomplete.current = false;
          }, 100);
        });

        setIsLoading(false);
        console.log('✅ Google Places Autocomplete initialized');
        return true;
      } catch (err) {
        console.error('Error initializing Google Places:', err);
        setError('Failed to initialize address autocomplete');
        setIsLoading(false);
        return false;
      }
    };

    // Try to initialize immediately
    if (initAutocomplete()) {
      return;
    }

    // If not ready, retry every 500ms for up to 10 seconds
    let retries = 0;
    const maxRetries = 20;
    const interval = setInterval(() => {
      retries++;
      if (initAutocomplete()) {
        clearInterval(interval);
      } else if (retries >= maxRetries) {
        clearInterval(interval);
        setError('Google Maps failed to load. Please refresh the page.');
        setIsLoading(false);
      }
    }, 500);

    return () => {
      clearInterval(interval);
      if (autocompleteRef.current && window.google && window.google.maps && window.google.maps.event) {
        window.google.maps.event.clearInstanceListeners(autocompleteRef.current);
      }
    };
  }, []); // Empty dependency array - only init once!

  if (error) {
    return (
      <Alert className="border-red-200 bg-red-50">
        <AlertDescription className="text-red-800">
          {error}
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="relative w-full">
      {isLoading && (
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 z-10">
          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
        </div>
      )}
      {!isLoading && (
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 z-10">
          <MapPin className="w-4 h-4 text-green-600" />
        </div>
      )}
      <Input
        ref={inputRef}
        type="text"
        placeholder={isLoading ? "Loading Google Maps..." : placeholder}
        className={`w-full pl-10 ${!isLoading ? 'border-green-500 focus:border-green-600' : ''}`}
        disabled={isLoading}
        value={inputValue}
        onChange={(e) => {
          // Skip state update if autocomplete is currently selecting a place
          if (!isSelectingFromAutocomplete.current) {
            setInputValue(e.target.value);
          }
        }}
        onKeyDown={(e) => {
          // Prevent form submission when autocomplete dropdown is open
          if (e.key === 'Enter' && document.querySelector('.pac-container:not([style*="display: none"])')) {
            e.preventDefault();
            e.stopPropagation();
          }
        }}
      />
      
      <style>{`
        .pac-container {
          background-color: white;
          border-radius: 8px;
          box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
          border: 1px solid #e5e7eb;
          margin-top: 4px;
          font-family: inherit;
          z-index: 100000 !important;
        }
        
        .pac-item {
          padding: 12px 16px;
          cursor: pointer;
          border-top: 1px solid #f3f4f6;
          font-size: 14px;
          line-height: 1.5;
        }
        
        .pac-item:first-child {
          border-top: none;
        }
        
        .pac-item:hover {
          background-color: #f9fafb;
        }
        
        .pac-item-selected,
        .pac-item-selected:hover {
          background-color: #eff6ff;
        }
        
        .pac-icon {
          display: none;
        }
        
        .pac-item-query {
          font-weight: 500;
          color: #111827;
        }
        
        .pac-matched {
          font-weight: 600;
          color: #2563eb;
        }
      `}</style>
    </div>
  );
}