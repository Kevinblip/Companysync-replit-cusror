import React, { useState, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectSeparator,
} from "@/components/ui/select";
import { Plus, X } from "lucide-react";

// Predefined customer groups
const PREDEFINED_GROUPS = [
  "Retail Sales",
  "Insurance Claims",
  "Water Mitigation",
  "Fire Mitigation",
  "Gutters",
  "Siding",
  "Windows & Doors",
  "Roofing",
  "Remodeling",
  "VIP",
  "Commercial",
  "Residential"
];

export default function CustomerGroupSelect({ value, onChange, companyId }) {
  const [customGroups, setCustomGroups] = useState([]);
  const [showAddCustom, setShowAddCustom] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");

  // Load custom groups from localStorage on mount
  useEffect(() => {
    if (companyId) {
      const saved = localStorage.getItem(`custom_customer_groups_${companyId}`);
      if (saved) {
        setCustomGroups(JSON.parse(saved));
      }
    }
  }, [companyId]);

  const allGroups = [...PREDEFINED_GROUPS, ...customGroups].sort();

  const handleAddCustomGroup = () => {
    const trimmed = newGroupName.trim();
    if (!trimmed) return;
    
    if (allGroups.some(g => g.toLowerCase() === trimmed.toLowerCase())) {
      alert("A group with this name already exists.");
      return;
    }

    const updated = [...customGroups, trimmed];
    setCustomGroups(updated);
    
    if (companyId) {
      localStorage.setItem(`custom_customer_groups_${companyId}`, JSON.stringify(updated));
    }
    
    onChange(trimmed);
    setNewGroupName("");
    setShowAddCustom(false);
  };

  const handleDeleteCustomGroup = (groupName) => {
    if (!window.confirm(`Delete custom group "${groupName}"? Customers with this group will keep their assignment.`)) {
      return;
    }
    
    const updated = customGroups.filter(g => g !== groupName);
    setCustomGroups(updated);
    
    if (companyId) {
      localStorage.setItem(`custom_customer_groups_${companyId}`, JSON.stringify(updated));
    }
    
    if (value === groupName) {
      onChange("");
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex gap-2 items-start">
        <Select value={value || ""} onValueChange={onChange}>
          <SelectTrigger className="flex-1">
            <SelectValue placeholder="Select group..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={null}>No Group</SelectItem>
            <SelectSeparator />
            <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 uppercase sticky top-0 bg-white">
              Standard Groups
            </div>
            {PREDEFINED_GROUPS.map(group => (
              <SelectItem key={group} value={group}>
                {group}
              </SelectItem>
            ))}
            {customGroups.length > 0 && (
              <>
                <SelectSeparator />
                <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 uppercase sticky top-0 bg-white">
                  Custom Groups
                </div>
                {customGroups.map(group => (
                  <SelectItem key={group} value={group}>
                    {group}
                  </SelectItem>
                ))}
              </>
            )}
          </SelectContent>
        </Select>
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={() => setShowAddCustom(!showAddCustom)}
          title="Add custom group"
        >
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {showAddCustom && (
        <div className="p-3 border rounded-lg bg-gray-50 space-y-3">
          <div className="flex gap-2">
            <Input
              placeholder="New group name"
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddCustomGroup();
                }
              }}
              autoFocus
            />
            <Button onClick={handleAddCustomGroup} size="sm" disabled={!newGroupName.trim()}>
              Add
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => {
                setShowAddCustom(false);
                setNewGroupName("");
              }}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {customGroups.length > 0 && (
            <div className="space-y-1">
              <p className="text-xs font-semibold text-gray-600">Manage Custom Groups:</p>
              {customGroups.map(group => (
                <div key={group} className="flex items-center justify-between p-2 bg-white rounded border text-sm">
                  <span>{group}</span>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => handleDeleteCustomGroup(group)}
                    className="h-6 w-6 p-0 text-red-600 hover:bg-red-50"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}