import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Gift, X, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function TrialReminderBanner({ user, myCompany }) {
  const navigate = useNavigate();
  const [dismissed, setDismissed] = useState(false);

  if (!myCompany || !user || dismissed) return null;

  // Don't show for legacy unlimited accounts
  if (myCompany.company_name?.includes('CompanySync') || 
      myCompany.company_name?.includes('YICN') || 
      myCompany.company_name?.includes('Insurance Claims Network')) {
    return null;
  }

  // Only show for trial status
  if (myCompany.subscription_status !== 'trial') return null;

  // Calculate days remaining
  const trialEndDate = myCompany.trial_ends_at ? new Date(myCompany.trial_ends_at) : null;
  if (!trialEndDate) return null;

  const today = new Date();
  const daysRemaining = Math.ceil((trialEndDate - today) / (1000 * 60 * 60 * 24));

  // Don't show if more than 10 days left
  if (daysRemaining > 10) return null;

  const handleAddCard = async () => {
    // Find the current plan to get the priceId
    const plans = [
      { name: 'freelance', priceId: 'price_1QOXhVCAqGydUaCs6leqFBKd' },
      { name: 'business', priceId: 'price_1QOXj1CAqGydUaCsPckcfKaI' },
      { name: 'enterprise', priceId: 'price_1QOXk9CAqGydUaCszdArEqb3' }
    ];

    const currentPlan = plans.find(p => p.name === myCompany.subscription_plan);
    if (!currentPlan) {
      alert('Plan not found. Please contact support.');
      return;
    }

    try {
      const response = await base44.functions.invoke('createCheckoutSession', {
        priceId: currentPlan.priceId,
        mode: 'subscription',
        companyId: myCompany.id,
        planName: myCompany.subscription_plan,
        metadata: { extend_trial: '7' }
      });

      if (response.data.url) {
        window.location.href = response.data.url;
      }
    } catch (error) {
      alert('Failed to start checkout: ' + error.message);
    }
  };

  return (
    <Alert className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-300 mb-6 relative">
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-3 right-3 text-gray-400 hover:text-gray-600"
      >
        <X className="w-4 h-4" />
      </button>
      
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0">
          <Gift className="w-6 h-6 text-white" />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="font-bold text-lg text-gray-900">
              🎁 Get 7 Extra Trial Days - FREE!
            </h3>
            <Badge className="bg-red-500 text-white">Limited Time</Badge>
          </div>
          
          <AlertDescription className="text-gray-700 mb-4">
            <p className="mb-2">
              <strong>Your trial ends in {daysRemaining} day{daysRemaining !== 1 ? 's' : ''}.</strong> Add your payment details now and we'll extend your trial by <strong className="text-purple-600">7 extra days</strong> - completely FREE!
            </p>
            <div className="flex items-center gap-4 text-sm">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4 text-purple-600" />
                Trial extended to {new Date(trialEndDate.getTime() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}
              </span>
              <span className="text-gray-600">• No charge until trial ends</span>
              <span className="text-gray-600">• Cancel anytime</span>
            </div>
          </AlertDescription>

          <div className="flex gap-3">
            <Button 
              onClick={handleAddCard}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Add Payment & Get 7 Free Days
            </Button>
            <Button 
              variant="outline"
              onClick={() => setDismissed(true)}
            >
              Remind Me Later
            </Button>
          </div>
        </div>
      </div>
    </Alert>
  );
}