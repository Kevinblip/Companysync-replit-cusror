import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LayoutDashboard, Users, Calendar, UserPlus, Menu } from "lucide-react";

export default function MobileNav({ onMenuClick }) {
  const location = useLocation();
  
  const navItems = [
    { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
    { title: "Customers", url: createPageUrl("Customers"), icon: Users },
    { title: "Leads", url: createPageUrl("Leads"), icon: UserPlus },
    { title: "Calendar", url: createPageUrl("Calendar"), icon: Calendar },
    { title: "More", icon: Menu, isAction: true },
  ];
  
  const isActive = (url) => location.pathname === url;
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-2xl z-50">
      <div className="flex items-center justify-around h-14">
        {navItems.map((item) => (
          item.isAction ? (
            <button
              key={item.title}
              onClick={() => {
                if (onMenuClick) {
                  onMenuClick();
                }
              }}
              className="flex flex-col items-center justify-center flex-1 h-full text-gray-600 hover:text-blue-600 transition-colors active:bg-gray-100 min-w-[64px]"
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] mt-0.5 font-medium">{item.title}</span>
            </button>
          ) : (
            <Link
              key={item.title}
              to={item.url}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors min-w-[64px] ${
                isActive(item.url)
                  ? "text-blue-600 font-semibold"
                  : "text-gray-600 hover:text-blue-600"
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">{item.title}</span>
            </Link>
          )
        ))}
      </div>
    </div>
  );
}