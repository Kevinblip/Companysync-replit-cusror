import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, RefreshCw, Mic, StopCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const LiveCameraCapture = ({ onUpload, onVoiceNote }) => {
    const videoRef = useRef(null);
    const canvasRef = useRef(null);
    const recognitionRef = useRef(null);
    const audioRef = useRef(null);
    const [stream, setStream] = useState(null);
    const [facingMode, setFacingMode] = useState('environment');
    const [isCameraReady, setIsCameraReady] = useState(false);
    const [isRecordingVoice, setIsRecordingVoice] = useState(false);
    const [uploadQueue, setUploadQueue] = useState([]);

    // Create better camera shutter sound
    useEffect(() => {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        const playShutterSound = () => {
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.1);
        };
        
        audioRef.current = { play: playShutterSound };
    }, []);

    const startCamera = useCallback(async (mode) => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        try {
            const newStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: { ideal: mode } }
            });
            if (videoRef.current) {
                videoRef.current.srcObject = newStream;
                await videoRef.current.play();
            }
            setStream(newStream);
            setIsCameraReady(true);
        } catch (err) {
            console.error("Error accessing camera:", err);
            setIsCameraReady(false);
        }
    }, [stream]);

    useEffect(() => {
        startCamera(facingMode);
        return () => {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
            if (recognitionRef.current) {
                recognitionRef.current.stop();
            }
        };
    }, [facingMode]);

    const takePhoto = async () => {
        if (!videoRef.current || !isCameraReady) return;
        
        // Play camera shutter sound
        try {
            audioRef.current?.play();
        } catch (e) {
            console.log('Audio play failed');
        }
        
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext('2d');
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Show brief flash effect on video element
        if (videoRef.current) {
            videoRef.current.style.filter = 'brightness(1.8)';
            setTimeout(() => {
                if (videoRef.current) {
                    videoRef.current.style.filter = 'brightness(1)';
                }
            }, 150);
        }
        
        // Convert to blob and upload in background
        canvas.toBlob(async (blob) => {
            if (!blob) return;
            
            const file = new File([blob], `capture-${Date.now()}.jpg`, { type: 'image/jpeg' });
            
            setUploadQueue(prev => [...prev, file.name]);
            
            try {
                await onUpload({ file, caption: '' });
                setUploadQueue(prev => prev.filter(name => name !== file.name));
            } catch (error) {
                console.error('Upload failed:', error);
                setUploadQueue(prev => prev.filter(name => name !== file.name));
            }
        }, 'image/jpeg', 0.9);
    };

    const switchCamera = () => {
        setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
    };

    const handleVoiceNote = () => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            alert('Voice recognition is not supported in your browser. Please try Google Chrome or Safari.');
            return;
        }

        if (isRecordingVoice) {
            recognitionRef.current?.stop();
            setIsRecordingVoice(false);
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
            setIsRecordingVoice(true);
        };
        
        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            if(transcript && onVoiceNote) {
                onVoiceNote(transcript + ' ');
            }
        };

        recognition.onend = () => {
            setIsRecordingVoice(false);
        };
        
        recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            setIsRecordingVoice(false);
            if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
                alert('Voice recognition blocked. Please allow microphone access in your browser settings.');
            } else {
                alert(`Voice recognition error: ${event.error}. Please try again.`);
            }
        };

        try {
            recognition.start();
            recognitionRef.current = recognition;
        } catch (e) {
            console.error("Could not start recognition service:", e);
            alert("Could not start voice recognition. It might be already active or blocked by your browser.");
        }
    };

    return (
        <Card className="mb-4">
            <CardContent className="p-2 md:p-4 space-y-4">
                <div className="relative w-full h-[50vh] md:h-96 bg-black rounded-lg overflow-hidden flex items-center justify-center text-white">
                    <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                        style={{ transition: 'filter 0.15s ease-out' }}
                    />
                    
                    {!isCameraReady && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/80">
                            <div className="text-center">
                                <Camera className="w-12 h-12 mx-auto mb-2 animate-pulse" />
                                <p className="text-sm">Starting camera...</p>
                            </div>
                        </div>
                    )}
                    
                    {uploadQueue.length > 0 && (
                        <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs flex items-center gap-2">
                            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                            Uploading {uploadQueue.length} photo{uploadQueue.length > 1 ? 's' : ''}...
                        </div>
                    )}
                    
                    <div className="absolute top-2 right-2 flex gap-2">
                        <Button variant="ghost" size="icon" className="text-white bg-black/30 hover:bg-black/50" onClick={switchCamera}>
                            <RefreshCw className="w-5 h-5" />
                        </Button>
                    </div>

                    <div className="absolute bottom-2 inset-x-0 flex justify-center items-center gap-4 md:gap-8">
                        <Button 
                            variant="ghost" 
                            className={`text-white/80 ${isRecordingVoice ? 'text-red-500 animate-pulse' : ''}`} 
                            onClick={handleVoiceNote} 
                            size="sm"
                        >
                            {isRecordingVoice ? <StopCircle className="w-5 h-5 md:mr-2" /> : <Mic className="w-5 h-5 md:mr-2" />}
                            <span className="hidden md:inline">{isRecordingVoice ? 'Stop' : 'Voice'}</span>
                        </Button>
                        
                        <Button
                            size="icon"
                            className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-white text-black hover:bg-gray-200 border-4 border-black/20"
                            onClick={takePhoto}
                            disabled={!isCameraReady}
                        >
                            <Camera className="w-7 h-7 md:w-8 md:h-8" />
                        </Button>
                        
                        <div className="w-24 absolute right-2 bottom-1" />
                    </div>
                </div>
                <canvas ref={canvasRef} className="hidden" />
            </CardContent>
        </Card>
    );
};

export default LiveCameraCapture;