import { jsPDF } from 'jspdf';

export async function generateInspectionPDF({
  job,
  myCompany,
  photoMedia,
  sectionNotes,
  linkedEstimate,
  inspectorSignature
}) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - (margin * 2);

  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 30, g: 58, b: 138 };
  };

  const primaryColor = myCompany?.brand_primary_color 
    ? hexToRgb(myCompany.brand_primary_color) 
    : { r: 30, g: 58, b: 138 };

  // Cover page
  let y = 20;
  if (myCompany?.logo_url) {
    try {
      doc.addImage(myCompany.logo_url, 'PNG', 18, y, 60, 25);
      y += 30;
    } catch (error) {
      console.log('⚠️ Logo error');
    }
  }

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text(myCompany?.company_name || 'Company Name', margin, y);
  y += 8;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(60, 60, 60);

  if (myCompany?.address) {
    doc.text(myCompany.address, margin, y);
    y += 5;
  }

  if (myCompany?.city || myCompany?.state || myCompany?.zip) {
    const cityStateZip = [myCompany?.city, myCompany?.state, myCompany?.zip].filter(Boolean).join(', ');
    doc.text(cityStateZip, margin, y);
    y += 5;
  }

  if (myCompany?.phone) {
    doc.text(`Phone: ${myCompany.phone}`, margin, y);
    y += 5;
  }

  if (myCompany?.email) {
    doc.text(`Email: ${myCompany.email}`, margin, y);
    y += 5;
  }

  if (myCompany?.company_website) {
    doc.text(`Web: ${myCompany.company_website}`, margin, y);
    y += 5;
  }

  // Title section
  y = 80;
  doc.setFillColor(primaryColor.r, primaryColor.g, primaryColor.b);
  doc.rect(0, y, pageWidth, 25, 'F');
  doc.setFontSize(28);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('INSPECTION REPORT', pageWidth / 2, y + 16, { align: 'center' });

  // Property details
  y = 125;
  doc.setFillColor(245, 247, 250);
  doc.rect(margin, y, contentWidth, 50, 'F');
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('PROPERTY INFORMATION', margin + 5, y + 8);
  y += 15;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(60, 60, 60);
  doc.text(`Property Address: ${job.property_address || 'N/A'}`, margin + 5, y);
  y += 5;
  doc.text(`Client Name: ${job.client_name || 'N/A'}`, margin + 5, y);
  y += 5;
  if (job.client_email) {
    doc.text(`Client Email: ${job.client_email}`, margin + 5, y);
    y += 5;
  }
  if (job.client_phone) {
    doc.text(`Client Phone: ${job.client_phone}`, margin + 5, y);
    y += 5;
  }
  doc.text(`Inspection Date: ${new Date(job.inspection_date || job.created_date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`, margin + 5, y);
  y += 5;
  if (job.insurance_claim_number) {
    doc.text(`Claim Number: ${job.insurance_claim_number}`, margin + 5, y);
    y += 5;
  }
  if (job.insurance_company) {
    doc.text(`Insurance Company: ${job.insurance_company}`, margin + 5, y);
  }

  // Group images by section
  const imagesBySection = {};
  photoMedia.forEach(item => {
    const section = item.section || 'Other';
    if (!imagesBySection[section]) {
      imagesBySection[section] = [];
    }
    imagesBySection[section].push(item);
  });

  // Add sections with photos
  for (const [section, images] of Object.entries(imagesBySection)) {
    doc.addPage();
    doc.setFillColor(primaryColor.r, primaryColor.g, primaryColor.b);
    doc.rect(0, 10, pageWidth, 12, 'F');
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text(section, pageWidth / 2, 18, { align: 'center' });

    let yPos = 30;

    if (sectionNotes && sectionNotes[section]) {
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(60, 60, 60);
      const lines = doc.splitTextToSize(sectionNotes[section], contentWidth);
      doc.text(lines, margin, yPos);
      yPos += (lines.length * 4) + 8;
    }

    for (const item of images) {
      if (yPos > pageHeight - 100) {
        doc.addPage();
        doc.setFillColor(primaryColor.r, primaryColor.g, primaryColor.b);
        doc.rect(0, 10, pageWidth, 12, 'F');
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(255, 255, 255);
        doc.text(`${section} (continued)`, pageWidth / 2, 18, { align: 'center' });
        yPos = 30;
      }

      try {
        const response = await fetch(item.file_url);
        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();
        const bytes = new Uint8Array(arrayBuffer);
        const binaryString = Array.from(bytes).map(byte => String.fromCharCode(byte)).join('');
        const base64String = btoa(binaryString);
        const contentType = response.headers.get('content-type') || 'image/jpeg';
        let format = contentType.includes('png') ? 'PNG' : 'JPEG';
        const imageDataUrl = `data:${contentType};base64,${base64String}`;
        const imgWidth = contentWidth;
        const imgHeight = 100;
        doc.setDrawColor(200, 200, 200);
        doc.setLineWidth(0.3);
        doc.rect(margin, yPos, imgWidth, imgHeight);
        doc.addImage(imageDataUrl, format, margin + 1, yPos + 1, imgWidth - 2, imgHeight - 2);
        yPos += imgHeight + 5;
        if (item.caption) {
          doc.setFontSize(7);
          doc.setFont('helvetica', 'normal');
          doc.setTextColor(80, 80, 80);
          const captionLines = doc.splitTextToSize(item.caption, contentWidth);
          doc.text(captionLines, margin, yPos);
          yPos += (captionLines.length * 3) + 10;
          doc.setTextColor(0);
        } else {
          yPos += 10;
        }
      } catch (error) {
        console.error(`❌ Error adding image:`, error);
        yPos += 10;
      }
    }
  }

  // Add estimate section if linked
  if (linkedEstimate) {
    doc.addPage();
    doc.setFillColor(primaryColor.r, primaryColor.g, primaryColor.b);
    doc.rect(0, 10, pageWidth, 12, 'F');
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('ESTIMATE SUMMARY', pageWidth / 2, 18, { align: 'center' });

    let yPos = 35;

    // Add company logo on estimate page
    if (myCompany?.logo_url) {
      try {
        doc.addImage(myCompany.logo_url, 'PNG', margin, yPos, 40, 16);
        yPos += 20;
      } catch (error) {
        console.log('⚠️ Logo error on estimate');
      }
    }

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text(myCompany?.company_name || 'Company Name', margin, yPos);
    yPos += 5;
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 60, 60);
    if (myCompany?.address) {
      doc.text(myCompany.address, margin, yPos);
      yPos += 4;
    }

    let rightY = yPos - 24;
    doc.setFontSize(20);
    doc.setTextColor(primaryColor.r, primaryColor.g, primaryColor.b);
    doc.setFont('helvetica', 'bold');
    doc.text('ESTIMATE', pageWidth - margin, rightY, { align: 'right' });
    rightY += 6;
    doc.setFontSize(9);
    doc.setTextColor(100, 100, 100);
    doc.setFont('helvetica', 'normal');
    doc.text(`# ${linkedEstimate.estimate_number}`, pageWidth - margin, rightY, { align: 'right' });

    yPos = Math.max(yPos, rightY) + 10;

    const items = linkedEstimate.items || linkedEstimate.line_items || [];

    if (items.length > 0) {
      // Table header
      doc.setFillColor(primaryColor.r, primaryColor.g, primaryColor.b);
      doc.rect(margin, yPos, contentWidth, 8, 'F');

      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(255, 255, 255);
      doc.text('#', margin + 2, yPos + 5.5);
      doc.text('Description', margin + 10, yPos + 5.5);
      doc.text('Qty', 115, yPos + 5.5, { align: 'right' });
      doc.text('Unit', 130, yPos + 5.5);
      doc.text('Rate', 150, yPos + 5.5, { align: 'right' });
      doc.text('Amount', pageWidth - margin - 2, yPos + 5.5, { align: 'right' });

      yPos += 10;

      let subtotal = 0;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(0, 0, 0);

      items.forEach((item, index) => {
        if (yPos > pageHeight - 40) {
          doc.addPage();
          yPos = 20;
        }

        if (index % 2 === 0) {
          doc.setFillColor(248, 250, 252);
          doc.rect(margin, yPos - 3, contentWidth, 6, 'F');
        }

        doc.setFontSize(7);
        doc.text(String(index + 1), margin + 2, yPos + 2);

        const desc = item.description || 'Item';
        const descLines = doc.splitTextToSize(desc, 95);
        doc.text(descLines[0], margin + 10, yPos + 2);

        const qty = parseFloat(item.quantity) || 0;
        const rate = parseFloat(item.rate) || 0;
        const amount = parseFloat(item.amount) || 0;

        doc.text(qty % 1 === 0 ? qty.toFixed(0) : qty.toFixed(2), 115, yPos + 2, { align: 'right' });
        doc.text(item.unit || 'EA', 130, yPos + 2);
        doc.text(`$${rate.toFixed(2)}`, 150, yPos + 2, { align: 'right' });
        doc.text(`$${amount.toFixed(2)}`, pageWidth - margin - 2, yPos + 2, { align: 'right' });

        subtotal += amount;
        yPos += 6;
      });

      // Total line
      yPos += 5;
      doc.setDrawColor(200, 200, 200);
      doc.line(margin, yPos, pageWidth - margin, yPos);
      yPos += 8;

      doc.setFontSize(11);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(primaryColor.r, primaryColor.g, primaryColor.b);
      doc.text('TOTAL', 145, yPos);
      doc.text(`$${subtotal.toFixed(2)}`, pageWidth - margin - 2, yPos, { align: 'right' });

      // Add disclaimer after estimate
      yPos += 15;
      if (yPos > pageHeight - 80) {
        doc.addPage();
        yPos = 20;
      }

      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(0, 0, 0);
      doc.text('DISCLAIMER:', margin, yPos);
      yPos += 5;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(40, 40, 40);
      const disclaimerText = `This estimate is valid for 30 days and based on a deposit of 50% upon acceptance with the remaining balance due upon completion. The estimate covers visible and disclosed damage only. Additional repairs discovered during work will require supplemental approval. Actual costs may vary based on unforeseen conditions. This estimate represents one professional opinion and is for informational purposes only. ${myCompany?.company_name || 'The Company'} and its representatives are held harmless from reliance on this estimate.`;
      const disclaimerLines = doc.splitTextToSize(disclaimerText, contentWidth);
      disclaimerLines.forEach(line => {
        if (yPos > pageHeight - 20) {
          doc.addPage();
          yPos = 20;
        }
        doc.text(line, margin, yPos);
        yPos += 3.5;
      });
    }
  }

  // Inspector signature
  if (inspectorSignature) {
    doc.addPage();
    doc.setFillColor(primaryColor.r, primaryColor.g, primaryColor.b);
    doc.rect(0, 10, pageWidth, 12, 'F');
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('INSPECTOR CERTIFICATION', pageWidth / 2, 18, { align: 'center' });

    let yPos = 40;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 60, 60);
    const certText = 'I hereby certify that this inspection report accurately reflects the conditions observed at the time of inspection.';
    const certLines = doc.splitTextToSize(certText, contentWidth);
    doc.text(certLines, margin, yPos);
    yPos += (certLines.length * 5) + 15;

    doc.setFillColor(245, 247, 250);
    doc.rect(margin, yPos, 90, 45, 'F');
    doc.setDrawColor(200, 200, 200);
    doc.rect(margin, yPos, 90, 45);

    yPos += 5;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(80, 80, 80);
    doc.text('Inspector Signature:', margin + 5, yPos + 3);

    try {
      doc.addImage(inspectorSignature, 'PNG', margin + 5, yPos + 6, 70, 25);
    } catch (error) {
      console.error('❌ Error adding signature:', error);
    }

    yPos += 35;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`Date: ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`, margin + 5, yPos);
  }

  // Add footer to all pages
  const totalPages = doc.internal.pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(150, 150, 150);

    const footerText = `${myCompany?.company_name || 'Inspection Report'} | ${myCompany?.phone || ''} | ${myCompany?.email || ''}`;
    doc.text(footerText, pageWidth / 2, pageHeight - 13, { align: 'center' });
    doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, pageHeight - 8, { align: 'center' });
  }

  return doc;
}