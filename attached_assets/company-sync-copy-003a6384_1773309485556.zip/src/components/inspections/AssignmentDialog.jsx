import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Loader2, Send, CheckCircle, UserPlus, Search } from 'lucide-react';
import { motion } from 'framer-motion';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { GoogleAddressAutocomplete } from '@/components/GoogleAddressAutocomplete';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import { Badge } from '@/components/ui/badge';

const SectionTitle = ({ children }) => (
    <h3 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">{children}</h3>
);

export default function AssignmentDialog({ isOpen, onOpenChange, existingJob = null, onAssignmentSent }) {
    const [contactSource, setContactSource] = useState('new');
    const [selectedLead, setSelectedLead] = useState(null);
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [openLeadSearch, setOpenLeadSearch] = useState(false);
    const [openCustomerSearch, setOpenCustomerSearch] = useState(false);
    const [openStormSearch, setOpenStormSearch] = useState(false);
    
    const [user, setUser] = useState(null);

    useEffect(() => {
        base44.auth.me().then(setUser).catch(() => {});
    }, []);

    const [formData, setFormData] = useState({
        property_address: '',
        property_type: 'Residential',
        inspection_type: 'Property Damage Assessment',
        access_instructions: '',
        client_name: '',
        client_phone: '',
        client_email: '',
        assigned_to_email: user?.email || '',
        priority: 'Normal',
        scheduled_date: '',
        inspection_time: '',
        damage_type: '',
        date_of_loss: '',
        insurance_claim_number: '',
        special_instructions: '',
        notes: '',
        status: 'assigned',
        lead_source: 'direct_call',
        ladder_assist_needed: false,
        ladder_assistant_name: '',
        ladder_assist_cost: 100,
        sales_rep_email: '',
        related_estimate_id: '',
        related_storm_event_id: '',
    });

    const [googleMapsApiKey, setGoogleMapsApiKey] = useState('');
    const [googleMapsLoaded, setGoogleMapsLoaded] = useState(false);
    const [createLead, setCreateLead] = useState(true);
    const [createCalendarEvent, setCreateCalendarEvent] = useState(true);
    const [createTask, setCreateTask] = useState(true);

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: () => base44.entities.Lead.list('-created_date'),
        initialData: [],
    });

    const { data: customers = [] } = useQuery({
        queryKey: ['customers'],
        queryFn: () => base44.entities.Customer.list('-created_date'),
        initialData: [],
    });

    const { data: estimates = [] } = useQuery({
        queryKey: ['estimates'],
        queryFn: () => base44.entities.Estimate.list('-created_date'),
        initialData: [],
    });

    const [searchQuery, setSearchQuery] = useState("");

    const { data: stormEvents = [], isLoading: isLoadingStorms } = useQuery({
        queryKey: ['storm-events-all'],
        queryFn: () => base44.entities.StormEvent.list('-start_time', 5000),
        initialData: [],
    });

    const filteredStorms = React.useMemo(() => {
        if (!searchQuery) return stormEvents;
        const lowerQuery = searchQuery.toLowerCase();
        return stormEvents.filter(storm => {
            const titleMatch = storm.title?.toLowerCase().includes(lowerQuery);
            const areaMatch = storm.affected_areas?.some(area => area.toLowerCase().includes(lowerQuery));
            const dateMatch = storm.start_time && format(new Date(storm.start_time), 'yyyy-MM-dd').includes(lowerQuery);
            return titleMatch || areaMatch || dateMatch;
        });
    }, [stormEvents, searchQuery]);

    useEffect(() => {
        const loadGoogleMaps = async () => {
            // Check if already loaded
            if (window.google && window.google.maps && window.google.maps.places) {
                setGoogleMapsLoaded(true);
                return;
            }

            try {
                const response = await base44.functions.invoke('getGoogleMapsApiKey');
                const { apiKey } = response.data;

                if (!apiKey) {
                    throw new Error('Google Maps API key not configured');
                }

                setGoogleMapsApiKey(apiKey);

                // Load the Google Maps script
                const script = document.createElement('script');
                script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
                script.async = true;
                script.defer = true;

                script.onload = () => {
                    console.log('✅ Google Maps loaded in AssignmentDialog');
                    setGoogleMapsLoaded(true);
                };

                script.onerror = () => {
                    console.error('❌ Failed to load Google Maps in AssignmentDialog');
                };

                document.head.appendChild(script);
            } catch (error) {
                console.error('Error loading Google Maps:', error);
            }
        };

        loadGoogleMaps();
    }, []);

    useEffect(() => {
        if (existingJob) {
            setFormData({
                property_address: existingJob.property_address || '',
                property_type: existingJob.property_type || 'Residential',
                inspection_type: existingJob.inspection_type || 'Property Damage Assessment',
                access_instructions: existingJob.access_instructions || '',
                client_name: existingJob.client_name || '',
                client_phone: existingJob.client_phone || '',
                client_email: existingJob.client_email || '',
                assigned_to_email: existingJob.assigned_to_email || user?.email || '',
                priority: existingJob.priority || 'Normal',
                scheduled_date: existingJob.scheduled_date || '',
                inspection_time: existingJob.inspection_time || '',
                damage_type: existingJob.damage_type || '',
                date_of_loss: existingJob.date_of_loss || '',
                insurance_claim_number: existingJob.insurance_claim_number || '',
                special_instructions: existingJob.special_instructions || '',
                notes: existingJob.notes || '',
                status: existingJob.status || 'assigned',
                lead_source: existingJob.lead_source || 'direct_call',
                ladder_assist_needed: existingJob.ladder_assist_needed || false,
                ladder_assistant_name: existingJob.ladder_assistant_name || '',
                ladder_assist_cost: existingJob.ladder_assist_cost || 100,
                sales_rep_email: existingJob.sales_rep_email || '',
                related_estimate_id: existingJob.related_estimate_id || '',
                related_storm_event_id: existingJob.related_storm_event_id || '',
            });
            
            if (existingJob.related_customer_id) {
                setContactSource('customer');
                const customer = customers.find(c => c.id === existingJob.related_customer_id);
                setSelectedCustomer(customer);
            } else if (existingJob.related_lead_id) {
                setContactSource('lead');
                const lead = leads.find(l => l.id === existingJob.related_lead_id);
                setSelectedLead(lead);
            } else {
                setContactSource('new');
            }
        } else {
            setFormData({
                property_address: '',
                property_type: 'Residential',
                inspection_type: 'Property Damage Assessment',
                access_instructions: '',
                client_name: '',
                client_phone: '',
                client_email: '',
                assigned_to_email: '',
                priority: 'Normal',
                scheduled_date: '',
                inspection_time: '',
                damage_type: '',
                date_of_loss: '',
                insurance_claim_number: '',
                special_instructions: '',
                notes: '',
                status: 'assigned',
                lead_source: 'direct_call',
                ladder_assist_needed: false,
                ladder_assistant_name: '',
                ladder_assist_cost: 100,
                sales_rep_email: '',
                related_estimate_id: '',
                related_storm_event_id: '',
                });
                setContactSource('new');
                setSelectedLead(null);
                setSelectedCustomer(null);
                setCreateLead(true);
                }
                }, [existingJob, isOpen, customers, leads, user]);

    useEffect(() => {
        if (selectedCustomer && contactSource === 'customer') {
            let fullAddress = '';
            if (selectedCustomer.address) {
                fullAddress = selectedCustomer.address;
            } else {
                const parts = [
                    selectedCustomer.street,
                    selectedCustomer.city,
                    selectedCustomer.state,
                    selectedCustomer.zip
                ].filter(Boolean);
                fullAddress = parts.join(', ');
            }

            setFormData(prev => ({
                ...prev,
                client_name: selectedCustomer.name,
                client_phone: selectedCustomer.phone || '',
                client_email: selectedCustomer.email || '',
                property_address: fullAddress,
                insurance_claim_number: selectedCustomer.insurance_claim_number || '',
            }));
            setCreateLead(false);
        }
    }, [selectedCustomer, contactSource]);

    useEffect(() => {
        if (selectedLead && contactSource === 'lead') {
            let fullAddress = '';
            if (selectedLead.address) {
                fullAddress = selectedLead.address;
            } else {
                const parts = [
                    selectedLead.street,
                    selectedLead.city,
                    selectedLead.state,
                    selectedLead.zip
                ].filter(Boolean);
                fullAddress = parts.join(', ');
            }

            setFormData(prev => ({
                ...prev,
                client_name: selectedLead.name,
                client_phone: selectedLead.phone || '',
                client_email: selectedLead.email || '',
                property_address: fullAddress,
                insurance_claim_number: selectedLead.insurance_claim_number || '',
            }));
            setCreateLead(false);
        }
    }, [selectedLead, contactSource]);

    const { data: users = [] } = useQuery({
        queryKey: ['staffUsers'],
        queryFn: () => base44.entities.User.list(),
    });

    const { data: myCompany } = useQuery({
        queryKey: ['myCompany'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const companies = await base44.entities.Company.filter({ created_by: user.email });
            return companies[0] || null;
        },
        staleTime: Infinity,
    });

    const createJobMutation = useMutation({
        mutationFn: async (newJobData) => {
            let job;
            let leadId = selectedLead?.id || null;
            let customerId = selectedCustomer?.id || null;
            let calendarEventId = null;
            let taskId = null;

            try {
                // Resolve company ID first
                let companyId = myCompany?.id;
                const user = await base44.auth.me();
                
                if (!companyId) {
                    const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: user.email });
                    if (staffProfiles && staffProfiles.length > 0) {
                        companyId = staffProfiles[0].company_id;
                    } else {
                        const companies = await base44.entities.Company.filter({ created_by: user.email });
                        if (companies && companies.length > 0) {
                            companyId = companies[0].id;
                        }
                    }
                }

                const jobDataWithLinks = {
                    ...newJobData,
                    related_lead_id: leadId,
                    related_customer_id: customerId,
                    company_id: companyId
                };

                if (existingJob) {
                    job = await base44.entities.InspectionJob.update(existingJob.id, jobDataWithLinks);
                } else {
                    job = await base44.entities.InspectionJob.create(jobDataWithLinks);
                }

                if (createLead && !existingJob && contactSource === 'new') {
                    try {
                        if (companyId) {
                            const addressParts = newJobData.property_address.split(',').map(s => s.trim());
                            const street = addressParts[0] || '';
                            const city = addressParts[1] || '';
                            const stateZip = addressParts[2] || '';
                            const [state, zip] = stateZip.split(' ').filter(Boolean);

                            // Create Lead
                            const lead = await base44.entities.Lead.create({
                                company_id: companyId,
                                name: newJobData.client_name,
                                email: newJobData.client_email || '',
                                phone: newJobData.client_phone || '',
                                street: street || newJobData.property_address,
                                city: city || '',
                                state: state || '',
                                zip: zip || '',
                                status: 'new',
                                source: newJobData.lead_source || 'other',
                                lead_source: `Inspection: ${newJobData.inspection_type}`,
                                notes: `Inspection scheduled for ${newJobData.scheduled_date || 'TBD'}.\nDamage Type: ${newJobData.damage_type || 'TBD'}\nPriority: ${newJobData.priority}`,
                                value: 0,
                                is_active: true,
                            });
                            leadId = lead.id;

                            // Also create Customer record
                            const customer = await base44.entities.Customer.create({
                                company_id: companyId,
                                name: newJobData.client_name,
                                email: newJobData.client_email || '',
                                phone: newJobData.client_phone || '',
                                street: street || newJobData.property_address,
                                city: city || '',
                                state: state || '',
                                zip: zip || '',
                                source: newJobData.lead_source || 'other',
                                notes: `Created from Inspection: ${newJobData.inspection_type}`,
                                is_active: true,
                            });
                            customerId = customer.id;

                            await base44.entities.InspectionJob.update(job.id, {
                                related_lead_id: leadId,
                                related_customer_id: customerId
                            });
                        }
                    } catch (leadError) {
                        console.error('Failed to create lead/customer (non-critical):', leadError);
                    }
                }

                if (createTask && newJobData.scheduled_date) {
                    try {
                        const user = await base44.auth.me();
                        const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: user.email });
                        let companyId = myCompany?.id;
                        
                        if (!companyId && staffProfiles && staffProfiles.length > 0) {
                            companyId = staffProfiles[0].company_id;
                        }

                        const boards = await base44.entities.TaskBoard.filter({ is_default: true, company_id: companyId });
                        const defaultBoard = boards[0];

                        if (defaultBoard) {
                            const task = await base44.entities.Task.create({
                                name: `Inspection: ${newJobData.client_name} - ${newJobData.property_address}`,
                                description: `Property Damage Assessment\n\nDamage Type: ${newJobData.damage_type || 'TBD'}\nDate of Loss: ${newJobData.date_of_loss || 'Unknown'}\nClaim #: ${newJobData.insurance_claim_number || 'N/A'}\n\n${newJobData.special_instructions || ''}`,
                                board_id: defaultBoard.id,
                                column: defaultBoard.columns[0]?.id || 'not_started',
                                priority: newJobData.priority === 'Urgent' ? 'high' : newJobData.priority === 'High' ? 'high' : 'medium',
                                start_date: newJobData.scheduled_date,
                                due_date: newJobData.scheduled_date,
                                assigned_to: newJobData.assigned_to_email,
                                assignees: newJobData.assigned_to_email ? [{
                                    email: newJobData.assigned_to_email,
                                    name: users.find(u => u.email === newJobData.assigned_to_email)?.full_name || newJobData.assigned_to_email,
                                    avatar: users.find(u => u.email === newJobData.assigned_to_email)?.avatar_url || ''
                                }] : [],
                                related_to: newJobData.client_name,
                                tags: ['inspection', newJobData.damage_type].filter(Boolean),
                                company_id: companyId,
                            });
                            taskId = task.id;

                            await base44.entities.InspectionJob.update(job.id, {
                                related_task_id: taskId
                            });
                        }
                    } catch (taskError) {
                        console.error('Failed to create task (non-critical):', taskError);
                    }
                }

                if (createCalendarEvent && newJobData.scheduled_date && newJobData.inspection_time) {
                    try {
                        const [hours, minutes] = newJobData.inspection_time.split(':');
                        const startDate = new Date(newJobData.scheduled_date);
                        startDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);
                        
                        const endDate = new Date(startDate);
                        endDate.setHours(startDate.getHours() + 2);

                        const calendarEvent = await base44.entities.CalendarEvent.create({
                            title: `Inspection: ${newJobData.client_name}`,
                            description: `📍 ${newJobData.property_address}\n\n👤 Client: ${newJobData.client_name}\n📞 ${newJobData.client_phone}\n\n🔍 Damage: ${newJobData.damage_type || 'Assessment'}\n⚡ Priority: ${newJobData.priority}\n\n${newJobData.special_instructions ? '📝 Special Instructions:\n' + newJobData.special_instructions : ''}`,
                            start_time: startDate.toISOString(),
                            end_time: endDate.toISOString(),
                            event_type: 'inspection',
                            assigned_to: newJobData.assigned_to_email,
                            related_customer: newJobData.client_name,
                            status: 'scheduled',
                            color: '#10b981',
                            send_email_notification: true,
                            send_sms_notification: false,
                        });
                        calendarEventId = calendarEvent.id;

                        await base44.entities.InspectionJob.update(job.id, {
                            calendar_event_id: calendarEventId
                        });
                    } catch (calendarError) {
                        console.error('Failed to create calendar event (non-critical):', calendarError);
                    }
                }

                try {
                    await base44.functions.invoke('sendInspectionAssignment', {
                        jobId: job.id,
                        inspectorEmail: newJobData.assigned_to_email
                    });
                } catch (emailError) {
                    console.error('Failed to send assignment email (non-critical):', emailError);
                }

                return { job, leadId, customerId, calendarEventId, taskId };
            } catch (error) {
                console.error('Error creating inspection job:', error);
                throw error;
            }
        },
        onSuccess: (data) => {
            const messages = ['✅ Inspection assigned successfully!'];
            if (data.leadId && contactSource === 'new') messages.push('✅ Lead created in CRM');
            if (data.taskId) messages.push('✅ Task created');
            if (data.calendarEventId) messages.push('✅ Added to calendar');
            if (selectedLead) messages.push(`✅ Linked to Lead: ${selectedLead.name}`);
            if (selectedCustomer) messages.push(`✅ Linked to Customer: ${selectedCustomer.name}`);
            
            alert(messages.join('\n'));
            onAssignmentSent(data.job);
        },
        onError: (error) => {
            console.error('Assignment error:', error);
            alert('❌ Failed to create assignment: ' + (error.message || 'Unknown error'));
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!formData.assigned_to_email) {
            alert('Please select an inspector to assign.');
            return;
        }
        createJobMutation.mutate(formData);
    };

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleSelectChange = (id, value) => {
        setFormData(prev => ({...prev, [id]: value}));
    };
    
    const handlePlaceSelected = (address) => {
        setFormData(prev => ({ ...prev, property_address: address }));
    };

    const handleInteractOutside = (e) => {
        const target = e.target;
        if (target.closest('.pac-container')) {
            e.preventDefault();
        }
    };

    const suggestedEstimates = estimates.filter(est =>
        est.customer_name?.toLowerCase().includes(formData.client_name?.toLowerCase() || '') ||
        est.property_address?.toLowerCase().includes(formData.property_address?.toLowerCase() || '')
    );

    const linkedEstimate = estimates.find(e => e.id === formData.related_estimate_id);
    const linkedStorm = stormEvents.find(s => s.id === formData.related_storm_event_id);

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange} modal={true}>
            <DialogContent 
                className="max-w-3xl max-h-[90vh] flex flex-col overflow-hidden"
                onInteractOutside={handleInteractOutside}
            >
                <DialogHeader>
                    <DialogTitle>{existingJob ? 'Edit' : 'Send'} Inspector Assignment</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6 overflow-y-auto px-1">
                    {!existingJob && (
                        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border-2 border-blue-200">
                            <SectionTitle>🔗 Link to CRM</SectionTitle>
                            <RadioGroup value={contactSource} onValueChange={setContactSource}>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <div className="flex items-center space-x-2 p-3 bg-white rounded border hover:border-blue-400 transition-colors">
                                        <RadioGroupItem value="new" id="new" />
                                        <Label htmlFor="new" className="cursor-pointer flex-1">
                                            <div className="font-semibold">New Contact</div>
                                            <div className="text-xs text-gray-500">Create new lead</div>
                                        </Label>
                                    </div>
                                    <div className="flex items-center space-x-2 p-3 bg-white rounded border hover:border-blue-400 transition-colors">
                                        <RadioGroupItem value="lead" id="lead" />
                                        <Label htmlFor="lead" className="cursor-pointer flex-1">
                                            <div className="font-semibold">Existing Lead</div>
                                            <div className="text-xs text-gray-500">Select from CRM</div>
                                        </Label>
                                    </div>
                                    <div className="flex items-center space-x-2 p-3 bg-white rounded border hover:border-blue-400 transition-colors">
                                        <RadioGroupItem value="customer" id="customer" />
                                        <Label htmlFor="customer" className="cursor-pointer flex-1">
                                            <div className="font-semibold">Existing Customer</div>
                                            <div className="text-xs text-gray-500">Select from CRM</div>
                                        </Label>
                                    </div>
                                </div>
                            </RadioGroup>

                            {contactSource === 'lead' && (
                                <div className="mt-4">
                                    <Label>Search and Select Lead</Label>
                                    <Popover open={openLeadSearch} onOpenChange={setOpenLeadSearch}>
                                        <PopoverTrigger asChild>
                                            <Button
                                                variant="outline"
                                                role="combobox"
                                                className="w-full justify-between"
                                            >
                                                {selectedLead ? selectedLead.name : "Search leads..."}
                                                <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-full p-0">
                                            <Command>
                                                <CommandInput placeholder="Search leads..." />
                                                <CommandEmpty>No leads found.</CommandEmpty>
                                                <CommandGroup className="max-h-64 overflow-y-auto">
                                                    {leads.map((lead) => (
                                                        <CommandItem
                                                            key={lead.id}
                                                            onSelect={() => {
                                                                setSelectedLead(lead);
                                                                setOpenLeadSearch(false);
                                                            }}
                                                        >
                                                            <div className="flex flex-col items-start">
                                                                <span className="font-semibold">{lead.name}</span>
                                                                <span className="text-xs text-gray-500">{lead.phone} • {lead.email}</span>
                                                                <span className="text-xs text-gray-400">{lead.street}, {lead.city}</span>
                                                            </div>
                                                        </CommandItem>
                                                    ))}
                                                </CommandGroup>
                                            </Command>
                                        </PopoverContent>
                                    </Popover>
                                    {selectedLead && (
                                        <Alert className="mt-2 bg-green-50 border-green-300">
                                            <CheckCircle className="h-4 w-4 text-green-600" />
                                            <AlertDescription className="text-green-800">
                                                ✅ Lead selected: {selectedLead.name} - Fields auto-populated!
                                            </AlertDescription>
                                        </Alert>
                                    )}
                                </div>
                            )}

                            {contactSource === 'customer' && (
                                <div className="mt-4">
                                    <Label>Search and Select Customer</Label>
                                    <Popover open={openCustomerSearch} onOpenChange={setOpenCustomerSearch}>
                                        <PopoverTrigger asChild>
                                            <Button
                                                variant="outline"
                                                role="combobox"
                                                className="w-full justify-between"
                                            >
                                                {selectedCustomer ? selectedCustomer.name : "Search customers..."}
                                                <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-full p-0">
                                            <Command>
                                                <CommandInput placeholder="Search customers..." />
                                                <CommandEmpty>No customers found.</CommandEmpty>
                                                <CommandGroup className="max-h-64 overflow-y-auto">
                                                    {customers.map((customer) => (
                                                        <CommandItem
                                                            key={customer.id}
                                                            onSelect={() => {
                                                                setSelectedCustomer(customer);
                                                                setOpenCustomerSearch(false);
                                                            }}
                                                        >
                                                            <div className="flex flex-col items-start">
                                                                <span className="font-semibold">{customer.name}</span>
                                                                <span className="text-xs text-gray-500">{customer.phone} • {customer.email}</span>
                                                                <span className="text-xs text-gray-400">{customer.street}, {customer.city}</span>
                                                            </div>
                                                        </CommandItem>
                                                    ))}
                                                </CommandGroup>
                                            </Command>
                                        </PopoverContent>
                                    </Popover>
                                    {selectedCustomer && (
                                        <Alert className="mt-2 bg-green-50 border-green-300">
                                            <CheckCircle className="h-4 w-4 text-green-600" />
                                            <AlertDescription className="text-green-800">
                                                ✅ Customer selected: {selectedCustomer.name} - Fields auto-populated!
                                            </AlertDescription>
                                        </Alert>
                                    )}
                                </div>
                            )}
                        </div>
                    )}

                    <div>
                        <SectionTitle>Site Information</SectionTitle>
                        <div className="space-y-4">
                            <div className="grid grid-cols-1 gap-4">
                                <div>
                                    <Label htmlFor="property_address">Site Address *</Label>
                                    <GoogleAddressAutocomplete
                                        initialAddress={formData.property_address}
                                        onAddressSelect={(address, details) => {
                                            setFormData(prev => ({ ...prev, property_address: address }));
                                        }}
                                        placeholder="Enter the inspection site address..."
                                    />
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <Label htmlFor="property_type">Property Type</Label>
                                    <Select value={formData.property_type} onValueChange={(v) => handleSelectChange('property_type', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Residential">Residential</SelectItem>
                                            <SelectItem value="Commercial">Commercial</SelectItem>
                                            <SelectItem value="Multi-Family">Multi-Family</SelectItem>
                                            <SelectItem value="Industrial">Industrial</SelectItem>
                                            <SelectItem value="Other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <Label htmlFor="inspection_type">Inspection Type *</Label>
                                    <Input id="inspection_type" value={formData.inspection_type} onChange={handleInputChange} required />
                                </div>
                            </div>
                             <div>
                                <Label htmlFor="access_instructions">Access Instructions</Label>
                                <Textarea id="access_instructions" placeholder="Gate codes, key location, contact for access, parking instructions..." value={formData.access_instructions} onChange={handleInputChange} />
                            </div>
                        </div>
                    </div>

                    <div>
                        <SectionTitle>Property Contact Information</SectionTitle>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <Label htmlFor="client_name">Contact Name *</Label>
                                <Input id="client_name" placeholder="Property owner/manager name" value={formData.client_name} onChange={handleInputChange} required />
                            </div>
                            <div>
                                <Label htmlFor="client_phone">Contact Phone *</Label>
                                <Input id="client_phone" type="tel" placeholder="(555) 123-4567" value={formData.client_phone} onChange={handleInputChange} required />
                            </div>
                            <div>
                                <Label htmlFor="client_email">Contact Email</Label>
                                <Input id="client_email" type="email" placeholder="contact@example.com" value={formData.client_email} onChange={handleInputChange} />
                            </div>
                        </div>
                    </div>

                    <div>
                        <SectionTitle>Inspector Assignment</SectionTitle>
                        <Label htmlFor="assigned_to_email">Select Vetted Inspector</Label>
                        <Select value={formData.assigned_to_email} onValueChange={(v) => handleSelectChange('assigned_to_email', v)}>
                            <SelectTrigger><SelectValue placeholder="Choose an inspector..." /></SelectTrigger>
                            <SelectContent>
                                {users.map(user => <SelectItem key={user.id} value={user.email}>{user.full_name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>

                    <div>
                        <SectionTitle>Assignment Details</SectionTitle>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <Label htmlFor="priority">Priority Level</Label>
                                <Select value={formData.priority} onValueChange={(v) => handleSelectChange('priority', v)}>
                                    <SelectTrigger><SelectValue/></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Low">Low</SelectItem>
                                        <SelectItem value="Normal">Normal</SelectItem>
                                        <SelectItem value="High">High</SelectItem>
                                        <SelectItem value="Urgent">Urgent</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                             <div>
                                <Label htmlFor="scheduled_date">Scheduled Date</Label>
                                <Popover>
                                    <PopoverTrigger asChild>
                                        <Button
                                            variant={"outline"}
                                            className="w-full justify-start text-left font-normal"
                                        >
                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                            {formData.scheduled_date ? format(new Date(formData.scheduled_date), "PPP") : <span>Pick a date</span>}
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0" align="start">
                                        <Calendar
                                            mode="single"
                                            selected={formData.scheduled_date ? new Date(formData.scheduled_date) : undefined}
                                            onSelect={(date) => handleSelectChange('scheduled_date', date ? format(date, 'yyyy-MM-dd') : '')}
                                            initialFocus
                                        />
                                    </PopoverContent>
                                </Popover>
                            </div>
                            <div>
                                <Label htmlFor="inspection_time">Inspection Time</Label>
                                <Input id="inspection_time" type="time" value={formData.inspection_time} onChange={handleInputChange} />
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                            <div>
                                <Label htmlFor="damage_type">Damage Type</Label>
                                <Input id="damage_type" placeholder="Wind, Hail, Water, Fire, etc." value={formData.damage_type} onChange={handleInputChange} />
                            </div>
                            <div>
                                <Label htmlFor="date_of_loss">Date of Loss</Label>
                                <Input id="date_of_loss" type="date" value={formData.date_of_loss} onChange={handleInputChange} />
                            </div>
                             <div>
                                <Label htmlFor="insurance_claim_number">Insurance Claim Number</Label>
                                <Input id="insurance_claim_number" placeholder="Claim reference number" value={formData.insurance_claim_number} onChange={handleInputChange} />
                            </div>
                        </div>
                        <div className="mt-4">
                            <Label htmlFor="lead_source">Lead Source</Label>
                            <Select value={formData.lead_source} onValueChange={(v) => handleSelectChange('lead_source', v)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="website">Website</SelectItem>
                                    <SelectItem value="referral">Referral</SelectItem>
                                    <SelectItem value="social_media">Social Media</SelectItem>
                                    <SelectItem value="storm_tracker">Storm Tracker</SelectItem>
                                    <SelectItem value="property_importer">Property Importer</SelectItem>
                                    <SelectItem value="direct_call">Direct Call</SelectItem>
                                    <SelectItem value="walk_in">Walk-in</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="mt-4">
                            <Label htmlFor="special_instructions">Special Instructions</Label>
                            <Textarea id="special_instructions" placeholder="Specific areas to focus on, safety concerns, equipment needed..." value={formData.special_instructions} onChange={handleInputChange} />
                        </div>
                    </div>

                    {/* NEW: Link Estimate & Storm Event */}
                    <div>
                        <SectionTitle>🔗 Link Estimate & Storm Data</SectionTitle>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="related_estimate_id">Link Xactimate Estimate</Label>
                                <Select 
                                    value={formData.related_estimate_id || 'none'} 
                                    onValueChange={(v) => handleSelectChange('related_estimate_id', v === 'none' ? '' : v)}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="No estimate linked" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="none">None</SelectItem>
                                        {suggestedEstimates.length > 0 && (
                                            <>
                                                <div className="px-2 py-1.5 text-xs font-semibold text-blue-600">🎯 Suggested</div>
                                                {suggestedEstimates.map(est => (
                                                    <SelectItem key={est.id} value={est.id}>
                                                        {est.estimate_number} - {est.customer_name} (${est.amount?.toFixed(2)})
                                                    </SelectItem>
                                                ))}
                                                <div className="px-2 py-1.5 text-xs font-semibold text-gray-600 border-t mt-1">All Estimates</div>
                                            </>
                                        )}
                                        {estimates.filter(e => !suggestedEstimates.includes(e)).map(est => (
                                            <SelectItem key={est.id} value={est.id}>
                                                {est.estimate_number} - {est.customer_name} (${est.amount?.toFixed(2)})
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                {linkedEstimate && (
                                    <Alert 
                                        className="mt-2 bg-green-50 border-green-300 cursor-pointer hover:bg-green-100 transition-colors" 
                                        onClick={() => window.open(createPageUrl('EstimateEditor') + `?id=${linkedEstimate.id}`, '_blank')}
                                    >
                                        <CheckCircle className="h-4 w-4 text-green-600" />
                                        <AlertDescription className="text-green-800 flex items-center justify-between">
                                            <span>✅ {linkedEstimate.estimate_number} - ${linkedEstimate.amount?.toFixed(2)}</span>
                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                            </svg>
                                        </AlertDescription>
                                    </Alert>
                                )}
                            </div>

                            <div>
                                <Label>Link Storm Event</Label>
                                <Popover open={openStormSearch} onOpenChange={setOpenStormSearch}>
                                    <PopoverTrigger asChild>
                                        <Button
                                            variant="outline"
                                            role="combobox"
                                            aria-expanded={openStormSearch}
                                            className="w-full justify-between h-auto py-2"
                                        >
                                            {linkedStorm ? (
                                                <div className="flex flex-col items-start text-left overflow-hidden w-full">
                                                     <span className="font-medium truncate w-full">{linkedStorm.title}</span>
                                                     <span className="text-xs text-muted-foreground truncate w-full">
                                                        {format(new Date(linkedStorm.start_time), 'MMM d, yyyy')} • {linkedStorm.affected_areas?.slice(0, 3).join(', ')}{linkedStorm.affected_areas?.length > 3 ? '...' : ''}
                                                     </span>
                                                </div>
                                            ) : (
                                                "Select storm event..."
                                            )}
                                            <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-[400px] p-0" align="start">
                                        <Command shouldFilter={false}>
                                            <CommandInput 
                                                placeholder="Search storm or city..." 
                                                value={searchQuery}
                                                onValueChange={setSearchQuery}
                                            />
                                            <CommandList>
                                                {isLoadingStorms ? (
                                                    <div className="py-6 text-center text-sm text-muted-foreground flex flex-col items-center gap-2">
                                                        <Loader2 className="h-4 w-4 animate-spin" />
                                                        Loading nationwide storms...
                                                    </div>
                                                ) : (
                                                    <>
                                                        <CommandEmpty>No storm found.</CommandEmpty>
                                                        <CommandGroup>
                                                            <CommandItem
                                                                value="none"
                                                                onSelect={() => {
                                                                    handleSelectChange('related_storm_event_id', '');
                                                                    setOpenStormSearch(false);
                                                                }}
                                                            >
                                                                None
                                                            </CommandItem>
                                                            {filteredStorms.map((storm) => (
                                                                <CommandItem
                                                            key={storm.id}
                                                            value={storm.id}
                                                            onSelect={() => {
                                                                handleSelectChange('related_storm_event_id', storm.id);
                                                                setOpenStormSearch(false);
                                                            }}
                                                        >
                                                            <div className="flex flex-col w-full">
                                                                <div className="flex justify-between items-center">
                                                                    <span className="font-semibold">{storm.title}</span>
                                                                    <span className="text-xs text-muted-foreground">{format(new Date(storm.start_time), 'MMM d, yyyy')}</span>
                                                                </div>
                                                                <div className="text-xs text-gray-600 mt-1">
                                                                    {storm.affected_areas?.join(', ')}
                                                                </div>
                                                                <div className="flex gap-2 mt-1">
                                                                    {storm.hail_size_inches > 0 && (
                                                                        <Badge variant="outline" className="text-[10px] px-1 py-0 h-4 border-blue-200 bg-blue-50 text-blue-700">
                                                                            {storm.hail_size_inches}" Hail
                                                                        </Badge>
                                                                    )}
                                                                    {storm.wind_speed_mph > 0 && (
                                                                        <Badge variant="outline" className="text-[10px] px-1 py-0 h-4 border-orange-200 bg-orange-50 text-orange-700">
                                                                            {storm.wind_speed_mph} mph Wind
                                                                        </Badge>
                                                                    )}
                                                                </div>
                                                            </div>
                                                            {formData.related_storm_event_id === storm.id && (
                                                                <CheckCircle className="ml-auto h-4 w-4 text-primary opacity-50" />
                                                            )}
                                                        </CommandItem>
                                                            ))}
                                                        </CommandGroup>
                                                    </>
                                                )}
                                            </CommandList>
                                        </Command>
                                    </PopoverContent>
                                </Popover>
                                {linkedStorm && (
                                    <Alert 
                                        className="mt-2 bg-orange-50 border-orange-300 cursor-pointer hover:bg-orange-100 transition-colors" 
                                        onClick={() => window.open(createPageUrl('StormReport') + `?id=${linkedStorm.id}`, '_blank')}
                                    >
                                        <CheckCircle className="h-4 w-4 text-orange-600" />
                                        <AlertDescription className="text-orange-800">
                                            <div className="flex items-center justify-between">
                                                <div className="flex-1">
                                                    <div>⚡ {linkedStorm.title}
                                                    {linkedStorm.start_time && ` (${format(new Date(linkedStorm.start_time), 'MMM d, yyyy')})`}</div>
                                                    <div className="text-xs mt-1 text-orange-700/80">
                                                        📍 {linkedStorm.affected_areas?.join(', ')}
                                                    </div>
                                                </div>
                                                <svg className="w-4 h-4 flex-shrink-0 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                                </svg>
                                            </div>
                                        </AlertDescription>
                                    </Alert>
                                )}
                                {stormEvents.length === 0 && (
                                    <p className="text-xs text-gray-500 mt-1">
                                        No active storms. Track storms in Storm Tracker.
                                    </p>
                                )}
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <SectionTitle>Ladder Assistant</SectionTitle>
                        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                            <div className="flex items-start gap-3 mb-3">
                                <Checkbox 
                                    id="ladder_assist_needed"
                                    checked={formData.ladder_assist_needed}
                                    onCheckedChange={(checked) => setFormData({...formData, ladder_assist_needed: checked})}
                                />
                                <div className="flex-1">
                                    <label htmlFor="ladder_assist_needed" className="font-medium text-gray-900 cursor-pointer">
                                        Ladder Assistant Needed
                                    </label>
                                    <p className="text-xs text-gray-600 mt-1">
                                        Cost will be deducted from sales rep's commission
                                    </p>
                                </div>
                            </div>

                            {formData.ladder_assist_needed && (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pl-7">
                                    <div>
                                        <Label htmlFor="ladder_assistant_name">Assistant Name (Optional)</Label>
                                        <Input 
                                            id="ladder_assistant_name" 
                                            placeholder="Who is helping?" 
                                            value={formData.ladder_assistant_name} 
                                            onChange={handleInputChange} 
                                        />
                                    </div>
                                    <div>
                                        <Label htmlFor="ladder_assist_cost">Cost (Default $100)</Label>
                                        <Input 
                                            id="ladder_assist_cost" 
                                            type="number" 
                                            step="0.01"
                                            value={formData.ladder_assist_cost} 
                                            onChange={handleInputChange} 
                                        />
                                    </div>
                                    <div className="md:col-span-2">
                                        <Label htmlFor="sales_rep_email">Sales Rep (Paying for Assist)</Label>
                                        <Select 
                                            value={formData.sales_rep_email || formData.assigned_to_email} 
                                            onValueChange={(v) => handleSelectChange('sales_rep_email', v)}
                                        >
                                            <SelectTrigger><SelectValue placeholder="Select sales rep..." /></SelectTrigger>
                                            <SelectContent>
                                                {users.map(user => <SelectItem key={user.id} value={user.email}>{user.full_name}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                        <p className="text-xs text-gray-500 mt-1">
                                            Defaults to assigned inspector. Change if a different sales rep is paying.
                                        </p>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    <div>
                        <SectionTitle>Additional Notes</SectionTitle>
                         <Textarea id="notes" placeholder="Any additional information, context, or requirements for this inspection..." value={formData.notes} onChange={handleInputChange} />
                    </div>

                    {!existingJob && (
                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                            <h4 className="font-semibold text-blue-900 mb-3 flex items-center gap-2">
                                <UserPlus className="w-5 h-5" />
                                Auto-create CRM Actions
                            </h4>
                            <div className="space-y-3">
                                {contactSource === 'new' && (
                                    <div className="flex items-center space-x-2">
                                        <Checkbox 
                                            id="createLead" 
                                            checked={createLead}
                                            onCheckedChange={setCreateLead}
                                        />
                                        <label
                                            htmlFor="createLead"
                                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                        >
                                            Create Lead in CRM (recommended)
                                        </label>
                                    </div>
                                )}
                                <div className="flex items-center space-x-2">
                                    <Checkbox 
                                        id="createTask" 
                                        checked={createTask}
                                        onCheckedChange={setCreateTask}
                                    />
                                    <label
                                        htmlFor="createTask"
                                        className="text-sm font-medium leading-none"
                                    >
                                        Create Inspection Task
                                    </label>
                                </div>
                                {!formData.scheduled_date && (
                                    <p className="text-xs text-amber-600 ml-6">⚠️ Add a scheduled date to enable task creation</p>
                                )}
                                <div className="flex items-center space-x-2">
                                    <Checkbox 
                                        id="createCalendarEvent" 
                                        checked={createCalendarEvent}
                                        onCheckedChange={setCreateCalendarEvent}
                                    />
                                    <label
                                        htmlFor="createCalendarEvent"
                                        className="text-sm font-medium leading-none"
                                    >
                                        Add to Calendar (prevents double-booking)
                                    </label>
                                </div>
                                {(!formData.scheduled_date || !formData.inspection_time) && (
                                    <p className="text-xs text-amber-600 ml-6">⚠️ Add date & time to enable calendar sync</p>
                                )}
                            </div>
                        </div>
                    )}

                </form>
                <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button type="button" onClick={handleSubmit} disabled={createJobMutation.isPending}>
                        {createJobMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                        {existingJob ? 'Update' : 'Send'} Assignment
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}