/**
 * Draws annotations on an image based on detection boxes.
 * @param {string} imageUrl - The URL of the source image
 * @param {Array} detections - Array of detection objects {type, box_2d: [ymin, xmin, ymax, xmax]} (0-1000 scale)
 * @returns {Promise<Blob>} - The annotated image as a Blob
 */
export const annotateImage = async (imageUrl, detections) => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      
      // Configure styles - thick "chalk-like" lines
      const scaleFactor = Math.max(img.width, img.height) / 1000;
      ctx.lineWidth = 10 * scaleFactor; // Thicker for chalk effect
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.6)'; // Stronger drop shadow for contrast
      ctx.shadowBlur = 6 * scaleFactor;
      
      detections.forEach(det => {
        const [ymin, xmin, ymax, xmax] = det.box_2d;
        
        // Convert 0-1000 scale to pixels
        const y = (ymin / 1000) * img.height;
        const x = (xmin / 1000) * img.width;
        const h = ((ymax - ymin) / 1000) * img.height;
        const w = ((xmax - xmin) / 1000) * img.width;
        
        const centerX = x + w / 2;
        const centerY = y + h / 2;
        
        // Color coding (Standard: Hail=Red, Wind=Yellow)
        if (det.type === 'hail') {
          ctx.strokeStyle = '#ef4444'; // Red Chalk
          ctx.fillStyle = 'transparent';
          
          // Draw Circle for Hail
          const radius = Math.max(w, h) / 2;
          ctx.beginPath();
          ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
          ctx.stroke();
          
        } else if (det.type === 'wind') {
          ctx.strokeStyle = '#eab308'; // Yellow Chalk
          ctx.fillStyle = 'transparent';
          
          // Draw Horizontal Line for Wind (Creases or Missing)
          // "Going horizontal in the same length as the shingles"
          ctx.beginPath();
          ctx.moveTo(x, centerY);
          ctx.lineTo(x + w, centerY);
          ctx.stroke();
          
        } else {
          // Other - Draw Box
          ctx.strokeStyle = '#3b82f6'; // Blue
          ctx.fillStyle = 'transparent';
          ctx.beginPath();
          ctx.rect(x, y, w, h);
          ctx.stroke();
        }
      });
      
      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
        else reject(new Error("Canvas to Blob conversion failed"));
      }, 'image/jpeg', 0.9);
    };
    img.onerror = (e) => reject(new Error("Failed to load image for annotation"));
    img.src = imageUrl;
  });
};