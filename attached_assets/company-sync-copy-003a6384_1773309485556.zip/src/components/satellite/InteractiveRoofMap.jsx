import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Undo,
  Trash2,
  Save,
  ArrowLeft,
  Pencil,
  Ruler,
  Plus,
  X
} from "lucide-react";

export default function InteractiveRoofMap({
  latitude,
  longitude,
  address,
  onMeasurementsComplete,
  onBack,
  googleMapsLoaded
}) {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const [map, setMap] = useState(null);
  const [drawingManager, setDrawingManager] = useState(null);
  const [currentTool, setCurrentTool] = useState(null);
  const [features, setFeatures] = useState([]);
  const [roofPolygon, setRoofPolygon] = useState(null);
  const [pitch, setPitch] = useState("7/12");
  
  const [structures, setStructures] = useState([
    { id: 1, name: "Main House", active: true }
  ]);
  const [activeStructureId, setActiveStructureId] = useState(1);
  const [editingStructureName, setEditingStructureName] = useState(null);
  
  const [includeGutters, setIncludeGutters] = useState(false);
  const [gutterLF, setGutterLF] = useState(0);
  const [downspoutCount, setDownspoutCount] = useState(0);

  useEffect(() => {
    if (!googleMapsLoaded || !mapRef.current || mapInstanceRef.current) return;
    if (typeof window === 'undefined' || !window.google) return;

    const mapInstance = new window.google.maps.Map(mapRef.current, {
      center: { lat: latitude, lng: longitude },
      zoom: 20,
      mapTypeId: 'satellite',
      tilt: 0,
      rotateControl: false,
      fullscreenControl: false,
      streetViewControl: false,
    });

    const manager = new window.google.maps.drawing.DrawingManager({
      drawingMode: null,
      drawingControl: false,
      polygonOptions: {
        fillColor: '#FF6B6B',
        fillOpacity: 0.3,
        strokeWeight: 2,
        strokeColor: '#FF6B6B',
        editable: true,
        draggable: false,
      },
      polylineOptions: {
        strokeWeight: 3,
        editable: true,
        draggable: false,
      }
    });

    manager.setMap(mapInstance);
    mapInstanceRef.current = mapInstance;
    setMap(mapInstance);
    setDrawingManager(manager);

    window.google.maps.event.addListener(manager, 'polygoncomplete', (polygon) => {
      manager.setDrawingMode(null);
      setRoofPolygon(polygon);
      setCurrentTool(null);
    });

    window.google.maps.event.addListener(manager, 'polylinecomplete', (polyline) => {
      manager.setDrawingMode(null);
      
      const newFeature = {
        id: Date.now(),
        type: currentTool,
        polyline: polyline,
        structureId: activeStructureId,
        color: getColorForType(currentTool)
      };
      
      polyline.setOptions({
        strokeColor: newFeature.color,
        strokeWeight: 3
      });

      setFeatures(prev => [...prev, newFeature]);
      setCurrentTool(null);
    });

  }, [googleMapsLoaded, latitude, longitude, activeStructureId, currentTool]);

  const getColorForType = (type) => {
    const colors = {
      ridge: '#9333ea',
      valley: '#10b981',
      rake: '#f97316',
      eave: '#ef4444',
      hip: '#3b82f6',
      step_flashing: '#ec4899'
    };
    return colors[type] || '#000000';
  };

  const calculateRoofArea = () => {
    if (!roofPolygon || typeof window === 'undefined' || !window.google) return 0;
    
    const path = roofPolygon.getPath();
    const area = window.google.maps.geometry.spherical.computeArea(path);
    const sqft = area * 10.7639;
    return sqft;
  };

  const calculateLineLength = (polyline) => {
    if (typeof window === 'undefined' || !window.google) return 0;
    
    const path = polyline.getPath();
    const meters = window.google.maps.geometry.spherical.computeLength(path);
    const feet = meters * 3.28084;
    return feet;
  };

  const getActiveStructure = () => structures.find(s => s.id === activeStructureId);

  const getMeasurementsByStructure = () => {
    const structureMeasurements = {};

    structures.forEach(structure => {
      const structureFeatures = features.filter(f => f.structureId === structure.id);
      
      structureMeasurements[structure.id] = {
        structureName: structure.name,
        ridge_lf: structureFeatures
          .filter(f => f.type === 'ridge')
          .reduce((sum, f) => sum + calculateLineLength(f.polyline), 0),
        valley_lf: structureFeatures
          .filter(f => f.type === 'valley')
          .reduce((sum, f) => sum + calculateLineLength(f.polyline), 0),
        rake_lf: structureFeatures
          .filter(f => f.type === 'rake')
          .reduce((sum, f) => sum + calculateLineLength(f.polyline), 0),
        eave_lf: structureFeatures
          .filter(f => f.type === 'eave')
          .reduce((sum, f) => sum + calculateLineLength(f.polyline), 0),
        hip_lf: structureFeatures
          .filter(f => f.type === 'hip')
          .reduce((sum, f) => sum + calculateLineLength(f.polyline), 0),
        step_flashing_lf: structureFeatures
          .filter(f => f.type === 'step_flashing')
          .reduce((sum, f) => sum + calculateLineLength(f.polyline), 0),
      };
    });

    return structureMeasurements;
  };

  const roofSqft = calculateRoofArea();
  const roofSQ = roofSqft / 100;

  const structureMeasurements = getMeasurementsByStructure();
  const currentStructureMeasures = structureMeasurements[activeStructureId] || {
    ridge_lf: 0,
    valley_lf: 0,
    rake_lf: 0,
    eave_lf: 0,
    hip_lf: 0,
    step_flashing_lf: 0
  };

  const handleStartDrawing = (type) => {
    if (!drawingManager || typeof window === 'undefined' || !window.google) return;
    
    if (type === 'roof_outline') {
      if (roofPolygon) {
        roofPolygon.setMap(null);
        setRoofPolygon(null);
      }
      drawingManager.setDrawingMode(window.google.maps.drawing.OverlayType.POLYGON);
      setCurrentTool('roof_outline');
    } else {
      drawingManager.setDrawingMode(window.google.maps.drawing.OverlayType.POLYLINE);
      setCurrentTool(type);
      
      drawingManager.setOptions({
        polylineOptions: {
          strokeWeight: 3,
          strokeColor: getColorForType(type),
          editable: true
        }
      });
    }
  };

  const handleUndo = () => {
    const lastFeature = features[features.length - 1];
    if (lastFeature) {
      lastFeature.polyline.setMap(null);
      setFeatures(prev => prev.slice(0, -1));
    }
  };

  const handleClearAll = () => {
    features.forEach(f => f.polyline.setMap(null));
    setFeatures([]);
  };

  const handleAddStructure = () => {
    const newId = Math.max(...structures.map(s => s.id)) + 1;
    const newStructure = {
      id: newId,
      name: `Structure ${newId}`,
      active: true
    };
    setStructures(prev => [...prev, newStructure]);
    setActiveStructureId(newId);
  };

  const handleRemoveStructure = (structureId) => {
    if (structures.length === 1) {
      alert("You must have at least one structure");
      return;
    }
    
    const structureFeatures = features.filter(f => f.structureId === structureId);
    structureFeatures.forEach(f => f.polyline.setMap(null));
    
    setFeatures(prev => prev.filter(f => f.structureId !== structureId));
    setStructures(prev => prev.filter(s => s.id !== structureId));
    
    if (activeStructureId === structureId) {
      setActiveStructureId(structures.find(s => s.id !== structureId)?.id || 1);
    }
  };

  const handleSaveMeasurements = () => {
    if (!roofPolygon) {
      alert("Please draw the roof outline first");
      return;
    }

    const allMeasurements = Object.values(structureMeasurements);
    
    const totalMeasurements = {
      roof_area_sqft: roofSqft,
      roof_area_sq: roofSQ,
      ridge_lf: allMeasurements.reduce((sum, m) => sum + m.ridge_lf, 0),
      valley_lf: allMeasurements.reduce((sum, m) => sum + m.valley_lf, 0),
      rake_lf: allMeasurements.reduce((sum, m) => sum + m.rake_lf, 0),
      eave_lf: allMeasurements.reduce((sum, m) => sum + m.eave_lf, 0),
      hip_lf: allMeasurements.reduce((sum, m) => sum + m.hip_lf, 0),
      step_flashing_lf: allMeasurements.reduce((sum, m) => sum + m.step_flashing_lf, 0),
      pitch: pitch,
      structures: structures.map(s => ({
        id: s.id,
        name: s.name,
        measurements: structureMeasurements[s.id]
      })),
      gutter_lf: includeGutters ? gutterLF : 0,
      downspout_count: includeGutters ? downspoutCount : 0
    };

    onMeasurementsComplete(totalMeasurements);
  };

  useEffect(() => {
    if (includeGutters) {
      const allMeasurements = Object.values(structureMeasurements);
      const totalEaves = allMeasurements.reduce((sum, m) => sum + m.eave_lf, 0);
      setGutterLF(totalEaves);
      
      const estimatedDownspouts = Math.ceil(totalEaves / 35);
      setDownspoutCount(estimatedDownspouts);
    }
  }, [includeGutters, features]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Pencil className="w-5 h-5 text-blue-600" />
          Manual Drawing Mode
        </h3>
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          <strong>📍 {address}</strong>
        </p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Structures</CardTitle>
            <Button size="sm" variant="outline" onClick={handleAddStructure}>
              <Plus className="w-4 h-4 mr-1" />
              Add Structure
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap gap-2">
            {structures.map(structure => (
              <div key={structure.id} className="flex items-center gap-1">
                {editingStructureName === structure.id ? (
                  <Input
                    value={structure.name}
                    onChange={(e) => {
                      setStructures(prev => prev.map(s => 
                        s.id === structure.id ? { ...s, name: e.target.value } : s
                      ));
                    }}
                    onBlur={() => setEditingStructureName(null)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') setEditingStructureName(null);
                    }}
                    className="w-32 h-8 text-sm"
                    autoFocus
                  />
                ) : (
                  <Button
                    variant={activeStructureId === structure.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setActiveStructureId(structure.id)}
                    className="h-8"
                  >
                    {structure.name}
                    {features.filter(f => f.structureId === structure.id).length > 0 && (
                      <Badge className="ml-2 bg-white/20">
                        {features.filter(f => f.structureId === structure.id).length}
                      </Badge>
                    )}
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setEditingStructureName(structure.id)}
                >
                  <Pencil className="w-3 h-3" />
                </Button>
                {structures.length > 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-red-600 hover:text-red-700"
                    onClick={() => handleRemoveStructure(structure.id)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                )}
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-2">
            💡 Currently drawing for: <strong>{getActiveStructure()?.name}</strong>
          </p>
        </CardContent>
      </Card>

      <div
        ref={mapRef}
        className="w-full h-[400px] rounded-lg border-2 border-gray-300 shadow-lg"
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            STEP 1: Draw Roof Outline (Required)
          </CardTitle>
          <p className="text-sm text-gray-600">
            Click around the perimeter of the roof to measure the total area
          </p>
        </CardHeader>
        <CardContent>
          <Button
            onClick={() => handleStartDrawing('roof_outline')}
            variant={currentTool === 'roof_outline' ? 'default' : 'outline'}
            className="w-full"
          >
            <Ruler className="w-4 h-4 mr-2" />
            {roofPolygon ? 'Redraw Roof Outline' : 'Draw Roof Outline'}
          </Button>
          
          {roofPolygon && (
            <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm font-semibold text-green-900">Measured Roof Area:</p>
              <p className="text-2xl font-bold text-green-700">
                {roofSQ.toFixed(2)} SQ
              </p>
              <p className="text-xs text-green-600">({roofSqft.toFixed(0)} sq ft)</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            STEP 2: Draw Linear Features (Optional)
          </CardTitle>
          <p className="text-sm text-gray-600">
            Click to draw ridge, valley, eave, rake, hip, or step flashing lines
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {['ridge', 'valley', 'rake', 'eave', 'hip', 'step_flashing'].map(type => (
              <Button
                key={type}
                onClick={() => handleStartDrawing(type)}
                variant={currentTool === type ? 'default' : 'outline'}
                className="capitalize"
                style={currentTool === type ? {} : { borderColor: getColorForType(type), color: getColorForType(type) }}
              >
                <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: getColorForType(type) }}></div>
                {type.replace('_', ' ')}
              </Button>
            ))}
          </div>

          <div className="flex gap-2">
            <Button onClick={handleUndo} variant="outline" size="sm" disabled={features.length === 0}>
              <Undo className="w-4 h-4 mr-2" />
              Undo Last
            </Button>
            <Button onClick={handleClearAll} variant="outline" size="sm" disabled={features.length === 0}>
              <Trash2 className="w-4 h-4 mr-2" />
              Clear All
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Gutters & Downspouts</CardTitle>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeGutters}
                onChange={(e) => setIncludeGutters(e.target.checked)}
                className="w-4 h-4"
              />
              <span className="text-sm">Include in estimate</span>
            </label>
          </div>
        </CardHeader>
        {includeGutters && (
          <CardContent className="space-y-4">
            <div>
              <Label>Gutter Length (LF)</Label>
              <Input
                type="number"
                value={gutterLF}
                onChange={(e) => setGutterLF(Number(e.target.value))}
                placeholder="Linear feet of gutters"
              />
              <p className="text-xs text-gray-500 mt-1">
                💡 Auto-filled based on eave measurements
              </p>
            </div>
            
            <div>
              <Label>Number of Downspouts</Label>
              <Input
                type="number"
                value={downspoutCount}
                onChange={(e) => setDownspoutCount(Number(e.target.value))}
                placeholder="Number of downspouts"
              />
              <p className="text-xs text-gray-500 mt-1">
                💡 Typically 1 downspout per 30-40 LF of gutter
              </p>
            </div>
          </CardContent>
        )}
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Manual Measurements</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="current">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">Current Structure</TabsTrigger>
              <TabsTrigger value="all">All Structures</TabsTrigger>
            </TabsList>
            
            <TabsContent value="current" className="space-y-2">
              <p className="text-sm font-semibold text-gray-700 mb-2">
                {getActiveStructure()?.name}
              </p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                  <span className="text-gray-600">Ridge:</span>
                  <span className="font-semibold">{currentStructureMeasures.ridge_lf.toFixed(2)} LF</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-gray-600">Valley:</span>
                  <span className="font-semibold">{currentStructureMeasures.valley_lf.toFixed(2)} LF</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                  <span className="text-gray-600">Rake:</span>
                  <span className="font-semibold">{currentStructureMeasures.rake_lf.toFixed(2)} LF</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span className="text-gray-600">Eave:</span>
                  <span className="font-semibold">{currentStructureMeasures.eave_lf.toFixed(2)} LF</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span className="text-gray-600">Hip:</span>
                  <span className="font-semibold">{currentStructureMeasures.hip_lf.toFixed(2)} LF</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-pink-500"></div>
                  <span className="text-gray-600">Step Flash:</span>
                  <span className="font-semibold">{currentStructureMeasures.step_flashing_lf.toFixed(2)} LF</span>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="all" className="space-y-4">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4 border border-blue-200">
                <p className="text-sm font-semibold text-gray-900 mb-2">Total Roof Area:</p>
                <p className="text-3xl font-bold text-blue-700">
                  {roofSQ.toFixed(2)} SQ
                </p>
                <p className="text-xs text-gray-600">({roofSqft.toFixed(0)} sq ft)</p>
              </div>

              {structures.map(structure => {
                const measures = structureMeasurements[structure.id] || {};
                const structureFeatureCount = features.filter(f => f.structureId === structure.id).length;
                
                return (
                  <div key={structure.id} className="border rounded-lg p-3 bg-white">
                    <p className="font-semibold text-sm mb-2">{structure.name}</p>
                    {structureFeatureCount > 0 ? (
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {measures.ridge_lf > 0 && <div>Ridge: {measures.ridge_lf.toFixed(2)} LF</div>}
                        {measures.valley_lf > 0 && <div>Valley: {measures.valley_lf.toFixed(2)} LF</div>}
                        {measures.rake_lf > 0 && <div>Rake: {measures.rake_lf.toFixed(2)} LF</div>}
                        {measures.eave_lf > 0 && <div>Eave: {measures.eave_lf.toFixed(2)} LF</div>}
                        {measures.hip_lf > 0 && <div>Hip: {measures.hip_lf.toFixed(2)} LF</div>}
                        {measures.step_flashing_lf > 0 && <div>Step Flash: {measures.step_flashing_lf.toFixed(2)} LF</div>}
                      </div>
                    ) : (
                      <p className="text-xs text-gray-500">No measurements yet</p>
                    )}
                  </div>
                );
              })}

              {includeGutters && (
                <div className="border rounded-lg p-3 bg-green-50 border-green-200">
                  <p className="font-semibold text-sm mb-2 text-green-900">Gutters & Downspouts</p>
                  <div className="grid grid-cols-2 gap-2 text-xs text-green-800">
                    <div>Gutters: {gutterLF.toFixed(2)} LF</div>
                    <div>Downspouts: {downspoutCount} EA</div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>

          <div className="mt-4">
            <Label>Roof Pitch (optional)</Label>
            <Input
              value={pitch}
              onChange={(e) => setPitch(e.target.value)}
              placeholder="e.g., 5/12, 7/12, 10/12"
              className="w-32"
            />
          </div>

          <Button
            onClick={handleSaveMeasurements}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white mt-4"
            disabled={!roofPolygon}
          >
            <Save className="w-4 h-4 mr-2" />
            Use These Measurements for Estimate
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}