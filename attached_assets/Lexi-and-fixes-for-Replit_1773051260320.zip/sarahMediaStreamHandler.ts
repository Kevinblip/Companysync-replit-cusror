/**
 * Sarah Media Stream Handler - Ultra Fast Version
 * Resolves company from TwilioSettings when companyId not in URL.
 * 
 * Twilio webhook URL format:
 * .../sarahMediaStreamHandler?companyId=XXX&routingMode=sarah_answers&repName=John&cellPhone=+15551234567
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

function normalizePhone(phone: string) {
    if (!phone) return '';
    return phone.replace(/\D/g, '').slice(-10);
}

function escapeXml(unsafe: string) {
    if (!unsafe) return '';
    return String(unsafe).replace(/[<>&"']/g, (c) => {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '"': return '&quot;';
            case "'": return '&apos;';
            default: return c;
        }
    });
}

function getWsUrl() {
    const wsHost = Deno.env.get('SARAH_WS_HOST') || 'getcompanysync.com';
    return `wss://${wsHost}/ws/twilio`;
}

function getBaseUrl() {
    return (Deno.env.get('APP_URL') || 'https://getcompanysync.com').replace(/\/+$/, '');
}

function xmlResponse(twiml: string) {
    return new Response(twiml, { headers: { 'Content-Type': 'text/xml' } });
}

function buildStreamTwiml(params: Record<string, string>) {
    const wsUrl = getWsUrl();
    const paramXml = Object.entries(params)
        .map(([k, v]) => `            <Parameter name="${escapeXml(k)}" value="${escapeXml(v)}" />`)
        .join('\n');
    return `    <Connect>
        <Stream url="${escapeXml(wsUrl)}">
${paramXml}
        </Stream>
    </Connect>`;
}

Deno.serve(async (req) => {
    const startTime = Date.now();
    try {
        const url = new URL(req.url);
        const path = url.pathname;

        let bodyParams = new URLSearchParams();
        if (req.method === 'POST') {
            try {
                const bodyText = await req.text();
                bodyParams = new URLSearchParams(bodyText);
            } catch (_e) {}
        }

        const callerPhone = bodyParams.get('From') || bodyParams.get('Caller') || '';
        const calledNumber = bodyParams.get('To') || bodyParams.get('Called') || '';

        let companyId = url.searchParams.get('companyId');
        if (!companyId && calledNumber) {
            try {
                const base44 = createClientFromRequest(req);
                const all = await base44.asServiceRole.entities.TwilioSettings.list('-created_date', 100);
                const normalizedTo = normalizePhone(calledNumber);
                const match = all.find((s: { main_phone_number?: string; thoughtly_phone?: string }) =>
                    normalizePhone(s.main_phone_number) === normalizedTo || normalizePhone(s.thoughtly_phone) === normalizedTo
                );
                if (match?.company_id) {
                    companyId = match.company_id;
                    console.log(`[Sarah] Resolved company ${companyId} from called number ${calledNumber}`);
                }
            } catch (e) {
                console.warn('[Sarah] Company lookup failed:', (e as Error).message);
            }
        }
        if (!companyId) companyId = '695944e3c1fb00b7ab716c6f';
        const routingMode = url.searchParams.get('routingMode') || 'sarah_answers';
        const repName = url.searchParams.get('repName') || '';
        const repEmail = url.searchParams.get('repEmail') || '';
        const repPhone = url.searchParams.get('repPhone') || '';
        const cellPhone = url.searchParams.get('cellPhone') || '';

        console.log(`[Sarah] ${Date.now() - startTime}ms path=${path}, from=${callerPhone}, to=${calledNumber}, mode=${routingMode}`);

        // ─── FORWARD FALLBACK: cell didn't answer, route to Sarah ───
        if (path.includes('forward-fallback')) {
            const dialStatus = bodyParams.get('DialCallStatus') || '';
            console.log(`[Sarah] Forward fallback: status=${dialStatus}, rep=${repName}`);

            if (dialStatus === 'completed') {
                return xmlResponse(`<?xml version="1.0" encoding="UTF-8"?><Response><Hangup/></Response>`);
            }

            return xmlResponse(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">${escapeXml(repName ? repName + ' is unavailable right now.' : 'The person you are trying to reach is unavailable.')} Let me connect you with our assistant who can help.</Say>
${buildStreamTwiml({
    companyId, callerPhone: url.searchParams.get('callerPhone') || callerPhone,
    maxCallDuration: '1800', isForwardedCall: 'true',
    forwardedRepName: repName, forwardedRepEmail: repEmail,
    callRoutingMode: 'sarah_answers', staffCellPhone: ''
})}
</Response>`);
        }

        // ─── TRANSFER: connect caller to rep's cell ───
        if (path.includes('transfer')) {
            const transferPhone = url.searchParams.get('cellPhone') || cellPhone;
            const callerId = url.searchParams.get('callerId') || calledNumber;
            console.log(`[Sarah] Transfer to ${transferPhone} for ${repName}`);
            return xmlResponse(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">Please hold while I connect you with ${escapeXml(repName || 'a team member')}.</Say>
    <Dial callerId="${escapeXml(callerId)}" timeout="30">
        <Number>${escapeXml(transferPhone)}</Number>
    </Dial>
    <Say voice="Polly.Joanna">I am sorry, the transfer was unsuccessful. Please try again later.</Say>
    <Hangup/>
</Response>`);
        }

        // ─── MAIN INBOUND CALL ───

        // ROUTE: Forward to cell phone
        if (routingMode === 'forward_to_cell' && cellPhone) {
            const baseUrl = getBaseUrl();
            const fallbackUrl = `${baseUrl}/api/functions/sarahMediaStreamHandler/forward-fallback?companyId=${encodeURIComponent(companyId)}&callerPhone=${encodeURIComponent(callerPhone)}&repName=${encodeURIComponent(repName)}&repEmail=${encodeURIComponent(repEmail)}`;

            console.log(`[Sarah] ${Date.now() - startTime}ms FORWARD TO CELL: ${cellPhone}`);
            return xmlResponse(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Dial callerId="${escapeXml(calledNumber)}" timeout="30" action="${escapeXml(fallbackUrl)}">
        <Number>${escapeXml(cellPhone)}</Number>
    </Dial>
</Response>`);
        }

        // ROUTE: Sarah answers (default) or Sarah then transfer
        console.log(`[Sarah] ${Date.now() - startTime}ms Routing to Sarah AI`);
        return xmlResponse(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
${buildStreamTwiml({
    companyId, callerPhone, maxCallDuration: '1800',
    isForwardedCall: 'false',
    forwardedRepName: repName, forwardedRepEmail: repEmail,
    forwardedRepPhone: repPhone,
    callRoutingMode: routingMode, staffCellPhone: cellPhone
})}
</Response>`);

    } catch (error: any) {
        console.error(`[Sarah] ${Date.now() - startTime}ms FATAL:`, error?.message || error);
        return xmlResponse(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">I am sorry, we are experiencing technical difficulties. Please try again later.</Say>
    <Hangup/>
</Response>`);
    }
});
