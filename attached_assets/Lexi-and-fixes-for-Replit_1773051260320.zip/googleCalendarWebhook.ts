import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        console.log('🔔 Google Calendar Webhook triggered');
        console.log('Request method:', req.method);
        console.log('Request headers:', Object.fromEntries(req.headers.entries()));
        
        // Google sends metadata in headers (no body)
        const channelId = req.headers.get('x-goog-channel-id');
        const resourceState = req.headers.get('x-goog-resource-state');
        const resourceId = req.headers.get('x-goog-resource-id');
        const channelToken = req.headers.get('x-goog-channel-token');
        
        console.log('Channel ID:', channelId);
        console.log('Resource State:', resourceState);
        
        // Ignore "sync" state (initial verification)
        if (resourceState === 'sync') {
            console.log('✅ Webhook verification successful');
            return new Response('OK', { status: 200 });
        }
        
        // Handle OPTIONS for CORS
        if (req.method === 'OPTIONS') {
            return new Response('OK', {
                status: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                    'Access-Control-Allow-Headers': '*'
                }
            });
        }
        
        const base44 = createClientFromRequest(req);

        // Prefer token (more reliable than parsing channel id)
        let userEmail: string | null = null;
        let userId: string | null = null;

        if (channelToken) {
            // We store either user.id or user.email as the token.
            if (channelToken.includes('@')) userEmail = channelToken;
            else userId = channelToken;
        }

        // Backward compat: parse email from legacy channel IDs like calendar_email_timestamp
        if (!userEmail && channelId?.startsWith('calendar_') && channelId.includes('@')) {
            userEmail = channelId.split('_')[1] || null;
        }
        
        if (!userEmail && !userId) {
            console.error('❌ No user identifier (token/channel)');
            return new Response('Invalid channel', { status: 400 });
        }
        
        console.log('🔄 Triggering instant sync for:', userEmail || userId);

        // Look up user and validate this webhook matches their active watch
        const users = userId
            ? await base44.asServiceRole.entities.User.filter({ id: userId })
            : await base44.asServiceRole.entities.User.filter({ email: userEmail });
        const user = users?.[0];
        
        if (!user || !user.google_calendar_connected) {
            console.error('❌ User not found or not connected:', userEmail || userId);
            return new Response('User not connected', { status: 404 });
        }

        if (channelId && user.google_watch_channel_id && channelId !== user.google_watch_channel_id) {
            console.warn('⚠️ Channel ID mismatch for user; ignoring webhook');
            return new Response('Ignored', { status: 200 });
        }
        if (resourceId && user.google_watch_resource_id && resourceId !== user.google_watch_resource_id) {
            console.warn('⚠️ Resource ID mismatch for user; ignoring webhook');
            return new Response('Ignored', { status: 200 });
        }
        
        // Trigger sync in background (don't wait for it)
        base44.asServiceRole.functions.invoke('syncUserGoogleCalendar', {
            targetUserEmail: user.email
        }).then(() => {
            console.log('✅ Background sync completed for', user.email);
        }).catch(err => {
            console.error('⚠️ Background sync error:', err.message);
        });
        
        return new Response('OK', { status: 200 });
        
    } catch (error) {
        console.error('❌ Webhook error:', error);
        return new Response('Error: ' + error.message, { status: 500 });
    }
});