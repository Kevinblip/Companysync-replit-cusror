import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await req.json().catch(() => ({}));
        let company_id = body.company_id;
        if (!company_id) {
            const staff = await base44.asServiceRole.entities.StaffProfile.filter({ user_email: user.email });
            if (staff?.[0]?.company_id) company_id = staff[0].company_id;
            if (!company_id) {
                const companies = await base44.asServiceRole.entities.Company.filter({ created_by: user.email });
                company_id = companies?.[0]?.id;
            }
        }
        if (!company_id) {
            return Response.json({ success: false, error: 'Company not found. Ensure you belong to a company.' }, { status: 400 });
        }

        // Check integration
        const settings = await base44.asServiceRole.entities.IntegrationSetting.filter({ 
            company_id: company_id,
            integration_name: 'gohighlevel'
        });
        
        if (settings.length === 0 || !settings[0].is_enabled) {
            return Response.json({ error: 'GHL not enabled' }, { status: 400 });
        }

        const apiKey = settings[0].config?.api_key || Deno.env.get('GHL_API_KEY');
        const locationId = body.locationId || settings[0].config?.location_id;
        if (!apiKey) return Response.json({ success: false, error: 'GHL API Key not configured. Set GHL_API_KEY in environment.' }, { status: 400 });

        // Fetch 1 contact (locationId required for Agency keys)
        let ghlUrl = 'https://rest.gohighlevel.com/v1/contacts/?limit=1';
        if (locationId) ghlUrl += `&locationId=${locationId}`;
        const response = await fetch(ghlUrl, {
            headers: { 
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json',
                'Version': '2021-07-28'
            }
        });

        if (!response.ok) {
            const text = await response.text();
            return Response.json({ success: false, error: `API Error: ${response.status}`, details: text });
        }

        const data = await response.json();
        const contact = data.contacts?.[0];

        if (!contact) {
            return Response.json({ success: true, message: 'Connection successful, but no contacts found.' });
        }

        return Response.json({ 
            success: true, 
            message: 'Connection successful!', 
            sample: { name: contact.contactName || contact.firstName, email: contact.email } 
        });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});