import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ success: false, error: 'Unauthorized' }, { status: 401 });
        }

        // Derive company from user
        let companyId = null;
        const staff = await base44.asServiceRole.entities.StaffProfile.filter({ user_email: user.email });
        if (staff?.[0]?.company_id) companyId = staff[0].company_id;
        if (!companyId) {
            const companies = await base44.asServiceRole.entities.Company.filter({ created_by: user.email });
            companyId = companies?.[0]?.id;
        }

        const settings = companyId
            ? await base44.asServiceRole.entities.IntegrationSetting.filter({
                company_id: companyId,
                integration_name: 'gohighlevel'
            })
            : [];
        const config = settings[0]?.config || {};
        const apiKey = config.api_key || Deno.env.get('GHL_API_KEY');
        const locationId = config.location_id;

        const baseUrl = Deno.env.get('APP_URL') || Deno.env.get('VERCEL_URL') || 'getcompanysync.com';
        const host = baseUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
        const webhookUrl = `https://${host}/api/functions/ghlWebhook`;

        const tests = {
            apiConnection: { status: 'not_tested', contacts: 0, error: null },
            webhookUrl: { url: webhookUrl, status: 'configured' },
            locationId: { status: locationId ? 'configured' : 'optional', value: locationId || 'Not set (Agency key may require it)' }
        };

        if (!apiKey) {
            return Response.json({
                success: false,
                error: 'GHL_API_KEY not configured. Add it in environment variables or Integration Settings.',
                tests
            });
        }

        // Actually test GHL API connection
        let ghlUrl = 'https://rest.gohighlevel.com/v1/contacts/?limit=1';
        if (locationId) ghlUrl += `&locationId=${locationId}`;
        const ghlResponse = await fetch(ghlUrl, {
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json',
                'Version': '2021-07-28'
            }
        });

        if (!ghlResponse.ok) {
            const errText = await ghlResponse.text();
            tests.apiConnection = { status: 'failed', contacts: 0, error: `API Error ${ghlResponse.status}: ${errText.substring(0, 200)}` };
            return Response.json({
                success: false,
                error: `GHL API connection failed: ${ghlResponse.status}. ${errText.includes('locationId') ? 'Try adding your Location ID in settings.' : errText.substring(0, 150)}`,
                tests,
                nextSteps: [
                    'Verify GHL_API_KEY is correct (Location API Key or Agency API Key)',
                    locationId ? 'Location ID looks configured' : 'If using Agency key, add Location ID in GoHighLevel Settings',
                    'GHL Location ID: Settings → Business Profile → Location ID in GHL'
                ]
            });
        }

        const ghlData = await ghlResponse.json();
        const contacts = ghlData.contacts || [];
        tests.apiConnection = { status: 'connected', contacts: contacts.length };

        return Response.json({
            success: true,
            message: 'Connection test successful!',
            tests,
            nextSteps: [
                'Copy the webhook URL above and add it to your GHL workflow',
                'Set up a trigger (e.g. Contact Created) and add a Webhook action',
                'Paste the URL and set method to POST'
            ]
        });

    } catch (error) {
        return Response.json({ success: false, error: error.message }, { status: 500 });
    }
});