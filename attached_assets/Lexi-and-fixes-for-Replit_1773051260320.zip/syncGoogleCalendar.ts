import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// Backward-compat wrapper: some older UI/automation referenced syncGoogleCalendar.
// Delegate to the active implementation in syncUserGoogleCalendar.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const me = await base44.auth.me().catch(() => null);

    let body: any = {};
    try {
      const text = await req.text();
      if (text && text.trim()) body = JSON.parse(text);
    } catch {}

    const targetUserEmail = body?.targetUserEmail || me?.email;
    if (!targetUserEmail) {
      return Response.json({ error: 'No user specified' }, { status: 400 });
    }

    const result = await base44.asServiceRole.functions.invoke('syncUserGoogleCalendar', { targetUserEmail });
    return Response.json({ success: true, delegated: true, result: result?.data ?? result });
  } catch (error) {
    console.error('❌ syncGoogleCalendar wrapper error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});