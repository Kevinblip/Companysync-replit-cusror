import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

// Simple rate limit: 30 req/min per IP
const rateLimit = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = 30;
const WINDOW_MS = 60_000;

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimit.get(ip);
  if (!entry) {
    rateLimit.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return true;
  }
  if (now > entry.resetAt) {
    rateLimit.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return true;
  }
  entry.count++;
  return entry.count <= RATE_LIMIT;
}

Deno.serve(async (req) => {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || req.headers.get('x-real-ip') || 'unknown';
    if (!checkRateLimit(ip)) {
      return Response.json({ error: 'Too many requests' }, { status: 429 });
    }

    const base44 = createClientFromRequest(req, { skipAuth: true });
    const { id, status } = await req.json();

    if (!id || !status) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    if (!['accepted', 'declined'].includes(status)) {
        return Response.json({ error: 'Invalid status' }, { status: 400 });
    }

    // Update estimate
    const result = await base44.asServiceRole.entities.Estimate.update(id, { status });

    // Trigger workflow or notification here if needed
    // e.g. notify sales rep

    return Response.json({ success: true, data: result });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});